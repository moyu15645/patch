[_tb_system_call storage=system/_choise.ks]

*photo1

[playbgm  volume="100"  time="1000"  loop="true"  storage="taiki.mp3"  ]
*p1wait

[cm  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xfff6e8"  time="300"  text="请选择目标"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="300" height="200" top="500" left="420"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message2.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[clearfix]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;sara
[button target=*huku01 enterimg=button/photosaraonM.png clickimg=button/photosara.png x=120 y=260 graphic=button/photosara.png]
[wait time=300]
;pill
[button target=*hazimepill1 enterimg=button/photopillonM.png clickimg=button/photopill.png x=470 y=130 graphic=button/photopill.png]
[wait time=300]
;fullmoon
[button target=*huzai01 enterimg=button/photofullmoononM.png clickimg=button/photofullmoon.png x=860 y=280 graphic=button/photofullmoon.png]
[_tb_end_tyrano_code]

[s  ]
*hazimepill1

[cm  ]
[tb_eval  exp="f.hazimepill+=5"  name="hazimepill"  cmd="+="  op="t"  val="5"  val_2="undefined"  ]
[jump  storage="choise.ks"  target="*huku01"  ]
*huzai01

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_ptext_hide  time="100"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
今日は　参加していない　[r]ようだ　……[p]
[_tb_end_text]

[tb_hide_message_window  ]
[jump  storage="choise.ks"  target="*p1wait"  ]
*huku01

[cm  ]
[tb_ptext_hide  time="300"  ]
[cm  ]
[tb_image_hide  time="100"  ]
[bg  time="100"  method="crossfade"  storage="antenbase.png"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xfff6e8"  time="300"  text="请选择最合适的着装要求"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;令嬢
[button target=*tuukaSA enterimg=button/hukuAonM.png clickimg=button/hukuA.png x=200 y=130 graphic=button/hukuA.png]
[wait time=300]
;おうじ
[button target=*tuukaSB enterimg=button/hukuBonM.png clickimg=button/hukuB.png x=500 y=130 graphic=button/hukuB.png]
;キザ
[button target=*tuukaSC enterimg=button/hukuConM.png clickimg=button/hukuC.png x=800 y=130 graphic=button/hukuC.png]
[_tb_end_tyrano_code]

[s  ]
*tuukaSA

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="choise.ks"  target="*pilltuuka1"  cond="f.hazimepill>6"  ]
[jump  storage="scene1.ks"  target="*sarano2"  cond=""  ]
*tuukaSB

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="choise.ks"  target="*pilltuuka2"  cond="f.hazimepill>6"  ]
[jump  storage="scene1.ks"  target="*sara00"  cond=""  ]
*tuukaSC

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="choise.ks"  target="*pilltuuka3"  cond="f.hazimepill>6"  ]
[jump  storage="scene1.ks"  target="*sarano3"  cond=""  ]
*pilltuuka1

[tb_ptext_hide  time="300"  ]
[cm  ]
[tb_eval  exp="f.hazimepill=10"  name="hazimepill"  cmd="="  op="t"  val="10"  val_2="undefined"  ]
[jump  storage="scene1.ks"  target="*sarano4"  cond=""  ]
*pilltuuka2

[cm  ]
[tb_eval  exp="f.hazimepill=20"  name="hazimepill"  cmd="="  op="t"  val="20"  val_2="undefined"  ]
[jump  storage="scene1.ks"  target="*sarano4"  cond=""  ]
*pilltuuka3

[cm  ]
[tb_eval  exp="f.hazimepill=25"  name="hazimepill"  cmd="="  op="t"  val="25"  val_2="undefined"  ]
[jump  storage="scene1.ks"  target="*sarano4"  cond=""  ]
*photo2

[cm  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="taiki.mp3"  ]
[tb_hide_message_window  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xfff6e8"  time="300"  text="请选择目标"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="300" height="200" top="500" left="420"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message2.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[clearfix]
[_tb_end_tyrano_code]

[tb_image_show  time="0"  storage="default/diesara.png"  width="259"  height="367"  x="120"  y="260"  name="img_66"  ]
[tb_start_tyrano_code]
[wait time=300]
;pill
[button target=*huku02 enterimg=button/photopillonM.png clickimg=button/photopill.png x=470 y=130 graphic=button/photopill.png]
[wait time=300]
;fullmoon
[button target=*huzai02 enterimg=button/photofullmoononM.png clickimg=button/photofullmoon.png x=860 y=280 graphic=button/photofullmoon.png]
[_tb_end_tyrano_code]

[s  ]
*huzai02

[cm  ]
[tb_image_hide  time="0"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_ptext_hide  time="100"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
今日は　参加していない　[r]ようだ　……[p]
[_tb_end_text]

[tb_hide_message_window  ]
[jump  storage="choise.ks"  target="*photo2"  ]
*huku02

[cm  ]
[tb_ptext_hide  time="300"  ]
[cm  ]
[tb_image_hide  time="100"  ]
[bg  time="100"  method="crossfade"  storage="antenbase.png"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xfff6e8"  time="300"  text="请选择最合适的着装要求"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;令嬢
[button target=*tuukaPA enterimg=button/hukuAonM.png clickimg=button/hukuA.png x=200 y=130 graphic=button/hukuA.png]
[wait time=300]
;おうじ
[button target=*tuukaPB enterimg=button/hukuBonM.png clickimg=button/hukuB.png x=500 y=130 graphic=button/hukuB.png]
;キザ
[button target=*tuukaPC enterimg=button/hukuConM.png clickimg=button/hukuC.png x=800 y=130 graphic=button/hukuC.png]
[_tb_end_tyrano_code]

[s  ]
*tuukaPA

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="scene2.ks"  target="*pill00"  cond=""  ]
*tuukaPB

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="scene2.ks"  target="*pillno02"  cond=""  ]
*tuukaPC

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="scene2.ks"  target="*pillno03"  cond=""  ]
*photo3

[cm  ]
[tb_image_hide  time="100"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="taiki.mp3"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xfff6e8"  time="300"  text="剩下的只有那家伙了"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="300" height="200" top="500" left="420"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message2.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[clearfix]
[_tb_end_tyrano_code]

[tb_image_show  time="0"  storage="default/diesara.png"  width="259"  height="367"  x="120"  y="260"  ]
[wait  time="300"  ]
[tb_image_show  time="0"  storage="default/diepill.png"  width="295"  height="383"  x="470"  y="130"  ]
[tb_start_tyrano_code]
[wait time=300]
;fullmoon
[button target=*huku03 enterimg=button/photofullmoononM.png clickimg=button/photofullmoon.png x=860 y=280 graphic=button/photofullmoon.png]
[_tb_end_tyrano_code]

[s  ]
*huku03

[cm  ]
[tb_ptext_hide  time="300"  ]
[cm  ]
[tb_image_hide  time="100"  ]
[bg  time="100"  method="crossfade"  storage="antenbase.png"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xfff6e8"  time="300"  text="请选择最合适的着装要求"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;令嬢
[button target=*tuukaFA enterimg=button/hukuAonM.png clickimg=button/hukuA.png x=200 y=130 graphic=button/hukuA.png]
[wait time=300]
;おうじ
[button target=*tuukaFB enterimg=button/hukuBonM.png clickimg=button/hukuB.png x=500 y=130 graphic=button/hukuB.png]
;キザ
[button target=*tuukaFC enterimg=button/hukuConM.png clickimg=button/hukuC.png x=800 y=130 graphic=button/hukuC.png]
[_tb_end_tyrano_code]

[s  ]
*tuukaFA

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="scene3.ks"  target="*fullmoonno03"  cond=""  ]
*tuukaFB

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="scene3.ks"  target="*fullmoonno02"  cond=""  ]
*tuukaFC

[tb_ptext_hide  time="300"  ]
[cm  ]
[jump  storage="scene3.ks"  target="*fullmoon01"  cond=""  ]
