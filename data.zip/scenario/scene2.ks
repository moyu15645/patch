[_tb_system_call storage=system/_scene2.ks]

*pill00

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="70"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiB01.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[wait  time="1000"  ]
[tb_start_tyrano_code]
[add_theme_button]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyuibase{number}.mp3" number=1]
[voconfig sebuf=2 name="pill" vostorage="vopill/pillst{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_15"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
哎呀！你……[r]看起来不像是兔人呢[p]
#pill
不过真是美得惊人……[l][r]

[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
但真遗憾啊！我只想和[r]高智商的女性聊天呢[p]
[_tb_end_text]

[tb_ptext_hide  time="300"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
对吧[r]不知道你能不能理解我说的话？
[_tb_end_text]

[tb_image_show  time="0"  storage="default/huntpill.gif"  width="1100"  height="600"  name="img_23"  ]
[wait  time="4000"  ]
[tb_image_hide  time="100"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#pill
嘛反正我也没抱期待啦！[p]
#pill
毕竟我可是哈～佛～大～学毕业的嘛[r]
[_tb_end_text]

[wait  time="1000"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
论智商可比[r]普通地球人高出一大截！
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '皮尔·托金王子'
[endscript]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill2ok enterimg=button/bun02aonM.png clickimg=button/bun02a.png x=700 y=200 graphic=button/bun02a.png]
;ng
[button target=*pill1ng enterimg=button/bun02bonM.png clickimg=button/bun02b.png x=700 y=270 graphic=button/bun02b.png]
[_tb_end_tyrano_code]

[s  ]
*pill2ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="100"  _clickable_img=""  name="img_42"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok1.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill10.png"  ]
[tb_start_text mode=4 ]
#pill
这反应很上道嘛！[r]那就让我来教教你[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
兔人现在在这个星球上只剩下157只了[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok2.mp3"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill02.png"  ]
[tb_start_text mode=4 ]
#pill
嗯？你是想问「剩下的347只去哪儿了」吗？[p]
#pill
在月球与地球相撞前，它们都在和巨犬族的战斗中被吃掉了哦[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
所以这场派对就是为了祈求日渐稀少的[r]兔人族繁荣昌盛的神圣派对！[r]这可是非常珍贵的机会
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '皮尔·托金王子'
[endscript]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill3ok enterimg=button/bun02conM.png clickimg=button/bun02c.png x=700 y=200 graphic=button/bun02c.png]
;ng
[button target=*pill1ng enterimg=button/bun02donM.png clickimg=button/bun02d.png x=700 y=270 graphic=button/bun02d.png]
[_tb_end_tyrano_code]

[s  ]
*pill3ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="150"  _clickable_img=""  name="img_64"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok3.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill08.png"  ]
[tb_start_text mode=4 ]
#pill
哼哼～要说兔人的历史我可特别在行！[r]其他事情也全都了如指掌！[r]有任何问题尽管来问我吧[p]
#pill
毕竟我可是那位满月之王的[r]左臂之女的孙子的青梅竹马的孙子的曾曾孙的曾曾曾孙[r]啊！
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill4ok enterimg=button/bun02eonM.png clickimg=button/bun02e.png x=700 y=200 graphic=button/bun02e.png]
;ng
[button target=*pill1ng enterimg=button/bun02fonM.png clickimg=button/bun02f.png x=700 y=270 graphic=button/bun02f.png]
[_tb_end_tyrano_code]

[s  ]
*pill4ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="200"  _clickable_img=""  name="img_77"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok4.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill09.png"  ]
[tb_start_text mode=4 ]
#pill
对吧对吧！[r]所以今晚派对的筹备工作[r]也让我「略尽绵力」了呢[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
今天招待用的葡萄酒[r]也是我爹地妈咪亲自挑选的！
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill5ok enterimg=button/bun02gonM.png clickimg=button/bun02g.png x=700 y=200 graphic=button/bun02g.png]
;ng
[button target=*pill1ng enterimg=button/bun02honM.png clickimg=button/bun02h.png x=700 y=270 graphic=button/bun02h.png]
[_tb_end_tyrano_code]

[s  ]
*pill5ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="250"  _clickable_img=""  name="img_92"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok5.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill04.png"  ]
[tb_start_text mode=4 ]
#pill
呵呵！没错吧！[r]你也该尝尝看！[p]
#pill
这可是重现了远古战争中[r]榨取巨犬血液滋味的特酿哦[p]
#pill
至今兔人族全体都[r]赞不绝口呢！[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok6.mp3"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
满分星数是…[r]呃…有多少颗来着？
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ng
[button target=*i01 enterimg=button/bun02i1onM.png clickimg=button/bun02i1.png x=700 y=10 graphic=button/bun02i1.png]
;ng
[button target=*i03 enterimg=button/bun02i3onM.png clickimg=button/bun02i3.png x=700 y=80 graphic=button/bun02i3.png]
;ng
[button target=*i05 enterimg=button/bun02i5onM.png clickimg=button/bun02i5.png x=700 y=150 graphic=button/bun02i5.png]
;ng
[button target=*i108 enterimg=button/bun02i108onM.png clickimg=button/bun02i108.png x=700 y=220 graphic=button/bun02i108.png]
;ok
[button target=*pill6ok enterimg=button/bun02i157onM.png clickimg=button/bun02i157.png x=700 y=290 graphic=button/bun02i157.png]
;ng
[button target=*ing enterimg=button/bun02i343onM.png clickimg=button/bun02i343.png x=700 y=360 graphic=button/bun02i343.png]
;ng
[button target=*ing enterimg=button/bun02i504onM.png clickimg=button/bun02i504.png x=700 y=430 graphic=button/bun02i504.png]
;ng
[button target=*ing enterimg=button/bun02i666onM.png clickimg=button/bun02i666.png x=700 y=500 graphic=button/bun02i666.png]
;ng
[button target=*ing enterimg=button/bun02i741onM.png clickimg=button/bun02i741.png x=700 y=570 graphic=button/bun02i741.png]
;ng
[button target=*i80oku enterimg=button/bun02i80okuonM.png clickimg=button/bun02i80oku.png x=700 y=640 graphic=button/bun02i80oku.png]
[_tb_end_tyrano_code]

[s  ]
*pill6ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="300"  _clickable_img=""  name="img_110"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok7.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill09.png"  ]
[tb_start_text mode=4 ]
#pill
对对！因为现存兔人族全员都给了好评[r]所以是157颗！你记得真清楚！[p]
[_tb_end_text]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_116"  ]
[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pillok{number}.mp3" number=10]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill11.png"  ]
[tb_start_text mode=4 ]
#pill
呜呜…[r]你是第一个听我讲到这里的人[p]
#pill
大家总是在故事中途就溜走了…[r]
你比我想象中[r]更聪慧呢！
[_tb_end_text]

[wait  time="3000"  ]
[tb_start_tyrano_code]
;ok
[button target=*pillkudoku enterimg=button/kudokuonM.png clickimg=button/kudoku.png x=700 y=200 graphic=button/kudoku.png]
[_tb_end_tyrano_code]

[s  ]
*pillkudoku

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[vostop]
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=15]
[voconfig sebuf=2 name="pill" vostorage="vopill/pillok{number}.mp3" number=12]
[vostart]

#
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB03.png"  ]
[tb_start_text mode=1 ]
#yui
如果不嫌弃我的话 我想多听听你的故事呢[p]
[_tb_end_text]

[tb_image_hide  time="100"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill05.png"  ]
[tb_start_text mode=4 ]
#pill
呜哇！你就是我的命中注定之人！[l][r]
#pill
或许我真正渴望的 不是聪慧[r]而是温柔也说不定！
[_tb_end_text]

[wait  time="3000"  ]
[tb_image_show  time="0"  storage="default/reijoyui.gif"  width="1100"  height="600"  name="img_133"  ]
[wait  time="3800"  ]
[tb_image_hide  time="100"  ]
[cm  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[stopbgm  time="5000"  fadeout="true"  ]
[wait  time="6000"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
;[add_theme_button]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save6.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load6.png" x="160" y="690"]
; オートボタン
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto6.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip6.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog6.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config6.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
;名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="18" x="350" y="400" width="340"]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voion3.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_143"  ]
[bg  time="1000"  method="crossfade"  storage="still06.png"  ]
[playbgm  volume="100"  time="3000"  loop="true"  storage="yozoraoff.mp3"  fadein="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_tyrano_code]
;ボイス設定
[vostop]
[voconfig sebuf=2 name="pill" vostorage="vopill/pilled{number}.mp3" number=17]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#pill
[font size=15]哎呀，已经这个时间啦？[r]和你聊天真是时光飞逝啊[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="still07.png"  ]
[tb_start_text mode=4 ]
#pill
但是 我还有好多话想说呢！[r]接下来 嗯……[p]
#pill
对了 来讲个月亮的古老传说吧！[l][r]
#pill
那个故事通常都结束在兔子们[r]平分巨犬肉的地方…[p]
#pill
其实 你知道这个故事还有后续吗？[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="300"  method="crossfade"  storage="still23.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=4 ]
#pill
满月之王虽然把巨犬肉[r]公平分给了大家[p]但实际上兔子的数量和肉块数量对不上呢
#pill
之后　在部分兔子之间流传着[r]「说不定还有巨犬的幸存者」[r]这样的传闻呢[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="300"  method="crossfade"  storage="still08.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=4 ]
#pill
呵呵　我是不是说了个有点恐怖的故事呀？[p]
#pill
嘛　不用担心啦！[r]这肯定是和平·悉索生活的平民百姓[r]随便编出来的胡说八道！[p]
#pill
就算有个贪吃鬼　或者士兵数错数量[r]也没什么好奇怪的吧？[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#pill
就算万一真的还活着　我们也有好多地球人[r]当盟友呢！[l][r]
#pill
区区一只狗崽子　有什么好怕的……[resetfont]
[_tb_end_text]

[wait  time="4000"  ]
[tb_start_tyrano_code]
[vostop]
#
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[bg  time="0"  method="crossfade"  storage="still09.png"  ]
[wait  time="2000"  ]
[bg  time="0"  method="crossfade"  storage="antenbase.png"  ]
[mask  time="0"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="500"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[mask_off  time="2000"  effect="fadeOut"  ]
[playbgm  volume="100"  time="2000"  loop="true"  fadein="true"  storage="redinner.mp3"  ]
[wait  time="2000"  ]
[cm  ]
[bg  time="1000"  method="crossfade"  storage="gohan02.png"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xc20000"  time="300"  text="食&nbsp;い&nbsp;つ&nbsp;く&nbsp;せ"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
[s  ]
*g02main

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g02mainOK.png"  width="330"  height="155"  x="385"  y="205"  name="img_181"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
[_tb_end_tyrano_code]

[s  ]
*g02sarada

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g02saradaOK.png"  width="196"  height="106"  x="626"  y="152"  name="img_190"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[s  ]
*g01ice

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[tb_image_show  time="600"  storage="default/g02syabetOK.png"  width="137"  height="77"  x="410"  y="150"  name="img_199"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[s  ]
*g02wine

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g02wineOK.png"  width="84"  height="163"  x="812"  y="90"  name="img_208"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="nomu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[s  ]
*allate02

[mask  time="0"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_image_hide  time="1000"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[tb_ptext_hide  time="100"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]

;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save2.png" x="77" y="520"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load2.png" x="80" y="541"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto2.png" x="93" y="620"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip2.png" x="92" y="596"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog2.png" x="76" y="641"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config2.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="75" y="568"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="560"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
; 名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="23" x="268" y="532" width="480" align="left"]
[chara_config ptext="chara_name_area"]

[hidemenubutton]
[clearfix]

[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
*homew2

[cm  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  fadein="true"  ]
[bg  time="600"  method="crossfade"  storage="base012.png"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiD01.png"  width="720"  height="720"  left="700"  top="020"  ]
[tb_start_tyrano_code]
;ママパパ
[button target=*mamapapa2 enterimg=button/mmpponM.png clickimg=button/mmpp.png x=700 y=200 graphic=button/mmpp.png]
;サザンカとはなす
[button target=*talk2 enterimg=button/sazankaonM.png clickimg=button/sazanka.png x=700 y=270 graphic=button/sazanka.png]
;ねる
[button target=*ruteok enterimg=button/neruonM.png clickimg=button/neru.png x=700 y=340 graphic=button/neru.png]
[_tb_end_tyrano_code]

[s  ]
*mamapapa2

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[bg  time="1000"  method="crossfade"  storage="base013.png"  ]
[tb_image_show  time="1000"  storage="default/hana.png"  width="199"  height="250"  x="341"  y="191"  _clickable_img=""  name="img_231"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
是爸爸和妈妈[p]
给了他们水和果酱[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD04.png"  ]
[tb_start_text mode=1 ]
爸爸……[p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_start_tyrano_code]
[hidemenubutton]
[clearfix]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[stopbgm  time="3000"  fadeout="true"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_image_hide  time="1000"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="2000"  ]
[playbgm  volume="100"  time="300"  loop="true"  storage="utyu.mp3"  fadein="true"  ]
[tb_show_message_window  ]
[bg  time="2000"  method="crossfade"  storage="still10.png"  ]
[tb_start_text mode=1 ]
[font size=15]尤伊，我听妈妈说了，[r]你一个人去散步了？[p]
听好了[r]你还是个孩子[r]不准一个人去环形山外面[p]
被太阳光烧到可就糟了[r]至少要和王子两个人一起的话……[p]
可那家伙笨手笨脚的！[r]只会死读书 连捉迷藏都玩不好[p]
两个人的话 回到家都要明天啦[p]
……嗯[r]看来得好好训练王子才行[p]
总之就是不行[r]妈妈和爸爸都很担心[p]
明白吗？不要一个人去危险的地方[r]这是和爸爸的约定[resetfont][p]
[_tb_end_text]

[mask  time="2000"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
[clearfix]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="3000"  fadeout="true"  ]
[bg  time="3000"  method="crossfade"  storage="base013.png"  ]
[mask_off  time="2000"  effect="fadeOut"  ]
[chara_show  name="yui"  time="1000"  wait="true"  storage="chara/1/yuiD01.png"  width="720"  height="720"  left="700"  top="20"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  ]
[tb_hide_message_window  ]
[jump  storage="scene2.ks"  target="*homew2"  ]
*talk2

[cm  ]
[chara_show  name="sazanka"  time="1000"  wait="true"  storage="chara/4/sazanka01.png"  width="720"  height="720"  left="200"  ]
[tb_start_tyrano_code]
;ふろ
[button target=*huro2 enterimg=button/ohuroonM.png clickimg=button/ohuro.png x=700 y=200 graphic=button/ohuro.png]
;おやすみ
[button target=*oyasumi2 enterimg=button/oyasumionM.png clickimg=button/oyasumi.png x=700 y=270 graphic=button/oyasumi.png]
[vostop]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[s  ]
*huro2

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
山茶花 我先去泡澡啦[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="1"  storage="vosazanka/sazanka5.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
啊 啊啊……已经进去了啊[p]
#yui
不是你说让我先洗的吗[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka10.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka6.mp3"  ]
[tb_start_text mode=4 ]
#sazanka
话是这么说！……不 但是[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka09.png"  ]
[tb_start_text mode=4 ]
#sazanka
因为今天的尤伊 特别漂亮……[l][r]就想着 还想多看会儿啦[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui16.mp3"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD02.png"  ]
[tb_start_text mode=4 ]
#yui
呵呵 是吗？[r]一直想试试看穿那种衣服呢[p]
#yui
以前在熟人老爷爷家里 经常看到这种款式[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka7.mp3"  ]
[tb_start_text mode=4 ]
#sazanka
诶 原来是裁缝师傅吗？[p]
#yui
唔……记不太清了[r]不过那确实是条漂亮的裙子呢[p]
#yui
所以今天很开心……[r]谢谢你[p]

[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka03.png"  ]
[tb_start_text mode=4 ]
#sazanka
……！你能开心就比什么都好！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD01.png"  ]
[tb_start_text mode=4 ]
#sazanka
话说今天的派对没问题吧？[l][r]没人找你搭讪吧？[p]
#yui
……突然说这个 好恶心[p]

[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka10.png"  ]
[tb_start_text mode=4 ]
#sazanka
没、没办法啊 我很担心嘛！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka11.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka8.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
听好了？不管什么种族[r]都不能跟可疑的男人走知道吗！[p]
#yui
（从喜欢狗的地球人那里拿到会员证的事[r]还是保密吧……）[p]
#
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka01.png"  ]
[tb_hide_message_window  ]
[jump  storage="scene2.ks"  target="*talk2"  ]
*oyasumi2

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_show_message_window  ]
[tb_start_text mode=4 ]
#yui
该睡了 晚安[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[tb_start_text mode=4 ]
#sazanka
啊…… 这就要睡了吗[l][r]
#sazanka
今天本来还想和尤伊多聊会儿的……[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka9.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka01.png"  ]
[tb_start_text mode=1 ]
#sazanka
不过熬夜确实不好呢 晚安[p]
#yui
…… 过来一下[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[tb_start_text mode=1 ]
#sazanka
？[p]
#
[_tb_end_text]

[tb_hide_message_window  ]
[wait  time="1000"  ]
[chara_move  name="sazanka"  anim="false"  time="300"  effect="linear"  wait="true"  left="430"  top="20"  ]
[wait  time="1000"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka04.png"  ]
[wait  time="2000"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD05.png"  ]
[wait  time="2000"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka05.png"  ]
[wait  time="2000"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka06.png"  ]
[wait  time="2000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#sazanka
…… …… ！？[p]
[_tb_end_text]

[tb_start_tyrano_code]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#sazanka
！ 呜 哇啊！[p]
#
[_tb_end_text]

[chara_mod  name="sazanka"  time="300"  cross="true"  storage="chara/4/sazanka07.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD01.png"  ]
[chara_move  name="sazanka"  anim="true"  time="600"  effect="easeInOutQuad"  wait="true"  left="-1000"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bakuha.mp3"  ]
[quake  time="300"  count="3"  hmax="10"  wait="true"  ]
[chara_hide  name="sazanka"  time="1000"  wait="true"  pos_mode="false"  ]
[chara_show  name="sazanka"  time="1000"  wait="true"  storage="chara/4/sazanka08.png"  width="720"  height="720"  left="200"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD03.png"  ]
[tb_start_text mode=1 ]
#sazanka
你、你干嘛突然亲我啊[p]
#yui
……我要睡了 你也赶紧去洗澡睡觉[p]
#sazanka
啊…！对、对了 我[r]还没洗澡呢！？[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD02.png"  ]
[tb_start_text mode=1 ]
#yui
晚安 山茶花[r]明天也拜托了[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka10.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
那当然 可是……呜呜……[r]这脸根本遮不住啊！怎么办啊！？[p]
#
[_tb_end_text]

[chara_hide  name="sazanka"  time="600"  wait="true"  pos_mode="false"  ]
[tb_hide_message_window  ]
[jump  storage="scene2.ks"  target="*homew2"  ]
*pillno02

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiA03.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[tb_start_tyrano_code]
[add_theme_button]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#pill
哼！干嘛干嘛？[r]你个非兔人的家伙找本大爷有事？[p]
#pill
啊啊 明明是难得的派对[r]为什么非得和男人聊天不可啊？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno29.mp3"  ]
[tb_start_text mode=4 ]
#pill
完全就是在浪费时间！[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
快点 快点 给我滚一边去！[l][r]
#pill
可爱的女孩子还在等着我呢[l][r]先走啦！[p]
#
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[jump  storage="scene2.ks"  target="*gameover"  ]
*pillno03

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiE04.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[tb_start_tyrano_code]
[add_theme_button]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
哼！干嘛干嘛？[r]你个非兔人的家伙找本大爷有事？[p]
#pill
啊啊 明明是难得的派对[r]为什么非得和男人聊天不可啊？[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno29.mp3"  ]
[tb_start_text mode=4 ]
#pill
完全就是在浪费时间！[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE03.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="voyui/yui19.mp3"  ]
[tb_start_text mode=4 ]
#yui
哦？你说和本大爷相遇是浪费时间？[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE05.png"  ]
[tb_start_text mode=1 ]
#yui
听说你是名校毕业[r]本来还想和你好好聊聊的……[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="voyui/yui20.mp3"  ]
[tb_start_text mode=1 ]
#yui
既然你这么想 那也没办法[r]恕我失陪了[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill06.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno30.mp3"  ]
[tb_start_text mode=1 ]
#pill
什、什么……？[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill04.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="0"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="100"  _clickable_img=""  name="img_381"  ]
[tb_image_show  time="0"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="150"  _clickable_img=""  name="img_382"  ]
[tb_image_show  time="0"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="200"  _clickable_img=""  name="img_383"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno31.mp3"  ]
[tb_start_text mode=4 ]
#pill
搞、搞什么啊！[r]既然这样你倒是早说啊！[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno32.mp3"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE10.png"  ]
[tb_start_text mode=4 ]
#pill
你其实很在意我吧！[l][r]
#pill
那本大爷就从婴儿时期的糗事到辉煌的学生时代统统讲给你听！[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE13.png"  ]
[tb_start_text mode=1 ]
#yui
（糟了好像不小心打开了什么开关……）[p]
（感觉会超级麻烦！[r]还是先撤为妙！）[p]
#
[_tb_end_text]

[tb_image_hide  time="100"  ]
[jump  storage="scene2.ks"  target="*gameover"  ]
*i01

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=1 ]
#pill
居、居然打一星？[r]你这女人太失礼了！[p]
像你这样没礼貌的女人我才不稀罕！[r]再见啦！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i03

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=1 ]
#pill
3分！？[r]你是在说我们托金家很寒酸吗！？[p]
像你这样没教养的女人[r]我们高攀不起！再见啦！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i05

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
那只是地球人的标准吧？[l][r]
#pill
我们兔人的价值观和标准和他们不一样[r]学校没教过你吗？[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
真是太让人失望了……[r]我对脑子不好的女人没兴趣！拜拜！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i108

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
虽然那确实是地球人的笨蛋数量标准……[l][r]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill06.png"  ]
[tb_start_text mode=4 ]
#pill
难、难道你觉得我也是笨蛋……！？[p]
#pill
太、太下流可不行啊女士！[l][r]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill05.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB04.png"  ]
[tb_start_text mode=4 ]
#pill
砰、我这就告辞啦！再见咯！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i80oku

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill02.png"  ]
[tb_start_text mode=4 ]
#pill
那只是前几天地球人的数量啦！[p]
#pill
地球人每秒会增加2～3个[r]所以现在应该更多了……[l][r]
现在不是说这个的时候……[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
唔～感觉有点扫兴呢……[l][r]
#pill
我以为你挺有品味的[r]可能是我看走眼了吧[p]

[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
我要去找寻其他命中注定的女孩啦！[r]拜拜！愿你也有个美妙的派对♪[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*ing

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[tb_start_text mode=1 ]
#pill
你根本没在认真听我说话吧？[p]
#pill
真是让人失望透顶……[r]我对脑子不好的女人没兴趣！再见！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*pill1ng

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=1 ]
#pill
哼、怎么啦！[r]像你这种脑子不好的女人我也拒绝往来哦！[p]
#
[_tb_end_text]

*gameover

[cm  ]
[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[bg  time="300"  method="crossfade"  storage="anten.png"  ]
[tb_ptext_show  x="373"  y="262"  size="75"  color="0xfff6e8"  time="1000"  text="GAME&nbsp;OVER..."  face="BestTen-DOT"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;retry
[button target=*retrygo enterimg=button/retryonM.png clickimg=button/retry.png x=370 y=550 graphic=button/retry.png]
;back
[button target=*backgo enterimg=button/titlebackonM.png clickimg=button/titleback.png x=680 y=550 graphic=button/titleback.png]
[_tb_end_tyrano_code]

[s  ]
*retrygo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="choise.ks"  target="*photo2"  ]
*backgo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="title_screen.ks"  target=""  ]
*ruteok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_eval  exp="f.pillsf='ok'"  name="pillsf"  cmd="="  op="t"  val="ok"  val_2="undefined"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[jump  storage="choise.ks"  target="*photo3"  ]
