[preload  storage="./data/bgimage/aten.png"  ]
[preload  storage="./data/bgimage/titlebase.png"  ]
[return]