[preload  storage="./data/bgimage/antenbase.png"  ]
[preload  storage="./data/fgimage/default/diesara.png"  ]
[preload  storage="./data/fgimage/default/diepill.png"  ]
[return]