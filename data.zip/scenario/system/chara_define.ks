;=========キャラクター事前定義情報 
;yui
[chara_new  name="yui"  jname="yui"  storage="chara/1/yuiA01.png"  ]
;sara
[chara_new  name="sara"  jname="sara"  storage="chara/2/sara01.png"  ]
;pill
[chara_new  name="pill"  jname="pill"  storage="chara/3/pill01.png"  ]
;sazanka
[chara_new  name="sazanka"  jname="sazanka"  storage="chara/4/omakes01.png"  ]
;fullmoon
[chara_new  name="fullmoon"  jname="fullmoon"  storage="chara/5/fullmoonbig01.png"  ]
;moba
[chara_new  name="moba"  jname="moba"  storage="chara/6/kyak.png"  ]
;master
[chara_new  name="master"  jname="master"  storage="chara/8/tensyo.png"  ]
;yagi
[chara_new  name="yagi"  jname="yagi"  storage="chara/9/kyak01.png"  ]
;tori
[chara_new  name="tori"  jname="tori"  storage="chara/10/kyak03.png"  ]
;kitune
[chara_new  name="kitune"  jname="kitune"  storage="chara/11/kyak02.png"  ]
;richiman
[chara_new  name="richiman"  jname="richiman"  storage="chara/12/richiman.png"  ]

;=========変数宣言部分 
[iscript] 
f['atesara']=5; 
f['atepill']=5; 
f['hazimepill']=5; 
f['omakebgm']=0; 
[endscript] 
