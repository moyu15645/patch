;プラグイン。テーマ読み込み



[plugin name="theme_kopanda_14" font_color="0xf8f4e6" name_color="0xf4dda5" opacity="255" ]


[mask time=10]
[add_theme_button]
[tb_hide_message_window]
[mask_off time=10]

[iscript]
TYRANO.kag.stat.charas['yui'].jname = 'ユイ'
TYRANO.kag.stat.charas['sara'].jname = 'サラ ・ミカズキーヌ令嬢'
TYRANO.kag.stat.charas['pill'].jname = 'ピール ・トーキン王子'
TYRANO.kag.stat.charas['sazanka'].jname = 'サザンカ'
TYRANO.kag.stat.charas['moba'].jname = '用心棒の男たち'
TYRANO.kag.stat.charas['fullmoon'].jname = 'レッドラビット ・フルムーン女王'
TYRANO.kag.stat.charas['yagi'].jname = '八木'
TYRANO.kag.stat.charas['tori'].jname = '鳥山'
TYRANO.kag.stat.charas['kitune'].jname = '狐崎'
TYRANO.kag.stat.charas['master'].jname = 'マスター'
[endscript]

[return]

				