[_tb_system_call storage=system/_scene1.ks]

*arasuji

[cm  ]
[tb_start_tyrano_code]
[clearfix]
[_tb_end_tyrano_code]

[wait  time="1000"  ]
[bg  time="2000"  method="crossfade"  storage="moon01.png"  ]
[wait  time="1500"  ]
[bg  time="100"  method="crossfade"  storage="moon02.png"  ]
[wait  time="1500"  ]
[bg  time="100"  method="crossfade"  storage="moon03.png"  ]
[wait  time="1500"  ]
[bg  time="100"  method="crossfade"  storage="moon04.png"  ]
[wait  time="1500"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bom.mp3"  ]
[bg  time="100"  method="crossfade"  storage="moon05.png"  ]
[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="300" height="200" top="200" left="120"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message2.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[wait  time="3000"  ]
[tb_show_message_window  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
[font size=15]月亮即将撞向地球的100年前[r]月球的居民兔子们　[r]为躲避种族灭亡的危机　[r]选择与地球人共存共生[r]就此存活下去[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
起初　兔人们　[r]为了混入地球人之中[r]企图改变　自己的样貌[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
但奈何　兔人们　[r]实在难以理解[r]地球人的耳朵形状[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
最终　他们放弃了[r]模仿人类的耳朵[r]但不知为何　这副模样[r]竟大受地球人欢迎[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
就这样　兔人们　[r]和地球人　和睦地[r]生活在了一起[p]
[_tb_end_text]

[wait  time="1000"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
[font color=0xff0000 font size=17 font bold=true]他们 早已忘却　[r]自己犯下的罪孽[resetfont][p]
[_tb_end_text]

[tb_start_tyrano_code]
[clearfix]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[wait  time="1000"  ]
*prr

[cm  ]
[bg  time="100"  method="crossfade"  storage="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
; 名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="23" x="268" y="532" width="480" align="left"]
[chara_config ptext="chara_name_area"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[_tb_end_tyrano_code]

[wait  time="2000"  ]
[bg  time="100"  method="crossfade"  storage="still16.png"  ]
[tb_image_show  time="100"  storage="default/voion3.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_40"  ]
[playbgm  volume="50"  time="2000"  loop="true"  storage="mudai.mp3"  fadein="true"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]

[iscript]
TYRANO.kag.stat.charas['richiman'].jname = '有钱的男人'
TYRANO.kag.stat.charas['yui'].jname = '？？？'
[endscript]
;ボイス設定
[voconfig sebuf=2 name="richiman" vostorage="vorich/richman{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[wait  time="1000"  ]
[tb_start_text mode=1 ]
#richiman
喏　这样行吗？[p]
#richiman
兔人族　祈求种族繁荣的他们[r]仅限部分富豪参加的秘密派对[r]而那张会员证……[p]
#richiman
搞到这东西　可费了老大劲[r]单张就要五百万哦？[p]
#yui
开心！真的太感谢了……[r]你真是个温柔的人呢！[r]我越来越喜欢你了！[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="still17.png"  ]
[tb_start_text mode=4 ]
#richiman
呵呵　我可是纯粹的犬派呢[r]温柔以待的对象　只有你哦？[p]
#richiman
话说回来　为什么你会想去兔人族的派对啊？[l][r]
#richiman
该不会是打算　去找除我以外的男人吧？[p]
#yui
怎么会！[r]是有个非见不可的孩子[p]
#yui
大概有　400年没见了吧[r]这次[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="antenbase.png"  ]
[tb_start_text mode=1 ]
#yui
终于能去见她了……[p]
#
[_tb_end_text]

[tb_image_hide  time="100"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_hide_message_window  ]
[wait  time="4000"  ]
[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[clearfix]
;	メッセージウィンドウの設定
[position layer="message0" width="300" height="200" top="200" left="120"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message2.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[jump  storage="choise.ks"  target="*photo1"  ]
*sara00

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[cm  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[tb_ptext_hide  time="1000"  ]
[wait  time="1000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[chara_show  name="sara"  time="0"  wait="true"  storage="chara/2/sara04.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiA01.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[wait  time="1000"  ]
[tb_start_tyrano_code]
[add_theme_button]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sarast{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_72"  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#sara
哎呀？……盯～～～[l][r]
#sara
讨厌！[p]
[_tb_end_text]

[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara01.png"  ]
[tb_start_text mode=4 ]
#sara
真是非常美妙的演奏呢[r]要不要来跳一支舞？
[_tb_end_text]

[tb_image_show  time="0"  storage="default/huntsara.gif"  width="1100"  height="600"  name="img_77"  x="100"  ]
[wait  time="3800"  ]
[tb_ptext_hide  time="300"  ]
[tb_image_hide  time="100"  ]
[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '莎拉·御厨音 小姐'
[endscript]
[_tb_end_tyrano_code]

[wait  time="500"  ]
[tb_start_tyrano_code]
;ok
[button target=*chose01ok enterimg=button/bun01aonM.png clickimg=button/bun01a.png x=700 y=200 graphic=button/bun01a.png]
;ng
[button target=*chose01ng enterimg=button/bun01bonM.png clickimg=button/bun01b.png x=700 y=270 graphic=button/bun01b.png]
#yui
[_tb_end_tyrano_code]

[s  ]
*chose01ok

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]

[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=5]
[vostart]

[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiA02.png"  ]
[tb_start_text mode=1 ]
#yui
哎呀呀　可爱的小兔子[r]不介意的话　莫说一曲　多少支舞我都奉陪[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiA01.png"  ]
[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara01.png"  ]
[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[voconfig sebuf=2 name="sara" vostorage="vosara/sara{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="vosara/sara20.mp3"  ]
[tb_start_text mode=1 ]
#sara
呵呵　跳得真棒呢！[p]
#sara
我啊　最喜欢跳舞了！[r]所以跳得特别好哦[r]能请你来领舞吗？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="125"  _clickable_img=""  name="img_97"  ]
[tb_start_text mode=4 ]
#sara
靠近看才发现　你真是帅气得不得了呢[p]
#sara
呐　你喜欢的类型是什么样的女孩呀？
[_tb_end_text]

[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '莎拉·御厨音 小姐'
[endscript]
[vostop]
[_tb_end_tyrano_code]

[wait  time="1000"  ]
[tb_start_text mode=4 ]
#yui
[_tb_end_text]

[tb_start_tyrano_code]
;ok
[button target=*chose02ok enterimg=button/bun01donM.png clickimg=button/bun01d.png x=700 y=200 graphic=button/bun01d.png]
;ng
[button target=*chose02ng enterimg=button/bun01conM.png clickimg=button/bun01c.png x=700 y=270 graphic=button/bun01c.png]
#yui
[_tb_end_tyrano_code]

[s  ]
*chose01ng

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara02.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiA03.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vosara/sara1.mp3"  ]
[tb_start_text mode=4 ]
#sara
你说什么！？[l][r]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sarano{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#sara
居然敢拒绝莎拉的邀请　太失礼了！[r]给我把他扔出去！[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_hide_all  time="1000"  wait="true"  ]
[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[jump  storage="scene1.ks"  target="*gameover"  ]
*chose02ok

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="1"  storage="voyui/yui6.mp3"  ]
[tb_start_text mode=1 ]
#yui
我最喜欢擅长跳舞的女孩子了[r]如果能忘记时间一起享受的话，那真是幸福呢[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="1"  storage="vosara/sara21.mp3"  ]
[tb_start_text mode=1 ]
#sara
哎呀！这么说的话[r]眼前正好有个[r]和你超配的女孩子哦！[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="170"  _clickable_img=""  name="img_128"  ]
[jump  storage="scene1.ks"  target="*chose03"  ]
*chose02ng

[cm  ]
[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sarano{number}.mp3" number=2]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#sara
哼、什么嘛[r]你是说莎拉团子般的脸蛋不可爱吗！？[p]
#sara
无礼之徒！[r]给我把他轰出去！[p]
#
[_tb_end_text]

[tb_image_hide  time="100"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_hide_all  time="1000"  wait="true"  ]
[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[jump  storage="scene1.ks"  target="*gameover"  ]
*chose03

[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=7]
[voconfig sebuf=2 name="sara" vostorage="vosara/saraok{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara03.png"  ]
[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_145"  ]
[tb_start_text mode=4 ]
#sara
心跳加速！以为你很冷酷[r]没想到你竟然这么热情！
[_tb_end_text]

[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '莎拉·御厨音 小姐'
[endscript]
[_tb_end_tyrano_code]

[wait  time="2000"  ]
[tb_start_tyrano_code]
;ok
[button target=*kudokusara enterimg=button/kudokuonM.png clickimg=button/kudoku.png x=700 y=200 graphic=button/kudoku.png]
[_tb_end_tyrano_code]

[s  ]
*kudokusara

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_hide  time="100"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiA04.png"  ]
[tb_start_text mode=1 ]
#yui
你真是充满魅力呢[r]今晚都不想放你回去了[p]
#yui
我可爱的小兔子[r]即使派对结束[r]还想继续和你跳舞呢[p]
[_tb_end_text]

[chara_move  name="sara"  anim="false"  time="0"  effect="linear"  wait="true"  width="720"  height="720"  left="100"  ]
[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara05.png"  ]
[tb_start_text mode=4 ]
#sara
莎拉公主的完美王子[r]若是你的邀请，我乐意之至！
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[wait  time="3000"  ]
[tb_image_show  time="100"  storage="default/yuiyui.gif"  width="1100"  height="600"  y="50"  name="img_163"  ]
[wait  time="3800"  ]
[tb_image_hide  time="100"  ]
[mask  time="3000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[stopbgm  time="5000"  fadeout="true"  ]
[wait  time="6000"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
;[add_theme_button]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save6.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load6.png" x="160" y="690"]
; オートボタン
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto6.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip6.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog6.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config6.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
;名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="18" x="350" y="400" width="340"]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voion3.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_172"  ]
[bg  time="1000"  method="crossfade"  storage="still01.png"  ]
[playbgm  volume="100"  time="3000"  loop="true"  storage="yozoraoff.mp3"  fadein="true"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=9]
[voconfig sebuf=2 name="sara" vostorage="vosara/saraed{number}.mp3" number=11]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#
[_tb_end_text]

[cm  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#sara
[font size=15]呵呵～能和这么帅气的人跳舞，简直像做梦一样![p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="still03.png"  ]
[tb_start_text mode=1 ]
#sara
呐、王子殿下 知道月亮的古老传说吗？[p]
#sara
是莎拉小时候听过的[r]超级有趣的故事哦！[p]
[_tb_end_text]

[bg  time="2000"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="1000"  ]
[bg  time="300"  method="crossfade"  storage="still20.png"  ]
[tb_start_text mode=1 ]
#sara
很久很久以前 月球第五环形山住着一只专吃兔子的丑陋巨犬[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="still21.png"  ]
[tb_start_text mode=1 ]
#sara
巨犬抓到像莎拉这样可爱的兔子后[r]就会用大平底锅煎烤 再浇上大锅里炖煮的[r]木莓酱汁大快朵颐[p]
#yui
这还真是……令人毛骨悚然的故事呢[p]
#sara
呵呵！接下来才是精彩部分！[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="still22.png"  ]
[tb_start_text mode=1 ]
#sara
「若因畏惧而止步不前 便永无改变之日」[r]满月之王斩钉截铁地说道[p]
#sara
「决不能继续纵容这些穷凶极恶的巨犬[r]此刻正是全民奋起抗争之时」[p]
#sara
兔子们高举着1000℃的火钳[r]攻入了巨犬盘踞的环形山[p]
#sara
面对巨犬们凶暴的獠牙[r]满月之王他们斩获了无数首级[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="still23.png"  ]
[tb_start_text mode=1 ]
#sara
在勇猛果敢的战士们手中[r]巨犬们转眼间就被生擒了[p]
#sara
满月之王将巨犬放在巨大餐盘上[r]浇上锅中熬煮的木莓酱汁[r]分发给兔子们享用[p]
#sara
「再也没什么好怕的了！[r]幸福与美食就该大家共享」[p]
#sara
兔子们分享着美味佳肴[r]同享喜悦 幸福生活[r]可喜可贺 可喜可贺[p]
[_tb_end_text]

[bg  time="2000"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="1000"  ]
[bg  time="300"  method="crossfade"  storage="still03.png"  ]
[tb_start_text mode=4 ]
#sara
怎么样？[r]莎拉呀 最——喜欢这个故事了！[p]
#sara
莎拉的爸爸也是[r]打败过巨犬的战士大人哦 厉害吧？[p]
#sara
爸爸说过 那些木莓酱汁啊[r]像红宝石一样闪闪发亮 特别漂亮[r]据说真的是这样呢！[p]
#sara
莎拉也一直好想尝尝看……
[_tb_end_text]

[wait  time="2000"  ]
[tb_start_text mode=4 ]
#
[_tb_end_text]

[tb_hide_message_window  ]
[bg  time="0"  method="crossfade"  storage="still04.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="still05.png"  ]
[wait  time="1000"  ]
[tb_image_hide  time="100"  ]
[bg  time="0"  method="crossfade"  storage="antenbase.png"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[stopbgm  time="1000"  fadeout="true"  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="1000"  method="crossfade"  storage="foods.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[playbgm  volume="100"  time="2000"  loop="true"  fadein="true"  storage="redinner.mp3"  ]
[wait  time="2000"  ]
[cm  ]
[bg  time="1000"  method="crossfade"  storage="gohan00.png"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xc20000"  time="300"  text="食&nbsp;べ&nbsp;ろ"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g01wine enterimg=button/g01wineonM.png clickimg=button/g01wine.png x=823 y=87 graphic=button/g01wine.png]
;前菜
[button target=*g01zensai enterimg=button/g01zensaionM.png clickimg=button/g01zensai.png x=555 y=150 graphic=button/g01zensai.png]
;バゲット
[button target=*g01pan enterimg=button/g01panonM.png clickimg=button/g01pan.png x=318 y=135 graphic=button/g01pan.png]
;スープ
[button target=*g01soop enterimg=button/g01sooponM.png clickimg=button/g01soop.png x=670 y=194 graphic=button/g01soop.png]
;ハンバーグ
[button target=*g01main enterimg=button/g01mainonM.png clickimg=button/g01main.png x=374 y=211 graphic=button/g01main.png]
[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
[s  ]
*g01main

[cm  ]
[tb_eval  exp="f.atesara+=1"  name="atesara"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[tb_image_show  time="600"  storage="default/g01mainOK.png"  width="326"  height="140"  x="374"  y="211"  name="img_221"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene1.ks"  target="*allate01"  cond="f.atesara==10"  ]
[tb_start_tyrano_code]
;のみもの
[button name=“wine1” button target=*g01wine enterimg=button/g01wineonM.png clickimg=button/g01wine.png x=823 y=87 graphic=button/g01wine.png]
;前菜
[button target=*g01zensai enterimg=button/g01zensaionM.png clickimg=button/g01zensai.png x=555 y=150 graphic=button/g01zensai.png]
;バゲット
[button target=*g01pan enterimg=button/g01panonM.png clickimg=button/g01pan.png x=318 y=135 graphic=button/g01pan.png]
;スープ
[button target=*g01soop enterimg=button/g01sooponM.png clickimg=button/g01soop.png x=670 y=194 graphic=button/g01soop.png]
[_tb_end_tyrano_code]

[s  ]
*g01soop

[cm  ]
[tb_eval  exp="f.atesara+=1"  name="atesara"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g01soopOK.png"  width="306"  height="100"  x="670"  y="194"  name="img_230"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="nomu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene1.ks"  target="*allate01"  cond="f.atesara==10"  ]
[tb_start_tyrano_code]
;のみもの
[button name=“wine1” button target=*g01wine enterimg=button/g01wineonM.png clickimg=button/g01wine.png x=823 y=87 graphic=button/g01wine.png]
;前菜
[button target=*g01zensai enterimg=button/g01zensaionM.png clickimg=button/g01zensai.png x=555 y=150 graphic=button/g01zensai.png]
;バゲット
[button target=*g01pan enterimg=button/g01panonM.png clickimg=button/g01pan.png x=318 y=135 graphic=button/g01pan.png]
;ハンバーグ
[button target=*g01main enterimg=button/g01mainonM.png clickimg=button/g01main.png x=374 y=211 graphic=button/g01main.png]
[_tb_end_tyrano_code]

[s  ]
*g01zensai

[cm  ]
[tb_eval  exp="f.atesara+=1"  name="atesara"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g01zensaiOK.png"  width="198"  height="75"  x="555"  y="150"  name="img_239"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene1.ks"  target="*allate01"  cond="f.atesara==10"  ]
[tb_start_tyrano_code]
;のみもの
[button name=“wine1” button target=*g01wine enterimg=button/g01wineonM.png clickimg=button/g01wine.png x=823 y=87 graphic=button/g01wine.png]
;バゲット
[button target=*g01pan enterimg=button/g01panonM.png clickimg=button/g01pan.png x=318 y=135 graphic=button/g01pan.png]
;スープ
[button target=*g01soop enterimg=button/g01sooponM.png clickimg=button/g01soop.png x=670 y=194 graphic=button/g01soop.png]
;ハンバーグ
[button target=*g01main enterimg=button/g01mainonM.png clickimg=button/g01main.png x=374 y=211 graphic=button/g01main.png]
[_tb_end_tyrano_code]

[s  ]
*g01pan

[cm  ]
[tb_eval  exp="f.atesara+=1"  name="atesara"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g01panOK.png"  width="216"  height="110"  x="318"  y="135"  name="img_248"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene1.ks"  target="*allate01"  cond="f.atesara==10"  ]
[tb_start_tyrano_code]
;のみもの
[button name=“wine1” button target=*g01wine enterimg=button/g01wineonM.png clickimg=button/g01wine.png x=823 y=87 graphic=button/g01wine.png]
;前菜
[button target=*g01zensai enterimg=button/g01zensaionM.png clickimg=button/g01zensai.png x=555 y=150 graphic=button/g01zensai.png]
;スープ
[button target=*g01soop enterimg=button/g01sooponM.png clickimg=button/g01soop.png x=670 y=194 graphic=button/g01soop.png]
;ハンバーグ
[button target=*g01main enterimg=button/g01mainonM.png clickimg=button/g01main.png x=374 y=211 graphic=button/g01main.png]
[_tb_end_tyrano_code]

[s  ]
*g01wine

[cm  ]
[tb_eval  exp="f.atesara+=1"  name="atesara"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g01wineOK.png"  width="80"  height="100"  x="823"  y="87"  name="img_257"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="nomu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene1.ks"  target="*allate01"  cond="f.atesara==10"  ]
[tb_start_tyrano_code]
;前菜
[button target=*g01zensai enterimg=button/g01zensaionM.png clickimg=button/g01zensai.png x=555 y=150 graphic=button/g01zensai.png]
;バゲット
[button target=*g01pan enterimg=button/g01panonM.png clickimg=button/g01pan.png x=318 y=135 graphic=button/g01pan.png]
;スープ
[button target=*g01soop enterimg=button/g01sooponM.png clickimg=button/g01soop.png x=670 y=194 graphic=button/g01soop.png]
;ハンバーグ
[button target=*g01main enterimg=button/g01mainonM.png clickimg=button/g01main.png x=374 y=211 graphic=button/g01main.png]
[_tb_end_tyrano_code]

[s  ]
*allate01

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_ptext_hide  time="100"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]

;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save2.png" x="77" y="520"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load2.png" x="80" y="541"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto2.png" x="93" y="620"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip2.png" x="92" y="596"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog2.png" x="76" y="641"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config2.png" storage="../others/plugin/theme_kopanda_14/config4.ks" x="75" y="568"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="560"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
; 名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="23" x="268" y="532" width="480" align="left"]
[chara_config ptext="chara_name_area"]

[_tb_end_tyrano_code]

[wait  time="6000"  ]
[cm  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  fadein="true"  ]
[tb_hide_message_window  ]
[tb_image_hide  time="1000"  ]
[bg  time="1000"  method="crossfade"  storage="base012.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
*homew

[cm  ]
[bg  time="600"  method="crossfade"  storage="base012.png"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiD01.png"  width="720"  height="720"  left="700"  top="020"  ]
[tb_start_tyrano_code]
;ママパパ
[button target=*mamapapa enterimg=button/mmpponM.png clickimg=button/mmpp.png x=700 y=200 graphic=button/mmpp.png]
;サザンカとはなす
[button target=*talk enterimg=button/sazankaonM.png clickimg=button/sazanka.png x=700 y=270 graphic=button/sazanka.png]
;ねる
[button target=*neru enterimg=button/neruonM.png clickimg=button/neru.png x=700 y=340 graphic=button/neru.png]
[_tb_end_tyrano_code]

[s  ]
*mamapapa

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[bg  time="1000"  method="crossfade"  storage="base013.png"  ]
[tb_image_show  time="1000"  storage="default/hana.png"  width="199"  height="250"  x="341"  y="191"  _clickable_img=""  name="img_286"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
爸爸和妈妈呀[p]
给他们送了水和果酱[p]
[_tb_end_text]

[chara_mod  name="yui"  time="300"  cross="true"  storage="chara/1/yuiD04.png"  ]
[tb_start_text mode=1 ]
妈妈……[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
[hidemenubutton]
[clearfix]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save6.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load6.png" x="160" y="690"]
; オートボタン
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto6.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip6.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog6.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config6.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[stopbgm  time="3000"  fadeout="true"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_image_hide  time="1000"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="2000"  ]
[playbgm  volume="100"  time="300"  loop="true"  storage="utyu.mp3"  fadein="true"  ]
[tb_show_message_window  ]
[mask_off  time="100"  effect="fadeOut"  ]
[bg  time="2000"  method="crossfade"  storage="still11.png"  ]
[tb_start_text mode=1 ]
[font size=15]从第五火山口向东北方向飞越两座大山丘。[p]
爸爸妈妈都不知道的秘密山丘[r]那里盛开着闪闪发光的鲜红花朵[p]
新月的大家都吓得要死[r]可我觉得阳光根本没这么烫呀[p]
发梢沾到一点点火星[r]午睡时候感觉可舒服啦[p]
特别漂亮呢……但是谁都不知道[p]
只属于我的秘密山丘[p]
……　……[p]
今天是我的生日[p]
偷偷看见厨房里藏着草莓[p]
现在妈妈一定在做草莓酱等着我[p]
把这些花当作礼物 我要让妈妈大吃一惊！[resetfont][p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
[clearfix]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]

;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save2.png" x="77" y="520"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load2.png" x="80" y="541"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto2.png" x="93" y="620"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip2.png" x="92" y="596"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog2.png" x="76" y="641"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config2.png" storage="../others/plugin/theme_kopanda_14/config4.ks" x="75" y="568"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="560"]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="3000"  fadeout="true"  ]
[wait  time="1000"  ]
[bg  time="2000"  method="crossfade"  storage="base013.png"  ]
[mask_off  time="2000"  effect="fadeOut"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiD01.png"  width="720"  height="720"  left="700"  top="020"  ]
[playbgm  volume="100"  time="300"  loop="true"  storage="kaisou.mp3"  fadein="true"  ]
[tb_image_hide  time="1000"  ]
[tb_hide_message_window  ]
[jump  storage="scene1.ks"  target="*homew"  ]
*talk

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
*talkwai

[cm  ]
[chara_show  name="sazanka"  time="1000"  wait="true"  storage="chara/4/sazanka01.png"  width="720"  height="720"  left="200"  ]
[tb_start_tyrano_code]
;ふろ
[button target=*huro enterimg=button/ohuroonM.png clickimg=button/ohuro.png x=700 y=200 graphic=button/ohuro.png]
;おやすみ
[button target=*oyasumi enterimg=button/oyasumionM.png clickimg=button/oyasumi.png x=700 y=270 graphic=button/oyasumi.png]
[vostop]
;[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
;[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
;[vostart]

[_tb_end_tyrano_code]

[s  ]
*huro

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_show_message_window  ]
[wait  time="200"  ]
[tb_start_text mode=1 ]
（雪白的青年正在洗餐具）[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="1"  storage="voyui/yui10.mp3"  ]
[tb_start_text mode=1 ]
#yui
山茶花[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka1.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[tb_start_text mode=1 ]
#sazanka
？ 怎么了 尤伊[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui11.mp3"  ]
[tb_start_text mode=1 ]
#yui
今天的裙子 谢谢你为我做[p]
[_tb_end_text]

[tb_start_tyrano_code]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
[vostart]

[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka2.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka09.png"  ]
[tb_start_text mode=4 ]
#sazanka
不用谢！我做得也很开心哦[p]
#sazanka
全都是想着适合尤伊做的……[r]超级合身呢！[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui12.mp3"  ]
[tb_start_text mode=4 ]
#yui
……嗯 是条非常漂亮的裙子[p]
#yui
不过那条裙子 被我弄脏了[l][r]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui13.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[tb_start_text mode=4 ]
#yui
难得做好的 对不起[p]
#sazanka
就这点事啊！别放在心上[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka01.png"  ]
[tb_start_text mode=4 ]
#sazanka
能让尤伊开心就是我最大的幸福啊[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka3.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka03.png"  ]
[tb_start_text mode=1 ]
#sazanka
所以不用道歉[r]有什么我能做的尽管说？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui14.mp3"  ]
[tb_start_text mode=2 ]
#yui
……这样啊[l][r]
#
[_tb_end_text]

[tb_hide_message_window  ]
[jump  storage="scene1.ks"  target="*talkwai"  ]
*oyasumi

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#yui
我要睡了　明天也拜托了[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka4.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
啊　当然！晚安　尤伊[p]
#
[_tb_end_text]

[tb_hide_message_window  ]
[chara_hide  name="sazanka"  time="1000"  wait="true"  pos_mode="false"  ]
[jump  storage="scene1.ks"  target="*homew"  ]
*neru

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[bg  time="3000"  method="crossfade"  storage="anten.png"  ]
[tb_eval  exp="f.sarasf='ok'"  name="sarasf"  cmd="="  op="t"  val="ok"  val_2="undefined"  ]
[wait  time="1000"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[jump  storage="choise.ks"  target="*photo2"  ]
*sarano2

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[cm  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[clearfix]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sarast{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_ptext_hide  time="1000"  ]
[wait  time="1000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[chara_show  name="sara"  time="0"  wait="true"  storage="chara/2/sara04.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiB01.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#sara
哎呀？……[r]盯～～[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[voconfig sebuf=2 name="sara" vostorage="vosara/sara{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara01.png"  ]
[tb_start_text mode=4 ]
#sara
噗噗噗！真是个土里土气的乡下姑娘呢！[p]
[_tb_end_text]

[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara03.png"  ]
[tb_start_text mode=4 ]
#sara
相比之下莎拉果然超级可爱！[p]
#sara
今天一定会有英俊的王子殿下[r]发现莎拉的！呀啊！[p]
[_tb_end_text]

[chara_hide  name="sara"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB04.png"  ]
[tb_start_text mode=4 ]
#yui
(谁是乡下丫头啊！[r] 可恶…)[p]
#yui
(看来要引起她的注意[r]必须换个形象才行……)[p]
#
[_tb_end_text]

[tb_ptext_hide  time="300"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[jump  storage="scene1.ks"  target="*gameover"  ]
*sarano3

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[cm  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[clearfix]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sarast{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_ptext_hide  time="1000"  ]
[wait  time="1000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[chara_show  name="sara"  time="0"  wait="true"  storage="chara/2/sara04.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiE01.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#yui
日安！可爱的小姐[p]
#sara
哎呀？……[r]盯～～[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sara{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE02.png"  ]
[tb_start_text mode=4 ]
#yui
我的脸上有什么东西吗……[p]
[_tb_end_text]

[chara_mod  name="sara"  time="0"  cross="true"  storage="chara/2/sara02.png"  ]
[tb_start_text mode=4 ]
#sara
多么做作的表情啊！[p]
#sara
莎拉很可爱这点我知道啦[r]但妈妈说过要远离危险人物！[l][r]
#sara
真遗憾呢！哼！[p]
[_tb_end_text]

[tb_ptext_hide  time="300"  ]
[chara_hide  name="sara"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE06.png"  ]
[tb_start_text mode=1 ]
#yui
（呜……看来[r]这副模样不是她喜欢的类型）[p]
#
[_tb_end_text]

[chara_hide_all  time="1000"  wait="true"  ]
[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[jump  storage="scene1.ks"  target="*gameover"  ]
*sarano4

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[cm  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
;ボイス設定
[voconfig sebuf=2 name="sara" vostorage="vosara/sarast{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_ptext_hide  time="1000"  ]
[wait  time="1000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[jump  storage="scene1.ks"  target="*pillouji"  cond="f.hazimepill==20"  ]
[jump  storage="scene1.ks"  target="*pillkiza"  cond="f.hazimepill==25"  ]
[jump  storage="scene1.ks"  target="*pillreijo"  cond="f.hazimepill==10"  ]
*pillouji

[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiA01.png"  width="720"  height="720"  left="700"  ]
[jump  storage="scene1.ks"  target="*nove04go"  ]
*pillkiza

[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiE01.png"  width="720"  height="720"  left="700"  ]
[jump  storage="scene1.ks"  target="*nove04go"  ]
*pillreijo

[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiB01.png"  width="720"  height="720"  left="700"  ]
[jump  storage="scene1.ks"  target="*nove04go"  ]
*nove04go

[tb_show_message_window  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[add_theme_button]

[vostop]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
啊啊！好忙好忙！[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vopill/pillok2.mp3"  ]
[tb_start_text mode=4 ]
#pill
嗯？什么事？[r]很不巧今天本少爷很忙哦[p]
#pill
毕竟还要帮爸爸妈妈干活呢！[l][r]
#pill
好啦闲人快走开～！[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_hide  name="pill"  time="600"  wait="true"  pos_mode="false"  ]
[jump  storage="scene1.ks"  target="*komarireijo"  cond="f.hazimepill==10"  ]
[jump  storage="scene1.ks"  target="*komariouji"  cond="f.hazimepill==20"  ]
[jump  storage="scene1.ks"  target="*komarikiza"  cond="f.hazimepill==25"  ]
*komarireijo

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB04.png"  ]
[jump  storage="scene1.ks"  target="*nove5"  ]
*komariouji

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiA05.png"  ]
[jump  storage="scene1.ks"  target="*nove5"  ]
*komarikiza

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE06.png"  ]
[jump  storage="scene1.ks"  target="*nove5"  ]
*nove5

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#yui
（可恶！错过了搭话机会！[r]皮尔王子不知跑去哪了……）[p]
#
[_tb_end_text]

[tb_ptext_hide  time="300"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[jump  storage="scene1.ks"  target="*gameover"  ]
*gameover

[cm  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[bg  time="300"  method="crossfade"  storage="anten.png"  ]
[tb_ptext_show  x="373"  y="262"  size="75"  color="0xfff8de"  time="1000"  text="GAME&nbsp;OVER..."  face="BestTen-DOT"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
[vostop]
;retry
[button target=*retrygo enterimg=button/retryonM.png clickimg=button/retry.png x=370 y=550 graphic=button/retry.png]
;back
[button target=*backgo enterimg=button/titlebackonM.png clickimg=button/titleback.png x=680 y=550 graphic=button/titleback.png]
[_tb_end_tyrano_code]

[s  ]
*retrygo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_eval  exp="f.hazimepill=5"  name="hazimepill"  cmd="="  op="t"  val="5"  val_2="undefined"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="choise.ks"  target="*photo1"  ]
*backgo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="title_screen.ks"  target=""  ]
