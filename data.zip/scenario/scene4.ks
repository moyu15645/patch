[_tb_system_call storage=system/_scene4.ks]

*0400

[cm  ]
[bg  time="1000"  method="crossfade"  storage="sazapart.png"  ]
[wait  time="1500"  ]
*omake1

[cm  ]
[bg  time="2000"  method="crossfade"  storage="antenbase2.png"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
;[add_theme_button]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save8.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load8.png" x="160" y="690"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto8.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip8.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog8.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config8.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message05.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
[font color=0x164a84 font size=15]我的人生尽是跌落谷底[p]
啊…不是 这真的不是在抱怨什么的 真的！[r]字面意义上的意思……[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill01.png"  ]
[tb_start_text mode=1 ]
小时候 全家人一起去野营的时候[r]在山里脚下一滑 从悬崖摔下去了[p]
正在山里哭着乱转时[r]旁边树丛里突然窜出一条[r]比夜空更漆黑的狗！[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill02.png"  ]
[tb_start_text mode=1 ]
当它那双红得发亮燃烧般的眼睛瞪过来时[r]那家伙就朝我飞奔而来……[p]
「「完蛋了！」[r]腿脚发软 下意识闭眼蜷缩起来[r]但那狗完全没有要扑过来的迹象[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill03.png"  ]
[tb_start_text mode=1 ]
被狗引导着往前走时[r]听见了谁的说话声[l][r]是爸爸妈妈的声音[p]
被妈妈他们抱住时回头看去[r]那家伙已经不见了[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill0400.png"  ]
[tb_start_text mode=1 ]
数年后 18岁的秋天[p]
我如愿以偿进入了憧憬的餐厅工作[l][r]不过新人时期只能被安排洗碗……[p]
但始终坚信着「总有一天我也能成为帅气的厨师」[p]
[_tb_end_text]

[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04a.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04e.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04f.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04e.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04f.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04f.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04b.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04c.png"  ]
[wait  time="500"  ]
[bg  time="0"  method="crossfade"  storage="omakestill04d.png"  ]
[wait  time="500"  ]
[bg  time="0"  method="crossfade"  storage="antenbase2.png"  ]
[wait  time="3000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill05.png"  ]
[wait  time="2000"  ]
[bg  time="1000"  method="crossfade"  storage="omakestill06.png"  ]
[tb_start_text mode=1 ]
「你要死了吗」[p]
「你就是那家店的家伙吧」[p]
「肚子饿瘪了……[r]反正都要死 临死前想用这个做点吃的」[p]
明明已是深更半夜[r]桥上站着个和我同龄的少女[r]她手里抱着只雪白的兔子[p]
凝视着我的双眼[r]像灼灼燃烧的赤红烈焰般……[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill07.png"  ]
[tb_start_text mode=1 ]
「心想「这就是命运」[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill08.png"  ]
[tb_start_text mode=1 ]
自那以后 我总在深夜的厨房里[r]为她烹饪料理[p]
她尝了一口便直言[r]「难吃」[p]
虽然深受打击 但她连碎屑都没剩下[r]全部吃完的模样 至今记忆犹新[p]
「下次……绝对会做得更好吃！」[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="antenbase2.png"  ]
[tb_start_text mode=1 ]
然而一年 三年 五年 十年……无论过去多少年[r]她再未出现在我面前[p]
那孩子莫非是濒死前看到的幻觉吗？[p]
不 不对！[r]那绝对是真实发生的事！[p]
还想再为那孩子做一次料理[p]
想让那孩子对我说「好吃」[p]
这就是我活下去的唯一理由[p]
「只要活着就一定能再相见」[r]我如此坚信着……[p]
[_tb_end_text]

[stopbgm  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="omakestill09.png"  ]
[tb_start_text mode=1 ]
结果误入了传销组织[p]
[_tb_end_text]

[playbgm  volume="100"  time="1000"  loop="true"  storage="maruchi.mp3"  ]
[tb_start_text mode=1 ]
[font color=0x164a84  bold=true font size=20]「这可是绳文时代流传下来的[r]　记载着666种黑暗魔法的[r]　魔导书哦！」[p]
「市场上绝对买不到的珍品……[r]　而且这次竟然……！？[r]　仅限本次活动……！？」[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="omakestill10.png"  ]
[tb_start_text mode=1 ]
[font color=0x164a84  bold=true font size=30]「什么！！」[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="omakestill11.png"  ]
[tb_start_text mode=1 ]
[font color=0x164a84  bold=true font size=30]「竟然只要！！」[p]

[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="omakestill12.png"  ]
[tb_start_text mode=1 ]
[font color=0x164a84  bold=true font size=50]「30万元！！」[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="kane.mp3"  ]
[tb_start_text mode=1 ]
[font color=0x164a84 font size=15]（叮铃）[p]
[_tb_end_text]

[tb_hide_message_window  ]
[bg  time="500"  method="crossfade"  storage="antenbase2.png"  ]
[bg  time="1000"  method="crossfade"  storage="omakestill18.png"  ]
*book1

[cm  ]
[bg  time="0"  method="crossfade"  storage="omakestill19.png"  ]
[tb_start_tyrano_code]
;tugi
[button target=*book2 enterimg=button/booknextonM.png clickimg=button/booknext.png x=1030 y=500 graphic=button/booknext.png]
[_tb_end_tyrano_code]

[s  ]
*book2

[cm  ]
[bg  time="0"  method="crossfade"  storage="omakestill20.png"  ]
[tb_start_tyrano_code]
;tugi
[button target=*book3 enterimg=button/booknextonM.png clickimg=button/booknext.png x=1030 y=500 graphic=button/booknext.png]
[_tb_end_tyrano_code]

[s  ]
*book3

[cm  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message06.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
;	名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0x1e50a2" size="23" x="268" y="532" width="480" align="left"]
[chara_config ptext="chara_name_area"]

[_tb_end_tyrano_code]

[bg  time="0"  method="crossfade"  storage="omakestill21.png"  ]
[wait  time="3000"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[font color=0x164a84 ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
[add_theme_button]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save3.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save4.png" x="77" y="520"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load3.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load4.png" x="80" y="541"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto3.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto4.png" x="93" y="620"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip3.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip4.png" x="92" y="596"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog3.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog4.png" x="76" y="641"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config3.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config4.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="75" y="568"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="560"]

[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#sazanka
「蜡像人偶·烛光娃娃」…[p]
这样的话说不定我也能办到……？[resetfont][p]
[_tb_end_text]

[tb_hide_message_window  ]
[stopbgm  time="1000"  fadeout="true"  ]
[bg  time="2000"  method="crossfade"  storage="antenbase2.png"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="tahi.mp3"  ]
[bg  time="1000"  method="crossfade"  storage="bar02a.png"  ]
[tb_ptext_show  x="249"  y="28"  size="17"  color="0x01466e"  time="300"  text="アカツキシティ　隠れ酒場「STARS」"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[tb_show_message_window  ]
[bg  time="100"  method="crossfade"  storage="bar02a.png"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazanka{number}.mp3" number=25]
[voconfig sebuf=2 name="kitune" vostorage="vokitune/kitune{number}.mp3" number=1]
[voconfig sebuf=2 name="tori" vostorage="votori/tori{number}.mp3" number=1]
[voconfig sebuf=2 name="yagi" vostorage="voyagi/yagi{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_show  name="tori"  time="50"  wait="false"  storage="chara/10/kyak03.png"  width="945"  height="720"  left="-41"  top="20"  ]
[chara_show  name="kitune"  time="50"  wait="false"  storage="chara/11/kyak02.png"  width="945"  height="720"  left="-41"  top="20"  ]
[chara_show  name="yagi"  time="50"  wait="false"  storage="chara/9/kyak02.png"  width="945"  height="720"  left="-40"  top="20"  ]
[tb_image_show  time="100"  storage="default/voion4.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_99"  ]
[tb_start_tyrano_code]
[chara_show  name="sazanka"  layer="0" time="300"  wait="true"  storage="chara/4/omakes01.png"  width="720"  height="720"  left="750"  ]
[font color=0x164a84 ]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#sazanka
……就这样[r]才有了现在的我[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak05.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=1 ]
#kitune
啊哈哈哈！！　山茶花君真是笨蛋～！[r]真正的魔导书怎么可能30万就买得到啊～！？[p]
[_tb_end_text]

[tb_ptext_hide  time="100"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes06.png"  ]
[tb_start_text mode=1 ]
#sazanka
真是的！我、我那时候也是知道的啊！[r]当时只是脑子短路了而已！[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03.png"  ]
[chara_mod  name="yagi"  time="0"  cross="true"  storage="chara/9/kyak01.png"  ]
[tb_start_text mode=1 ]
#yagi
所以？变成蜡像人偶延长了寿命后……[r]最重要的那个小姑娘重逢了吗？[p]
[_tb_end_text]

[chara_mod  name="yagi"  time="0"  cross="true"  storage="chara/9/kyak02.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes03.png"  ]
[tb_start_text mode=1 ]
#sazanka
嗯！现在一起生活着[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[tb_start_text mode=1 ]
#sazanka
同龄的朋友们虽然都不在了……[r]但还有店长和其他客人们陪着[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes09.png"  ]
[tb_start_text mode=1 ]
#sazanka
最重要的是又能遇见尤伊[r]所以一点都不寂寞！[p]
[_tb_end_text]

[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=1 ]
#tori
嚯！原来是火热小情侣啊！[r]真让人羡慕呢！[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
[voconfig sebuf=2 name="kitune" vostorage="vokitune/kitunebase{number}.mp3" number=1]
[voconfig sebuf=2 name="tori" vostorage="votori/toribase{number}.mp3" number=1]
[voconfig sebuf=2 name="yagi" vostorage="voyagi/yagibase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_image_hide  time="100"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vokitune/kitune2.mp3"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak05.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes02.png"  ]
[tb_start_text mode=1 ]
#kitune
混蛋！这家伙超「怂」的[r]一直不敢出手最后顿悟了[r]直接看破红尘了啊[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka30.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes04.png"  ]
[tb_start_text mode=1 ]
#sazanka
才不是！[r]我想在喜欢的人面前保持绅士风度啊[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes05.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03.png"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[tb_start_text mode=1 ]
#sazanka
而且最近她好像遇到些事情[r]有点消沉的样子[p]
#sazanka
所以现在我的感情无所谓[r]比起这个更希望她能振作起来……[p]

[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="votori/tori2.mp3"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=1 ]
#tori
白痴啊～这么丰盛的美食当前[r]不是秒杀她的机会吗？[r]你小子明明有这本事！[p]
#tori
老子来这儿可不是为了喝酒[r]是专程来吃山茶花君做的料理啊！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes07.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vokitune/kitune3.mp3"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[tb_start_text mode=1 ]
#kitune
超厉害的吧？从菜青虫粪便到克拉肯触手[r]什么都能做成美味[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vokitune/kitune4.mp3"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak05.png"  ]
[tb_start_text mode=1 ]
#kitune
看招！[r]『STARS』头牌料理人！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="votori/tori3.mp3"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=1 ]
#tori
喔喔！那这顿饭老子请了！[r]给你家姑娘带去吧[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vokitune/kitune5.mp3"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes09.png"  ]
[tb_start_text mode=1 ]
#kitune
笨蛋！哪有送吃到一半的东西的道理！[r]真是的……[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagi2.mp3"  ]
[tb_start_text mode=1 ]
#yagi
好啦好啦 俗话说「饿着肚子打不了仗」[r]鸟山说的也不无道理[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="votori/tori4.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes07.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03.png"  ]
[tb_start_text mode=1 ]
#tori
看吧！果然是这样对吧！？[p]
#yagi
……月球坠落到地球已过去百年[r]当时我还是个年幼的孩子呢[p]
#yagi
山茶花君知道「新月」吗？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka31.mp3"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes02.png"  ]
[tb_start_text mode=1 ]
#sazanka
嗯…我记得……在月球坠落地球之前[r]是从地球上看月亮完全变黑时的[r]称呼对吧？[p]
#
[_tb_end_text]

[chara_hide_all  time="1000"  wait="false"  ]
[tb_start_tyrano_code]
;キャラ退場
@chara_hide name="sazanka" layer="0" zindex=1005 time=1000
[_tb_end_tyrano_code]

[bg  time="1000"  method="crossfade"  storage="bar.png"  ]
[bg  time="600"  method="crossfade"  storage="bar03are.png"  ]
[chara_show  name="yagi"  time="1000"  wait="true"  storage="chara/9/kyakyagi.png"  width="710"  height="720"  left="650"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagi3.mp3"  ]
[tb_start_text mode=1 ]
#yagi
没错[r]那你知道为什么看起来会全黑吗？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka32.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
呃……[r]是为什么呢？[p]
#yagi
因为月球运行到了太阳与地球之间[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="bar03b.png"  ]
[tb_start_text mode=1 ]
#yagi
在远古时代……[l][r]存在着追逐光明生活在月丘的『满月之民』[r]与栖身光影之中的『新月之民』[p]
#yagi
满月之民畏惧黑暗[r]而新月之民惧怕太阳的炙热[p]
#yagi
据说双方辗转迁徙于陆地与海洋间[r]始终不曾往来[p]
#kitune
八木先生 又在讲古早传说吗[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="votori/tori5.mp3"  ]
[tb_start_text mode=1 ]
#tori
哎呀呀[r]当时亲历者的讲述可是很珍贵的啊[p]
#yagi
「被称为「Moonster」的我们正是新月之民[p]
#yagi
根据地球历史记载[r]百年前那场撞击发生的日子[r]正是新月之日[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka33.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
那个……也就是说……[r]当时正好处在月球与地球相撞的截面上[r]新月之民们都在那里是吗？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagi4.mp3"  ]
[tb_start_text mode=1 ]
#yagi
就是这么回事[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="bar03b1.png"  ]
[tb_start_text mode=1 ]
#yagi
新月之民全都被压扁了[r]而原本居住在月球「背面」的兔子们降临地面[r]与地球人相遇了[p]
他们建立起友好关系[r]并在灾后重建过程中……[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="bar03b2.png"  ]
[tb_start_text mode=1 ]
#yagi
发现了被撞击压垮的新月之民尸体[r]作为与月球共存的未知怪物「Moonster」[r]逐渐被视为恐惧的象征[p]
这就是如今这个世界的起源了[p]
#sazanka
月球撞击的事[r]我也听母亲说起过[p]
#sazanka
不过母亲的故乡距离月球坠落处很远[r]所以她知道的也不太详细[p]
#sazanka
听说那是世界前所未有的大灾难……[l][r]在那样的绝境中，您究竟是怎么幸存下来的？[p]
#yagi
当时我躲在「环形山」里[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="bar03b3.png"  ]
[tb_start_text mode=1 ]
#yagi
月球表面不是有无数坑洞吗？[p]
#yagi
其中最深的那个坑洞……[r]好像被称作『第五环形山』来着[p]
#yagi
相传是远古时期爆发过战争的场所[r]所以平时几乎没人会靠近那里[p]
#yagi
凡是藏身于那片地域的人[r]就这样活了下来[p]
#sazanka
第五环形山……[p]
[_tb_end_text]

[chara_hide_all  time="600"  wait="true"  ]
[bg  time="1000"  method="crossfade"  storage="bar02a.png"  ]
[chara_show  name="tori"  time="50"  wait="false"  storage="chara/10/kyak03.png"  width="945"  height="720"  left="-41"  top="20"  ]
[chara_show  name="kitune"  time="50"  wait="false"  storage="chara/11/kyak02.png"  width="945"  height="720"  left="-41"  top="20"  ]
[chara_show  name="yagi"  time="50"  wait="false"  storage="chara/9/kyak01.png"  width="945"  height="720"  left="-40"  top="20"  ]
[tb_image_show  time="100"  storage="default/voion4.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_28"  ]
[tb_start_tyrano_code]
[chara_show  name="sazanka"  layer="1" time="300"  wait="true"  storage="chara/4/omakes07.png"  width="720"  height="720"  left="750"  ]

[vostop]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazanka{number}.mp3" number=34]
[voconfig sebuf=2 name="kitune" vostorage="vokitune/kitune{number}.mp3" number=6]
[voconfig sebuf=2 name="tori" vostorage="votori/tori{number}.mp3" number=6]
[voconfig sebuf=2 name="yagi" vostorage="voyagi/yagi{number}.mp3" number=5]
[voconfig sebuf=2 name="master" vostorage="vomaster/master{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#yagi
虽说如此 幸存者的总数依然寥寥无几[r]而且这副模样要是暴露 就会变成「蜂窝」了[p]
#yagi
所以当时连吃顿饭都得拼命……[p]
#yagi
多亏有那个洞窟才能活到今天[l][r]
#yagi
虽然绝望的岁月很漫长 但现在能遇到志同道合的伙伴 安稳地喝着酒[p]
#tori
虽然也算是有限度的安稳啦[p]
[_tb_end_text]

[chara_mod  name="yagi"  time="0"  cross="true"  storage="chara/9/kyak02.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[tb_start_text mode=1 ]
#kitune
真的真的！[r]地球人都超喜欢兔耳朵！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes07.png"  ]
[tb_start_text mode=1 ]
#kitune
所以连那种鬼话都会相信[r]说什么我们是见啥吃啥的怪物[r]根本胡编乱造！[p]
[_tb_end_text]

[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=1 ]
#tori
啊——就像兔子打倒了巨犬之类的[r]荒唐故事对吧？[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes08.png"  ]
[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03.png"  ]
[tb_start_text mode=1 ]
#kitune
对对就是！那种故事任谁听了[r]都知道是瞎扯[p]
#kitune
与其有闲工夫管他们的耳朵[r]不如先把自己耳屎掏干净吧！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes07.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=1 ]
#tori
说到耳朵 其实有极少数[r]自愿站在我们这边的「特殊席位」[r]好像确实存在这种家伙呢[p]
#kitune
就像人类分什么猫派狗派之类的[r]对吧？[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[tb_start_text mode=1 ]
#kitune
即便如此 我们在这个世界上[r]依然活得抬不起头来[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[tb_start_text mode=4 ]
#kitune
外貌也好 内心也罢……[r]能接纳我们的 就只有这家店了[p]
[_tb_end_text]

[chara_mod  name="yagi"  time="0"  cross="true"  storage="chara/9/kyak01.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes07.png"  ]
[tb_start_text mode=4 ]
#yagi
总之就算和这个星球的居民相比[r]我们的寿命也长得离谱[l][r]
#yagi
而且随着世代更迭 价值观也会改变[p]
#yagi
就算现在身处低谷[r]也不代表未来会永远如此啊[p]
#yagi
无论是谁 偶尔好好休息一下也没关系[p]
[_tb_end_text]

[chara_mod  name="yagi"  time="0"  cross="true"  storage="chara/9/kyak02.png"  ]
[tb_start_text mode=4 ]
#yagi
所以……[r]希望她也不要放弃啊[p]
#sazanka
八木先生……[l]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[tb_start_text mode=4 ]
#sazanka
说得对[r]我也会好好支持她 让她能这么想的！[p]
[_tb_end_text]

[chara_show  name="master"  time="1000"  wait="true"  storage="chara/8/tensyo.png"  width="720"  height="796"  left="650"  top="-30"  ]
[tb_start_text mode=1 ]
#master
山茶花君 陪那群醉鬼就到此为止吧[r]差不多该打烊了[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes02.png"  ]
[tb_start_text mode=1 ]
#sazanka
！啊 好的！老板[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes01.png"  ]
[tb_start_text mode=1 ]
#kitune
啧 什么啊 老板你在啊[p]
[_tb_end_text]

[chara_mod  name="master"  time="0"  cross="true"  storage="chara/8/tensyo2.png"  ]
[tb_start_text mode=1 ]
#master
怎么可能让可爱的招牌姑娘一个人[r]应付那群说教臭的老油条呢[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/omakes09.png"  ]
[tb_start_text mode=1 ]
#sazanka
那俺就先撤了……[r]八木你们也别喝太晚啊！[p]
#tori
好嘞 辛苦啦～路上小心～[p]
#
[_tb_end_text]

[tb_start_tyrano_code]
;キャラ退場
@chara_hide name="sazanka" layer="1" zindex=1005 time=500
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#master
……所以「特殊癖好」是啥意思？[r]敢骚扰我家孩子的话 以后就永久禁入啊[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[chara_mod  name="tori"  time="0"  cross="true"  storage="chara/10/kyak03a.png"  ]
[tb_start_text mode=4 ]
#kitune
骚、骚扰！？[r]我没那个意思啊！？[p]
#tori
哈哈哈！不是啦[r]是说我们Moonster（怪物）的社会风评问题啦！[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[tb_start_text mode=4 ]
#tori
虽然可能还有偏见 但至少说明[r]我们的存在已经被社会认知了[r]重要的是今后提升形象对吧？[p]
#tori
我们才不是什么怪物！[l][r]
#tori
总有一天……要抓住[r]那个叫「人类幸福」的东西！[p]
[_tb_end_text]

[chara_mod  name="master"  time="0"  cross="true"  storage="chara/8/tensyo2.png"  ]
[tb_start_text mode=4 ]
#master
哼、本来世道就不景气，[r]我们还要被当成怪物对待，[r]怎么可能顺利啊[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[tb_start_text mode=4 ]
#kitune
哇啊！所以我才说店长你啊！[r]别老是这么愁眉苦脸的！[p]
[_tb_end_text]

[chara_mod  name="master"  time="0"  cross="true"  storage="chara/8/tensyo.png"  ]
[tb_start_text mode=4 ]
#master
最近出现过吧？[r]袭击兔人的新月之民[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak02.png"  ]
[tb_start_text mode=4 ]
#tori
啊、那只巨犬的……新闻里报道过[r]估计是积压了相当多的怨气吧[p]
[_tb_end_text]

[chara_mod  name="master"  time="0"  cross="true"  storage="chara/8/tensyo2.png"  ]
[tb_start_text mode=4 ]
#master
……说起巨犬，据说在古老的新月族里，[r]曾是拥有强大力量的生物[p]
[_tb_end_text]

[chara_mod  name="master"  time="0"  cross="true"  storage="chara/8/tensyo.png"  ]
[tb_start_text mode=4 ]
#master
拥有强大力量者若发声挥力，[r]会怎样？[p]
#yagi
想必也会有追随者出现吧[p]
[_tb_end_text]

[chara_mod  name="kitune"  time="0"  cross="true"  storage="chara/11/kyak04.png"  ]
[tb_start_text mode=4 ]
#kitune
怎么可能！店长和八木都想太多了！[p]
#kitune
像我们这样悄悄混在人类社会、<br>装成普通上班族的家伙才是大多数啊！<br>怎么可能有那种激进分子！[p]
#master
……<br>但愿如此吧……[p][resetfont]
#
[_tb_end_text]

[stopbgm  time="3000"  fadeout="true"  ]
[tb_hide_message_window  ]
[tb_image_hide  time="100"  ]
[mask  time="5000"  effect="fadeIn"  color="0x000000"  graphic="omakestill13.png"  ]
[chara_hide_all  time="100"  wait="true"  ]
[bg  time="100"  method="crossfade"  storage="omakestill13.png"  ]
[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['moba'].jname = '？？？'
[endscript]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazanka{number}.mp3" number=38]
[voconfig sebuf=2 name="moba" vostorage="vomoba/hodoki{number}.mp3" number=1]
[vostart]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
;[add_theme_button]

;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save8.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load8.png" x="160" y="690"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto8.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip8.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog8.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config7.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config8.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
;	名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0x164a84" size="18" x="350" y="400" width="340"]
[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
[tb_show_message_window  ]
[tb_image_show  time="100"  storage="default/voion5.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_28"  ]
[playbgm  volume="100"  time="5000"  loop="true"  storage="yozoraoff.mp3"  fadein="true"  ]
[tb_start_text mode=1 ]
#sazanka
[font color=0x0095d9 font size=15]糟了！已经这个点了吗[p]
#sazanka
尤伊应该已经醒了吧<br>不想让她等太久 得赶紧回去……[p]
！！[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill16.png"  ]
[tb_start_text mode=4 ]
#sazanka
哇！对不起！[p]
#moba
那个 打扰了<br>听说这附近有家「星辰会员制」酒吧……<br>您知道在哪吗[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="omakestill16a.png"  ]
[tb_start_text mode=4 ]
#sazanka
！要这么说的话 就在那边窄巷子尽头哦[p]
#sazanka
如您所知 因为是「星辰会员制」<br>小哥您要不是「星辰」的话可进不去呢[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="omakestill16b.png"  ]
[tb_start_text mode=4 ]
#sazanka
哇　糟了！[r]
[_tb_end_text]

[wait  time="700"  ]
[bg  time="0"  method="crossfade"  storage="omakestill16c.png"  ]
[tb_start_text mode=1 ]
对不起　我末班车要赶不上了！[r]先走了！[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill15.png"  ]
[tb_start_text mode=1 ]
#moba
……原来如此[r]果然　这颗星球上　还有同胞存在[p]
#moba
说不定　果然那个英勇的身影是……[p]
#
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill13.png"  ]
[cm  ]
[tb_start_text mode=1 ]
[font color=0xff0000 font size=17]第五火山口被占据已有数百年[p]
巨犬们的肉被分配给了月宫里的兔子[p]
当盘子里的肉消失时[r]几只兔子来到士兵面前　这样说道[p]
[_tb_end_text]

[stopbgm  time="300"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="omakestill17a.png"  ]
[tb_start_text mode=1 ]
「我们还没分到肉呢……」[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="omakestill13.png"  ]
[tb_start_text mode=1 ]
不知是兔士兵数错了　还是有人贪恋肉的美味[p]
又或者是……[p]
#moba
「果然　您还活着呢」[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="omakestill17.png"  ]
[tb_start_text mode=1 ]
#moba
公主殿下　终于找到了……[resetfont][p]
#
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[tb_image_hide  time="100"  ]
[bg  time="1000"  method="crossfade"  storage="omakestill13.png"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_hide_message_window  ]
[wait  time="3000"  ]
[movie  volume="80"  storage="karikure2025.mp4"  ]
[tb_eval  exp="sf.exkaiho='ok'"  name="exkaiho"  cmd="="  op="t"  val="ok"  val_2="undefined"  ]
[cm  ]
[jump  storage="title_screen.ks"  target="*title"  ]
