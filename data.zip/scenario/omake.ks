[_tb_system_call storage=system/_omake.ks]

*extras00

[cm  ]
[bg  time="300"  method="crossfade"  storage="omakeRE.png"  ]
[tb_start_tyrano_code]
;世界観
[button target=*sekai enterimg=button/sekaionM.png clickimg=button/sekai.png x=225 y=250 graphic=button/sekai.png]
;尤伊
[button target=*yui enterimg=button/omakeyuionM.png clickimg=button/omakeyui.png x=623 y=93 graphic=button/omakeyui.png]
;サラ
[button target=*sara enterimg=button/omakesaraonM.png clickimg=button/omakesara.png x=623 y=211 graphic=button/omakesara.png]
;レラビ
[button target=*red enterimg=button/omakeredonM.png clickimg=button/omakeredl.png x=625 y=325 graphic=button/omakeredl.png]
;3rabi
[button target=*rabi3 enterimg=button/omakerabi3onM.png clickimg=button/omakerabi3.png x=623 y=438 graphic=button/omakerabi3.png]
;サザンカ
[button target=*sazanka enterimg=button/omakesazankaonM.png clickimg=button/omakesazanka.png x=934 y=93 graphic=button/omakesazanka.png]
;ピール
[button target=*pill enterimg=button/omakepillonM.png clickimg=button/omakepill.png x=933 y=210 graphic=button/omakepill.png]
;用心棒
[button target=*bodyguard enterimg=button/omakebodyonM.png clickimg=button/omakebody.png x=935 y=325 graphic=button/omakebody.png]
;かねもち
[button target=*richoji enterimg=button/omakerichonM.png clickimg=button/omakerich.png x=934 y=438 graphic=button/omakerich.png]
;すたーず
[button target=*kyakus enterimg=button/omakestaraonM.png clickimg=button/omakestara.png x=933 y=554 graphic=button/omakestara.png]

;もどる
[button target=*modori enterimg=button/modorubotanonM.png clickimg=button/modorubotan.png x=50 y=660 graphic=button/modorubotan.png]
[_tb_end_tyrano_code]

[clickable  storage="omake.ks"  x="424"  y="98"  width="148"  height="51"  target="*bgmbotan"  _clickable_img=""  ]
[clickable  storage="omake.ks"  x="446"  y="624"  width="119"  height="40"  target="*atogaki"  _clickable_img=""  ]
[clickable  storage="omake.ks"  x="301"  y="622"  width="119"  height="40"  target="*creg"  _clickable_img=""  ]
[s  ]
*yui

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara1.png"  width="1280"  height="720"  name="img_8"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*sekai

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/race1.png"  width="1280"  height="720"  name="img_14"  ]
[l  ]
[tb_image_show  time="300"  storage="default/race2.png"  width="1280"  height="720"  name="img_16"  ]
[l  ]
[tb_image_show  time="300"  storage="default/race3.png"  width="1280"  height="720"  name="img_18"  ]
[l  ]
[mask  time="300"  effect="fadeIn"  color="0x000000"  graphic="anten.png"  ]
[tb_image_hide  time="300"  ]
[mask_off  time="300"  effect="fadeOut"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*sara

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara2.png"  width="1280"  height="720"  name="img_26"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*pill

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara3.png"  width="1280"  height="720"  name="img_32"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*red

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara4.png"  width="1280"  height="720"  name="img_38"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*bodyguard

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara6.png"  width="1280"  height="720"  name="img_44"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*sazanka

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara5.png"  width="1280"  height="720"  name="img_50"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*rabi3

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara8.png"  width="1280"  height="720"  name="img_50"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*richoji

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara7.png"  width="1280"  height="720"  name="img_50"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*kyakus

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/chara9.png"  width="1280"  height="720"  name="img_50"  ]
[l  ]
[tb_image_show  time="300"  storage="default/chara10.png"  width="1280"  height="720"  name="img_50"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*creg

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="300"  storage="default/creg.png"  width="1280"  height="720"  name="img_50"  ]
[l  ]
[tb_image_hide  time="300"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*atogaki

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[button  storage="omake.ks"  target="*modo00"  graphic="button/kome.png"  width="324"  height="99"  x="269"  y="523"  _clickable_img=""  ]
[s  ]
[jump  storage="omake.ks"  target=""  ]
*bgmbotan

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[jump  storage="omake.ks"  target="*off"  cond="f.omakebgm==5"  ]
*on

[tb_eval  exp="f.omakebgm+=5"  name="omakebgm"  cmd="+="  op="t"  val="5"  val_2="undefined"  ]
[playbgm  volume="80"  time="1000"  loop="true"  storage="omakeoke.mp3"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*off

[tb_eval  exp="f.omakebgm-=5"  name="omakebgm"  cmd="-="  op="t"  val="5"  val_2="undefined"  ]
[stopbgm  time="1000"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*modo00

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*modori

[cm  ]
[tb_image_hide  time="1000"  ]
[stopbgm  time="600"  fadeout="true"  ]
[jump  storage="title_screen.ks"  target="*title"  ]
