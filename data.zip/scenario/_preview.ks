[_tb_system_call storage=system/_preview.ks ]

[mask time=10]
[mask_off time=10]
*pill00

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="70"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiB01.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[wait  time="1000"  ]
[tb_start_tyrano_code]
[add_theme_button]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pillst{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_15"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
哎呀！你……[r]看起来不像是兔人呢[p]
#pill
但是非常美丽……[l][r]

[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
不过真遗憾啊！我只想和[r]聪明的女性聊天[p]
[_tb_end_text]

[tb_ptext_hide  time="300"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
对吧[r]我的话题你能理解吗？
[_tb_end_text]

[tb_image_show  time="0"  storage="default/huntpill.gif"  width="1100"  height="600"  name="img_23"  ]
[wait  time="4000"  ]
[tb_image_hide  time="100"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#pill
反正我也没抱什么期待啦！[p]
#pill
毕竟我可是哈～佛～大～学毕业的[r]
[_tb_end_text]

[wait  time="1000"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
论头脑可比那些普通的地球人[r]高出一截呢！
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '皮尔·托金王子'
[endscript]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill2ok enterimg=button/bun02aonM.png clickimg=button/bun02a.png x=700 y=200 graphic=button/bun02a.png]
;ng
[button target=*pill1ng enterimg=button/bun02bonM.png clickimg=button/bun02b.png x=700 y=270 graphic=button/bun02b.png]
[_tb_end_tyrano_code]

[s  ]
*pill2ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="100"  _clickable_img=""  name="img_42"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok1.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill10.png"  ]
[tb_start_text mode=4 ]
#pill
这反应倒是不错！[r]那就让我来教教你这个小地方来的[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
兔人现在这个星球上只剩157只了[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok2.mp3"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill02.png"  ]
[tb_start_text mode=4 ]
#pill
嗯？你问「剩下的347只去哪了」？[p]
#pill
在月球撞地球之前，都被巨犬族吃掉啦[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
所以这场派对是为了祈求日渐稀少的[r]兔人族繁荣的神圣派对！[r]这可是千载难逢的机会
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '皮尔·托金王子'
[endscript]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill3ok enterimg=button/bun02conM.png clickimg=button/bun02c.png x=700 y=200 graphic=button/bun02c.png]
;ng
[button target=*pill1ng enterimg=button/bun02donM.png clickimg=button/bun02d.png x=700 y=270 graphic=button/bun02d.png]
[_tb_end_tyrano_code]

[s  ]
*pill3ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="150"  _clickable_img=""  name="img_64"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok3.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill08.png"  ]
[tb_start_text mode=4 ]
#pill
哼哼～论兔人历史我可是特别在行！[r]其他事情也是无所不知！[r]有什么不懂的尽管问我[p]
#pill
要知道～我可是那位满月之王的[r]左臂之女的孙子的青梅竹马的孙子的曾曾孙的曾曾曾孙[r]啊！
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill4ok enterimg=button/bun02eonM.png clickimg=button/bun02e.png x=700 y=200 graphic=button/bun02e.png]
;ng
[button target=*pill1ng enterimg=button/bun02fonM.png clickimg=button/bun02f.png x=700 y=270 graphic=button/bun02f.png]
[_tb_end_tyrano_code]

[s  ]
*pill4ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="200"  _clickable_img=""  name="img_77"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok4.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill09.png"  ]
[tb_start_text mode=4 ]
#pill
对吧对吧！[r]所以今晚的派对筹备工作[r]也让我「咬了一小口」呢[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
今天招待用的葡萄酒[r]也是我爹地妈咪亲自挑选的！
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
[vostop]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ok
[button target=*pill5ok enterimg=button/bun02gonM.png clickimg=button/bun02g.png x=700 y=200 graphic=button/bun02g.png]
;ng
[button target=*pill1ng enterimg=button/bun02honM.png clickimg=button/bun02h.png x=700 y=270 graphic=button/bun02h.png]
[_tb_end_tyrano_code]

[s  ]
*pill5ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="250"  _clickable_img=""  name="img_92"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok5.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill04.png"  ]
[tb_start_text mode=4 ]
#pill
呵呵！对吧！[r]你也该尝尝看！[p]
#pill
这可是重现了远古战争中[r]榨取巨犬们鲜血滋味的珍酿哦[p]
#pill
直到现在兔兔们[r]都赞不绝口呢！[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok6.mp3"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
满星的数量是…[r]呃…有几个来着？
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ng
[button target=*i01 enterimg=button/bun02i1onM.png clickimg=button/bun02i1.png x=700 y=10 graphic=button/bun02i1.png]
;ng
[button target=*i03 enterimg=button/bun02i3onM.png clickimg=button/bun02i3.png x=700 y=80 graphic=button/bun02i3.png]
;ng
[button target=*i05 enterimg=button/bun02i5onM.png clickimg=button/bun02i5.png x=700 y=150 graphic=button/bun02i5.png]
;ng
[button target=*i108 enterimg=button/bun02i108onM.png clickimg=button/bun02i108.png x=700 y=220 graphic=button/bun02i108.png]
;ok
[button target=*pill6ok enterimg=button/bun02i157onM.png clickimg=button/bun02i157.png x=700 y=290 graphic=button/bun02i157.png]
;ng
[button target=*ing enterimg=button/bun02i343onM.png clickimg=button/bun02i343.png x=700 y=360 graphic=button/bun02i343.png]
;ng
[button target=*ing enterimg=button/bun02i504onM.png clickimg=button/bun02i504.png x=700 y=430 graphic=button/bun02i504.png]
;ng
[button target=*ing enterimg=button/bun02i666onM.png clickimg=button/bun02i666.png x=700 y=500 graphic=button/bun02i666.png]
;ng
[button target=*ing enterimg=button/bun02i741onM.png clickimg=button/bun02i741.png x=700 y=570 graphic=button/bun02i741.png]
;ng
[button target=*i80oku enterimg=button/bun02i80okuonM.png clickimg=button/bun02i80oku.png x=700 y=640 graphic=button/bun02i80oku.png]
[_tb_end_tyrano_code]

[s  ]
*pill6ok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
#
#yui
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="300"  _clickable_img=""  name="img_110"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillok7.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill09.png"  ]
[tb_start_text mode=4 ]
#pill
对对！因为现存兔人全票通过[r]所以是157颗！你记得真清楚！[p]
[_tb_end_text]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_116"  ]
[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pillok{number}.mp3" number=10]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill11.png"  ]
[tb_start_text mode=4 ]
#pill
呜呜…能听我把话说完的[r]你还是第一个啊[p]
#pill
其他人总是说到一半就溜走了…[r]
你比想象中更聪慧呢！
[_tb_end_text]

[wait  time="3000"  ]
[tb_start_tyrano_code]
;ok
[button target=*pillkudoku enterimg=button/kudokuonM.png clickimg=button/kudoku.png x=700 y=200 graphic=button/kudoku.png]
[_tb_end_tyrano_code]

[s  ]
*pillkudoku

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[vostop]
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=15]
[voconfig sebuf=2 name="pill" vostorage="vopill/pillok{number}.mp3" number=12]
[vostart]

#
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB03.png"  ]
[tb_start_text mode=1 ]
#yui
如果不嫌弃的话 我想多听听你的故事呢[p]
[_tb_end_text]

[tb_image_hide  time="100"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill05.png"  ]
[tb_start_text mode=4 ]
#pill
呜嗯！你就是我的命中注定之人！[l][r]
#pill
或许我真正渴求的并非聪慧[r]而是温柔也说不定！
[_tb_end_text]

[wait  time="3000"  ]
[tb_image_show  time="0"  storage="default/reijoyui.gif"  width="1100"  height="600"  name="img_133"  ]
[wait  time="3800"  ]
[tb_image_hide  time="100"  ]
[cm  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[stopbgm  time="5000"  fadeout="true"  ]
[wait  time="6000"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
;[add_theme_button]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save6.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load6.png" x="160" y="690"]
; オートボタン
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto6.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip6.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog6.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config6.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
;名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="18" x="350" y="400" width="340"]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voion3.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_143"  ]
[bg  time="1000"  method="crossfade"  storage="still06.png"  ]
[playbgm  volume="100"  time="3000"  loop="true"  storage="yozoraoff.mp3"  fadein="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_tyrano_code]
;ボイス設定
[vostop]
[voconfig sebuf=2 name="pill" vostorage="vopill/pilled{number}.mp3" number=17]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#pill
[font size=15]哎呀，都这个点儿啦？[r]跟你聊天时间过得可真快呀～[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="still07.png"  ]
[tb_start_text mode=4 ]
#pill
但我还有好多话想说呢！[r]接下来该说……对了……[p]
#pill
对了 来讲个月亮传说吧！[l][r]
#pill
那个故事主流版本结束于兔子们[r]分食巨犬肉块的场景…[p]
#pill
但其实那个故事还有后续 你知道吗？[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="300"  method="crossfade"  storage="still23.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=4 ]
#pill
满月之王虽将巨犬肉[r]公平分给了大家 其实兔子的数量[p]和肉块数量根本对不上呢
#pill
后来　在部分兔子之间流传着[r]『或许还有巨犬的幸存者』[r]这样的传闻呢[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="300"  method="crossfade"  storage="still08.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=4 ]
#pill
呵呵　我是不是说了[resetfont]有点吓人的话题呀？[p]
#pill
嘛　不用担心的！[r]这肯定是和平·悉索的平民们[r]随便瞎编出来的啦！[p]
#pill
就算有贪吃鬼或者士兵数错数量[r]也没什么好奇怪的吧？[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#pill
就算万一真的还活着　我们也有好多地球人[r]当盟友呢！[l][r]
#pill
区区一只狗崽子　有什么好怕的……[resetfont]
[_tb_end_text]

[wait  time="4000"  ]
[tb_start_tyrano_code]
[vostop]
#
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[bg  time="0"  method="crossfade"  storage="still09.png"  ]
[wait  time="2000"  ]
[bg  time="0"  method="crossfade"  storage="antenbase.png"  ]
[mask  time="0"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="500"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[mask_off  time="2000"  effect="fadeOut"  ]
[playbgm  volume="100"  time="2000"  loop="true"  fadein="true"  storage="redinner.mp3"  ]
[wait  time="2000"  ]
[cm  ]
[bg  time="1000"  method="crossfade"  storage="gohan02.png"  ]
[tb_ptext_show  x="276"  y="33"  size="25"  color="0xc20000"  time="300"  text="食&nbsp;い&nbsp;つ&nbsp;く&nbsp;せ"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
[s  ]
*g02main

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g02mainOK.png"  width="330"  height="155"  x="385"  y="205"  name="img_181"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
[_tb_end_tyrano_code]

[s  ]
*g02sarada

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g02saradaOK.png"  width="196"  height="106"  x="626"  y="152"  name="img_190"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[s  ]
*g01ice

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[tb_image_show  time="600"  storage="default/g02syabetOK.png"  width="137"  height="77"  x="410"  y="150"  name="img_199"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="taberu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;のみもの
[button target=*g02wine enterimg=button/g02wineonM.png clickimg=button/g02wine.png x=812 y=90 graphic=button/g02wine.png]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[s  ]
*g02wine

[cm  ]
[tb_eval  exp="f.atepill+=1"  name="atepill"  cmd="+="  op="t"  val="1"  ]
[tb_image_show  time="600"  storage="default/g02wineOK.png"  width="84"  height="163"  x="812"  y="90"  name="img_208"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="nomu.mp3"  ]
[wait  time="600"  ]
[jump  storage="scene2.ks"  target="*allate02"  cond="f.atepill==9"  ]
[tb_start_tyrano_code]
;サラダ
[button target=*g02sarada enterimg=button/g02saradaonM.png clickimg=button/g02sarada.png x=626 y=152 graphic=button/g02sarada.png]
;シャーベット
[button target=*g01ice enterimg=button/g02syabetonM.png clickimg=button/g02syabet.png x=410 y=150 graphic=button/g02syabet.png]
;パイ
[button target=*g02main enterimg=button/g02mainonM.png clickimg=button/g02main.png x=385 y=205 graphic=button/g02main.png]
[_tb_end_tyrano_code]

[s  ]
*allate02

[mask  time="0"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_image_hide  time="1000"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[tb_ptext_hide  time="100"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]

;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save2.png" x="77" y="520"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load2.png" x="80" y="541"]
; オートボタ
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto2.png" x="93" y="620"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip2.png" x="92" y="596"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog2.png" x="76" y="641"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config2.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="75" y="568"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="560"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
; 名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="23" x="268" y="532" width="480" align="left"]
[chara_config ptext="chara_name_area"]

[hidemenubutton]
[clearfix]

[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
*homew2

[cm  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  fadein="true"  ]
[bg  time="600"  method="crossfade"  storage="base012.png"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiD01.png"  width="720"  height="720"  left="700"  top="020"  ]
[tb_start_tyrano_code]
;ママパパ
[button target=*mamapapa2 enterimg=button/mmpponM.png clickimg=button/mmpp.png x=700 y=200 graphic=button/mmpp.png]
;サザンカとはなす
[button target=*talk2 enterimg=button/sazankaonM.png clickimg=button/sazanka.png x=700 y=270 graphic=button/sazanka.png]
;ねる
[button target=*ruteok enterimg=button/neruonM.png clickimg=button/neru.png x=700 y=340 graphic=button/neru.png]
[_tb_end_tyrano_code]

[s  ]
*mamapapa2

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[bg  time="1000"  method="crossfade"  storage="base013.png"  ]
[tb_image_show  time="1000"  storage="default/hana.png"  width="199"  height="250"  x="341"  y="191"  _clickable_img=""  name="img_231"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
是爸爸和妈妈呀[p]
给两人送了水和果酱[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD04.png"  ]
[tb_start_text mode=1 ]
爸爸……[p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_start_tyrano_code]
[hidemenubutton]
[clearfix]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[stopbgm  time="3000"  fadeout="true"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_image_hide  time="1000"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="2000"  ]
[playbgm  volume="100"  time="300"  loop="true"  storage="utyu.mp3"  fadein="true"  ]
[tb_show_message_window  ]
[bg  time="2000"  method="crossfade"  storage="still10.png"  ]
[tb_start_text mode=1 ]
[font size=15]尤伊，我听妈妈说了，[r]你一个人去散步了？[p]
听好了[r]你还是个孩子[r]不许独自去环形山外面[p]
被太阳晒到会烧焦的[r]至少要和王子两个人一起的话……[p]
可那家伙笨手笨脚的！[r]书呆子一个 连捉迷藏都玩不好[p]
两个人的话 回来都要等到明天了[p]
……唔[r]看来得好好训练王子才行啊[p]
总之就是不行[r]妈妈和爸爸都很担心[p]
明白吗？不许一个人去危险的地方[r]这是和爸爸的约定[resetfont][p]
[_tb_end_text]

[mask  time="2000"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
[clearfix]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="3000"  fadeout="true"  ]
[bg  time="3000"  method="crossfade"  storage="base013.png"  ]
[mask_off  time="2000"  effect="fadeOut"  ]
[chara_show  name="yui"  time="1000"  wait="true"  storage="chara/1/yuiD01.png"  width="720"  height="720"  left="700"  top="20"  ]
[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  ]
[tb_hide_message_window  ]
[jump  storage="scene2.ks"  target="*homew2"  ]
*talk2

[cm  ]
[chara_show  name="sazanka"  time="1000"  wait="true"  storage="chara/4/sazanka01.png"  width="720"  height="720"  left="200"  ]
[tb_start_tyrano_code]
;ふろ
[button target=*huro2 enterimg=button/ohuroonM.png clickimg=button/ohuro.png x=700 y=200 graphic=button/ohuro.png]
;おやすみ
[button target=*oyasumi2 enterimg=button/oyasumionM.png clickimg=button/oyasumi.png x=700 y=270 graphic=button/oyasumi.png]
[vostop]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[s  ]
*huro2

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
山茶花 我先去泡澡啦[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="1"  storage="vosazanka/sazanka5.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
啊 啊…… 已经进去洗了吗[p]
#yui
不是你让我先洗的吗[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka10.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka6.mp3"  ]
[tb_start_text mode=4 ]
#sazanka
是没错！…… 不过[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka09.png"  ]
[tb_start_text mode=4 ]
#sazanka
因为今天的尤伊 特别漂亮……[l][r]就想着 好想再多看一会儿啊[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui16.mp3"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD02.png"  ]
[tb_start_text mode=4 ]
#yui
呵呵 是吗？[r]我一直想试试穿那种衣服呢[p]
#yui
以前在认识的老爷爷家 经常看到这种款式[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka7.mp3"  ]
[tb_start_text mode=4 ]
#sazanka
诶 原来是裁缝师傅家吗？[p]
#yui
嗯……记不太清了[r]不过那件礼服确实很美呢[p]
#yui
所以今天真的很开心……[r]谢谢你[p]

[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka03.png"  ]
[tb_start_text mode=4 ]
#sazanka
……！你能开心就比什么都好！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD01.png"  ]
[tb_start_text mode=4 ]
#sazanka
话说今天的派对没事吧？[l][r]没人找你麻烦吧？[p]
#yui
……突然说这个好恶心[p]

[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka10.png"  ]
[tb_start_text mode=4 ]
#sazanka
没、没办法啊！我就是担心嘛！[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka11.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka8.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
听着！不管对方是什么种族[r]都不准跟奇怪的男人走知道吗！[p]
#yui
（从喜欢狗狗的地球人那里拿到会员卡的事[r]还是保密吧……）[p]
#
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka01.png"  ]
[tb_hide_message_window  ]
[jump  storage="scene2.ks"  target="*talk2"  ]
*oyasumi2

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_show_message_window  ]
[tb_start_text mode=4 ]
#yui
该睡了 晚安[p]
[_tb_end_text]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[tb_start_text mode=4 ]
#sazanka
啊…… 这么早就要睡了吗[l][r]
#sazanka
本来还想和尤伊多聊一会儿的……[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka9.mp3"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka01.png"  ]
[tb_start_text mode=1 ]
#sazanka
不过熬夜确实不好呢 晚安[p]
#yui
…… 过来一下[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka02.png"  ]
[tb_start_text mode=1 ]
#sazanka
？[p]
#
[_tb_end_text]

[tb_hide_message_window  ]
[wait  time="1000"  ]
[chara_move  name="sazanka"  anim="false"  time="300"  effect="linear"  wait="true"  left="430"  top="20"  ]
[wait  time="1000"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka04.png"  ]
[wait  time="2000"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD05.png"  ]
[wait  time="2000"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka05.png"  ]
[wait  time="2000"  ]
[chara_mod  name="sazanka"  time="0"  cross="true"  storage="chara/4/sazanka06.png"  ]
[wait  time="2000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#sazanka
…… ……！？[p]
[_tb_end_text]

[tb_start_tyrano_code]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuibase{number}.mp3" number=1]
[voconfig sebuf=2 name="sazanka" vostorage="vosazanka/sazankabase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#sazanka
！ 呜 哇啊！[p]
#
[_tb_end_text]

[chara_mod  name="sazanka"  time="300"  cross="true"  storage="chara/4/sazanka07.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD01.png"  ]
[chara_move  name="sazanka"  anim="true"  time="600"  effect="easeInOutQuad"  wait="true"  left="-1000"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bakuha.mp3"  ]
[quake  time="300"  count="3"  hmax="10"  wait="true"  ]
[chara_hide  name="sazanka"  time="1000"  wait="true"  pos_mode="false"  ]
[chara_show  name="sazanka"  time="1000"  wait="true"  storage="chara/4/sazanka08.png"  width="720"  height="720"  left="200"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD03.png"  ]
[tb_start_text mode=1 ]
#sazanka
为、为什么突然亲上来啊[p]
#yui
…… 我要睡了 你也赶紧去洗澡睡觉[p]
#sazanka
啊…！对、对了[r]我还没洗澡呢！？[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiD02.png"  ]
[tb_start_text mode=1 ]
#yui
晚安 山茶花[r]明天也拜托了[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vosazanka/sazanka10.mp3"  ]
[tb_start_text mode=1 ]
#sazanka
那是当然……呜呜……[r]脸根本没法见人啊！怎么办啊！？[p]
#
[_tb_end_text]

[chara_hide  name="sazanka"  time="600"  wait="true"  pos_mode="false"  ]
[tb_hide_message_window  ]
[jump  storage="scene2.ks"  target="*homew2"  ]
*pillno02

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiA03.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[tb_start_tyrano_code]
[add_theme_button]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#pill
哼！怎么着？[r]你个非兔人的家伙找本大爷有何贵干？[p]
#pill
啊啊 难得参加派对[r]为什么非得和男人聊天不可啊？[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno29.mp3"  ]
[tb_start_text mode=4 ]
#pill
完全就是在浪费时间嘛！[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
好了好了 快给我消失！[l][r]
#pill
可爱的女孩子还在等着我呢[l][r]拜拜！[p]
#
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[jump  storage="scene2.ks"  target="*gameover"  ]
*pillno03

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[chara_show  name="pill"  time="0"  wait="true"  storage="chara/3/pill02.png"  width="720"  height="720"  left="200"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiE04.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[wait  time="300"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[tb_start_tyrano_code]
[add_theme_button]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
哼！怎么着？[r]你个非兔人的家伙找本大爷有何贵干？[p]
#pill
啊啊 难得参加派对[r]为什么非得和男人聊天不可啊？[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno29.mp3"  ]
[tb_start_text mode=4 ]
#pill
完全就是在浪费时间嘛！[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE03.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="voyui/yui19.mp3"  ]
[tb_start_text mode=4 ]
#yui
哦？你说和我的相遇是种浪费？[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE05.png"  ]
[tb_start_text mode=1 ]
#yui
听说你是名校出身[r]本想着一定要和你聊聊看呢……[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="voyui/yui20.mp3"  ]
[tb_start_text mode=1 ]
#yui
既然你这么想 那也没办法[r]我就先告辞了[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill06.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno30.mp3"  ]
[tb_start_text mode=1 ]
#pill
什、什么……？[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill04.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="0"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="100"  _clickable_img=""  name="img_381"  ]
[tb_image_show  time="0"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="150"  _clickable_img=""  name="img_382"  ]
[tb_image_show  time="0"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="200"  _clickable_img=""  name="img_383"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno31.mp3"  ]
[tb_start_text mode=4 ]
#pill
真、真是的！搞什么啊！[r]要这样的话就早点说清楚啊！[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno32.mp3"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE10.png"  ]
[tb_start_text mode=4 ]
#pill
你其实很在意我吧！[l][r]
#pill
那就从我珍贵的婴儿记忆到辉煌的学生时代[r]统统都说给你听！[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE13.png"  ]
[tb_start_text mode=1 ]
#yui
（哇啊、好像不小心打开了什么开关……）[p]
（感觉会超级麻烦！[r]还是先撤退吧！）[p]
#
[_tb_end_text]

[tb_image_hide  time="100"  ]
[jump  storage="scene2.ks"  target="*gameover"  ]
*i01

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=1 ]
#pill
居、居然只给一星！？太失礼了这位女士！[p]
像你这样没礼貌的女人[r]我才不想搭理呢！[r]再见啦！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i03

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=1 ]
#pill
给3颗星？你[r]是在说我们托金家很寒酸吗！？[p]
像你这样没礼貌的女人[r]我才不稀罕呢！再见啦！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i05

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
那是地球人的标准吧？[l][r]
#pill
我们兔人的价值观和标准和他们不同[r]学校没教过你吗？[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=4 ]
#pill
真是让人失望……[r]我对笨女人没兴趣！拜拜！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i108

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
那好像是地球人的星星数量标准吧……[l][r]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill06.png"  ]
[tb_start_text mode=4 ]
#pill
难、难道你在给我打星星评价！？[p]
#pill
太、太轻浮可不行啊淑女！[l][r]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill05.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB04.png"  ]
[tb_start_text mode=4 ]
#pill
那、那我就先告辞啦！再见咯！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*i80oku

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill02.png"  ]
[tb_start_text mode=4 ]
#pill
那不过是前阵子地球人的数量罢了！[p]
#pill
据说地球人每秒会增加2～3人[r]所以现在应该更多了……[l][r]
现在不是说这个的时候啦……[p]
[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill03.png"  ]
[tb_start_text mode=4 ]
#pill
唔…感觉有点扫兴呢……[l][r]
#pill
我以为你挺有品味的[r]可能是我看走眼了吧[p]

[_tb_end_text]

[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill01.png"  ]
[tb_start_text mode=4 ]
#pill
我要去找其他命中注定的女孩啦！[r]拜拜！祝你派对玩得开心♪[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*ing

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[tb_start_text mode=1 ]
#pill
你刚才没认真听我说话吗？[p]
#pill
真是让人失望啊……[r]我对脑子不好的女人没兴趣！再见！[p]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*gameover"  ]
*pill1ng

[cm  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="pill" vostorage="vopill/pill{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_image_hide  time="100"  ]
[wait  time="200"  ]
[playse  volume="100"  time="1000"  buf="3"  storage="vopill/pillno28.mp3"  ]
[chara_mod  name="pill"  time="0"  cross="true"  storage="chara/3/pill07.png"  ]
[tb_start_text mode=1 ]
#pill
哼，怎么啦！[r]像你这样脑子不好的女人我也拒绝哦！[p]
#
[_tb_end_text]

*gameover

[cm  ]
[tb_start_tyrano_code]
[vostop]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="2000"  fadeout="true"  ]
[chara_hide_all  time="1000"  wait="true"  ]
[bg  time="300"  method="crossfade"  storage="anten.png"  ]
[tb_ptext_show  x="373"  y="262"  size="75"  color="0xfff6e8"  time="1000"  text="GAME&nbsp;OVER..."  face="BestTen-DOT"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;retry
[button target=*retrygo enterimg=button/retryonM.png clickimg=button/retry.png x=370 y=550 graphic=button/retry.png]
;back
[button target=*backgo enterimg=button/titlebackonM.png clickimg=button/titleback.png x=680 y=550 graphic=button/titleback.png]
[_tb_end_tyrano_code]

[s  ]
*retrygo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="choise.ks"  target="*photo2"  ]
*backgo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="title_screen.ks"  target=""  ]
*ruteok

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_eval  exp="f.pillsf='ok'"  name="pillsf"  cmd="="  op="t"  val="ok"  val_2="undefined"  ]
[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[jump  storage="choise.ks"  target="*photo3"  ]
