[_tb_system_call storage=system/_scene3.ks]

*fullmoon01

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[cm  ]
[tb_ptext_hide  time="1000"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[wait  time="1000"  ]
[bg  storage="base01.png"  time="1000"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['moba'].jname = '兔人(Cute)'
[endscript]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=21]
[voconfig sebuf=2 name="fullmoon" vostorage="vored/red{number}.mp3" number=1]
[voconfig sebuf=2 name="moba" vostorage="vomoba/rabi{number}.mp3" number=1]

[vostart]
[_tb_end_tyrano_code]

[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[tb_ptext_show  x="260"  y="33"  size="15"  color="0xfff6e8"  time="300"  text="Akatsuki City<br>Akatsuki Premium Hall 3rd Floor"  face="FontopoNIHONGO"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[chara_show  name="moba"  time="0"  wait="true"  storage="chara/6/mob05a.png"  width="634"  height="720"  left="1400"  ]
[chara_show  name="fullmoon"  time="0"  wait="true"  storage="chara/5/fullmoonbig01.png"  width="720"  height="792"  left="200"  top="-36"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiE04.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_18"  ]
[wait  time="1500"  ]
[chara_move  name="moba"  anim="true"  time="2000"  effect="easeInOutQuad"  wait="true"  left="-60"  ]
[chara_mod  name="moba"  time="0"  cross="true"  storage="chara/6/mob05b.png"  ]
[tb_start_tyrano_code]
#moba
快看快看！红兔子女王哟！[p]
[_tb_end_tyrano_code]

[chara_mod  name="moba"  time="0"  cross="true"  storage="chara/6/mob05c.png"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['moba'].jname = '兔人(Cool)'
[endscript]
#moba
哎呀 今天 您大驾光临了呢[p]
[_tb_end_tyrano_code]

[chara_mod  name="moba"  time="0"  cross="true"  storage="chara/6/mob05d.png"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['moba'].jname = '兔人(Beauty)'
[endscript]
#moba
听说当代女王是只冷酷无情的兔子[r]连个朋友都没有呢[p]
[_tb_end_tyrano_code]

[chara_mod  name="moba"  time="0"  cross="true"  storage="chara/6/mob05b.png"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['moba'].jname = '兔人(Cute)'
[endscript]
#moba
那位绅士肯定也会被拒绝吧？[p]
#
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE05.png"  ]
[chara_mod  name="moba"  time="0"  cross="true"  storage="chara/6/mob05.png"  ]
[tb_start_tyrano_code]
咯咯 咯咯 咯咯……
[_tb_end_tyrano_code]

[tb_image_show  time="0"  storage="default/huntrerabi.gif"  width="1100"  height="600"  name="img_32"  x="100"  ]
[wait  time="4000"  ]
[tb_image_hide  time="100"  ]
[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_35"  ]
[tb_ptext_hide  time="300"  ]
[chara_move  name="moba"  anim="true"  time="1000"  effect="easeInOutQuad"  wait="true"  left="-700"  ]
[chara_hide  name="moba"  time="1000"  wait="true"  pos_mode="false"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE03.png"  ]
[cm  ]
[tb_start_text mode=1 ]
#yui
哎呀呀 女王陛下 贵安[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE01.png"  ]
[tb_start_text mode=4 ]
#fullmoon
贵安 素未谋面的丽人[r]找本宫有何贵干？[p]
#fullmoon
很抱歉 禁止与来历不明之人交谈[r]您究竟是哪国的王子呢？
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
;ok
[button target=*rabi01ok enterimg=button/bun03aonM.png clickimg=button/bun03a.png x=700 y=270 graphic=button/bun03a.png]
;ng
[button target=*rabi01ng enterimg=button/bun03bonM.png clickimg=button/bun03b.png x=700 y=200 graphic=button/bun03b.png]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '红兔·满月'
[endscript]
[vostop]
#yui
[_tb_end_tyrano_code]

[s  ]
*rabi01ok

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[cm  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE07.png"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yui{number}.mp3" number=22]
[voconfig sebuf=2 name="fullmoon" vostorage="vored/red{number}.mp3" number=3]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
我并非哪国的王子[p]
#yui
只是为了一睹这世间最美的兔人女王[r]特此前来的无名之辈[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#yui
女王陛下 可否赏脸与我共舞一曲？[p]
#fullmoon
抱歉 今日只是来观察情况的[l][r]
#fullmoon
虽是美妙的邀约 但请容我婉拒[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE04.png"  ]
[tb_start_text mode=1 ]
#yui
这样啊……[r]真是遗憾[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE08.png"  ]
[tb_start_text mode=1 ]
#yui
像您这般美丽的人[r]想必还有众多追求者[r]在等着您吧[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE02.png"  ]
[tb_start_text mode=1 ]
#yui
我还是识趣退下为好[r]方才失礼唐突了[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig03.png"  ]
[tb_start_text mode=1 ]
#fullmoon
……　也是呢[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[tb_start_text mode=1 ]
#fullmoon
好吧　稍微聊一会儿也行[p]
[_tb_end_text]

[tb_image_hide  time="300"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE01.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="125"  _clickable_img=""  name="img_68"  ]
[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[voconfig sebuf=2 name="fullmoon" vostorage="vored/redbase{number}.mp3" number=1]
[voconfig sebuf=2 name="moba" vostorage="vomoba/rabi{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig03.png"  ]
[tb_start_text mode=4 ]
#fullmoon
无论去哪里　遇到的都是急着自报家门的家伙　[r]你可真是个奇怪的人呢[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[tb_start_text mode=4 ]
#fullmoon
说到底　会想见我的家伙　[r]本来就少之又少[p]
#fullmoon
兔人们啊　尽是些骗子[l][r]
#fullmoon
就算有　也不过是贪图与王家的关系　……[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE05.png"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig04.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vored/red7.mp3"  ]
[tb_start_text mode=4 ]
#fullmoon
呵呵　你也是这样的吗？　[l][r]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[tb_start_text mode=4 ]
开个玩笑啦[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE08.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui28.mp3"  ]
[tb_start_text mode=1 ]
#yui
唔　看来　女王陛下　似乎[r]非常寂寞呢[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui29.mp3"  ]
[tb_start_text mode=1 ]
#yui
若您不嫌弃　不妨向我倾诉烦恼[r]意下如何？[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vored/red8.mp3"  ]
[tb_start_text mode=1 ]
#fullmoon
感谢您的关心[r]不过不必了[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE04.png"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig03.png"  ]
[tb_start_text mode=1 ]
#fullmoon
况且　民间传闻说　我是只[r]冷酷无情的兔子[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE01.png"  ]
[tb_start_text mode=4 ]
#fullmoon
难得的宴会　您不如[r]和更合心意的对象共度时光[r]这样不是更好吗？
[_tb_end_text]

[wait  time="2000"  ]
[tb_start_tyrano_code]
;ok
[button target=*rabi02ok enterimg=button/bun03donM.png clickimg=button/bun03d.png x=700 y=200 graphic=button/bun03d.png]
;ng
[button target=*rabi02ng enterimg=button/bun03conM.png clickimg=button/bun03c.png x=700 y=270 graphic=button/bun03c.png]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '红兔·满月'
[endscript]
[vostop]
#yui
[_tb_end_tyrano_code]

[s  ]
*rabi02ok

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui28.mp3"  ]
[tb_start_text mode=4 ]
#yui
唔……　拒绝女王亲自[r]给出的建议　真是胆大包天[l][r]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui30.mp3"  ]
[tb_start_text mode=4 ]
#yui
那么　谨遵吩咐……[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vored/red9.mp3"  ]
[tb_start_text mode=1 ]
#fullmoon
嗯　请慢走[p]
#
[_tb_end_text]

[chara_hide  name="yui"  time="1000"  wait="true"  pos_mode="false"  ]
[wait  time="1000"  ]
[chara_show  name="yui"  time="100"  wait="false"  storage="chara/1/yuiE10.png"  width="720"  height="720"  left="700"  ]
[quake  time="300"  count="3"  hmax="10"  wait="false"  ]
[tb_start_text mode=1 ]
#yui
[font size=30  font bold=true]等等！[r]您不打算挽留我吗！？[resetfont][p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vored/red10.mp3"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig04.png"  ]
[tb_start_text mode=1 ]
#fullmoon
怎么了？　[r]是要去找比我更棒的姑娘吗？[p]
#fullmoon
比起[font size=27]这位世间最美的女王[resetfont]，[r]但愿能有更合您心意的姑娘呢[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[tb_start_text mode=1 ]
#fullmoon
用眼睛谈恋爱的美人儿　[r]来来　快去把那种会被[r]甜腻台词骗到的傻兔子找来呀[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE11.png"  ]
[tb_start_text mode=1 ]
#yui
说得真过分……[r]明明我才是来追求你的那个人[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig04.png"  ]
[tb_start_text mode=1 ]
#fullmoon
瞧　再磨蹭下去　[r]宴会可就要结束了哦[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE13.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui31.mp3"  ]
[tb_start_text mode=1 ]
#yui
岂有此理！连约会都求而不得　[r]果然如传闻所说　你就是个冷酷无情的家伙[r]……！[p]
#fullmoon
……是啊[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vored/red11.mp3"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[tb_start_text mode=1 ]
#fullmoon
要是到最后都没人要的话　[r]本小姐陪你玩玩也无妨哦　呵呵[p]
[_tb_end_text]

[jump  storage="scene3.ks"  target="*rabi03"  ]
*rabi02ng

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE02.png"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[tb_start_text mode=1 ]
#yui
真是令人惊讶[r]素闻您冷酷无情　没想到竟会[r]为我这等贱民忧心[p]
#yui
女王陛下　您真是位温柔的人呢[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vored/red12.mp3"  ]
[tb_start_text mode=1 ]
#fullmoon
是在讽刺我吗？真是多谢了[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig04.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="vored/red13.mp3"  ]
[tb_start_text mode=1 ]
#fullmoon
我最讨厌[r]肤浅的谎言了[r]这下你满意了吧？[p]
[_tb_end_text]

[tb_image_hide  time="300"  ]
[chara_hide  name="fullmoon"  time="600"  wait="true"  pos_mode="false"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE06.png"  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
（糟了！好像惹她生气了）[p]
#yui
（被甩开手了……）[p]
#
[_tb_end_text]

[jump  storage="scene3.ks"  target="*gameover"  ]
*rabi03

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_image_show  time="100"  storage="default/lovegage.gif"  width="48"  height="41"  x="340"  y="170"  _clickable_img=""  name="img_150"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE12.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui33.mp3"  ]
[tb_start_text mode=1 ]
#yui
这真是……何其慈悲的恩典[r]在下感激涕零地收下了[p]
[_tb_end_text]

[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['moba'].jname = '保镖们'
[endscript]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboy{number}.mp3" number=1]
[voconfig sebuf=2 name="fullmoon" vostorage="vored/red{number}.mp3" number=14]
[vostart]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_155"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[tb_start_text mode=4 ]
#fullmoon
可爱的小少爷[l][r]
#fullmoon
若是能有您这样的人作为朋友　想必……[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE01.png"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig03.png"  ]
[tb_start_text mode=1 ]
#fullmoon
不　没什么[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[voconfig sebuf=2 name="fullmoon" vostorage="vored/redbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[tb_start_text mode=1 ]
#fullmoon
最后　我也有件事想请教呢[p]
#fullmoon
虽说您说是来查看情况　[r]其实我也有位正在寻找的人[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE04.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui34.mp3"  ]
[tb_start_text mode=1 ]
#yui
哦　那是哪位？[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[voconfig sebuf=2 name="fullmoon" vostorage="vored/red{number}.mp3" number=17]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#fullmoon
[font color=0xff0000]「漆黑大耳朵 红眼睛的
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE09.png"  ]
[tb_start_text mode=4 ]
Moonster（月兽）」[resetfont]、[r]您可曾听说过
[_tb_end_text]

[wait  time="1000"  ]
[tb_start_tyrano_code]
;ok
[button target=*rabi03ng enterimg=button/bun03bonM.png clickimg=button/bun03b.png x=700 y=200 graphic=button/bun03b.png]
;ng
[button target=*rabi03ok enterimg=button/bun03eonM.png clickimg=button/bun03e.png x=700 y=270 graphic=button/bun03e.png]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '红兔·满月'
[endscript]
[vostop]
#yui
[_tb_end_tyrano_code]

[s  ]
*rabi03ng

[cm  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE05.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yui35.mp3"  ]
[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[voconfig sebuf=3 name="fullmoon" vostorage="vored/red{number}.mp3" number=18]
[voconfig sebuf=3 name="moba" vostorage="vomoba/gardmanbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
这个嘛……没见过那种东西呢[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig02.png"  ]
[tb_start_text mode=4 ]
#fullmoon
呵呵　不必隐瞒也无妨哦[p]
#fullmoon
你现在就恨不得立刻杀了我吧？[l][r]
#fullmoon
呐，新月的幸存者[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE04.png"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_image_hide  time="300"  ]
[wait  time="3000"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE05.png"  ]
[tb_start_text mode=1 ]
#yui
哼，既然被识破那就没办法了[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[jump  storage="scene3.ks"  target="*bare"  ]
*rabi03ok

[cm  ]
[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yuiboybase1.mp3"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
啊，那件事我当然很清楚[r]毕竟那家伙可是[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyagi/yagibase1.mp3"  ]
[tb_start_text mode=1 ]
#yui
[font size=30 font color=0xff0000 font bold=true]因为那个人就在您的眼前[resetfont][p]
[_tb_end_text]

[stopbgm  time="3000"  fadeout="true"  ]
[tb_image_hide  time="300"  ]
[wait  time="3000"  ]
[jump  storage="scene3.ks"  target="*bare"  ]
*bare

[cm  ]
[chara_hide  name="yui"  time="100"  wait="true"  pos_mode="false"  ]
[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[playbgm  volume="60"  time="300"  loop="true"  storage="kiki.mp3"  fadein="true"  ]
[tb_start_tyrano_code]
[chara_show  name="yui"  layer="2" time="300"  wait="true"  storage="chara/1/yuiC02.png"  width="720"  height="720"  left="700"  ]
[vostop]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yui{number}.mp3" number=36]
[voconfig sebuf=3 name="fullmoon" vostorage="vored/red{number}.mp3" number=21]
[voconfig sebuf=3 name="moba" vostorage="vomoba/gardmanbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voicon.gif"  width="36"  height="27"  x="265"  y="500"  _clickable_img=""  name="img_193"  ]
[wait  time="1500"  ]
[tb_start_text mode=4 ]
#fullmoon
过去两天里[r]已有两位公爵千金和一位王子相继失踪[l][r]
#fullmoon
都与我们满月家族渊源颇深[p]
#fullmoon
而今晚……[r]果然如我所料找上门来了呢[p]
#
[_tb_end_text]

[camera  time="1000"  zoom="0.94"  wait="true"  layer="0"  x="0"  y="0"  rotate="0"  ease_type="ease"  ]
[tb_start_tyrano_code]
[chara_show  name="moba"  layer="1" time="300"  wait="true"  storage="chara/6/mob03.png"  width="830"  height="720"  left="50"  ]

[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="vomoba/gardman1.mp3"  ]
[tb_start_text mode=1 ]
#moba
嚯？这小鬼就是连环杀手？[r]毛都没长齐嘛[p]
#fullmoon
那家伙就算长这样也活了几百年[r]稍不注意你们的喉咙就会被咬断哦[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vomoba/gardman2.mp3"  ]
[tb_start_text mode=4 ]
#moba
切 我知道啦[p]
#moba
抓到你的话能领到巨额赏金[l][r]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="vomoba/gardman3.mp3"  ]
[tb_start_text mode=4 ]
#moba
咱这不是缺钱花嘛[r]别见怪啊[p]
[_tb_end_text]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiC03.png"  ]
[tb_start_text mode=4 ]
#yui
一个个都这么好骗……[r]所以说最讨厌兔人了[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yuibase1.mp3"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiC02.png"  ]
[tb_start_text mode=4 ]
#yui
地球人……[r]这个星球上智商最高的生物[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="voyui/yuibase1.mp3"  ]
[tb_start_text mode=4 ]
#yui
那又怎样[r]论撕肉的爪牙我可不会输给你们[p]
[_tb_end_text]

[tb_start_tyrano_code]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yui{number}.mp3" number=37]
[voconfig sebuf=3 name="fullmoon" vostorage="vored/red{number}.mp3" number=24]
[voconfig sebuf=3 name="moba" vostorage="vomoba/gardmanbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiC04.png"  ]
[tb_start_text mode=4 ]
#yui
我是尤伊·布拉格多格[r]新月最后的巨犬幸存者[p]
#yui
就算同归于尽[r]我也要把你拖进地狱最深处！[p]
#
[_tb_end_text]

[stopbgm  time="1000"  fadeout="true"  ]
[tb_image_hide  time="100"  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[tb_start_tyrano_code]
[vostop]
;主人公キャラ退場
@chara_hide name="moba" layer="1" zindex=1005 time=0
@chara_hide name="yui" layer="2" zindex=1005 time=0
[_tb_end_tyrano_code]

[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[reset_camera  time="1000"  wait="true"  layer="layer_camera"  ease_type="ease"  ]
[bg  time="100"  method="crossfade"  storage="anten.png"  ]
[cm  ]
[movie  volume="100"  storage="moimi.mp4"  skip="true"  ]
[tb_start_tyrano_code]
; 歯車ボタン（メニューボタン）非表示
[hidemenubutton]
[clearfix]
;[add_theme_button]


;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save6.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load6.png" x="160" y="690"]
; オートボタン
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto6.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip6.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog8.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config6.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
;	名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="18" x="350" y="400" width="340"]
[_tb_end_tyrano_code]

*mvend

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="1000"  method="crossfade"  storage="still15.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[stopbgm  time="1000"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[font size=15]

;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yui{number}.mp3" number=39]
[voconfig sebuf=3 name="fullmoon" vostorage="vored/red{number}.mp3" number=25]
[voconfig sebuf=3 name="moba" vostorage="vomoba/gardman{number}.mp3" number=4]
[vostart]
[_tb_end_tyrano_code]

[tb_image_show  time="100"  storage="default/voion3.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_233"  ]
[tb_start_text mode=4 ]
#moba
啧 真难缠[l][r]
#moba
以为是个小鬼[r]结果是个不得了的怪物啊[p]
#moba
喂 这家伙怎么处理？[p]
#fullmoon
他杀害了两名兔人[r]作为兔人之王 绝不能宽恕此罪[p]
#yui
我是……新月的第一王女……[r]如今王已不在[r]我必须为子民而战……[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still33.png"  ]
[tb_start_text mode=4 ]
#fullmoon
…………[r]所谓王 是建立在国家存在的基础上[p]
#fullmoon
国家即土地与人民[r]失去一切的你[r]不过是个自称王女的罪人罢了[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="still46.png"  ]
[tb_start_text mode=4 ]
#fullmoon
你们的护卫任务到此为止了[p]
#fullmoon
所有人都给我出去[r]这怪物的残骸将成为你们一生的噩梦[p]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="2000"  method="crossfade"  storage="still50.png"  ]
[mask_off  time="2000"  effect="fadeOut"  ]
[wait  time="2000"  ]
[bg  time="0"  method="crossfade"  storage="still51.png"  ]
[wait  time="600"  ]
[bg  time="0"  method="crossfade"  storage="still52.png"  ]
[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="still53.png"  ]
[wait  time="2000"  ]
[bg  time="0"  method="crossfade"  storage="still54.png"  ]
[wait  time="300"  ]
[bg  time="0"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="2000"  ]
[tb_start_text mode=4 ]
#fullmoon
……终于只剩我们两个人了[p]
[_tb_end_text]

[bg  time="2000"  method="crossfade"  storage="still34.png"  ]
[wait  time="1000"  ]
[playbgm  volume="100"  time="3000"  loop="true"  storage="utyu.mp3"  ]
[tb_start_text mode=4 ]
#fullmoon
来吧 站起来[r]你不是要邀请我跳舞吗？[p]
#fullmoon
我一直都在等着你[p]
[_tb_end_text]

[bg  time="2000"  method="crossfade"  storage="antenbase.png"  ]
[tb_start_text mode=4 ]
#fullmoon
在月亮坠落地球的300年前[r]我的祖先曾对你的故乡发动过战争[p]
#fullmoon
知道是为什么吗？[p]
[_tb_end_text]

[bg  time="2000"  method="crossfade"  storage="still35.png"  ]
[tb_start_text mode=4 ]
#fullmoon
只因在那片唯一能开出食物的花田里[r]出现了一头巨犬[p]
#fullmoon
明明存在传承记忆的方法[r]本该有心意相通的途径[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="still47.png"  ]
[tb_start_text mode=4 ]
#fullmoon
可那只兔子却没有这么做[p]
#fullmoon
只因畏惧比他们庞大得多的你们[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[tb_start_text mode=4 ]
#fullmoon
克服恐惧本就是件值得骄傲的事[p]
#fullmoon
所有人都兴高采烈地炫耀着那个故事[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still36.png"  ]
[tb_start_text mode=4 ]
#fullmoon
……　……[r]那种故事究竟有趣在哪里……[p]
#fullmoon
大家都不正常[r]脑子某处已经疯掉了[p]
#fullmoon
将新月焚烧殆尽[r]却轻蔑地称那些逝者为月兽（Moonster）[p]
#fullmoon
最后竟将他们自己的残暴行径[r]当作丰功伟绩讲述给地球人听[p]
#fullmoon
仿佛我们兔子才更像怪物……[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still37.png"  ]
[tb_start_text mode=4 ]
#fullmoon
地球人都很聪明[p]
#fullmoon
改头换面凌驾于他们的兔人们[r]全都沉醉于自己的力量之中[p]
#fullmoon
就像巨犬们那样……[r]说不定下次就会袭向地球人[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still34.png"  ]
[tb_start_text mode=4 ]
#fullmoon
我害怕那些家伙[l][r]
#fullmoon
我根本不可能胜任他们的统领[p]
#fullmoon
喂　快点说服我啊[l][r]
#fullmoon
用欺骗他们的那张嘴 说着同样的话[p]
#fullmoon
快点 把我 吃掉吧[p]
#
[_tb_end_text]

[wait  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="antenbase.png"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="tataku.mp3"  ]
[wait  time="2000"  ]
[bg  time="1000"  method="crossfade"  storage="still38.png"  ]
[tb_start_text mode=1 ]
#yui
真恶心……[p]
#yui
谁要吃你这种东西啊[p]
#yui
在谁都抢不走的[r]安全之处 永远活下去吧[p]
#yui
就这样 让你们一生都为自己犯下的罪受苦吧……[p]
#
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="nige.mp3"  ]
[bg  time="600"  method="crossfade"  storage="still38a.png"  ]
[wait  time="2000"  ]
[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=2 name="fullmoon" vostorage="vored/red{number}.mp3" number=54]
[voconfig sebuf=2 name="moba" vostorage="vomoba/gardman{number}.mp3" number=7]
[vostart]
[_tb_end_tyrano_code]

[bg  time="1000"  method="crossfade"  storage="still40.png"  ]
[wait  time="600"  ]
[tb_start_text mode=4 ]
#moba
啊—啊[r]被甩了 真难堪啊[p]
#fullmoon
…… …… 我应该说过让你滚出去[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still41.png"  ]
[tb_start_text mode=4 ]
#moba
要是你有个三长两短 掉脑袋的可是我们啊[p]
#moba
话说 最后不还是让人给逃了吗[r]这样真的好吗？[p]
#fullmoon
……　……　没有月光的夜晚 想必你也找不到路了[r]就算不补刀 横竖也是曝尸荒野的命[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#moba
哼 谁知道呢……[p]
#moba
我们可没听说还要对付那种怪物[r]差点就交代在那儿了[p]
#fullmoon
没及时通知你们 我道歉[r]但这也是看中了你们的本事[p]
#moba
哈！区区雇佣兵 可当不起您这般抬举[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still44.png"  ]
[tb_start_text mode=4 ]
#moba
不过是想要些死了也不心疼的棋子罢了[p]
#moba
你也没变啊 跟其他兔人一个德性[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still45.png"  ]
[tb_start_text mode=4 ]
#moba
管你是稀有种还是什么 兔人族啊[r]好像都把我们人类看扁了是吧[p]
#moba
你们这些傲慢家伙 看不顺眼的人要多少有多少[p]
#moba
要是让那些人听到刚才的话……[l][r]
#moba
你猜会怎样？[p]
#fullmoon
……是我不好[r]报酬按原价三倍准备吧[p]
#moba
这么爽快真是帮大忙了[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still43.png"  ]
[tb_start_text mode=4 ]
……　……[p]
#moba
你　不就是想被那个怪物杀掉吗[l][r]
#moba
现在赶过去　说不定还来得及呢[p]
#moba
难得的美人服务[r]要瞒着士兵们跟踪你吗[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="still42.png"  ]
[tb_start_text mode=4 ]
#fullmoon
……不需要[p]
#fullmoon
我们兔人族的地狱　远比想象中要残酷得多[p]
#fullmoon
能明白这一点　就已经足够了[p]
#
[_tb_end_text]

[tb_start_tyrano_code]
[clearfix]
[_tb_end_tyrano_code]

[bg  time="5000"  method="crossfade"  storage="antenbase.png"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[wait  time="5000"  ]
*gohome

[cm  ]
[tb_image_hide  time="100"  ]
[wait  time="3000"  ]
[bg  time="2000"  method="crossfade"  storage="still55.png"  ]
[wait  time="1000"  ]
[playbgm  volume="100"  time="1000"  loop="false"  storage="touboe.mp3"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still20.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1300"  ]
[bg  time="0"  method="crossfade"  storage="gohan00.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still05.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1300"  ]
[bg  time="0"  method="crossfade"  storage="base012.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1300"  ]
[bg  time="0"  method="crossfade"  storage="gohan02.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still09.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1300"  ]
[bg  time="0"  method="crossfade"  storage="base013.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still20.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1300"  ]
[bg  time="0"  method="crossfade"  storage="still27.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still23.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1100"  ]
[bg  time="0"  method="crossfade"  storage="still28.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still56.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1500"  ]
[bg  time="0"  method="crossfade"  storage="still47.png"  ]
[mask  time="1800"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[bg  time="0"  method="crossfade"  storage="still26b.png"  ]
[wait  time="100"  ]
[mask_off  time="0"  effect="fadeOut"  ]
[wait  time="1500"  ]
[bg  time="100"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="1000"  ]
[stopbgm  time="500"  fadeout="false"  ]
[wait  time="3000"  ]
[tb_image_show  time="100"  storage="default/voion3.png"  width="36"  height="27"  x="230"  y="62"  _clickable_img=""  name="img_233"  ]
[wait  time="2000"  ]
[bg  time="2000"  method="crossfade"  storage="still30.png"  ]
[tb_start_tyrano_code]
;メニューボタン
; クイックセーブボタン
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_14/image/button/save5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/save6.png" x="80" y="690"]
; クイックロードボタン
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_14/image/button/load5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/load6.png" x="160" y="690"]
; オートボタン
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_14/image/button/auto5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/auto6.png" x="240" y="690"]
; スキップボタン
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_14/image/button/skip5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/skip6.png" x="320" y="690"]
; バックログボタン
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_14/image/button/backlog5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/backlog8.png" x="400" y="690"]
;コンフィグボタン
;コンフィグボタン（※sleepgame を使用して config.ks を呼び出しています）
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_14/image/button/config5.png" enterimg="../others/plugin/theme_kopanda_14/image/button/config6.png" storage="../others/plugin/theme_kopanda_14/config.ks" x="510" y="690"]
; メッセージウィンドウ非表示ボタン[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_14/image/button/close.png" enterimg="../others/plugin/theme_kopanda_14/image/button/close2.png" x="1250" y="690"]

[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[font size=15]
[vostop]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yui{number}.mp3" number=44]
[vostart]
[_tb_end_tyrano_code]

[playbgm  volume="100"  time="1000"  loop="true"  storage="kaisou.mp3"  fadein="true"  ]
[tb_start_text mode=1 ]
#yui
不是秘密场所　也没关系了[p]
#yui
没想到还有其他知道这个地方的孩子　……[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="vosara/sara{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
是　我的错吗？[p]
#yui
都怪我去　那座山丘上玩[p]
#yui
但是那天　是我的生日啊[r]所以才需要　至少摘一朵花的……[p]
#yui
妈妈做了草莓酱　一直在等我[p]
#yui
本来要和爸爸　我们三个一起[r]吃蛋糕的……[p]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yui{number}.mp3" number=46]
[voconfig sebuf=3 name="sazanka" vostorage="vosazanka/sazanka{number}.mp3" number=11]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
我已经　什么都没有了[p]
#yui
爸爸　妈妈……好想见你们啊……[p]
#
[_tb_end_text]

[wait  time="2000"  ]
[bg  time="2000"  method="crossfade"  storage="still31.png"  ]
[wait  time="3000"  ]
[bg  time="1000"  method="crossfade"  storage="still32.png"  ]
[wait  time="3000"  ]
[tb_start_text mode=4 ]
#sazanka
看来你真的很爱你的父母呢[p]
#sazanka
那两个人　一定也　非常珍惜小唯吧[p]
#sazanka
才不是　一无所有[r]被爸爸妈妈珍视的小唯　就在这里啊[p]
#sazanka
谢谢你　好好地回来了[l][r]
#sazanka
因为重要的唯酱去了危险的地方　让人很担心呢[p]
#sazanka
欢迎回家　小唯[r]我来给你处理伤口　准备饭菜吧[p]
#
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="antenbase.png"  ]
[wait  time="3000"  ]
*lastdinner

[cm  ]
[bg  time="1000"  method="crossfade"  storage="gohan04.png"  ]
[tb_start_tyrano_code]
;みず
[button target=*dok enterimg=button/g03wateronM.png clickimg=button/g03water.png x=724 y=199 graphic=button/g03water.png]
;ごはん
[button target=*dok enterimg=button/g03riceonM.png clickimg=button/g03rice.png x=398 y=269 graphic=button/g03rice.png]
;しちゅ
[button target=*dok enterimg=button/g03stewonM.png clickimg=button/g03stew.png x=529 y=231 graphic=button/g03stew.png]
;さらだ
[button target=*dok enterimg=button/g03saradaonM.png clickimg=button/g03sarada.png x=733 y=274 graphic=button/g03sarada.png]
[_tb_end_tyrano_code]

[s  ]
*dok

[cm  ]
[bg  time="1000"  method="crossfade"  storage="still39.png"  ]
[tb_start_text mode=1 ]
#sazanka
[font size=15]调味怎么样……[r]合你口味吗？[p]
#yui
……好吃是好吃　就是有点淡…？[p]
#sazanka
我的料理可是用「健康有机」食材做的啊[p]
#yui
蜡像还需要讲究健康吗[p]
#sazanka
……　可能　从来没想过吧　……　哈哈[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#sazanka
距离下次宴会还有100年呢[r]时间要多少有多少[p]
#sazanka
复仇也好　和平生活也罢　……　[r]只要是唯想要做的　我都会奉陪到底[p]
#sazanka
你看　公主殿下总得有个随从对吧？[p]
#yui
……　哼　[r]Moonster最底层的Candoll也配当随从？[p]
#sazanka
在无月之夜为你照亮脚下　这点事还是做得到的[p]
#sazanka
虽然　可能也就这点用处了　……[l][r]
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yui{number}.mp3" number=51]
[voconfig sebuf=3 name="sazanka" vostorage="vosazanka/sazankaa{number}.mp3" number=24]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#sazanka
我会永远追随在唯身边[p]
#yui
……　也是呢[p]
#
[_tb_end_text]

[tb_image_hide  time="300"  ]
[tb_start_tyrano_code]
[clearfix]
;	メッセージウィンドウの設定
[position layer="message0" width="580" height="130" top="400" left="350"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message3.png" margint="10" marginl="10" marginr="10" opacity="&mp.frame_opacity" page="fore"]
[_tb_end_tyrano_code]

[bg  time="1000"  method="crossfade"  storage="anten.png"  ]
[tb_start_text mode=1 ]
[font size=15]月亮坠落到地球已过去300年[p]
在这颗兔人与地球人结盟的星球上[p]
无月之夜能照明的　唯有一支蜡烛[p]
现在　……　这样便足够了[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  graphic="anten.png"  ]
[tb_image_hide  time="1000"  ]
[tb_eval  exp="sf.rousoku='ok'"  name="rousoku"  cmd="="  op="t"  val="ok"  val_2="undefined"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]
[add_theme_button]
; 名前部分のメッセージレイヤ削除
[free name="chara_name_area" layer="message0"]
; 名前枠の設定
[ptext name="chara_name_area" layer="message0" color="0xf4dda5" size="23" x="268" y="532" width="480" align="left"]
[chara_config ptext="chara_name_area"]

[vostop]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="5000"  fadeout="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[wait  time="5000"  ]
[jump  storage="title_screen.ks"  target="*title"  ]
*fullmoonno02

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]

;ボイス設定
[voconfig sebuf=3 name="fullmoon" vostorage="vored/redbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[chara_show  name="fullmoon"  time="0"  wait="true"  storage="chara/5/fullmoonbig01.png"  width="720"  height="792"  left="200"  top="-36"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiA03.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#fullmoon
哎呀……　真是张陌生的面孔呢[l][r]请问阁下从何国而来？[p]
#fullmoon
很抱歉　我们被告知　谢绝与未经预约的异国人士交往[p]
#fullmoon
能否改日再约？[p]
[_tb_end_text]

[chara_hide  name="fullmoon"  time="600"  wait="true"  pos_mode="false"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiA05.png"  ]
[tb_start_text mode=1 ]
#yui
（被拒之门外了　……[r]　以这副模样　看来是无法见到她了　……）[p]
#
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[jump  storage="scene3.ks"  target="*gameover"  ]
*fullmoonno03

[mask  time="100"  effect="fadeIn"  color="0x000000"  graphic="antenbase.png"  ]
[tb_start_tyrano_code]
; メッセージウィンドウの設定
[position layer="message0" width="922" height="233" top="487" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_14/image/frame_message.png" margint="65" marginl="268" marginr="50" opacity="&mp.frame_opacity" page="fore"]

;ボイス設定
[voconfig sebuf=3 name="fullmoon" vostorage="vored/redbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[cm  ]
[wait  time="2000"  ]
[bg  storage="base01.png"  time="1000"  ]
[mask_off  time="100"  effect="fadeOut"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="Jack.mp3"  ]
[chara_show  name="fullmoon"  time="0"  wait="true"  storage="chara/5/fullmoonbig01.png"  width="720"  height="792"  left="200"  top="-36"  ]
[chara_show  name="yui"  time="0"  wait="true"  storage="chara/1/yuiB01.png"  width="720"  height="720"  left="700"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[add_theme_button]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#fullmoon
哎呀……　真是张陌生的面孔呢[l][r]请问阁下从何国而来？[p]
#fullmoon
很抱歉　我们被告知　谢绝与未经预约的异国人士交往[p]
#fullmoon
能否改日再约？[p]
[_tb_end_text]

[chara_hide  name="fullmoon"  time="600"  wait="true"  pos_mode="false"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiB04.png"  ]
[tb_start_text mode=1 ]
#yui
（被拒之门外了　……[r]　以这副模样　看来是无法见到她了　……）[p]
#
[_tb_end_text]

[tb_start_tyrano_code]
[vostop]
[_tb_end_tyrano_code]

[jump  storage="scene3.ks"  target="*gameover"  ]
*rabi01ng

[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[cm  ]
[tb_image_hide  time="100"  ]
[tb_start_tyrano_code]
[iscript]
TYRANO.kag.stat.charas['yui'].jname = '尤伊'
[endscript]
[vostop]
;ボイス設定
[voconfig sebuf=3 name="yui" vostorage="voyui/yuiboybase{number}.mp3" number=1]
[voconfig sebuf=3 name="fullmoon" vostorage="vored/redbase{number}.mp3" number=1]
[vostart]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#yui
我来自这颗星球极东之地——松赞市的奈伊国[r]专程为睹您风采而来[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig03.png"  ]
[tb_start_text mode=1 ]
#fullmoon
？？？　[r]从未听说过这样的国度呢[p]
[_tb_end_text]

[chara_mod  name="fullmoon"  time="0"  cross="true"  storage="chara/5/fullmoonbig01.png"  ]
[tb_start_text mode=1 ]
#fullmoon
禁止与来历不明者交谈[p]
#fullmoon
神秘的旅人呀[r]有缘再会吧[p]
[_tb_end_text]

[chara_hide  name="fullmoon"  time="600"  wait="true"  pos_mode="false"  ]
[chara_mod  name="yui"  time="0"  cross="true"  storage="chara/1/yuiE06.png"  ]
[tb_start_text mode=1 ]
#yui
（啧　果然　对女王说谎　行不通呢）[p]
（被委婉地拒绝了　……）[p]
#
[_tb_end_text]

*gameover

[cm  ]
[stopbgm  time="2000"  fadeout="true"  ]
[tb_hide_message_window  ]
[chara_hide_all  time="1000"  wait="true"  ]
[bg  time="300"  method="crossfade"  storage="anten.png"  ]
[tb_ptext_show  x="373"  y="262"  size="75"  color="0xfff6e8"  time="1000"  text="GAME&nbsp;OVER..."  face="BestTen-DOT"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_start_tyrano_code]
;retry
[button target=*retrygo enterimg=button/retryonM.png clickimg=button/retry.png x=370 y=550 graphic=button/retry.png]
;back
[button target=*backgo enterimg=button/titlebackonM.png clickimg=button/titleback.png x=680 y=550 graphic=button/titleback.png]
[_tb_end_tyrano_code]

[s  ]
*retrygo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="choise.ks"  target="*photo3"  ]
*backgo

[cm  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bad.mp3"  ]
[tb_ptext_hide  time="300"  ]
[jump  storage="title_screen.ks"  target="*title"  ]
