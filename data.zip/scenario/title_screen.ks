[_tb_system_call storage=system/_title_screen.ks]

*tt00

[hidemenubutton]

[tb_clear_images]

[tb_keyconfig  flag="0"  ]
[tb_hide_message_window  ]
[bg  storage="aten.png"  time="1000"  ]
[l  ]
[playse  volume="100"  time="1000"  buf="0"  storage="love.mp3"  ]
*title

[bg  storage="titlebase.png"  time="1000"  ]
[jump  storage="title_screen.ks"  target="*rou"  cond="sf.rousoku=='ok'"  ]
[tb_start_tyrano_code]
;はじめから
[button target=*start enterimg=button/startbotanonM.png clickimg=button/startbotan.png x=550 y=500 graphic=button/startbotan.png]
;つづきから
[button target=*load enterimg=button/tudukionM.png clickimg=button/tuduki.png x=550 y=550 graphic=button/tuduki.png]
[_tb_end_tyrano_code]

[s  ]
*rou

[jump  storage="title_screen.ks"  target="*ex"  cond="sf.exkaiho=='ok'"  ]
[tb_start_tyrano_code]
;はじめから
[button target=*start enterimg=button/startbotanonM.png clickimg=button/startbotan.png x=550 y=500 graphic=button/startbotan.png]
;つづきから
[button target=*load enterimg=button/tudukionM.png clickimg=button/tuduki.png x=550 y=550 graphic=button/tuduki.png]
;rou
[button target=*sazasp enterimg=button/rouonM.png clickimg=button/rou.png x=1190 y=625 graphic=button/rou.png]
[_tb_end_tyrano_code]

[s  ]
*ex

[tb_start_tyrano_code]
;はじめから
[button target=*start enterimg=button/startbotanonM.png clickimg=button/startbotan.png x=550 y=500 graphic=button/startbotan.png]
;つづきから
[button target=*load enterimg=button/tudukionM.png clickimg=button/tuduki.png x=550 y=550 graphic=button/tuduki.png]
;rou
[button target=*sazasp enterimg=button/rouonM.png clickimg=button/rou.png x=1190 y=625 graphic=button/rou.png]
;ex
[button target=*extras enterimg=button/exbotanonM.png clickimg=button/exbotan.png x=550 y=600 graphic=button/exbotan.png]
[_tb_end_tyrano_code]

[s  ]
*start

[cm  ]
[tb_keyconfig  flag="1"  ]
[tb_eval  exp="f.atesara=5"  name="atesara"  cmd="="  op="t"  val="5"  val_2="undefined"  ]
[tb_eval  exp="f.atepill=5"  name="atepill"  cmd="="  op="t"  val="5"  val_2="undefined"  ]
[tb_eval  exp="f.hazimepill=5"  name="hazimepill"  cmd="="  op="t"  val="5"  val_2="undefined"  ]
[tb_eval  exp="f.omakebgm=0"  name="omakebgm"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[jump  storage="scene1.ks"  target=""  ]
[s  ]
*load

[cm  ]
[showload]

[jump  target="*title"  storage=""  ]
[s  ]
*extras

[cm  ]
[jump  storage="omake.ks"  target="*extras00"  ]
*sazasp

[cm  ]
[jump  storage="scene4.ks"  target="*0400"  ]
