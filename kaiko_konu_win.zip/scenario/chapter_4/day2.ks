;-------------------------------------------------------------------------------
*part4
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '四章二日目'"]
;アホの量　なんでこんなに増えたのか全然わからん
;-------------------------------------------------------------------------------
[chara_face name="ituki" face="normalG_s" storage="chara/ituki/sihuku/normalG_s.png"]
[chara_face name="ituki" face="angry_s" storage="chara/ituki/sihuku/angry_s.png"]
[chara_face name="ituki" face="angryN_s" storage="chara/ituki/sihuku/angryN_s.png"]
[chara_face name="ituki" face="cry_s" storage="chara/ituki/sihuku/cry_s.png"]
[chara_face name="ituki" face="cry1_s" storage="chara/ituki/sihuku/cry1_s.png"]
[chara_face name="ituki" face="cry2_s" storage="chara/ituki/sihuku/cry2_s.png"]
[chara_face name="ituki" face="cry3_s" storage="chara/ituki/sihuku/cry3_s.png"]
[chara_face name="ituki" face="cry4_s" storage="chara/ituki/sihuku/cry4_s.png"]
[chara_face name="ituki" face="cry5_s" storage="chara/ituki/sihuku/cry5_s.png"]
[chara_face name="ituki" face="hate_s" storage="chara/ituki/sihuku/hate_s.png"]
[chara_face name="ituki" face="hateG_s" storage="chara/ituki/sihuku/hateG_s.png"]
[chara_face name="ituki" face="lookAway_s" storage="chara/ituki/sihuku/lookAway_s.png"]
[chara_face name="ituki" face="sad_s" storage="chara/ituki/sihuku/sad_s.png"]
[chara_face name="ituki" face="sadB_s" storage="chara/ituki/sihuku/sadB_s.png"]
[chara_face name="ituki" face="sadG_s" storage="chara/ituki/sihuku/sadG_s.png"]
[chara_face name="ituki" face="shame_s" storage="chara/ituki/sihuku/shame_s.png"]
[chara_face name="ituki" face="shout_s" storage="chara/ituki/sihuku/shout_s.png"]
[chara_face name="ituki" face="smile_s" storage="chara/ituki/sihuku/smile_s.png"]
[chara_face name="ituki" face="smileLA_s" storage="chara/ituki/sihuku/smileLA_s.png"]
[chara_face name="ituki" face="smileW_s" storage="chara/ituki/sihuku/smileW_s.png"]
[chara_face name="ituki" face="tweet_s" storage="chara/ituki/sihuku/tweet_s.png"]
[chara_face name="ituki" face="tweetB_s" storage="chara/ituki/sihuku/tweetB_s.png"]
[chara_face name="ituki" face="tweetG_s" storage="chara/ituki/sihuku/tweetG_s.png"]
[chara_face name="ituki" face="tweetLA_s" storage="chara/ituki/sihuku/tweetLA_s.png"]

[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[mask folder="bgimage" graphic="still/part4.png" time="3000"]
[wait time="2000"]
[bg storage="koen_m.png" time="10"]
[chara_face name="kirie" face="normal_s" storage="chara/kirie/summer/normal.png"]
[chara_face name="kirie" face="hate_s" storage="chara/kirie/summer/hate.png"]
[chara_face name="kirie" face="lookAway_s" storage="chara/kirie/summer/lookAway.png"]
[chara_face name="kirie" face="angry_s" storage="chara/kirie/summer/angry.png"]
[chara_face name="kirie" face="sad_s" storage="chara/kirie/summer/sad.png"]
[chara_face name="kirie" face="smile_s" storage="chara/kirie/summer/smile.png"]
[chara_face name="kirie" face="smileW_s" storage="chara/kirie/summer/smileW.png"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[mask_off time="100"]
[font size="40"]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = '？？'
[endscript]
#
[stopbgm]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[quake time="30"]
马门君！[p][resetfont]
[chara_show name="kirie" face="smile_s" left="150" top="-10" wait="true" time="2000"]
#kirie
[playbgm storage="faure-op84-5.ogg" loop=true volume="40" sprite_time="0000-76400"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
呀吼呀吼！喂、你听我说！！[p]

#makado
雾绘…………[l][r]
差不多该和小谷坂的人出去玩了吧……[p]

#makado
要是一直和我混在一起，第二学期开始你也交不到朋友的[p]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = '宗方 きりえ'
[endscript]

#kirie:angry_s
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
吵死了啊。[p]
#kirie:smile_s
比起那个你快看，瞧！[r]
三山同学家今天早上送了我超多花！[p]
#kirie:smileW_s
也分你一些，我们一起去神社吧！[p]
#
雾绘将背在身后的花束捧到面前。[p]

#makado
(……供佛的花……)[p]

#makado
谁告诉你我在这里的？[p]

#kirie:normal_s
享四郎。[l][r]　
#kirie:smileW_s
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
『贤治郎啊，[r]
在雾绘来之前就害羞跑掉啦——』[p]

#makado
……老爸这玩笑开得真恶劣[p]
[delay speed="100"]
#kirie:angry_s
话说回来，你刚才是要买果汁吧？[r][resetdelay]
#kirie:hate_s
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
也给我买嘛——请我喝嘛——[p]

#makado
啊—好好好……[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_mod name="kirie" face="normal_s"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="2000"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="2000"]
;ＳＥがこん
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
给[p]

#kirie
……[wait time="500"]
#kirie:smile_s
呵呵[p]
[delay speed="70"]
#
明明只是像往常一样递给她汽水……[r]
她却莫名笑了起来。[p]
[resetdelay]
#makado
怎么了，你想要别的吗？[p]

#kirie:normal_s
不是啦。这个就行。[l][r]
#kirie:smile_s
[delay speed="50"]
这样就很好，我是因为开心才笑的啦[p]
[resetdelay]
#kirie:angry_s
话说啊——马门君你经常用自动贩卖机，[r]
但易拉罐垃圾处理起来很麻烦的耶。你不如带个水壶吧[p]

#makado
烦死了[p]

#kirie:hate_s
[quake time="30"]
[font size="40"]
哈——！？[p][resetfont]
[delay speed="100"]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
雾绘一边瞪着我，[r]
她猛地抡起装满碳酸饮料的易拉罐……！[p]
[delay speed="10"]
#makado
[quake time="30"]
喂！别拿饮料乱挥啊！[p]

#kirie:smile_s
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
哈哈哈！看你能往哪逃！[p]
[chara_hide name="kirie" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[mask time="2000"]
[fadeoutbgm time="3000"]
[wait time="1000"]
[bg storage="brack.png" time="10"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[clearfix]
#
[delay speed="50"]
[mask_off time="2000"]
[playse storage=page.ogg volume="50"]
今晚的　读物是　横跨银河的　铁道物语[l][r]
[r]
[r]
[r]
最近净读这个人的作品会不会腻呀？[wait time="500"][r]
[delay speed="80"]
……但请原谅我嘛　不知怎的就是很喜欢[p]
[delay speed="50"]
[playse storage=page.ogg volume="50"]
我说　宫泽贤治他……[wait time="700"][r]
[r]
[resetdelay]
彗星是　一边说着什么[r]
你知道他写过彗星是从天而降的吗？[l][r]
[playse storage=page.ogg volume="30"]
[r]
不知道的话 姐姐告诉你呀[l][r]
[r]
[delay speed="80"]
彗星是喊着『吱吱呼—吱吱呼—』落下来的哦[l][r]
[r]
啊哈哈！岐阜什么的……[p]
[playse storage=page.ogg volume="50"]
[mask]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[wait time="2000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[bg storage="indoor/ituki_heya.jpeg" time="10"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
#
[mask_off]
——8月23日，下午1点。[p]
[chara_show name="ituki" top="-160" face="hate_s" wait="false" left="-70"]
#ituki
…………………………[p]
[delay speed="100"]
#ituki:sad_s
（……风铃……坏掉了呢……）[p]

;ＳＥゴンゴン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]

#ituki:tweet_s
……嗯？[p]

;SEコンコン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]

#
……怎么回事？[r]
从窗户那边，传来了声音。[p]

;SEコンコン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]
;ＳＥゴンゴン
[chara_hide name="ituki" wait="false"]
#ituki
………………[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]

#
向外望去。[p]
[font size="40"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……啊、哎！？[p][resetfont]
[resetdelay]
#ituki:sadB_s
啊、啊、等等、我现在就开……[p]
[fadeoutbgm time="2000"]

;ＳＥ引き戸
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="sarasa" face="normal_c" left="360" wait="false" top="-160"]
[delay speed="60"]
#sarasa
……哈啊、谢谢你，一树……[p]
[font size="40"]
[chara_show name="ituki" wait="true" time="100" face="shout_s" left="-70" top="-160"]
#ituki:shout_s
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
你在搞什么鬼啊！？[p][resetfont][stop_kanim name=ituki]
[resetdelay]
#sarasa
我来还之前借的东西。给[p]

;アイテムスチル；モバイルバッテリー
[image layer=0 folder="image" name="moba" storage="item/moba.png" width="460" x="270" y="107" time="800"]
#ituki:angryN_s
[delay speed="60"]
啊……！ 我的、克尔佩罗移动电源！[p]
[resetdelay]
#ituki:hate_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
为什么会在你手里！？[p]
[free layer=0 name="moba" time="500" wait="false"]

#sarasa:closeEye_c
……[p]

#sarasa:normal_c
一树的房间总是这么凉快呢……[r]
甚至有点冷……[p]

#ituki:sadB_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
（无视我！？）[p][stop_kanim name=ituki]


#ituki:hateG_s
…………[p]
[chara_face name="ituki" face="angryB_s" storage="chara/ituki/sihuku/angryB_s.png"]
#ituki:angryB_s
回去。[p]

#sarasa:worry_c
诶……怎么这样、明明才刚让我进来的……[p]

#ituki
回去。充电宝就送你了……[p]
给我回去兔，[font size="40"]
#ituki:shout_s
[chara_move name="ituki" left="300" anim="true" wait="false"]
[chara_move name="sarasa" left="500" anim="true" wait="false"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
给我滚出去熊——！！[p][resetfont]

#sarasa:closeEye_c
啊、等……等等！ 别……！[p]
[font size="40"]
[delay speed="60"]
[chara_move name="sarasa" left="360" anim="true" wait="false"]
[chara_move name="ituki" left="-70" anim="true" wait="false"]
#sarasa:worryLA_c
[playse  volume="20" buf="0" storage="sariin.ogg" ]
要不要、一起去玩啊！？！[p][resetfont]
[fadeoutbgm time="5000"]
#ituki:hate_s
哈？[p]

#sarasa:normal_c
我们……暑假后的第一个返校日。[r][wait time="500"]
明明约定过……就算不是返校日，也要一起玩的……[p]

#sarasa:worry_c
如果忘记了……也没关系……[p]

#sarasa:closeEye_c
求你了……[p]

#ituki:hate_s
…………………………[p]

#
树月叹了口气……[wait time="500"]随后低下了头。[p]

#ituki:sad_s
…………………………[l][r]
#ituki:tweetLA_s
好吧……[p]
[resetdelay]
#sarasa:normal_c
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
！　真的吗！？[p]
[delay speed="70"]
[font size="20"]
#ituki:tweetLA_s
……要去哪里呢。太远的地方的话，我去不了……[p]
[resetfont]
#sarasa
……嗯，嗯……[p]
[fadeoutbgm time="2000"]
[resetdelay]
#sarasa:smile_c
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
那个啊，我想先去咖啡店……然后去杂货铺。[r]
有想看的东西……[p]

#ituki:tweet_s
想看的东西？[p]

#sarasa:closeEye_c
嗯……[p]
[delay speed="50"]
#sarasa:normal_c
之前，[r]
去贤治郎先生家的时候，不小心打碎了他的玻璃杯。[r]
所以想找个替代品……送给他[p]
[delay speed="100"]
#ituki:hate_s
………………………[p]
[chara_mod name="ituki" face="hateG_s" cross="false" wait="false" time="500"]
[playse  volume="30" buf="0" storage="shimeage.ogg" ]
………………………………………………[p]
[playbgm storage="faure-op84-5.ogg" loop=true volume="40" sprite_time="0000-76400"]
[mask time="2000"]
[bg storage="indoor/cafe.jpeg" time="10"]
[chara_face name="mokke" face="master" storage="chara/mokke/tibiStudent.png"]
#sarasa:worry_s
[mask_off time="2000"]
;喫茶店
#sarasa
…………[p]

#ituki
…………[p]
[resetdelay]
[chara_show name="mokke" top="100" left="330" wait="false" face="master" time="100"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'マスター'
[endscript]
#mokke
你们在吵架吗？[p]
[mask time="2000"]
#sarasa:worry_c
[chara_hide name="mokke" time="10" pos_mode="false"]
[bg storage="indoor/miyage.jpeg" time="10"]
[mask_off time="2000"]

;雑貨屋
[delay speed="100"]
#sarasa
…………这个……[p]

#ituki
…………不是这样的吧[p]

#sarasa:worryLA_c
…………[p]

[mask time="2000"]
[fadeoutbgm time="2000"]
[wait time="2000"]
[bg storage="fork_a.jpg" time="10"]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=30]
;分かれ道
[mask_off time="2000"]
;ＳＥカラス

#sarasa
……[p]

#ituki
……[p]

#ituki:
那今天就先到这里拜拜啦[r]
下次给别人挑礼物的时候别再来找我了[r]
拜拜[p]
[font size="40"]
#sarasa:closeEye_c
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
等等！先别走！[p][resetfont]
[resetdelay]
#ituki:angryB_s
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
哈～！够了吧，计划不是全都完成了吗～……！[r]
还是说啊，你还想让我陪你去什么地方吗！？[p]
[delay speed="60"]
#sarasa:normal_c
[playse  volume="20" buf="0" storage="sariin.ogg" ]
希望你能来……我家里[p]

#ituki
[chara_mod name="ituki" face="hate_s" cross="false" wait="false" time="700"]
——诶？[p]

#sarasa:closeEye_c
一树……你还没来过我的房间吧。[r]
我可是去过你的房间呢……[p]
[resetdelay]
#ituki:
与其说是去过不如说是强行闯进去的喵[p]
[delay speed="60"]
#sarasa:
因为有想让你看的东西，所以希望你能来。
[chara_move name="sarasa" left="-30" anim="true" wait="false"]
#sarasa:normal_c
快点、求你了……！[p]
[chara_move name="sarasa" left="200" anim="true" wait="false"]
[chara_move name="ituki" anim="true" wait="false" left="100"]
#
我抓住树月的手，往自己家的方向拽去。[p]

#ituki:sad_s
……呜哇啊啊、啊！[p]
[font size="40"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
#ituki:sadB_s
[playse  volume="30" buf="0" storage="shimeage.ogg" ]
知道啦！知道了所以别拽了！！[p][resetfont]
[stop_kanim name=ituki]

#sarasa
[chara_move name="sarasa" left="360" anim="true" wait="false"]
[chara_move name="ituki" left="-70" anim="true" wait="false"]
……！[p][resetfont]
#ituki:angryN_s
哈啊。真是的……[p]
[delay speed="100"]
#ituki:tweetLA_s
……搞不懂。我，[wait time="700"]
#ituki:sad_s
……………………………………[p]
[mask]
[fadeoutbgm time="2000"]
#sarasa:closeEye_s
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[bg storage="indoor/sitodaHouse.jpg" time="10"]
[wse]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=10]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'アキラさん'
[endscript]

;s Eガラガラ
[mask_off]
#sarasa
我回来了……[p]
[chara_hide_all time="10"]
[resetdelay]
[chara_show name="mokke" face="akira" wait="false" top="100"]
#mokke
嗨～嗨～欢迎回来—[p]

#mokke
……啊啦[p]

#sarasa
我把一树带过来了。[r]
我先带她去房间，稍后麻烦送些饮料过来[p]
[delay speed="50"]
#mokke
好……[wait time="500"]好的，明白啦～[r]
应该没有过敏史吧？[p]

#sarasa
没问题……对吧[p]
[font size="20"]
#ituki
……没问题的……[p]
[resetfont]
#mokke
好久不见了呢。[r]
小学时候，你们还经常在客厅一起玩耍呢。[p]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
上了中学之后，[r]
你还会这样来找纱罗纱玩呀～[p]

#sarasa
因为是朋友嘛[p]

#mokke
嗯～。这样啊……[p]
[delay speed="70"]
不过啊纱罗纱，[r]
宗方家的女儿啊，你看，现在各种事情……[p]
[chara_show name="kinuyo" top="-160" face="normal" wait="false"]
#kinuyo
阿基拉[p]
[font size="40"]
#mokke
嗨！[resetfont][r]
[resetdelay]
啊，绢世小姐。怎么了？[p]
[delay speed="50"]
#kinuyo
我什么都没做，电脑就坏了。[r]
好不容易选好的游戏还在购物车里呢[p]

#mokke
绢世小姐，电脑啊，就是因为做了什么才会卡住的啦[p]
[chara_hide name="mokke" wait="false"]
;ＳＥ歩いて行く
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]

#kinuyo
……………………[p]

#kinuyo:closeEye
……别让回家时间拖得太晚啊。[r]
纱罗纱[p]
[chara_hide name="kinuyo" wait="false"]
;ＳＥ歩いて行く
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
[chara_show name="sarasa" face="normal_s" left="360" wait="false" top="-160"]
[chara_show name="ituki" face="sad_s" left="-70" wait="false" top="-160"]
#sarasa
……[l][r]
#sarasa:smile_s
好的，妈妈[p]

#sarasa:normal_s
一树……这边。房间在二楼[p]
[font size="20"]
#ituki:sad_s
啊……嗯[p][resetfont]
[mask time="2000"]
[chara_hide name="ituki" time="10"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
[bg storage="indoor/sarasaRoom_a.jpeg" time="10"]
[mask_off time="1000"]
;○部屋

;ＳＥばたん

#ituki
……………………[p]

#sarasa
一树[p]

#
树月只是将视线转向这边。[p]

#sarasa:smile_s
这个，给一树[p]

#ituki
诶？[p]

#sarasa
今天陪我玩的谢礼……。[r][wait time="500"]
请收下吧[p]
#
我将从杂货店买来的――[wait time="500"]风铃递了过去。[p]
[delay speed="100"]
#ituki
[playse  volume="20" buf="0" storage="sariin.ogg" ]
啊……哇，好漂亮……！[p]
[delay speed="50"]
#
树月从袋中取出的风铃[r]
借着窗边透进来的光，他轻轻摇晃着确认铃声。[l][r]
看来他很中意。[p]
[delay speed="100"]
#ituki
贝壳做的……好厉害，真的好厉害啊……[p]
[delay speed="50"]

#sarasa:smile_s
其实，[r]
还有凯鲁佩罗款的风铃，当时纠结了好久。[r][wait time="500"]
但和一树你房间里那个更像的，应该是这款……[p]

#ituki
哇啊……[p]
[resetdelay]
#ituki
……等等，「和一树你房间里那个」？[r]
啥玩意儿。[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
该不会…前几天趁我不在进我房间了吧？[p]

#sarasa:normal_s
…………[p]
[delay speed="100"]
#sarasa:closeEye_s
……门开着就……[p]
[chara_move name="sarasa" left="360" anim="true" wait="false"]
[chara_show name="ituki" top="-160" face="hate_s" wait="false" left="-70"]
#ituki
[delay speed="50"]
不可能啦[p]
[chara_face name="ituki" face="normal_s" storage="chara/ituki/sihuku/normal_s.png"]
#sarasa
……对不起[p]

#ituki
所以今天你才知道我房间窗户的位置啊……[p]
[delay speed="100"]
#ituki:smileLA_s
…………………………嗯—[p]
[delay speed="50"]
#ituki:normal_s
纱罗纱啊。你今天、是想和我重归于好吗？[p]

#ituki:tweetB_s
如果是这样的话，那很遗憾，我只能说对不起了。[r]
因为我们之间、从一开始就不存在能和好的关系。[p]
[delay speed="100"]
#sarasa:worry_s
不是的……[wait time="500"]不是这样的一树[p]

#sarasa:normal_s
我今天、是想向一树你……道歉的[p]

#ituki
……道歉？[p]

#sarasa:closeEye_s
总之今天呢、有三次……[wait time="500"][r]
有三件事、想要道歉[p]
[delay speed="50"]
#sarasa:normal_s
明明你一直在守护我，我却没能察觉，对不起[p]

#sarasa
在一树温柔的庇护下，[r]
我却总是无法安分守己，对不起[p]

#sarasa
还有，那个时候……[l][r]
[delay speed="70"]
#sarasa:closeEye_s
没能对你说出「我们一起去海边吧」，对不起[p]
[delay speed="50"]
#
树月歪了歪头。[p]

#ituki:tweetLA_s
……那时候？[p]

#sarasa:closeEye_s
小学时，我们不是一起……[wait time="500"][r]
我们不是一起拍过跳舞的视频吗？[p]

[mask]
[chara_hide_all time="10"]
#
[bg storage="still/dance1.png" time="10"]
[filter grayscale="100"]
[mask_off]

一树不知道海之家是什么……[p]
所以就把海之家、[r]
称作”海边的小屋”[p]

当时看着一树的侧脸　我[r][wait time="500"]
『总有一天要真的　一起去海边哦』这样……[p]
话到嘴边又咽了回去[p]
[delay speed="100"]
#
因为害怕许下　无法实现的约定――[p]
[delay speed="50"]
#
大概……冥冥之中，我早已明白。在脑海的某个角落。[r]
一树和我 必须遵循的生存法则本就不同……[p]
[mask]
[bg storage="indoor/sarasaRoom_a.jpeg" time="10"]
[chara_show name="sarasa" left="360" top="-160" face="normal_s" time="10"]
#ituki
[chara_show name="ituki" top="-160" face="tweet_s" time="10" left="-70"]
[free_filter]
[mask_off time="3000"]
[fadeoutbgm time="3000"]
……纱罗纱[p]

#sarasa:normal_s
但现在的我 想和一树定下约定[p]
#sarasa:smile_s
总有一天真的、[wait time="600"]一起去看海吧。[r]
这种贝壳什么的 要多少有多少啊[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time="5000" volume=50]
#ituki
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
――啊、[wait time="1000"]
#ituki:cry_s
……[p]
[resetdelay]
#ituki:smileLA_s
…………………………………………[r][wait time="500"]
#ituki:smileW_s
诶～真的假的。这种约定最后多半都会不了了之吧？[p]

#sarasa:angry_s
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
真的啦！绝对的约定！[p]
[delay speed="50"]
#ituki:smileLA_s
呵呵。[r]
………………………………[p]
#ituki:smileW_s
[font size="20"]
……就算现在和纱罗纱约定好了，等真的去看海时，恐怕也不会只有我们两个人吧[p]
[resetfont]
#sarasa:normal_s
咦？[p]
#ituki:normal_s
[wait time="600"]
[resetdelay]
[chara_hide name="ituki" wait="false" pos_mode="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
#ituki
――这边墙上的架子，怎么说……超级时髦呢。[r]
这些都是纱罗纱的东西吗？[p]
[delay speed="60"]
#
我正想追问，却被[r]
树月仔细打量起我身后的装饰架来。[p]

她大概是故意岔开话题吧……[r]
我便也顺势不再追问。[p]
[delay speed="50"]
#sarasa:closeEye_s
啊、嗯……。[r]
下层摆的都是珍藏的回忆。[p]
[chara_hide name="sarasa" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
上面大格子放的[r]
并排放着……[p]

#ituki
……那个，紧挨着纱罗纱的玩具，是最可爱的。[r]
旋转木马？[p]
#
树月所指的，[wait time="600"]……正如她所说，[r]
是迷你旋转木马模型。[p]
#
我将这个结构精巧的模型轻轻从架子上取下来展示。[p]
#sarasa
嗯 这个……大概是九岁左右吧。[r]
是爸爸送给我的……[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/omotya.png" wait="true" cross="false" time="5000"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……啊[p]

#ituki
怎么了？[p]

#sarasa
刚刚——[wait time="500"]想起了一件小时候的事。[l][r]
[resetdelay]
在贤治郎先生家，聊起旋转木马的事[p]
#ituki
哼嗯。嘿。那可真是太好了呀。[r]
所以呢？那个贤治郎先生怎么了[p]
#sarasa
那个啊，我……[wait time="500"]自从上次扫墓日之后就没能好好说过话。[r]
那个人，消沉得厉害……[l][r]
[delay speed="50"]
完全不是能好好说话的氛围……[p]
#sarasa
只打听到一件事[r][delay speed="100"]
「完全不记得成为眷属的事」[delay speed="50"]
就是这么个情况……[p]
[mask]
[bg storage="indoor/sarasaRoom_a.jpeg" time="10"]
[chara_show name="sarasa" left="360" top="-160" face="sad_s" time="10"]
#ituki
[chara_show name="ituki" top="-160" face="tweetLA_s" time="10" left="-70"]
[mask_off time="300"]
[resetdelay]
#ituki
但既然『茧之典』上有他的名字记载　那他毫无疑问是[r]
狮心教的眷属啊。[p]
#ituki:
那是三位官女献上[font color="0xf08080"]愿文[resetfont]之后，[r]
[font color="0xf08080"]这是为了记录被接纳为[resetfont]眷属者姓名的名册[p]
[delay speed="50"]
#sarasa:closeEye_s
……没错……是这样呢。[r][wait time="500"]
我也能清晰地看到贤治郎先生，保持着人类”的形态……[p]

#ituki:tweet_s
………………………………[p]
[delay speed="100"]
#ituki:hate_s
……那个，『马门贤治郎』这几个字——[r][wait time="100"][resetdelay]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
是雾绘写的字[p]

#sarasa:wow_s
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
……！？[font color="0xf08080"]雾绘小姐[resetfont]的？[p]

#ituki:hate_s
嗯。不会错的。那个笔迹。[r]
绝对是雾绘的字迹[p]

#sarasa:worry_s
（……雾绘小姐生前……）[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
贤治郎先生是在【本人毫不知情的情况下】被登记为眷属的，[r]
是这样吗……？[p]
[chara_mod name="sarasa" face="worryLA_s"]
[delay speed="50"]
这种事情，真的有可能吗？[r]
擅自决定他人信仰的神明这种事——[p]

#sarasa:angry_s
（……又或者）[p]
#
就像树月[r]
故意遗忘自身记忆那样，[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
贤治郎先生成为眷属那天的记忆[r][font color="0xf08080"]
被某种方式[resetfont]强行封存了吗――[p]
[fadeoutbgm time="5000"]
#sarasa
…………………………[l][r]
#sarasa:worry_s
雾绘小姐临终前这样说过[p]
#sarasa:closeEye_s
『真正的诅咒啊，是永远不会消失的。[wait time="100"]别自作多情了』[r]
这样……[p]

#ituki:tweetLA_s
……没错。[r]
那个人确实这么说过[p]

#sarasa:normal_s
终于传达给你了。[r][wait time="600"]
一直、都想把这个留言传达给一树呢[p]

#ituki:normal_s
……自从雾绘回来之后[r]
我们都没怎么说过话呢[p]
[delay speed="60"]
#sarasa:closeEye_s
好寂寞啊。总觉得、一直被躲着[p]

#sarasa:normal_s
……一树最近……[r]
记忆缺失的情况越来越频繁了吧。[r][wait time="500"]
说话方式变得奇怪、还有话题对不上的次数……明显变多了呢[p]

#ituki
……嗯　[wait time="500"]大概，消失的次数增加了。[l][r]
#ituki:smileLA_s
我觉得每天都有很多想要忘记的事情[p]
[resetdelay]
#ituki:tweetB_s
……怎么说呢。[r]
说不定雾绘其实已经死了，[r]
我一直都没能搞清楚。我……[p]
[delay speed="50"]
#ituki:tweetB_s
因为我不喜欢那么任性的姐姐。[r]
可能从一开始就没有多少关于她的回忆[r]
也说不定。[p]
关于雾绘的记忆，全都模糊不清……[p]
[delay speed="70"]
……………………………………[p]
#ituki:smileW_s
唉——要是不会再增加新的记忆的话，[r]
当初好好保存下来别扔掉就好了。[l][r]
像这个房间的宝物一样，整齐地陈列起来[p]
[delay speed="80"]
#ituki:tweetLA_s
如果能这样好好面对的话，回忆起来也许会很开心……[p]
#ituki:cry_s
……………………………………[p]
[chara_hide_all time="1000"]
#
说到这里，[r]
树月低着头……陷入了沉默。[p]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=10]
#sarasa
……[wait time="600"]一树。[p]
再和我做个约定吧[p]

#sarasa
这次…绝对不要再忘记了……。[l][r]
和我、还有雾绘经历过的事，一起说过的话，[wait time="500"][r]
就连讨厌的部分也……一件都不要[p]

#ituki
……[wait time="500"]纱罗纱[p]
[font size="20"]
#ituki
…………………………………………………………[l][r]
谢谢……风铃[p][resetfont]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="50"]
点点光芒缓缓飘落。[p]

我将手轻轻放在树月低垂的头上。[p]
[font size="20"]
#ituki
谢谢……[p]
[resetfont]
#sarasa
……[wait time="500"]嗯[p]

;回想
[mask time="1000"]
[wait time="2000"]
[filter grayscale="100"]
[bg storage="still/kirie_bridge.jpeg" time="10"]
#
[mask_off time="1000"]
[delay speed="100"]
终于、能去相见了。[p]
[mask time="100"]
[playse  volume="40" buf="0" storage="basya2.ogg"]
[wait time="500"]
[free_filter]
[bg storage="indoor/sarasaRoom_a.jpeg" time="10"]
[mask_off time="1000"]


#sarasa
（……雾绘小姐）[p]
[bg storage="brack.png" wait="false" cross="false"]
#sarasa
（那个让你不惜舍弃生命、也想要见到的人……）[p]

#sarasa
（究竟、是谁呢。）[p]

[mask time="3000"]
[wait time="3000"]
;○神社　廊下
[bg storage="indoor/makado_roka.jpeg" time="10"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="normal_e" storage="chara/makado/trueEye/normal_e.png"]
[chara_face name="makado" face="hurryB_e" storage="chara/makado/trueEye/hurryB_e.png"]
[chara_face name="makado" face="lookAway_e" storage="chara/makado/trueEye/lookAway_ce.png"]
[chara_face name="makado" face="shout_e" storage="chara/makado/trueEye/shout_e.png"]
[chara_face name="makado" face="smileMini_e" storage="chara/makado/trueEye/smileMini_e.png"]
[chara_face name="makado" face="tweetB_e" storage="chara/makado/trueEye/tweetB_e.png"]
[chara_face name="makado" face="worry_e" storage="chara/makado/trueEye/worry_e.png"]
[chara_face name="makado" face="wowB_e" storage="chara/makado/trueEye/wowB_e.png"]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="normal_ce" storage="chara/makado/trueEye_Cap/normal_ce.png"]
[chara_face name="makado" face="angry_ce" storage="chara/makado/trueEye_Cap/angry_ce.png"]
[chara_face name="makado" face="bike_ce" storage="chara/makado/trueEye_Cap/bike_ce.png"]
[chara_face name="makado" face="lookAway_ce" storage="chara/makado/trueEye_Cap/lookAway_ce.png"]
[chara_face name="makado" face="shout_ce" storage="chara/makado/trueEye_Cap/shout_ce.png"]
[chara_face name="makado" face="smile_ce" storage="chara/makado/trueEye_Cap/smile_ce.png"]
[chara_face name="makado" face="smileMini_ce" storage="chara/makado/trueEye_Cap/smileMini_ce.png"]
[chara_face name="makado" face="tweetB_ce" storage="chara/makado/trueEye_Cap/tweetB_ce.png"]
[chara_face name="makado" face="tweetLA_ce" storage="chara/makado/trueEye_Cap/tweetLA_ce.png"]
[chara_face name="makado" face="worry_ce" storage="chara/makado/trueEye_Cap/worry_ce.png"]
;-------------------------------------------------------------------------------
[chara_show name="marigan" top="-10" face="normal" time="10"]
#marigan
[mask_off time="3000"]
;ＳＥガラガラ
[resetdelay]
有人吗？[p]

#makado
……[p]

#marigan:sad
啊～啊～脸色真差。[r][delay speed="50"]
真可怜……小和尚，有好好吃饭吗？[p]
#
带着尖锐红指甲的手，抓住了我的脸。[l][r]
脱下高跟鞋进来的玛丽甘，比想象中要矮。[p]

#makado
……您找谁？找我，还是找母亲。
或者是父亲？[p]

#marigan:normal
你。[p]
#marigan:smileB
借一步说话 有东西必须转交给你呢[p]

#makado
……那个、[l][r]
……[p]

#marigan:worry
……什么？[playse  volume="20" buf="0" storage="sariin.ogg" ]
享四郎先生出事了吗？[p]
#
她似乎察觉到我视线的游移。[wait time="500"][r]
玛丽甘突然提起父亲的名字，让我有些错愕。[p]

#makado
……没有。[l][r]
父亲有母亲照顾……所以没问题的[p]
[r]
我现在就过去[p]
[mask]
[bg storage="mountainRoad_a.jpeg" time="10"]
[fadeoutbgm time="2000"]
[wait time="2000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
;○森
#marigan:smileB
[mask_off]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=30]
……你真是个孝顺父亲的孩子呢。[r]
现在读的大学也是你父亲的母校吧？[p]

#makado
……是的。那是我一直想去的学校……[r][wait time="500"]
是我任性要求继续升学的[p]

#marigan:tweetLA
现在却说想退学？[p]

#makado
反正本来就是勉强维持的学生生活，没关系的。[r]
比起这个，我现在更想陪在父亲身边[p]
[delay speed="60"]
#makado
毕竟是从鬼门关捡回来的命，下一次就……[r][wait time="800"]
不知道什么时候就会走到尽头。[l][r]
我也想守在母亲身边，免得她太过勉强自己[p]
[delay speed="50"]
#marigan:sad
……是啊。[l][r]
#marigan:sad
是啊。父母终究是父母呢……[p]
[chara_hide name="marigan" time="1000" wait="false"]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="brack.png" wait="true" cross="false" time="1000"]
;ＳＥガサガサ
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#marigan
……到了。呼，太好了。还记得路[p]
#marigan
我就是想来这里[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="hall_a.jpg" wait="true" time="3000" cross="false"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
[font size="40"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——！！[resetfont]　这、这里是……[p]
[resetdelay]
#makado
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
请稍等一下！！[r]
为什么、为什么你会知道这个地方！？[p]

#makado
这里是——[wait time="800"]传说中"奥露毛克封印"的核心所在，[r]
【封印の絹布】供奉的神殿[p]

实物如你所知已于前些日子焚毁……[r]
但神殿的具体位置，马门家世代都对外保密[r]
这是我们世代秘传的机密！[p]
[delay speed="70"]
可是纪伊玛莉甘，为什么你竟然……！[r][wait time="500"]
[quake time="30"]
你究竟、[wait time="500"]知道了多少、[wait time="500"]了解到什么程度！？[p]
#marigan
[chara_show name="marigan" top="-10" face="normal" wait="true"]
关于八种町的真相[p]

#makado
啊……？[p]

#marigan
这个地方啊　贤治郎君[r][wait time="500"]
是从你父亲那里得知的哦[p]

#makado
…………[p]

#marigan:angry
嘿……咿[p]
[chara_hide name="marigan" wait="false"]
;ＳＥギイー
[playse  volume="50" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]

#
玛丽甘走进祠堂，掀开了一块地板。[l][r]
只见地板下方，赫然露出一个空洞……[p]

而在那个洞中，安放着一个桐木小匣。[p]

带着红指甲的手指——[wait time="1000"]将匣中之物递了过来。[p]
;○アイテム：彫刻刀
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[image layer=0 folder="image" name="chokokuto" storage="item/chokokuto.png" width="500" x="250" y="52" time="800" ]
#marigan
给，这个。[r]
听说是和封印有关的重要物件[p]

#makado
这是……小刀？[p]

#marigan
与其说是小刀，更像是雕刻刀的构造呢。[r]
用来雕刻木头、修整形状的……[p]
[chara_show name="marigan" top="-10" face="smileCE" wait="true"]
#marigan
[anim name="marigan" top="+=30" time="200"]
[anim name="marigan" top="-=30" time="200"]
你看，这刀刃看起来就很锋利！[p]
[resetdelay]
#makado:closeEye_c
……很危险，请收起来吧[p]
[free layer=0 name="chokokuto" time="800" wait="false"]
#
……将接过的小刀直接收进了口袋。[p]
[delay speed="60"]
#makado:lookAway_ce
——父亲说这是……「与封印有关的重要东西」？[p]

#marigan:smileB
嗯[r][wait time="500"]
说白了咱就是被当成保险专员随意使唤了呢……[p]

#makado:normal_ce
…………这是，[r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
您也不清楚这东西的具体用途吗？[p]
[resetdelay]
#marigan:smileCE
那个人啊，是个超～级靠谱的大人。[r]
所以我什么都没能问出口，也没能说出口[p]
[delay speed="50"]
#marigan:smileB
你也要成为靠谱的大人啊小和尚。[r]
成为超越享四郎先生的好男人[p]

#makado:tweetLA_ce
不用你说，我也一直很尊敬父亲，[r]
始终以成为父亲那样的人为目标[p]

#makado:normal_ce
……………………[p]

#marigan:tweet
……干嘛啦。这样盯着看，我身上又没哪里不对劲[p]
[delay speed="70"]
#makado:tweetLA_ce
……………………[wait time="800"][r]
——父亲他，为什么要告诉你这个地方的事……[r]
你…明白吗？[p]
[delay speed="50"]
#marigan:tweetLA
……………………[p]
#marigan:sad
……呵。[wait time="800"]
#marigan:smileCE
当然！[p]

#marigan:normal
我、曾是他的首徒。[wait time="1000"][r]
除此之外别无身份啊[p]
[delay speed="70"]
#makado:normal_ce
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（…………首徒么、）[p]
#marigan:angry
好了，[wait time="500"]对你的拜访就到此为止。[r]
我、还有下个预约要先走了[p]
[resetdelay]
#makado:lookAway_ce
……这就要走了吗[p]

#marigan:smileB
干嘛啦。舍不得？先说好我可不吃卖萌这套哦。[r]
我专挑年长的[p]

#makado:tweetLA_ce
不……即便不知道这把雕刻刀的用途……[r]
但我想趁现在打听纱罗纱眼睛异常的原因[p]

#makado:normal_ce
您之前不是说过　您知道这件事吗[p]

#marigan:smile
啊哈哈……虽然很抱歉要辜负您的期待，[r]
同属马门[r]
但人家只听享四郎先生的话呢[p]
[delay speed="50"]
#marigan:normal
所以对你有利的情报　人家不能再多说了哦[p]

#makado:lookAway_ce
……这样啊[p]

#marigan:tweetLA
抱歉啦。[r]
嘛、我会给你加油的。你也好好努力吧[p]
#
玛丽甘将手提包朝这边甩动了几下。[p]

#marigan:smileCE
我也会想办法努力不让自己横死街头的啦[p]
[delay speed="60"]
#makado:tweetLA_ce
……非常感谢[p]
[chara_hide name="marigan" wait="true"]
#
玛丽甘对我的道谢，[r]
头也不回地　只是轻轻摆了摆手作为回应。[p]
#
嘴里哼着某种古老的民谣……[r]
她离开了。[p]
[font size="20"]
[delay speed="200"]
#marigan
不～知～为～何～　迷～途～在～遥～远～之～地……♪
[playse  volume="50" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse][er]
[fadeoutbgm time="4000"]
[delay speed="60"]
[chara_show name="makado" top="-10" face="lookAway_ce" wait="true"]
#makado:lookAway_ce
…………[l][r]
#makado:closeEyeB_c
……………………………………………………[p]

#makado:lookAway_ce
（……作为祭主，必须认真履行职责才行）[p]
#
[chara_hide name="makado" wait="false" time="3000"]
[bg storage="brack.png" wait="true" cross="false" time="3000"]

在这座城镇，代替父亲……[r]
必须展现出应有的姿态――[p]

#makado
(……等等)[p]
[delay speed="100"]
#makado
（…………所谓正确的姿态，究竟是什么）[p]

#makado
(……我、究竟该何去何从？[wait time="1000"]……）[p]
#
我本该、[wait time="1000"]做些什么才对？[p]
[mask time="100"]
[stopbgm]
[chara_show name="kirie" face="smile_s" left="150" top="-60" time="10"]
[bg storage="indoor/makado_ima_m.jpg" time="10"]
#kirie
[playbgm storage="faure-op84-5.ogg" loop=true volume="40" sprite_time="0000-76400"]
[mask_off time="100"]
[resetdelay]
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
[delay speed="50"]
哈——好——舒——服——[p]

#makado
刚到别人家就放松个什么劲儿啊[p]

#kirie:angry_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
我把房主权给你吧[p]

#makado
也不出租了[p]
[delay speed="70"]
#kirie:lookAway_s
不过话说回来这房间可真够冷清的。[l][r]
[resetdelay]
#kirie:smile_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=kirie keyframe=up time=300 wait="false"]
所以人家特意带了花来给你嘛～[r]
给！要摆起来吗？[p][stop_kanim name=kirie]
[delay speed="60"]
#makado
我说啊……刚才没来得及说明，那是供佛用的花哦。[l][r]
偏偏挑待会儿有客人要来的时候添乱……[p]
[resetdelay]
#kirie:sad_s
客人？不是去神社而是来马门家？[p]

#makado
嗯。下午父亲的朋友要携全家过来。[l][r]
[delay speed="60"]
他家女儿还小，现在大概十岁吧……[p]
#kirie:hate_s
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
诶～不小啦。十岁可是半成人式呢？[r]
而且女孩子的话，我觉得十岁已经超级早熟啦～[p]
[delay speed="50"]
#makado
是那样吗……[p]

#kirie:sad_s
本来就是嘛～[l][r]
我啊，[wait time="500"]十岁的时候也有喜欢的人了……[p]
[fadeoutbgm time="3000"]
#kirie:lookAway_s
……………………[p]
[chara_hide name="kirie" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
#
雾绘，[r]
一把抓起我面前的汽水罐，仰头灌了下去。[l][r]
[resetdelay]
她突如其来的举动让我愣了好几秒。[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="60"]
#makado
喂、[wait time="800"]……那是我的啊[p]
[resetdelay]

#kirie
噗哈——。温吞吞的、真难喝啊[p]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
#
她踏着重重的脚步声走向厨房，[r]
把空罐子哗啦哗啦冲洗干净——[p]
[delay speed="60"]
……然后把它放在水槽边的空位上，插上了供花。[p]
[resetdelay]
[chara_show name="kirie" face="sad_s" left="150" top="-60" time="500" wait="false"]
#kirie
对你这种没文化的家伙，配这个正合适。[r]
是不是稍微风雅点了？[p]
[delay speed="60"]
#
虽然那个粗陋的罐子仍散发着不祥的气息……[r]
正如她所说，[r]
总觉得这罐子似乎真能让房间稍微鲜活几分。[p]

#kirie:hate_s
喂——你那什么表情。[r]
我走之后可别立刻扔掉啊[p]

#makado
不会啦。难得你特意带过来的[p]
[delay speed="70"]
#makado
要是雾绘也上同一所高中……[r]
说不定暑假之外也能这样一起玩了[p]

#kirie:lookAway_s
…………………………[p]
[delay speed="60"]

#makado
那个啊。在小谷坂那边，没遇到什么不愉快的事吧？[l][r]
你这家伙……升学组里连一个要好的朋友都没有吧……[p]

#kirie:normal_s
……是啊。总觉得，净是些不顺心的事呢。[p]
#kirie:lookAway_s
下个月终于[wait time="500"]要成为三官女的最高位了呢[p]

#kirie:smile_s
不过呢，没关系。[p]
人生啊，[r]
总会有诸事不顺的阶段也是没办法的事[r][wait time="800"]
命中注定要沉沦的情况也是存在的呀[p]
[delay speed="60"]
#kirie:normal_s
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
这种时候啊——[wait time="500"]就当是神明赐予的人生长假吧，[r][wait time="500"]
不要勉强自己着急，[wait time="500"]别急着奔跑！[p]

#kirie:smile_s
[anim name="kirie" left="-=100" time=500 ]
[anim name="kirie" left="+=200" time=500 ]
[anim name="kirie" left="-=100" time=500 ]
要自然地～、随遇而安！[p]

#
雾绘……张开双臂，轻快地转了个圈示范着。[p]
[delay speed="50"]
#makado
……这想法，挺不错的嘛。[l][r]
御白姬就是用这种方式赐予祝福的吗[p]

#kirie:sad_s
唔嗯。不是哦。[r]
这是我家喜欢的电视剧里的台词[p]

#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
诶。[p]

#kirie:smileW_s
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
啊哈哈……你惊讶什么啦！[p]

#kirie:normal_s
有什么关系嘛？就算我喜欢什么样的神明大人[p]
[delay speed="100"]
#kirie:lookAway_s
连你都要说三道四……讨厌啦[p]
#
[resetdelay]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[chara_mod name="kirie" face="sad_s"]
[kanim name=kirie keyframe=up time=300 wait="false"]
[font size="20"]
打扰啦—[p][stop_kanim name=kirie]

[resetfont]
#kirie
……啊[p]
#
玄关方向传来成年男性浑厚的声音。[p]

#kirie:lookAway_s
……是刚才说的客人吗？[p]

#makado
也许吧。[r][wait time="500"]
[delay speed="60"]
老爸…刚才注意到了吗……[p]
#
在我留意里屋动静的时候，[p]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[chara_hide name="kirie" wait="false"]
#
雾绘把朝向神社院子的窗户微微推开——[r][wait time="800"]
朝外窥探。[p]

#makado
……你在干什么？[p]
[delay speed="50"]
#kirie
侦察。[wait time="500"]想亲眼看看传说中的客人呀[p]

#makado
传说什么的…太夸张了吧。[r]
只是两家有些交情罢了[p]

#makado
好像是为了筹备三年后的白绢祭典，有些事项需要商定……[p]

#kirie
…………………………[p]
[fadeoutbgm time="4000"]
#kirie
……………………………………………………[p]

#makado
…………………………[wait time="600"]雾绘？[p]
[delay speed="70"]
#
见她始终盯着窗外沉默不语，我担心地唤了一声。[p]

这时，雾绘……[r][wait time="500"]
像机械般直挺挺地站起身来，开口说道。[p]
[resetdelay]

#kirie
我回家了[p]

#makado
诶？[p]
#kirie
……要回去了。拜拜[p]
[bg storage="brack.png" wait="false" cross="false" time="3000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
;ＳＥ歩いて行く
[delay speed="70"]
#
雾绘连看都没看我一眼，便快步离开了。[p]
我只能呆呆地望着她远去的背影。[p]
;【第四章】　０　終
[mask folder="bgimage" graphic="still/part4.png" time="3000"]
;セーブしますか？
[showsave]
@jump storage="chapter_5/day1_vol1.ks"
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
