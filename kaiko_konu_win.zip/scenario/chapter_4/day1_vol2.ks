;-------------------------------------------------------------------------------
*part4
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '四章一日目　中編'"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="indoor/sisin.jpeg" time="10"]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=30]
[wait time="1000"]
[mask folder="bgimage" graphic="still/part4.png" time="1000"]
#
[mask_off time="2000"]
[delay speed="50"]
――13点前，『茧的家』一角。[p]

#aki
听好了 纱罗纱[p]
[chara_show name="hino" top="-100" left="160" wait="false" face="normal_o"]
[chara_show name="riki" top="-100" left="-120" wait="false" face="normal_o"]
[chara_show name="aki" top="-100" left="-250" wait="false" face="normal_o"]
[chara_show name="sarasa" top="-100" face="normal_o" left="500" wait="false"]
我们好像有[font color="0xf08080"]秘密教典[resetfont]哦[r]
资料室的话 我会带你去的啦[p]
[resetdelay]
#riki:smile_o
之后就要靠你自己加油咯！一旦开始匹配的话[r]
16点前所有人都出不来的[p]

#sarasa
嗯[p]
[delay speed="50"]
#hino
就连我们眷属都不知道其存在的珍藏资料，[r]
竟然是已知事项……[p]
#hino:hurry_o
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
不愧是玛丽甘小姐 知识量真不是盖的[p]

#riki:normal_o
那个阿姨到底是什么来头啊[p]
[resetdelay]
#hino:angry_o
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
所以说多少遍了你才懂[l]她可是八种才媛！[r]
是在东浓实地考察时著名的民俗学者啊[p]
[delay speed="80"]
#riki:normal_o
东—浓—？什么地方啊[p]
[delay speed="10"]
#hino:hurry_o
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[font size="40"]
就是我们所在的[r]
这个地区啦————！！（小声）[p][resetfont]
[delay speed="60"]
#hino
[anim name="hino" top="-=10" time=100 ]
[anim name="hino" top="+=10" time=100 ]
[anim name="hino" top="-=10" time=100 ]
[anim name="hino" top="+=10" time=100 ]
呼、呼哈，志户田！[r]
圣典上写了什么待会儿可得告诉我啊[p]
[chara_mod name="sarasa" face="closeEye_o"]
#
我朝着日野的方向点头示意。[p]

#aki
好……[l][font size="40"][stopbgm]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
走喽[p][resetfont]
[mask]
[chara_hide_all time="10"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="2000"]
[bg storage="brack.png" time="10"]
;ＳＥドタドタ
#
[clearfix]
[mask_off]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[resetdelay]
刚冲出走廊，头顶便传来[r]
大人们的声音。[wait time="1000"][er]
#老人の声
哟——这不是小鬼头嘛。上午躲哪儿去了[wait time="1000"][er]
#老婆の声
今天要是能有祝福就好了呢。[wait time="200"][r]
毕竟白绢祭前最后一天结茧日嘛[wait time="1000"][er]
[delay speed="60"]
#
隔着布料，有人轻轻抚摸着我的头。[wait time="1000"][er]
#
随着视野逐渐模糊，[r]
方向感也变得越来越不明确。[wait time="1500"][er]
[resetdelay]
#子供の声
今早状态如何？还精神吗？[wait time="1000"][er]
#男性の声
还穿着那双袜子？真难看 快扔掉[wait time="1500"][er]
#女性の声
难得的结茧日。来祈祷吧，为了祝福[wait time="2000"][er]
#
陌生人们的声音如雨点般接连落下。[wait time="1000"][er]
[delay speed="50"]
#sarasa
（……有点……[wait time="800"]害怕起来了呢……）[wait time="2000"][er]
#女性の声
咦。[wait time="1000"][er]

绢世小姐。好久不见[wait time="2000"][er]
[stopbgm]
#sarasa
诶[p]

#kinuyo
好久不见[p]
[delay speed="80"]
#
刚才的……[p]

唯独刚才的声音　[wait time="1000"]我　记得……[p]

我不由自主地停下了脚步，就在那一瞬间。[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
有人隔着布料握住了我的手。[p]

#sarasa
（…………！？这只手………是谁的，）[p]
#
被那只手牵引着，不断向前迈进――[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[font size="25"]
[resetdelay]
#
绢世小姐……怎么看都不像是同龄人……一直……冷静……[wait time="300"][er]
[font size="23"]
对了……从上次……小姬那时候起就一直…………[wait time="200"][er]
[font size="20"]
不要啊……但是呢……罗纱………就……[wait time="200"][er]
[resetfont]
[delay speed="60"]

…………[l]就这样………[p]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
不仅熟悉的声音消失了，连方才的喧闹也彻底远去，[r]
当周遭完全陷入寂静时。[p]

是抵达目的地了吗。那只手松开了我。[p]

#sarasa
[delay speed="100"]
（…………………………）[p]
[delay speed="60"]
#sarasa
（…………不。）[p]
（现在无论如何，[r]
必须集中精力寻找封印怨灵的方法）[p]

#sarasa
（……这里……就是存放『秘密教典』的房间吗。）[p]
#
在死寂的空气中。[r]
静静地，梳理着思绪。[p]

本想确认周围的情况，[r]
但绢布上的窥视孔似乎在中途移位了，[r]
怎么也找不到。[p]

没办法，只好蹲下身，[r]
决定从布料与地面的缝隙间窥探外界。[p]

…………[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message0 visible=false
[clearfix]

[bg storage="still/hebi_1.png" time="10"]
[wait time="3000"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/hebi_2.png" time="10"]
[wait time="5000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]


;（クリックで全体スチルに）

#ituki
……纱罗纱？[p]
[mask time="10"]
;ＳＥバッ
[bg storage="indoor/sisin_stage.png" time="10"]
[chara_show name="ituki" top="-160" face="normal_o" left="-70" time="10"]
[chara_show name="sarasa" top="-160" face="wow_s" left="360" time="10"]

[mask_off time="10"]
;会場
[font size="40"]
#sarasa
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
哇……！？[p]
[stop_kanim name=sarasa]
[resetfont]
#ituki
啊——果然。是纱罗纱啊[p]
[delay speed="50"]
在这种地方做什么呀～[p]

#sarasa
…………　一、[l]一树……[p]

#ituki
向比三柱巫女更尊贵的白绢御白姬大人祈愿[p]

吾等自祈祷之后　不食　不飞　不视[r]
故在此献上祈愿　守护此地的姬神大人啊[r]
恭迎圣临　恭迎圣临[p]

#ituki
…………………………[l][r]
如果纱罗纱真的是眷属的话[r]
该有多好啊噗哟……[p]
[delay speed="60"]
[anim name="ituki" top="+=30" time="200"]
[anim name="ituki" top="-=30" time="200"]
[anim name="ituki" top="+=30" time="200"]
[anim name="ituki" top="-=30" time="200"]
要是那样的话　如果真的那样的话呢[wait time="500"][r]
咱肯定每天都会更幸福哒噗哟噗哟[p]
[resetdelay]
#sarasa:worryLA_s
……这里……是哪儿！？大家呢……[p]

#sarasa:wow_s
……[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
[font size="22"]
――抬起视线，[r]
意识到自己此刻正站在体育馆的舞台……之类的地方。[l][r]
但下方铺展着的并非[r]
打过蜡的木地板，而是榻榻米。[l][r]
这样看来，与其用体育馆舞台来形容这个场所，[r]
说是旅馆宴会厅的展台或许更贴切。[l][r]
这个适合举办大规模集会的房间，[r]
恐怕就是『丝织之间』吧。[p]
然而……[l][r]
我望着自己眼前的光景，[r]
只能僵在原地　说不出一句话。[p]
[resetfont]
[chara_hide_all time="10"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/taorete.png" time="10"]
@layopt layer=message0 visible=false
[clearfix]
[wse]
[wait time="2000"]
@layopt layer=message0 visible=true
[playbgm storage=fuon.ogg loop=true time=300 volume="30"]
;スチル；舞台下

就在自己站立的高台之下，[r]
陌生的人们失去意识……[r]
横七竖八地倒了一地。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……为……为什么[p]

#sarasa
这些人……为什么，为什么……[p]

#ituki
都是本大爷让他们睡着的，[r]
现在全都像石头一样咕噜噜滚倒一片喵～[p]
[bg storage="indoor/sisin_stage.png" wait="false" cross="false"]
[chara_show name="ituki" top="-160" face="normal_o" wait="false" time="1000"]
#ituki
接下来要和你干架，[r]
其他眷属在场的话超～麻烦的说。[l][r]
对吧～纱罗纱亲♡[p]

#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
――！[l][r]
战…………战斗什么的……[p]
[delay speed="25"]
等、等等……不在这里的登利君他们呢……！？[r]
哪里？你把他们带到哪里去了？[p]
[delay speed="60"]

#ituki
……………………[p]
[delay speed="25"]

#sarasa
…………喂、喂，一树！[p]

#ituki
…………[p]

#sarasa
……呜……呜、[p]
[delay speed="60"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[quake time="30"]
为什么什么都不肯说……！？[l][r]
我一直都在等着啊，[r]
等你好好跟我说话……[p]
[stopbgm]
#ituki
谁？[p]

#sarasa
诶？[p]

#ituki
你[wait time="800"]是谁？[p]

#sarasa
……………………………………[p]

#ituki
你…………………………[l]不是眷属吧 到底是谁？[r]
班上的同学？是来捉弄我的吗？[p]

#sarasa
……………………为什么、要说这么刻薄的话[l][r]
就像完全不认识我一样……[p]
[resetdelay]
#ituki
刻薄？不坏啊。一点都不坏呢。[r]
固执哪分什么良性恶性。[p]

真正心术不正的，是你才对吧。[r]
搞什么啊，嘚啵嘚啵说个不停。[l][r]
我认识的人里根本没人会这么说话[p]
[delay speed="60"]
#sarasa
……………………………………[l]

……………我……我是、[wait time="100"][er]
[font size="40"]
#ituki
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[anim name="ituki" top="+=80" time="200"]
[anim name="ituki" top="-=80" time="200"]
骗人——————[p]
[resetfont]
#sarasa
………………[p]

#ituki
[playse  volume="30" buf="0" storage="kansei.ogg" ]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
才·怪·呢——[r]
白痴、被骗了吧[wse][p]
#sarasa
……树月酱[wait time="100"][er]
[delay speed="100"]
#ituki
[font size="40"]
[font color="0xf08080"]
[playse  volume="30" buf="0" storage="kansei.ogg" ]
但忘记可是真的哦——————。[wse][p]
[resetfont]
我啊、大概迟早会忘记你的事吧 总有一天 某个时候。[r]
因为我的祝福是————[p]
[font size="40"]
[font color="0xf08080"]
可是会没收所有人记忆的庆贺哦——[p][resetfont]

#sarasa
…………[wait time="800"]记忆？[p]
[delay speed="80"]
#
她那出人意料的话语，令人难以置信——[l][r]
我如此反问之后，只能沉默以对。[p]
[delay speed="50"]
#ituki
啊——啊。[l][r]
看来，光是聊天也能让人开心呢。[r]
毕竟，没有其他能让人高兴的事了。[p]

呐……今年的暑假，结果完全没能一起玩呢。[r]
纱罗纱。[p]

但是啊。[l][r]
我们之前的暑假，[r]
到底是怎么度过的来着？[p]
[delay speed="80"]

#sarasa
……忘记了。[p]
[delay speed="50"]
#ituki
忘了吧。彻底忘了[p]

#ituki
就连倒在下面的大家的事……也都忘记了。[r]
大概，是我搞成这样的吧[p]

呐呐，纱罗纱，[r]
连自己都不记得的事情，怎么可能替别人回忆起来呢？[l][r]
做不到吧？那我也一样做不到啊[p]

所以呢——来！[p]
[delay speed="80"]

#
从布帘下方伸出手的树月，递给了我某样东西。[p]

我确认着掌心中的物件。[p]

;道具スチル：包丁
[image layer=0 folder="image" name="hotyo" storage="item/hotyo.png" width="460" x="250" y="107" time="2000"]
[wait time="2000"]
#sarasa
………………诶？[p]
#ituki
正好你来到这里的话……[p]
[delay speed="50"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
希望你能趁现在把我处理掉呢。[l][r]
趁我体内尚未孕育出无可挽回的诅咒之前——[p]
[delay speed="80"]
[free layer=0 name="hotyo" wait="false" time="3000"]
#
我将一直微张着的嘴唇[r]
用力咬紧。[p]

或许是冷气的缘故，舌头和牙齿都冰冷彻骨。[p]

#sarasa
无可挽回的……诅咒，到底是指什么……[p]
[delay speed="50"]

#ituki
我啊，连自己如何获得祝福的过程，都忘得一干二净了[p]
#
树月保持着毫无波澜的声线，继续说着。[p]
[resetdelay]
#ituki
所谓愿望啊……[l][r]
据说那会暴露人心脆弱的部分，[r]
以前在什么漫画里读到过啊[p]

#ituki
御白姬赐予的祝福，[r]
本应填补那些心灵缝隙——[p]

但奥库罗姆克却将其逆向穿透，[r]
似乎是要给傀儡人偶穿线呢[l][r]
[delay speed="50"]
也就是说，会将获得祝福的回忆……扭曲成诅咒[p]
#ituki
但我始终想不明白，为什么那些丝线能轻易穿透人心[l][r]
我竟想不起为何会获得这份祝福[p]
也就是说，[r]
那岂不是……没救了啊。[l]　要是，我――[p]
[delay speed="25"]
#sarasa
一树不会被诅咒的[p]
[delay speed="50"]
#ituki
要真是那样就好了呢[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="800"]

;ＳＥ歩いて行く

#ituki
……[l]纱罗纱？你要去哪……？[p]
#
布帘深处传来树月不安的低语。[p]
她看不见我。[l][r]
然而，从脚步声判断纱罗纱正从祭坛退向侧廊[r]
这点我很清楚。[p]

;ＳＥ歩いてくる
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]


#sarasa
……留在那边的东西[p]

#ituki
……你说留在那边？[p]
[delay speed="100"]
#sarasa
因为、啊、太危险了…………把那种东西交出去……[r]
就算是玩笑也绝对不行[p]
[delay speed="50"]
#sarasa
[fadeinbgm storage="faure-op84-5.ogg" loop=true time=5000 volume="50"]
呐……一树，我们一起想办法吧？[r]
到底要怎样才能封印御黑幕。[p]

我今天……就是为了寻找那个才来到这里的[p]
[delay speed="100"]
#ituki
…………[l][r]
纱、纱罗纱[p]
#
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
志户田纱罗纱向前迈出一步。[r]
为了向最重要的挚友传达自己的心意。[p]
#sarasa
……一树…………[p]
我们之间不该有暴力，[r]
或是互相伤害这种事，[r]
我觉得……那些东西不需要……也不该存在。[p]

因为我们都是女孩子，[l][r]
一直以来都相处得……很融洽啊。[p]

这次也一定，[r]
就连御黑前家的诅咒，也都能顺利解决的。[l][r]
不用做危险的事……也不用受伤……[p]
我们……没问题的对吧[p]
[chara_hide name="ituki" wait="false" time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[mask time="100"]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="50" buf="0" storage="sariin.ogg" ]
[wse]
[bg storage="still/kobura_1.png" time="10"]
;ＳＥばっ
[mask_off time="3000"]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]



;スチル：抱きしめ

#ituki
…………[p]

#ituki
……纱罗纱……………………………[p]



[bg storage="still/kobura_2.png" time="10"]
[stopbgm]
;スチル：コブラツイスト
[resetdelay]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
#ituki
好好做啊[p]
[delay speed="60"]
#sarasa
………………………………………………[l][r]
？？……？？？[p]
[delay speed="50"]
好、好痛啊，树月……[p]
[resetdelay]
#ituki
认真点啊。别小看我。[r]
我可是认真的[p]
#
为了回应冷酷挚友的声音，[r]
拼命驱动着发出悲鸣的肺部。[p]
[resetdelay]
#sarasa
……才没有、犯傻……！[p]

#ituki
明明就有吧[p]
[playse  volume="20" buf="0" storage="shimeage.ogg" ]
[bg storage="still/kobura_3.png" time="10"]
[delay speed="50"]
;スチル：怖い顔

那为什么要跑到这种地方来？[p]
你以为我、怀着怎样的心情、[r]
一直把你当作秘密隐瞒至今的？[p]

#sarasa
那是……[l][r]
[quake time="10"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
所以、刚才不就说过了吗！黑函的、封印的……[p]
[bg storage="still/kobura_4.png" time="10"]
[font size="38"]
[resetdelay]
#ituki
[quake time="30"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
——对吧，现在的纱罗纱一定是[r]
连其他人都想拯救对吧！！[p][resetfont]

[mask time="100"]
#
[bg storage="indoor/sisin_stage.png" time="10"]
[playse  volume="70" buf="0" storage="book.ogg" ]
[mask_off time="100"]
;ＳＥドサッ
……我挣扎着想摆脱勒住脖子的手臂，却因此[r]
两人一起重重摔在地板上。[p]
[delay speed="100"]
#sarasa
呜……！[p]
[resetdelay]
#ituki
快……快点啊，别磨蹭了，快点……！[p]
;-------------------------------------------------------------------------------
;あとでけす
[chara_face name="ituki" face="angryB_gs" storage="chara/ituki/isyo/angryB_gs.png"]
;-------------------------------------------------------------------------------
[delay speed="18"]
[chara_show name="ituki" face="smileH_gs" top="-160" wait="false"]
#ituki
纱罗纱她……为了奥库罗姆的封印，[r]
宗方树的[r]
既然能轻易踏入我隐藏了八年的秘密！！？[p]
#ituki:angryB_gs
[quake time="100"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
事到如今还有什么好犹豫的！？[r]
连回忆都会消失无法驱散，这种无可救药的[r]
在诅咒开始前，你给我杀了我就好了啊！！！！[p]
[font size="40"]
#ituki:shout_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
反正你从今往后永远都[r]
不会再是只属于我的纱罗纱了[r]
不是吗！！[p][resetfont][stop_kanim name=树]

[delay speed="100"]
#sarasa
…………………………………………[l][r]
……………………（一树、）[p]
（你们……究竟为什么要[wait time="600"][r]
摆出这种完全不珍惜自己性命的样子？）[p]
#
――我，注视着树月的脸庞。[l][r]
…………理所当然地，能看到雾绘的轮廓。[p]
#
正在改变。外壳正加速融化。[l][r]
在这个暑假开始之前，一树明明还只是[r]
普通的[wait time="500"]　一树而已。[p]
[mask time="100"]
[chara_hide name="ituki" time="10"]
[stopbgm]
[clearfix]
[bg storage="brack.png" time="10"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[resetdelay]
[mask_off time="100"]
;ＳＥカーン

4月＿日 晴[l][r]
虽然和预想的一样，[r]
幼儿园的小朋友们全都＿＿＿＿完全不友善。[l][r]
[r]
从第一天开始[r]
就说我的发带是紫色的不行＿＿＿。[l][r]
虽然＿＿老师说没关系，[r]
明明这＿是姐姐传下来的不可能＿＿＿。[l][r]
[r]
大家聚在一起聊天时也完全＿＿＿＿我。[l][r]
[r][delay speed="60"]
不看电视吗？[l]　嗯。不看。[l][r]

啊，不过我会看录像哦。[l][r]
大人们聊天的时候，大家都会聚在录像室里……[l][r]
[r][resetdelay]
＿＿一起看《钥匙小丑》＿＿。[l][r]
《欢乐小丑》。不知道吗？[p]
[r][delay speed="80"]
和谁一起看？[l][r]
和阿基、力，还有妹妹……[l][r]
[r]
听说阿基家和力家的孩子都要去八种小学。[l][r]
我也……觉得那边更好。[l][r]
[resetdelay][r]
如果＿＿这样说的话，[r]
那就去＿里不就好了＿＿嘛。被人这么说了。[l][r]
[r][delay speed="60"]
但是呢，只有一个孩子，[l]在回家的路上主动和我说话了。[l][r]
[r]
[r]
[wait time="2000"]＿＿＿＿＿＿＿ちゃんっていう子でした。[p]
[mask time="100"]
@layopt layer="message0" visible="false"
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[stopbgm]
[bg storage="indoor/sisin_stage.png" time="10"]

[mask_off time="3000"]
@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
＿＿＿＿＿＿＿酱是谁？[r]
[glink color="btn_12_black" target="*sarasa" text="志戸田紗羅紗" width="20" x="450" y="60" clickse="tapSE.ogg"]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*sarasa
;-------------------------------------------------------------------------------
[mask time="10"]
[cm]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]
[delay speed="100"]
[mask_off time="2000"]
#sarasa
@layopt layer="message0" visible="true"
………………………………[p]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
（这是……初次相遇时的回忆）[p]
[font size="20"]
#ituki
呜哇、别……不要啊！[p]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
[resetdelay]
[font size="40"]
[chara_show name="ituki" top="-160" face="shout_gs" time="100" wait="true"]
[quake time="30"]
你、你看什么看！？？[p]
[resetfont]
[delay speed="50"]
#sarasa
（因为回忆都是断断续续的，[r]
所以之前有很多对话都对不上……）[p]
[font size="40"]
#sarasa
――呃！？[wait time="300"][er][resetfont]
[playse  volume="80" buf="0" storage="punch.ogg"]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="ituki" wait="false"]
[quake time="30"]
[wait time="1000"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wait time="1000"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
;ＳＥドサッ
#
树月把我狠狠按在地上。[l][r]
[r]
近距离对视时他的瞳孔，[r]
比平时更加细长锐利。[p]
[chara_show name="ituki" top="-160" face="shout_gs" time="100" wait="true"]
[font size="40"]
[delay speed="25"]
#ituki
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[anim name="ituki" top="+=30" time="15"]
[anim name="ituki" top="-=30" time="15"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
别看、不准看、不许窥探！！！！[r]
快点、乖乖地、把我解决掉吧！！[p]
[resetfont]
[delay speed="50"]
#ituki:angryB_gs
都说了不需要啊，事到如今这种回忆………！[r]
只要你解决了我，这个故事就到此为止了！！！[p]

#sarasa
……[l][r]
我、能、将人的回忆、一同……[r]
回溯重现的[p]

所以、说不定，[l][r]
就连一树获得祝福时的记忆也――[r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
或许能让你一同看见[p]
即便你已经遗忘……[wait time="500"]　只要通过我的双眼，[r]
说不定能帮你回忆起来，所以啊[p]
[resetdelay]
#ituki:shout_gs
[font size="40"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
不要！！　这种事、根本不需要！！[p]
#sarasa
[quake time="30"]
[playse  volume="50" buf="2" storage="kaminari.ogg" ]
我不要！[p][resetfont]
[delay speed="100"]
#sarasa
我也、不愿意……　[wait time="800"]如果一树被诅咒的话，[r]
可能会变得无能为力…………[p]
[delay speed="50"]
#sarasa
我不会杀一树的，[r]
也不会让一树杀死我的[p]
为了这个……为了这个目的，[r]
必须确认清楚，我能否看透你！！[p]
[chara_face name="ituki" face="angry_gs" storage="chara/ituki/isyo/angry_gs.png"]
#ituki:angry_gs
笨蛋……纱罗纱你真是个笨蛋[wait time="500"][er]
#ituki:shout_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
[font size="40"]
伪善者、伪善者、伪善者！！[p][stop_kanim name=ituki]
[resetfont]
#ituki:angryB_gs
你还不明白吗！？既然我忘记了，[r]
那说明这段记忆是我自己「想要遗忘」的啊！？[r]　
[delay speed="100"]
这种事、这种事现在才想起来的话，与其这样做还不如我――[wait time="500"][er]
[resetdelay]
#sarasa
[font size="40"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
当伪善者也无所谓！！[wait time="300"][r]
因为我想看，[wait time="500"]因为想做才这样做的！！[wait time="500"][er]
[font size="40"]
#sarasa
一树……别来妨碍我！！[wait time="200"][resetfont][er]

[mask time="100"]
[delay speed="50"]
;ＳＥカーン
[chara_hide name="ituki" time="10"]
[bg storage="brack.png" time="10"]
[playse  volume="80" buf="0" storage="sariin.ogg" ]
[wse]
[fadeoutbgm time="5000"]
[wait time="5000"]
#
[mask_off time="2000"]
[wait time="2000"]
;SＥ録音ボタン
[wse]
[font color="0xb0c4de"][font size="25"]
…………咦[p]
[resetdelay]
喂　开始录像了吗[p]
[playse storage="phone.ogg" volume="30" sprite_time="0000-200"]

[delay speed="50"]
……啊！　[wait time="500"]好像没问题[p]

好嘞　那开始咯—[wait time="500"][r]
预备——[wait time="500"][er]
[font color="0xb0c4de"]
一——二————三—————四——————[wait time="600"][er]
[resetfont]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/dance1.png" time="100"]
[wse]
[wait time="3000"]
[bg storage="still/dance2.png" time="100"]
[wait time="4000"]
;○ダンススチル
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]


;ＳＥバァン
[resetdelay]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
#先生
[font color="0xb0c4de"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
喂！！[bg storage="school/kotei_m.jpeg" time="300" cross="false" wait="false"]
谁他妈在屋顶上啊[p]

#ituki
糟了！！纱罗纱快走[p]

#sarasa
嗯[p]

;ｓＥ走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[delay speed="50"]
#先生
宗方！！志户田！！又是你们俩！！[p]

#ituki
对不起啦——[p]

#sarasa
对不起啦——[p]
[mask time="1000"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=5000 volume=50]
[wait time="1000"]
[bg storage="school/rouka_m.jpg" time="10"]
#
[mask_off time="1000"]
;学校廊下
啊哈哈哈！！[p]
#ituki
啊呀啊呀 只把椅子丢在那里就逃掉了[p]
[delay speed="50"]
不过 游泳圈倒是带出来了 还行吧[r]
好不容易AA制买的 要是被没收就太浪费了[p]

#sarasa
我啊 在一树告诉我之前[r]
都不知道还有跳舞用的游泳圈呢[p]
一树懂得真多呀[p]

#ituki
嘿嘿～还好啦[l][r]
这不是常识吗？[p]

#sarasa
对了！[l][r]
录像、好好拍下来了吗？[p]

;ＳＥ録画ボタン
[playse storage="phone.ogg" volume="30" sprite_time="0000-200"]
[delay speed="70"]
#ituki
…………嗯 效果不错！[wait time="500"][r]
总觉得真的……[wait time="500"]像真的一样[p]

#sarasa
真的？[p]

#ituki
嗯……总觉得[wait time="500"][r]
这个楼顶……看起来就像海边的小屋呢[p]
[delay speed="50"]
#sarasa
是说海滨小屋吗？[p]

#ituki
……海滨小屋……[l]　嗯　大概就是那个吧[p]
[delay speed="70"]
#ituki
……简直像是真的去海边玩了……、还拍了视频一样[p]
[fadeoutbgm time="3000"]
#ituki
…………[l][r]
…………………………………………[p]
#sarasa
一树[p]

#ituki
嗯？[p]
[resetdelay]
#sarasa
下次要去河边拍对吧？走吧[p]

#ituki
……走吧！[p]

#生徒
啊——！把相机带到学校来了——[r]
不可以的啦——就算是暑假也——[wait time="500"][er]
[font color="0xb0c4de"]
#ituki
对不起嘛——[wait time="500"][er]
[font color="0xb0c4de"]
#sarasa
抱歉啦——[wait time="500"][er]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]
;○スチル　ダンス
#
[playbgm storage=gymnopedies2.ogg loop=true volume=70]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[bg storage="still/dance3.png" time="4000" wait="true" cross="false"]
[wait time="5000"]
@layopt layer=message0 visible=true

[delay speed="60"]
[font size="22"]
如果我的记忆没出错的话[l][r]
曾经我坚信　和朋友跳舞时　必须要有游泳圈才行[l][r]
理由很简单[r]
因为我家录像带里 最喜欢的舞蹈视频[r]
正是用了游泳圈的那种 仅此而已[l][r]
现在想来 根本不合常理[l][r]
倒不如说 游泳圈在跳舞时 完全用不上才对[l][r]
[r]
但是[l][r]
因为我和我唯一的朋友 都不知道其他能和友人共舞的舞蹈[l][r]
[r]
所以在我们的小世界里 和好朋友跳舞必须要有游泳圈[r]
不过是小时候常有的一种无聊误会罢了[p]

每次偷出雾绘房间里那台老旧摄像机时[r]
我们就会在各种各样的地方拍摄跳舞视频玩耍[l][r]
[r]
仿佛自己钻进了电视里 有趣得不得了[r]
画面里的世界 既不是八种也不是任何地方[r]
那个本应无法抵达的[wait time="500"]外界[p]
[resetdelay]
两人一起笑的时候 笑声仿佛能响彻整个小镇[l][r]
化作回声从高处荡回来的笑声，[r]
已经分不清究竟属于哪一边了[l][r]
[r]
我们的舞蹈动作氛围和广播体操有几分相似，[l][r]
[delay speed="60"]
[r]
每到清晨广播体操时间，[r]
[r]
「啊，这会儿纱罗纱应该在神社和大家一起跳舞吧」[r]
[r]
这样想着。[p]

那段日子　我的生活就像庆典[l][r]
[r]
[r]
[r]
[wait time="1000"]だが夏も永くは続かない。いずれ冬が訪れる。[p]
[mask time="3000"]
[wait time="3000"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="school/rouka_m.jpg" time="10"]
[filter grayscale="100"]
[mask_off time="2000"]
[playse storage=bell.ogg sprite_time="0000-6000" volume="5"]
[wse]
;○学校
[resetfont]
;ｓＥ学校のチャイム
[font color="0xb0c4de"]
#sarasa
啊……！[p]
[quake time="30"]
#sarasa
一树！一树……[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
#ituki
……………………………………[p]
[delay speed="100"]
#sarasa
那、那个……听我说…………[p]
大、大家都变得超级可怕……已经持续好久了。[r]
突然这是怎么了，而且。[p]

所以我已经不知道该怎么办才好……[p]
#
纱罗纱战战兢兢地搭着话。[p]
[font color="0xf08080"]
[fadeoutbgm time="4000"]
看到她这副模样，我莫名火大得不行。[r]
明明必须忘记这种情绪的。[p]
[font color="0xb0c4de"]
[resetdelay]
#ituki
一直搞不明白不也挺好？[p]

#sarasa
诶……[p]
[delay speed="50"]
#ituki
永远蒙在鼓里不也挺好。[r]
保持沉默不也挺好。[p]
[resetfont]
反正纱罗纱你就算[r][wait time="500"]
不说话　不动弹　什么都不做，[r]
也还是纱罗纱啊[p]
[mask time="100"]
[playse  volume="50" buf="0" storage="sariin.ogg" ]
[wse]
[bg storage="indoor/sisin_stage.png" time="10"]
[free_filter ]
;ｓＥカーン
#sarasa
[delay speed="100"]
[mask_off time="1000"]
……………………[l]
一树[p]
#
在回忆过后陷入沉默，[r]
窥探着她纹丝不动的模样。[p]

#sarasa
想起来了吗？被遗忘的回忆……[p]

#ituki
…………………………[p]

#ituki
………………………………………………[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="ituki" face="smileCE_gs" time="100" wait="false" top="-160"]
[wait time="1000"]
[chara_mod name="ituki" face="hate_gs"]
[wait time="500"]
;ＳＥしゅばっ
[font size="40"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

#sarasa
[filter blur="4"]
[quake time="100"]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
[playbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400"]
――！？[resetfont][r]
咳、咳咳……[wait time="500"][er]
[resetdelay]
#
树月的长发如同活物般蠕动延伸，[r]
缠绕上我的脖颈。[p]

#sarasa
[playse  volume="40" buf="1" storage="shimeage.ogg" ]
呜……呜呜呜……！[p]
[bg storage="brack.png" wait="false" cross="false"]

#sarasa
一……一、一树……[r]
为什么…要做这种事……[p]

#ituki
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
啊哈哈　那些袒护你的　背叛者的眷属们[r]
全都被我提前关在另一个房间　真是太好了一[r]
绝对没法来碍事呢[p]

#sarasa
咕……[p]

#sarasa
……把……关起来……[l][r]
难……难道小组的、大……大家都…………？[p]

#ituki:smileH_gs
还有啊。顺便连你的母亲大人，[r]
也抓起来关进去了呢。呵呵呵。[r]
五个人一起愉快地当牢友吧[p]

#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（――！[r]
果然、刚才的……是妈妈的声音……！）[p]
[delay speed="70"]
#sarasa
为……为什么……连妈妈都……[p]
[delay speed="50"]
#ituki
纱罗纱的妈妈是狮心教的哦？[p]
[delay speed="70"]
#sarasa
诶…………[p]
[chara_hide name="ituki" wait="false" time="3000"]
#ituki:angryB_gs
对对……啊～。终于想起来了～。[r]
[delay speed="50"]
为什么连今天的计划都决定要忘记呢。我啊。[r]
是临阵退缩了吧～[p]

#sarasa
……计划、是……[p]
[font size="40"]
[resetdelay]
#ituki
[font color="0xf08080"]
志户田家的处刑！！！[p][resetfont]
#
束紧脖颈的发丝，将我狠狠摔向地面。[p]
@layopt layer=message0 visible=false
[clearfix]
[quake time="800" wait="true"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

[delay speed="70"]
#sarasa
呜……[l][r]
处、处刑？什么啊，为什么，我……[p]

#ituki
就是处刑哦。处刑。[r]
把本该懵懂活下去的权利彻底摧毁的罪孽[p]
[delay speed="50"]
#ituki
最近啊，和很多人变得要好，[r]
打听了不少事情呢……[r]
纱罗纱。[p]
就因为这个，[wait time="500"]原本不该知晓的真相，[wait time="500"]多余的话语，[r]
全都被你吞进了肚子里[p]

#ituki
我实在，无法容忍。[wait time="500"]明明那时候，明明都说清楚了……[p]
[resetdelay]
[quake time="100"]
[font color="0xf08080"][font size="40"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
装作不知道就好，[r]
保持沉默就好[r][resetfont]啊！！[p]
#
………………此刻的我，[l]面对语气凶狠暴戾的树月，[r]
不知为何感到无比愤怒……[p]
不对，到此为止，[r]
接连不断地说着莫名其妙的话，[r]
或许已经形成了心理负担。[p]
缓缓起身后，带着满腔怒火……[l][r]
朝企图将我推倒的树月走去，[r]
遵从内心的冲动，狠狠瞪着她，脱口而出。[p]
#sarasa
………………………………[r]
要、要是生我的气，冲我来就好了。[r]
可是……[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
没必要把其他无关的人也卷进来吧……！[p]

而且、[l]刚才一树你说我妈妈是[r]
狮心教的人对吧、[p]
但我从来没看到过妈妈[r]
去茧家或者参加狮心教集会啊[p]
一次都没有见过[p]

把毫无关系的陌生人[r]
还有同学关起来这种事、我……[p]
[stopbgm]
[delay speed="100"]
#ituki
纱罗纱 好可恨啊[p]
[delay speed="80"]
#ituki
是啊 你怎么可能会懂[l][r]
你从来都没感受过 身为狮心教相关家族[r]
诞生的痛苦吧[p]
[delay speed="100"]
#ituki
明明身为创始家族的人[p]
#
树月仿佛要印证方才的话语般，[r]
用充满恨意的眼神凝视着这边。[p]

我却没有看向那副表情――[p]

面对树月方才的话语，我倒吸一口凉气。[p]

#sarasa
………………[p]

#sarasa
……创教者……？[l][r]
不对吧……狮心教的创教者明明是宗方家……[wait time="800"][r]
和我们家根本[er]
[font size="40"]
[free_filter]
[resetdelay]
[bg storage="indoor/sisin_stage.png" time="100" wait="false" cross="false"]
[chara_show name="ituki" top="-160" face="shout_gs" time="100" wait="true"]
#ituki
[quake time="100"]
[font color="0xf08080"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
是纱罗纱家啊！！！！[p][resetfont]
[delay speed="100"]
#
这咄咄逼人的气势，让我瞬间屏住呼吸。[p]
[delay speed="60"]
#ituki:shout_gs
是志户田家。创立狮心教的是志户田家啊。[p]
#ituki:angryB_gs
志户田家的[font color="0xf08080"]
取[resetfont]志[font color="0xf08080"]字为名创立了士心教[resetfont]。[r]
一百多年前，由你们家族创立……[wait time="600"][r]
却把这坨垃圾文化硬塞给宗方家。[p]
[delay speed="50"]
[font color="0xf08080"]
通过扩大供奉蚕神组织的规模，[r]
只为更高效地经营缫丝业[p]
在这座供奉蚕女神的小镇，[r]
作为养蚕权威谋取更高地位[resetfont][p]
#ituki:hate_gs
就这样，[r]
在充分享受完那些利益之后又把一切都抛弃掉……[r]
所以我们才无法离开这座小镇[p]
#ituki
明明好不容易才忘记的……[p]
#ituki:smileH_gs
刚才看到了我回忆的纱罗纱[r]
都怪你 让我又想起来了啊[p]
#ituki
[font color="0xf08080"]
为什么我会这么 讨厌你呢[p][resetfont]

#sarasa
…………一树[p]
#
树月，[r]
正缓缓向我刚才被抛下的位置靠近。[p]
[chara_hide name="ituki" wait="false"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[delay speed="50"]
#ituki
呐　要是你现在觉得「不知道就好了」的话　就说出来啊[p]

#ituki
知晓真相很痛苦吧　理解现状很恶心吧　所以才抗拒的。[r]
我也是。[l][r]
咱也是。俺也是。本大爷也是。小女子也是………………啊啊……[p]
[delay speed="100"]

#ituki
所以啊——我就想着只要不去回忆就好了。[r]
现在的你　应该也能明白吧——[p]
喂。纱罗纱[p]
#
——树月……[wait time="800"][r]
伸出了手指。[p]


;右の小指を握る
;左の小指を握る
#
[link target="*right"]【１】握住右手的小指[endlink][r]
[link target="*left"]【２】握住左手的小指[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*right
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]


;右の小指を握る
[bg storage="brack.png" wait="false" cross="false"]
#ituki
是啊……。[p]
所以，[l][r]
从今往后不必再回忆了。永远不必[p]

我也会陪你一起忘记。[r]
这样才是真正的朋友呢[p]
#
……………[p]
[resetdelay]

我的记忆　再也不会举办盛宴了。[p]

终章５　「地狱的季节」[p]
[cm]
[clearfix]
@jump storage="first.ks"
;-------------------------------------------------------------------------------
*left
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;左の小指を握る

#sarasa
……一树…………[p]

#ituki
……[p]

#ituki
…………[wait time="800"][r]
[resetdelay]
[font size="40"]
[quake time="100"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
都说了很恶心啊！！[wait time="500"][er][resetfont]
[playbgm storage=severe-reprimande.ogg loop=true volume="30"]
;ｓＥバシンッ

#sarasa
[bg storage="brack.png" wait="false" time="100"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
咳哈……[p]
#
树月用双手遮住了我的双眼。[r]
与此同时，触碰上开始被勒紧的颈项，[r]
滑腻的鳞片触感传来。[p]
[font size="40"]
#ituki
[playse  volume="50" buf="0" storage="shimeage.ogg" ]
[delay speed="25"]
讨厌讨厌讨厌讨厌[r][wait time="600"]
讨厌讨厌讨厌、最——讨厌了！！！[p][resetfont]
#ituki
如果这座城镇也好御白姬也好狮心教也好全是为了你而存在，[r]
那就全都消失好了！！[p]
为了你而准备的这世间一切，[r]
[delay speed="50"]
不幸也好、饥饿也罢、丑陋不堪、卑劣至极、粗糙刺手——[wait time="600"][r]
[font size="40"]
[resetdelay]
最好连气味都令人作呕！！[wait time="500"][er]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[mask time="2000"]
[fadeoutbgm time="2000"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

#
[mask_off time="2000"]
;ｓＥガチャガチャ
……嗯～……[wait time="800"][p]
[playbgm storage=gymnopedies2.ogg loop=true volume=50]
[bg storage="indoor/siryo.jpeg" time="1000" wait="false" cross="false"]
[chara_show name="riki" top="-100" face="sad_s" wait="false" time="1000"]
[delay speed="60"]
#riki
可恶……树月那家伙……[l][r]
居然特意把我引到房间里关起来[p]
[delay speed="50"]
[chara_hide name="riki" time="10"]
[chara_show name="aki" top="-100" face="sad_s" time="300" wait="false"]
#aki
哈啊　答应带路的优君　从一开始[r]
就和一树串通好了吧[l][r]
完全被耍了啊　真是狡猾呢[p]
[chara_move  name="aki" left=250 top=-100 time="300" wait="false" anim="true"]
[chara_show  name="riki" face="normal_s" left=-70 top=-100 time="300" wait="false"]
[chara_show  name="hino" face="normal_s" left=-230 top=-100 time="300" wait="false"]
[chara_show  name="suguru" face="sadB_s" left=490 top=-100 time="300" wait="false"]
#suguru
[font size="40"]
最讨厌阿奇了！！[p][resetfont]
[resetdelay]
#hino:angry_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="hino" top="-=10" time=100 ]
[anim name="hino" top="+=10" time=100 ]
就是啊器乐堂！[r]　
聪君怎么可能有这种精湛的演技啊[p]
#hino:lookAway_s
而且她本人也是[r]
被亲姐姐弄晕关起来的可怜人啊！！[r]
同为受害者就该团结一致啊[p]
[delay speed="60"]
#suguru:sad_s
日、日野学长……♡[p]
[delay speed="50"]
#riki:hate_s
话说人挤人热死了。谁快出去啦—[p]

#hino:shame_s
[font size="40"]
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
就是因为做不到才在发愁啊！[p][resetfont]
#aki:normal_s
力君真是没救了啦[p]

#riki:smile_s
啊——说起来阿姨呢？没事吧？[r]
该不会头痛到要晕倒吧？[p]
#
[chara_hide_all wait="true"]
[chara_show name="kinuyo" top="-160" face="back" wait="true"]
#kinuyo
…………嗯[p]

#riki
嘿～。超厉害～啊～。[r]
明明穿得最厚实！[p]
一滴汗都没流，超帅！[p]

#kinuyo
…………[p]
[chara_hide name="kinuyo" time="10"]
[chara_show  name="aki" left=250 top=-100 wait="false" top="-100" face="wow_s"]
[chara_show  name="riki" face="smileCE_s" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="normal_s" left=-230 top=-100 wait="false"]
[chara_show  name="suguru" face="normal_s" left=490 top=-100 wait="false"]

#aki
真是的～力，别连对熟人家长都阿谀奉承啊。[p]

就算真的被志户田家拐走了，你[r]
可是要当纱罗纱的弟弟哦？能忍受吗？[p]
[resetdelay]
#riki
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
能忍能忍！每天都能抄志户田的作业！[p]
[delay speed="50"]
#aki:smile_s
……………[r]
啊～纱罗纱的妈妈对不起，吵到您了……[p]
[delay speed="50"]
#aki:ghost_s
如果真的到极限的话[r]
让我加入也可以哦[r]
内部平均年龄看起来也不会有什么变动呢[p]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
#hino:shame_s
器乐堂！！你居然连同学的母亲都敢戏弄！！！[r]
闭嘴闭嘴！！[p]
[stop_kanim name=hino]
[chara_hide_all time="10"]
[chara_show name="kinuyo" face="angry" top="-160" wait="false"]
[delay speed="60"]
#kinuyo
……还是算了吧。[r]
这种程度根本不需要借助他人力量[p]

#kinuyo:sad
不过话说回来……内部？[r]
你究竟获得了什么样的祝福……[p]
[chara_hide name="kinuyo" time="10"]
[chara_show  name="aki" left=250 top=-100 wait="false" top="-100" face="normal_s"]
[chara_show  name="riki" face="smileCE_s" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="normal_s" left=-230 top=-100 wait="false"]
[chara_show  name="suguru" face="angry_s" left=490 top=-100 wait="false"]
#suguru
……是啊……[r]
拜托别再说这些祝福相关的内部梗了[p]
[delay speed="50"]
#riki:smile_s
哈哈。[r]
优——别摆出那种闹别扭的表情嘛——[p]

#hino:tweet_s
没错，没必要在意。[p]
#hino:smile_s
要是太着急勉强自己的话，[r]
反而可能会获得奇怪的祝福哦，真的！[r]
只要稳坐钓鱼台，祝福迟早会降临到你身上的[p]
#hino:happy_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
相反，正因为等待了这么久，[r]
说不定会降临惊天动地的祝福哦！？[p]
#suguru:normal_s
……………………[l][r]
#suguru:smile_s
[delay speed="100"]
……嘿嘿，好的……前辈[p]
[resetdelay]
#aki:normal_s
哈——哈哈 好啦好啦 好烫好烫[p]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
#hino:angry_s
话说回来，对了！[p][stop_kanim name=火野]
#hino:tweet_s
刚才热得都忘了说……[r]
是登利啊。[p]

#riki:normal_s
啊？[p]
[delay speed="50"]
#hino:smile_s
密室在你面前连市民公园都不如吧。[r]
快点消失，从外面把锁打开[p]
#riki:normal_s
………………………………[l][r]
#riki:lookAway_s
不行[p]

#hino:shame_s
为啥啊！[p]

#riki:tweetLA_s
总觉得不太顺利。[r]
可能是被树月消除了祝福的使用方法[p]

#aki:tweetLA_s
真是滴水不漏啊 不愧是一树[p]

#hino:sad_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
可恶、这么说在外部救援到来之前[r]
我们得一直在这里被蒸着吗……！[p]

#riki:sad_s
……啊、[p]
[resetdelay]
#riki:shoutG_s
[font size="40"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
啊啊啊！ 你那什么眼神———！？[p]

#riki:wow_s
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
搞什么啊、[r]
你想说是我的错吗！？[r]
不对、不是我的错、对吧！？[p][resetfont]
[delay speed="50"]
#aki:tweet_s
啊——烦死了 都怪日野说了多余的话[p]
[chara_mod name="suguru" face="sad_s"]
#hino:shame_s
[font size="40"]
诶！？！？[p][resetfont]
[resetdelay]
[font size="35"]
#riki:shoutG_s
就是啊 连祝福都没有的我根本派不上用场[r]
简直就是垃圾！这种事、这种事我最清楚不过[r]
我比谁都明白！！[p]
[resetfont]
#hino:sad_s
呜哇，呜哇啊啊，[r]
这到底是怎么回事，该怎么办才好！？[p]
[delay speed="50"]
#aki
真是…………　没办法啊。[l][r]
#aki:wow_s
…………………………[p]
[chara_hide name="aki" wait="false" pos_mode="false"]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]

;ＳＥごそごそ
[resetdelay]
#hino:shame_s
[anim name="riki" left="-=60" time=100 ]
[anim name="riki" left="+=60" time=100 ]
器乐堂君！！别无视我快帮忙……[l][r]
#hino:sad_s
喂、你在干什么啊？[p]
[delay speed="60"]
#aki
嗯——所以说啊……[l][r]
我啊 最讨厌空白啊 空虚啊 浪费时间的行为了[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" face="tweet_s" wait="false"]
#aki
这里[r]
是纱罗纱要去的资料室吧 虽然现在被困住了[p]
#aki:normal_s
而且 我们 除了力之外 都没有获得祝福[r]
只有破坏茧的家才能离开这里[l][r]
也就是说 短时间内无法对外采取行动[p]
#aki:smile_s
既然如此 不如趁现在[r]
就用我们在这里的[wait time="500"][er]
[chara_move name="aki" left="-70" anim="true" wait="false"]
[chara_show name="suguru" top="-100" face="wow_s" left="360" wait="false"]
#suguru
[quake time="30"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
诶！？[p]
[delay speed="100"]
#aki:smileB_s
…………[p]

#suguru
难道……[l][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
要看吗……？[font color="0xf08080"]秘密教典[resetfont]……[p]
[delay speed="50"]
#aki:normal_s
啊哈哈 果然还是不行吗？[p]
#aki:hate_s
那个叫马利甘的外人 好像知道内情的样子[r]
身为眷属的我们却什么都不知道[r]
总觉得很不爽呢[p]

#aki:tweet_s
而且……那本所谓的秘密教典[r]
究竟是记载了什么内容 才会成为狮心教的秘藏[r]
我也很想知道啊[p]
[chara_hide_all time="10"]
[chara_show name="riki" top="-100" face="smileH_s" left="300"  wait="false" time="100"]
[chara_show name="hino" top="-100" face="tweet_s" left="-70" wait="false" time="100"]
#riki:smileH_s
哈哈，哈哈哈。[r]
肯定是写了什么不得了的秘密吧　该不会是本小黄书吧[p]
[resetdelay]
#hino:angry_s
[anim name="hino" left="+=60" time=100 ]
[anim name="hino" left="-=60" time=100 ]
喂登利你够了啊，[r]
狮心教藏起来的信息怎么可能只是小黄书这种程度[r]
开玩笑吧[p]

#riki
就是啊　又不是国雄家老爷子那种人[p]

#hino:shame_s
[quake time="30"]
[font size="40"]
你这混蛋还要纠缠到什么时候啊！！！！[p][resetfont]
[delay speed="50"]
[chara_hide_all time="10"]
[chara_show  name="aki" left=250 top=-100 wait="false" top="-100" face="tweet_s"]
[chara_show  name="riki" face="normal_s" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="angry_s" left=-230 top=-100 wait="false"]
[chara_show  name="suguru" face="sad_s" left=490 top=-100 wait="false"]
#aki
优酱虽然知道[font color="0xf08080"]秘密教典[resetfont]的存放地点……[l][r]
但从之前的口气来看　你其实没读过对吧？[p]

#suguru:normal_s
……嗯[p]
[delay speed="60"]
#suguru:normal_s
『秘密教典』严格来说……[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]只有最高位的三名女官[resetfont]才被允许阅读[font color="0xf08080"]
是传承资料[resetfont]……啦[p]

所以雾绘姐、树月姐姐她们……应该都读完了吧[p]
[fadeoutbgm time="2000"]
#kinuyo
上面记载的是，[r]
关于狮心教与宗方家、志户田家的交易关系哦[p]
[chara_mod name="riki" face="wow_s"]
[chara_mod name="aki" face="wow_s"]
[chara_mod name="hino" face="sad_s"]
#suguru:wow_s
……诶？[p]
#
[chara_hide_all time="100"]
[chara_show name="kinuyo" face="sad" top="-160" wait="true"]
#kinuyo
………………………………[p]

#kinuyo:angry
够了……[r]
事到如今，只能由我……从头开始说明了吧。[l][r]
[delay speed="100"]
对那孩子也一定……[p]

[mask folder="bgimage" graphic="still/part4.png" time="3000"]
[wait time="2000"]
[chara_hide name="kinuyo" time="10" wait="true"]

;セーブしますか？
;第四章　パート三へ
[showsave]
@jump storage="chapter_4/day1_vol3.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#e14f4b");
},
function() {
  $(this).css("color", "#000000");
　}
);
[endscript]
[return]
;---------------------------------------------------------
[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
