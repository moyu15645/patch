;-------------------------------------------------------------------------------
*part4
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '四章一日目　後編'"]

@layopt layer=message0 visible=true
[bg storage="brack.png" time="100"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font color="0xb0c4de"]
[clearfix]
#
[mask_off]
茧之典[l]
[r]
[r]
明治○年[l][r]由志户田家当家　志户田正嗣所提倡的　士心教[l][r]
[r]
由宗方家继承[p][resetfont]
[playse storage=page.ogg volume="50"]
[mask time="2000"]
[wait time="1000"]
[bg storage="brack.png" wait="false" time="10"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=3000 volume="30"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
#sarasa
[mask_off time="2000"]
……一树……[p]
[filter invert="90" blur="4"]
[bg storage="indoor/sisin_stage.png" time="100" wait="false" cross="false"]
[chara_show name="ituki" face="angryB_gs" top="-160" time="100" wait="false"]
[resetdelay]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
[font size="36"]
[delay speed="18"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
吵死了、吵死了！！[r]
别看我、不要看啊啊啊[p][stop_kanim name=ituki][resetfont]
#
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
树月的发束，紧紧勒住我的脖子。[p]

#sarasa
（――再这样下去，就再也无法和一树说话了）[p]

#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
必须想办法…………让一树、[r]
找到不让我被杀的方法…………！！！[p]
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=false
[clearfix]
@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
树月方才回忆的是？[r]
[glink color="btn_12_black" target="*but" text="与纱罗纱共度的今年初夏时分" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but" text="纱罗纱开始能够看到他人回忆的那一天" width="20" x="630" y="60"]
[glink color="btn_12_black" target="*good" text="与纱罗纱共度的小学时代的暑假" width="20" x="580" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*but
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask]
[chara_hide name="ituki" time="10"]
[fadeoutbgm time="4000"]
[wait time="4000"]
@layopt layer=message1 visible=false
[clearfix]
[wse]
@layopt layer=message0 visible=true
[current layer="message0"]
[position vertical=false]
#
[bg storage="brack.png" time="100"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetfont]
;-------------------------------------------------------------------------------
[mask_off]
……[l][r]
………………………[p]

我的记忆　再也不会举办宴会了。[p]

结局５　「地狱的季节」[p]
[free_filter]
[resetdelay]
[clearfix]
@jump storage="first.ks"
;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
【选择正确的选项】[r]
树月刚才[r]
自然而然回忆起的，[r]
[font color="0x00008b"]纱罗纱所不知道的记忆[font color="0x000000" face="serif" shadow="0xffffff"]
是？[r]
[glink color="btn_12_black" target="*but" text="关于八种町的地方病" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good2" text="与狮心教相关的志户田家与宗方家的关系。" width="20" x="630" y="60"]
[glink color="btn_12_black" target="*but" text="关于御黑祟想要的情报" width="20" x="580" y="60" ]
[resetfont]
[s]

;-------------------------------------------------------------------------------
*good2
;-------------------------------------------------------------------------------
[mask time="10"]
@layopt layer=message1 visible=false
[clearfix]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
@layopt layer=message0 visible=true
[current layer="message0"]
[position vertical=false]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetfont]
[mask_off]
;-------------------------------------------------------------------------------
[delay speed="50"]
#sarasa
（没错……那一刻）[p]
[mask]
[filter grayscale="100"]
[chara_hide name="ituki" time="10"]
[bg storage="still/kobura_1.png" time="10"]
[mask_off]

（我并未看见、本不可能知晓……[r]
[font color="0xf08080"]『关于志户田家是狮心教最初提倡者的说法。』）[p][resetfont]


（[font color="0xf08080"]被遗忘的记忆[resetfont]正在一树脑海中苏醒）[p]

#sarasa
（也就是说……）[p]
[mask]
[free_filter]
[bg storage="indoor/sisin_stage.png" time="10"]
[chara_show name="ituki" face="angryB_gs" top="-160" time="10"]
[filter blur="4" invert="90"]
#sarasa
[mask_off]
（即便是小一树自己曾经遗落的记忆，[r]
[font color="0xf08080"]只要给予一个契机[resetfont]就有可能将其拖拽回来……）[p]
[resetdelay]
#
高举着我的树月的身影，[r]
仍在忽明忽暗的视野中若隐若现。[p]
[font size="40"]
[delay speed="14"]
#ituki
看着我的眼睛，忘记吧！[r]
把全部统统忘记，变成石头吧！！[p][resetfont]
[delay speed="80"]
#sarasa
（为什么小一树会……[l][r]
想要遗忘那段记忆……！？）[p]
[resetdelay]
#ituki:hate_gs
啊哈哈，呐，将死之人散发的味道真美妙啊……！！[r]
是什么呢，这是什么味道……[p]
#ituki:smileH_gs
[quake time="30"]
[quake time="30"]
知道了，是刨冰！是刨冰的味道！[p]
[delay speed="50"]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
――她看起来像是神志不清的样子。[r]
想要进行对话，恐怕根本不可能。[l][r]
[r]
[delay speed="70"]
我下定决心，从后口袋掏出那个”，[r]
抵在她脖颈处那片带有[font color="0xf08080"]祝福[resetfont]字样的鳞片上――[wait time="500"][l][r]
[r]
用力扯了下去。[p]
[mask time="100"]
[wait time="100"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[free_filter ]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[stopbgm]
[wse]
[chara_face name="sarasa" face="cut_s" storage="chara/sarasa/sihuku/cut_s.png"]
[chara_face name="sarasa" face="cut2_s" storage="chara/sarasa/sihuku/cut2_s.png"]
;ＳＥジャッ
[wse]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
;ＳＥどさっ
[chara_hide name="ituki" time="10"]
[chara_show name="sarasa" top="-160" face="cut_s" time="10"]
[mask_off time="100"]
[delay speed="100"]
#sarasa
呜……[l]咳呃，
[anim name="sarasa" top="-=30" time="100"]
[anim name="sarasa" top="+=30" time="100"]
咳呕[p]

#ituki
――纱罗纱[p]
[delay speed="60"]
#
跌倒在地的我，[r]
迎向紧攥着被割断发丝的她[r]
「那充满「不可置信」的目光。[p]
#ituki
你居然…………[p]
………………………你竟然、对我做出这种事[p]
[delay speed="100"]
#sarasa
…………树月、君[p]

#sarasa:cut2_s
……我的眼睛也是与众不同的啊，[l][r]
……………………[wait time="600"]一树[p]
[mask time="100"]
#
[clearfix]
[delay speed="50"]
;ＳＥカーン
[chara_hide name="sarasa" time="10"]
[bg storage="brack.png" time="10"]
[playse  volume="80" buf="0" storage="sariin.ogg" ]
[wse]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[filter grayscale="100"]
;ＳＥカーン
[mask_off time="6000"]
[delay speed="60"][font size="22"]
姐姐大概打算永远不再回到这个小镇吧[r]
我隐约察觉到了[l][r]
[r]
或许是因为最后那晚看到的 她难以形容的表情[l][r]
又或许是因为她本身[r]
对这个家缺乏归属感的缘故[l]
[r]
[r]
总之 那个女人 肯定再也不会回到这个家了[wait time="600"][r]
我有这种确信[p]

「『雾绘逃走了。』[l][r]
「『在下个簇日 你将作为最高位的三人官女即位。』[l][r]
「『树月。今晚睡前要读『茧之典』。』[l][r]
[r]
[delay speed="80"]
……虽然父亲和母亲们这么说着[r]
我满脑子都是已经请假一周的纱罗纱的事情[l][r]
[r]
今天纱罗纱也没来学校[r]
[r]
见不到她好寂寞[l][r]
在见不到你的这段时间里…姐姐她消失了[r]
好想快点传达这份心情　想告诉你　想让你和我融为一体[r]
想分担这份心情[wait time="500"]　想和你获得解脱[p]
[bg storage="indoor/siryo.jpeg" wait="true" cross="false"]
[playse storage=page.ogg volume="50"]
[wse]
;ＳＥペラ
[delay speed="50"]
[font color="0xb0c4de"]
[r]
[r]
茧之典[l]
[r]
[r]
明治○年[r]由志户田家当家志户田正嗣提倡的士心教[r]
[r]
由宗方家继承[p][resetfont]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetdelay]
#ituki
…………咦？[p]
[delay speed="70"]
……啊、啊？　这……[wait time="200"]为什么、[p]
…………………………………………[r]
……………………[resetdelay]完全不明白[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font color="0xb0c4de"]
[delay speed="50"]
[r]
[r]
[r]
由宗方家选出的三位巫女将　与疏离的[r]
志户田家[r]
严禁利用此事实进行接触[l][r]
[r]
[r]
[delay speed="120"]
马门神社神主　马门审四郎[p][resetfont]

「…………………………………………」[l][r]
「这、………………………………[l]完全………………不明白」[p]
[font size="22"]
[delay speed="50"]
[r]
[r]
（为什么会出现四ツ山神社的名字？为什么为什么，[l][r]
　为什么这里会写着志户田这几个字？）[r]
 [delay speed="100"]
（为什么……我们必须，
　对志户田家隐瞒这件事？）[r]
[r]
「为什么，为什么为什么，[resetdelay]为什么，我不明白啊」[l][r]
[r]
[font size="40"]
（不明白不明白不知道不知道！！）[p]
[quake time="30"]
（不知道！！）（不知道不知道！！）[r]
（不知道不知道！！）[r]
（不知道不知道）（不知道不知道）[r]
（不知道不知道）[r]
（不明白不明白！！）（不明白不明[er]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[r]
[resetfont][delay speed="50"]
;ＳＥガラッ
[r]
[font size="22"]
「看完就睡吧。树月」[p]
[delay speed="70"]
只能选择理解。[l][r]
[r]
看着父亲们的脸，我意识到即便无法理解，也必须接受这个事实。[p]
[bg storage="brack.png" wait="false" cross="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
;ＳＥ歩く
[delay speed="50"]
我可是很善解人意的哦。纱罗纱。[r]
而且一定比你对我所做的 更加激烈[r]
我和你交谈的时候 可是考虑了很多事情和规则才开口的哦。[l][r]
[r]
你大概觉得我和你是对等的朋友关系吧[r]
就在此时此刻[r]
我又多了一件和你说话时必须考虑的新事情[l][r]
你大概从不会怀疑[l]
我和你一样活得无拘无束这件事吧[r]
[r]
[delay speed="70"]
你真棒呢 是个自由又特别的女孩呢 纱罗纱[l][r]
让我痛苦的一切[l]都源自于你[p]

……回寝室的途中，[l][r]
经过了茧家里那扇最大的窗户。[l][r]
[r]
窗外，雪花零星飘落。[l][r]
[r]
黑暗中玻璃映出的我的脸，[r]
和最后见到姐姐时的[wait time="600"] 那个表情，一模一样。[p]
[bg storage="still/ganmon.png" time="5000" wait="false"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="30"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="20"]
[wse]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
;くはぬ　とばぬ　みず　なれば
;ねがひたてまつる　しるしあらわせ　しるしあらわせ
[bg storage="indoor/sisin_stage.png" time="10"]
[free_filter ]
[wait time="2000"]
[mask_off time="10"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[font size="40"]
[resetdelay]
#ituki
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[quake time="30"]
[quake time="30"]
呜、呜哇、不要！[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[resetfont]
#
树月猛地从原地跳开。[l][r]
我立刻站起来，俯视着蜷缩的树月。[p]
#sarasa
（……马门神社……！？　为什么，狮心教的教典里会……）[p]
#ituki
笨蛋……你、你要干什么……[p]
#sarasa
………………！[p]
#
――树月也立即站起身，朝我这边走来。[p]
;ＳＥシャー
[chara_show name="ituki" top="-160" face="angryB_gs" time="100" wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#ituki
看着我啊，看着我！　看着我的眼睛啊，纱罗纱！！[p]
[delay speed="18"]
#ituki
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
[font size="36"]
然后像往常一样，装作什么都不知道，[r]
什么都不明白――[r]
继续做那个纯白无垢的志户田纱罗纱啊，给我继续啊！！[p][stop_kanim name=ituki]
[quake time="30"]
#sarasa
……我已经知道了，你一直在保护着我！[r]
就算是为了一树，[r]
我也绝不会假装不知道！[p]
[resetfont]
#ituki:shout_gs
――这种说话方式，最讨厌了！！　什么纱罗纱……[p]
[filter invert="90"]
[font size="36"]
[delay speed="60"]
#ituki:angryB_gs
[playse  volume="30" buf="1" storage="garasu.ogg" ]
别以为知道了我的过去，[r]
就自以为完全明白我的心情[r]
开什么玩笑！！！！！！[p]
[resetfont]
[mask time="10"]
[wse]
[bg storage="hataneA.jpg" time="10" wait="false"]
[chara_hide name="ituki" time="10"]
[playse  volume="70" buf="0" storage="sariin.ogg"]
[mask_off time="100"]
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=false
[clearfix]
@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
[font size="25"]
【选择正确的选项】[r]
宗方树发现了＿＿的秘密[r][font color="0x00008b"]
＿是创始者的事实[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
并渴望忘却这个事实。[r]
[glink color="btn_12_black" target="*loop" text="马门神社" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*loop2" text="狮心教" width="20" x="630" y="60"]
[glink color="btn_12_black" target="*loop" text="开祖" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*loop" text="志戸田家" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*loop" text="宗方三姉妹" width="20" x="480" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*loop2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
[font size="25"]
宗方树发现了狮心教的秘密[r][font color="0x00008b"]
＿是创始者的事实[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
并渴望忘却这个事实。[r]
[glink color="btn_12_black" target="*loop2" text="馬門神社" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*loop2" text="開祖" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*good3" text="志戸田家" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*loop2" text="宗方三姉妹" width="20" x="480" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[mask time="10"]
@layopt layer=message1 visible=false
[clearfix]
[wse]
@layopt layer=message0 visible=true
[current layer="message0"]
[position vertical=false]
[playse  volume="70" buf="0" storage="sariin.ogg"]
[fadeoutbgm time="8000"]
[wait time="4000"]
[free_filter]
#
[delay speed="60"]
[mask_off time="3000"]

[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetfont]
;-------------------------------------------------------------------------------
我再次将那些企图勒紧脖子的发丝，[r]
狠狠斩断――[p]
@layopt layer=message0 visible=false
[clearfix]
[quake time="300"]
[bg storage="indoor/sisin_stage.png" time="3000" cross="false" wait="true"]
[wait time="1300"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
栗色美丽的丝束，[wait time="500"]反射着光芒，[r]
簌簌飘落在两人之间。[p]
[delay speed="100"]
#ituki
…………………………………………[r]
……………………………………………………………………………[p]
#ituki
啊啊………………………[l][r]
啊哈哈　很讨厌吧　纱罗纱[p]
[delay speed="60"]
#ituki
现在被诅咒的，肯定是其他地方的某个人啦[l][r]
但就算是没被诅咒的我，也如此这般地[r]
想要夺走你的性命呢[p]
[delay speed="100"]
#ituki
所以　丝绸燃烧的事　也是我散布出去的[r]
肯定是这样的[p]

#sarasa
………………………………[p][resetdelay]
不……[l]一树是杀不了我的哦[p]
[delay speed="50"]
#ituki
…………[p]
[delay speed="100"]

#
抓住我的手掌力道，正逐渐松懈。[p]

#ituki
…………[wait time="600"]最近的纱罗纱、总让人觉得害怕……[r]
为什么擅自就变成这样了呢…………[p]
#
随后完全松开了我，把头扭向一边。[p]
[delay speed="70"]

#ituki
杀得掉的。能让你死。因为，我绝不会原谅[p]

#ituki
…………只要纱罗纱还存在，[r]
就永远无法得到幸福什么的……[l]我无法忍受啊[p]
[delay speed="50"]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="indoor/sisin_holl.jpeg" time="100" wait="false"]
#
[quake time="300"]
[chara_show name="suguru" face="wow_s" wait="false" top="-100"]
[font size="40"]
#suguru
树月！！！！[p][resetfont]
#
[chara_hide name="suguru" wait="true" time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[delay speed="50"]
[chara_show name="ituki" wait="false" top="-160" face="tweet_gs" left="-70"]
[chara_show name="suguru" wait="false" left="360" top="-100" face="angry_s"]
[fadeinbgm storage="faure-op84-5.ogg" loop=true volume="50"  time="3000" sprite_time="0000-76400"]
#ituki
……优。[l][chara_mod name="ituki" face="angry_gs"]……[p]

#suguru:angry_s
[anim name="suguru" top="+=30" time="70"]
[anim name="suguru" top="-=30" time="70"]
你在干什么！把我的重要的眷属关起来……[p]

#ituki
这不是能出来嘛[p]
[chara_hide_all time="10"]
[chara_show  name="aki" left=250 top=-100 face="normal_s" wait="false"]
[chara_show  name="riki" face="normal_s" left=-70 top=-100 wait="false"]
[chara_show  name="suguru" face="angry_s" left=-230 top=-100 wait="false"]
[chara_show  name="kinuyo" face="normal" left=490 top=-160 wait="false"]
#riki
我把门撬开啦。用钳子哦—[p]
#ituki
钳子？[l]
……那种东西明明不该存在的啊[p]
#aki
是绢世小姐带来的[p]

#aki:tweet_s
她还带了螺丝刀呢。[r]
不知为何还带了锉刀？[p]

#ituki
这、这是什么组合啊……[p]

#kinuyo
是常备工具……[r]
#kinuyo:closeEye
为了随时能处理门锁零件[p]

#aki:tweetLA_s
看吧？问了你也听不懂的[r]
所以我决定不再深究了[p]
#
阿奇说完后，母亲缓缓转向树月――[r]
然后、肯定恶狠狠地瞪了过去。[p]
[chara_hide_all time="10"]
[chara_show name="kinuyo" top="-160" face="back" wait="false"]
#kinuyo
……听说你和我家纱罗纱相处得相当不错呢。[r]
三位官女中的树月小姐[p]
[delay speed="100"]
#kinuyo
………………真是的，你究竟从哪儿搞到我们家的电话号码……[p]
#ituki
………………[p]
[resetdelay]
#
树月滴溜溜地转向母亲，露出可爱的笑容。[p]
[chara_hide name="kinuyo" time="10"]
[chara_mod name="kinuyo" face="sad"]
[chara_show name="kinuyo" top="-160" face="sad" left="360" wait="false"]
[chara_show name="ituki" face="smileCE_gs" top="-160" wait="false" left="-70"]
#ituki
让人家摆出威胁人的架势真是抱歉啦～[p]

#kinuyo
……[l][r]
#kinuyo:angry
总之，再这样下去的话，养蚕的日子就要结束了吧。[r]
必须唤醒眷属们，开始配种仪式了[p]

#sarasa
……妈妈……[p]
[delay speed="60"]
#kinuyo:normal
纱罗纱。你就在丝织室外面等着。[r]
这里可是眷属们神圣的祈祷场所啊[p]
[chara_hide name="ituki" time="10" pos_mode="false"]
[chara_show name="suguru" left="-70" face="angry_s" top="-100" wait="false"]
#suguru
……您说什么呢，绢世小姐。[r]
其实不必勉强的[p]

#suguru:normal_s
毕竟您是不常来的[font color="0xf08080"]离散眷属[resetfont]……[l][r]
对现在的您来说，看这种簇拥交配只会觉得无聊吧。[r]
蔟的纠缠什么的[p]
[delay speed="60"]
#sarasa
……离散、眷属？[p]
[resetdelay]
#suguru
不是以家庭为单位入教的成年眷属，[r]
渐渐不再出席集会的情况非常普遍。[l][r]
大多都是放弃了祝福。还有……[p]
#suguru:angry_s
一旦获得祝福就认为狮心教已经没什么可留恋的，[r]
也有人会舍弃信仰。[r]
对于那些不再来茧家的人，大家都这么称呼[p]
#
优用扭曲的视线望向母亲。[p]
[delay speed="60"]
#kinuyo:normal
……………………[l][r]
#kinuyo:sad
不。让我祈祷。[p]
[delay speed="60"]
#kinuyo:angry
好久没有这样的感觉了……[r][wait time="500"]
所以请让我祈祷吧 各位[p]
[delay speed="100"]
#kinuyo:sad
然后……[wait time="500"]等结束后，[r]
来和我聊聊吧，纱罗纱[p]
[fadeoutbgm time="5000"]
[mask time="5000"]
[wait time="2000"]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="indoor/sisin.jpeg" time="10" wait="false"]
[chara_hide_all time="10"]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=40]
#
[mask_off time="5000"]
[delay speed="50"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
窗外传来乌鸦的啼鸣。[r]
不知不觉已是黄昏。[p]

在空无一人的走廊里回荡着某个人的歌声。[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
啊，这是——[wait time="500"]树月的声音。[l][r]
树月的声音明亮而坚定，带着毋庸置疑的自信，仿佛在——[wait time="600"][r]
吟唱着狮心教的祷文之类的歌谣。[p]
[bg storage="shotengai_a.jpeg" cross="false" wait="false"]
[delay speed="150"]
#
愿三柱女官将祈祷传达至白绢御白比卖命[wait time="1000"][er]

吾等自祈祷之后　不食　不飞　不视[r]
故而供奉祈愿　于此镇守大地之姬神尊[wait time="1000"][er]
[bg storage="hataneA.jpg" cross="false" wait="false"]
姬君垂怜　姬君垂怜[wait time="500"][r][wait time="500"]
姬君垂怜　姬君垂怜[wait time="500"][er]
[bg storage="indoor/sisin.jpeg" cross="false" wait="false"]
…………[p]
[delay speed="50"]
从房间探出身去，环视四周。[p]

这时，在走廊的尽头――[wait time="500"][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
发现有什么闪闪发光的东西掉落在地。[p]

#sarasa
（……[wait time="500"]是什么呢？）[p]
#
走出房间，决定去确认那个发光的东西。[p]

;ＳＥ廊下を歩く
[fadeoutbgm time="3000"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[bg storage="indoor/sisin_roka.jpeg" cross="false" wait="false"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
…………[p]

#sarasa
（咦，这个……是玻璃弹珠……？）[p]
#
静静躺在那里的，[r]
是一颗表面有些缺损的圆形玻璃饰品。[p]

从玻璃珠所在处向左望去――[wait time="500"][r]
可见一道通向半掩门扉的小小阶梯。[p]

在那每一级台阶上，[r]
都镶嵌着与我手中之物相似的晶亮碎片。[p]
[bg storage="brack.png" cross="false" wait="false"]
我拾起每一颗发光的珠子，沿着阶梯向上……[wait time="800"][r]
将手搭在了那扇半开的门扉上――[p]
[mask]
;ＳＥぎいー
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[bg storage="indoor/ituki_heya.jpeg" time="10"]
[mask_off]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=30]
#sarasa
（……！这是…别人的房间……）[p]
#
正想着不该擅自闯入而低头的瞬间。[l][r]
我再次发现了某样东西，[wait time="500"]不由自主将身体探回屋内。[p]
脚边……[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
挂着弹珠装饰的风铃，已然碎了一地。[p]
我捡到的所有玻璃珠，[r]
大概都是从这儿散落的吧。[p]
[delay speed="80"]
这水母般的形状，似曾相识――[p]

……………………………………[p]
#sarasa
（……啊……这是……）[p]
（小学时，暑假手工作业发下来的，[r]
　风铃材料包的……！！）[p]
[delay speed="50"]
#
我抬起头。[l][r]
在房间墙壁的高处，[r]
发现插着一枚塑料图钉。[p]
或许是悬挂的绳子老化，又或许是风吹过——[r]
总之它原本应该是挂在那里的装饰品。[p]

勉强保持完好的半透明钟形表面，[r]
点缀着制作者绘制的图案。[l][r]
[delay speed="80"]
而这些图案全都描绘着夏日的风物诗。[p]

向日葵。[l]蝉鸣。[l]冰淇淋。[l][r]
白色的……小小的、幽灵。[p]

然后。[p]

并排放置的、游泳圈。[p]
[fadeoutbgm time="5000"]
#sarasa
……[p]

#sarasa
……………………[p]
[mask time="3000"]
[playbgm storage=gymnopedies2.ogg loop=true volume=50]
;スチル：屋上
#
[delay speed="50"]
[bg storage="still/dance3.png" time="4000" wait="true" cross="false"]
[mask_off time="3000"]
如果我的记忆没错，那时候……我的生活就像一场盛宴。[p]
每当两人一同欢笑，那声音仿佛能传遍整条街道。[r]
那声音化作回声从高处传来，[r]
已分不清是我的还是树月的。[p]
[delay speed="80"]
夏日的决心　[wait time="500"]是树月教会我的。[p]
………………[wait time="500"][r]
………………………………………[wait time="500"][r]
但夏天也不会永远持续　[wait time="500"]终将迎来寒冬。[p]
[bg storage="brack.png" wait="false" cross="false"]
――约两年前　冬日。[p]
[resetdelay]
#父
纱罗纱。哥哥和爸爸时隔好久回来了哦。[r]
为什么要逃跑？[p]
[delay speed="100"]
#
…………[p]
[filter grayscale="60"]
[bg storage="indoor/sitodaHouse.jpg" wait="false" cross="false"]
[chara_face name="mokke" face="ani" storage="chara/mokke/longBlack.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '兄'
[endscript]
[chara_show name="mokke" top="100" face="ani" wait="false"]
[resetdelay]
#mokke
妈妈。纱罗纱真的没什么问题吧？[r]
总觉得……简直像完全变了个人似的[p]
[delay speed="50"]
#kinuyo
…………嗯 应该什么事都没有的[p]
[chara_face name="mokke" face="titi" storage="chara/mokke/menGreen.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '父'
[endscript]
#mokke:titi
真让人担心啊。明明马上就要升初中了……[p]

#
………………[p]

我想这件事对谁都不能说。[r]
父亲也好，哥哥也好……[p]
[chara_hide_all time="1000" wait="false"]
[bg storage="brack.png" time="1000" cross="false"]
[delay speed="100"]
[filter grayscale="100"]
班主任也好，同学也好，街上行人也好，[wait time="500"]全都像怪物一样。[p]

;○学校

;ｓＥ学校のチャイム
[playse storage=bell.ogg sprite_time="0000-6000" volume="5"]
[wse]
[bg storage="school/rouka_m.jpg" wait="false" cross="false"]
[resetdelay]
#sarasa
啊……！[p]

#sarasa
一树！一树……[p]
[delay speed="50"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
#ituki
……………………………………[p]
#sarasa
请假一周，对不起啊。[r]
我啊，那个，很不对劲。眼睛，出了毛病……[p]

#ituki
哈？[p]
[delay speed="50"]

#sarasa
……诶？[wait time="500"]所以说，我的[wait time="500"][r]
[quake time="30"]
……噫！！[p]

#ituki
……怎么了？那声惨叫[p]

#sarasa
那、那个，大家都、变得超级可怕……已经持续很久了。[r]
突然这是怎么了，而且。[l][r]
所以我已经、完全不知道该怎么办才好……[p]

#ituki
不知道不就好了嘛？[p]

#sarasa
诶……[p]
#ituki
装作不知道不就好了嘛。[r]
保持沉默不就好了嘛。[p]
反正纱罗纱你呀[r][wait time="500"]
就算不作声　一动不动　什么都不做，[r]
也还是纱罗纱呀[p]
[mask time="1000"]
[free_filter]
[bg storage="indoor/sisin.jpeg" time="10"]
[chara_face name="sarasa" face="cry_s" storage="chara/sarasa/sihuku/cry_s.png"]
[chara_show name="sarasa" top=-160 left="360" face="sad_s" time="10"]
[delay speed="60"]
[fadeoutbgm time="3000"]
[wait time="3000"]
#
[mask_off time="1000"]
树月大概从那时候起……[wait time="500"][r]
就已经不太信任我了吧。[p]

#sarasa
（即便如此……[wait time="500"]一树还是把我当朋友的。）[p]

#sarasa:closeEye_s
（明明可以理所当然地厌恶我，却硬是隐瞒了那个决定性的事实——[r]
甚至不惜用强制手段也要藏着……[wait time="500"]就这样一直陪伴在我身边）[p]
#
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=30]
[delay speed="70"]
回想起刚才在房间里看到的、[r]
那个已经损坏的风铃。[p]
钟形图案的底色完全被颜料涂抹成一片蓝色。[r]
简直像是大海，[wait time="500"]……………………………[p]
[delay speed="100"]
如同在八种町永远无法得见的、[wait time="500"]那片海洋一般。[p]
[delay speed="70"]
#sarasa:sad_s
…………对不起[p]
#sarasa:cry_s
对不起…………[p]
#
我，[r]
一边回想着人生中最快乐的那个暑假——[p]
那个瞬间能永远停留的、[wait time="500"]幼小的自己，[wait time="500"]令人嫉妒到心痛。[p]
[bg storage="brack.png" time="3000" wait="false" cross="false"]
[chara_hide name="sarasa" time="3000" wait="true"]
[wait time="1000"]
#sarasa
……一树[p]

#
一树。[wait time="1000"]一树。[p]

明明差点被杀掉了呢，[p]

脑海中却始终保持着[r]
[wait time="500"]私に知らしめる。[p]
[fadeoutbgm time="3000"]
今后无论[wait time="500"]　暴露出怎样的事实――[p]
与你相遇这件事，[wait time="800"][r]
我一定[wait time="800"]　不会后悔。[p]

[mask folder="bgimage" graphic="still/part4.png" time="3000"]
[wait time="2000"]
[delay speed="50"]
[chara_hide name="sarasa" time="10"]
[mask folder="bgimage" graphic="still/part3.png" time="3000"]
[eval exp="f.save_title = '三章二日目　後編'"]
;暗転
[playbgm storage=sicilienne.ogg loop=true volume="30"]
[wait time="2000"]
[mask_off time="2000"]
;○焼肉
#nyudo
啊……这个、已经可以吃了……哦[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
@layopt layer=message0 visible=false
[clearfix]
[resetdelay]
[bg storage="still/yakiniku1.png" time="2000" wait="true" cross="false"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#marigan
哎呀—，谢谢您。[r]
我超喜欢猪五花肉呢—　呵呵[p]
[font size="20"]
#nyudo
[playse  volume="30" buf="0" storage="kansei.ogg"]
我……我也、喜欢……！[p]
[resetfont]
[delay speed="100"]
#makado
…………………………[l][r]
那……………………那个、[p]
[bg storage="still/yakiniku3.png" wait="false" cross="false"]
#nyudo
？[l][r]
怎么………了吗。马门君。[p]
#makado
………[wait time="500"]没事。[l][resetdelay]入道老师。[r]
我来替您烤吧，老师也请趁热吃[p]

#nyudo
不用了……我本来饭量就小……[r]
来……年轻人要多吃点……[p]

#makado
啊，那个[p]

#makado
……那个、抱歉[p]
[bg storage="still/yakiniku2.png" wait="false" time="300"]
[chara_show name="marigan" top="-10" face="smileB" left="420" wait="false"]
[chara_show name="nyudo" top="-30" face="normal" left="-200" wait="false"]
#kawa
[chara_show name="kawa" top="-10" face="normal" left="140" wait="false"]
[font size="20"]
喂。[p]
[resetfont]
#makado
那我去点下一轮饮料。[r]
要喝点什么？[p]
[delay speed="60"]
#nyudo:sad
[anim name="nyudo" top="-=60" time="200"]
[anim name="nyudo" top="+=60" time="200"]
唔……啊、那就……乌龙茶……乌龙茶好了……[p]
[resetdelay]
#marigan:smileCE
我要啤酒——大杯的[p]
[font size="40"]
#kawa:smile
喂！喂！喂——！[p]
[resetfont]
#makado
好的，川铃木老师点的是茶对吧。[r]
[r][wait time="500"][font time="40"]
不好意思——[p]
#kawa
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[font size="40"]
不对！是嗨棒！！[l][r]
[chara_mod name="kawa" face="sad"]
[resetfont]ってそれも違ーうー[p]
#marigan:tweet
总感觉、来这儿之后川铃木老师没什么干劲啊[p]
[delay speed="60"]
#nyudo:closeEye
[font size="20"]
不过是不能吹笛子的状态罢了……居然会弱化到这种程度……[p]
[resetfont]
[resetdelay]
#kawa:normal
我说啊。肉。是肉啊[p]
#makado
啊？[p]
#kawa:smile
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
老子盘子里好久都没上肉了啊——。[p]
[delay speed="60"]
#nyudo:normal
川铃木老师……  您自己……烤也没关系的哦……[p]
[resetdelay]
#kawa:shame
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
哈哈哈。入道老师总是这么幽默风趣啊[p]

#marigan:worry
啊—贤治郎，你的肉被偷吃了哦—[p]
[delay speed="70"]
#makado
………………………………[p]
[delay speed="50"]
#makado
…………肉也好酒也好，请随意享用。[p]
#makado
但是，…………[wait time="500"]我没忘记来这里的目的吧？[r]
川铃木老师[p]
[resetdelay]
#kawa:normal
啊—知道知道。宗教信仰是吧—。[l][r]
[delay speed="70"]
#kawa:smile
我和入道老师都是狮心教的！　[resetdelay]这下满意了？[p]
[font size="40"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
――！！[p][resetfont]
[delay speed="70"]
#makado:
那……那么、[r]
小谷坂学园的教师中，信仰狮心教的……[p]
[resetdelay]
#kawa:think
[font color="0xf08080"]
熊明子老师[resetfont]、在下[font color="0xf08080"]川铃木仁[resetfont]、
顺便还有[font color="0xf08080"]入道永海[resetfont]老师三人啦—。[l][r]
#kawa:smileW
[delay speed="50"]
啊，服务员—。点单—[p]
#makado
那……入道老师！刚才的话……[p]
[delay speed="100"]
#nyudo:sad
是的……作为顺便提及的眷属，就是我……[p]

#makado
[chara_hide name="makado" wait="false"]
……………………[p]
[delay speed="60"]
#makado
（纱罗纱……[l][r]
你所说的[font color="0xf08080"]「特殊教师」[resetfont]们，确实存在共同点……）[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="70"]
#
三人全都是以崇拜御白姬为核心的[font color="0xf08080"]狮心教信徒[resetfont]……！[p]

#makado
[fadeoutbgm time="5000"]
（然而――）[p]
[delay speed="50"]
#
那孩子，[r]
究竟对此事预见到了何种程度呢。[p]

当她特意让我打探的内容仅限于 [font color="0xf08080"]信仰相关[resetfont] 之时，[r]
她一定早就预料到了某种程度――[p]
[delay speed="80"]
#makado
（……那孩子所说的'特殊教师'，[r]
究竟为何特殊）[p]
#makado
（在弄清这点之前，恐怕……[l][r]
我再怎么思考也是徒劳）[p]
[font size="20"]
[resetdelay]
#nyudo
（玛丽甘小姐……连用餐仪态都如此优雅迷人……）[p][resetfont]

[delay speed="50"]
#makado
（对了，总之得先把已确认的情报汇报上去。[r]
	希望茧那边也能顺利进展……）[p]
[font size="20"]
[resetdelay]
#nyudo
（这么优秀的人……肯定已经有恋人了吧……[r]
抱歉我擅自兴奋过头了…………唉……）[p]
[resetfont]
#kawa:normal
那、就到这里吧[p]
[delay speed="100"]
[font size="20"]
#店員
啊……好……我明白了……[p]
[resetfont][delay speed="50"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
#marigan:normal
川铃木老师～。您嘴上说什么叛逆期啦之类的……[r]
#marigan:angry
其实只是单纯想找个喝酒的借口吧～？[p]
[resetdelay]
#kawa:smile
哈哈哈～被看穿了吗～？[p]
#marigan:sad
明明还有未成年在场，真是位了不得的教师呢……[r]
虽然我相信这是不言而喻的，但请不要给他劝酒哦[p]

#kawa:smileW
您在说什么呀～[r]
大一学生放眼整个人生都是最意气风发的春天对吧？[r]
不存在没喝过酒的未成年人啦～[p]
[delay speed="80"]
[font size="20"]
#nyudo
（这说得……有点过头了吧……）[p]
[resetfont]
#makado
………………[p]
[resetdelay]
#makado
我就是[p]

#kawa:shame
啊？什么？反向装逼是吧？[p]

#makado
不管你是装逼还是怎样都无所谓啦，[r]
反正我觉得合法的比较好[p]

#kawa:sad
一点都不可爱的19岁呢～[r]
你大学里前辈们也不太会邀请你去酒会吧[p]
[delay speed="60"]
#makado
嘛……是的[p]

#nyudo:closeEye
马门同学是……坐新干线通勤的……[r]
应该不太能和同学们一起度过放学后的时光吧……[p]

#kawa:normal
嘿～新干线啊。[p]
[resetdelay]
#kawa:think
……哈？　这什么啊[p]
[delay speed="50"]
#makado
从六月份开始就不是住宿舍，而是从老家通勤上学的[r]
如果我不在的话，父亲看护啊家务什么的就周转不开了……[p]

#marigan:normal
[playse  volume="20" buf="0" storage="sariin.ogg" ]
智子小姐真的对你这么说了？[p]
#makado
…………………………[l][r]
母亲性格使然，遇到困难时不愿意依赖别人[p]

#marigan:tweetLA
……呵。是么……[p]

#makado
（……）[p]
…………………………[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
为什么、要提母亲的名字[p]

#marigan:smileB
嗯—？怎么了？[r]
比平时更用力地皱起眉头。会留下痕迹吗？[p]

#makado
……你总是这样、一味地回避问题呢[p]
#marigan
…………………[p]
#makado
…………………[p]
#marigan:normal
……………………………………[p]
[delay speed="100"]
#nyudo
…………………[p]
#nyudo:angry
[font size="20"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
（呃……这、这是什么气氛……）[p]
#nyudo:angryB
…………………[p]
#nyudo:angryB
[delay speed="60"]
（……得、得想办法……我是不是该说点什么搞笑段子）[p][resetfont]
#nyudo
…………………………………………！！[r]
[playse  volume="20" buf="2" storage="kakan.ogg" ]
那个……[wait time="200"][er]
#kawa:smile
[resetdelay]
不过嘛[r]
你这干脆利落的脑袋倒是挺讨人喜欢的。[r]
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
毛囊是不是死掉了？难道真的坏死了吗？[p]
[chara_mod name="nyudo" face="closeEye"]
[resetdelay]
#makado
别敲了啦[r][wait time="500"]
而且我们家遗传的毛囊可强韧了[r]
不用您操心啦[p]
#kawa:smile
真不可爱。那来比划比划？毛囊对决。[r]
我绝对能撑到五五开的局面啊喂[p]
#marigan:smileCE
啊，入道老师。您的饮品来啦，请用～[p]
[font size="20"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=nyudo keyframe=up time=300 wait="false"]
#nyudo:shame
！！！[resetfont]谢、谢谢您噗……！[r][stop_kanim name=nyudo]
[font size="20"]
（呜哇…咬字完全咬错了……！好丢脸……！）[p][resetfont]

[mask]
[chara_hide_all time="10"]
[fadeoutbgm time="2000"]
[wait time="1000"]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
;sS Eガラガラ
[bg storage="yakiniku.jpeg" time="10" wait="true" cross="false"]
[chara_show name="marigan" top="-60" face="normal" time="10"]
[wse]
#marigan
[mask_off]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
那[wait time="500"]　我去结账哦[r]
请老师们和小和尚先到外面等着吧[p]
#
玛丽甘伸手将三个男人推搡到屋檐下。[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[chara_hide time="10" name="marigan"]
[chara_show name="nyudo" top="-60" face="angry" left="-200" wait="false"]
[chara_show name="kawa" top="-10" face="normal" left="420" wait="false"]
#makado
……咦？这不太对吧？[r]
明明是看在我的面子上才赏光来的[p]
[delay speed="80"]
#nyudo:angryB
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
！就、就是啊……玛丽甘小姐……！[r]
我来付钱就行……！[p]
[resetdelay]
[font size="40"]
#kawa:whistle
哔——！！哔哔哔哔哔——！[r]
哔哔——！[p][resetfont]

#makado:closeEye_c
……川铃木老师……至少现在请您停下吧[p]
[delay speed="50"]
#marigan
啊哈哈！虽然您这么客气让我很过意不去……[wait time="500"][r]
在这里面最有钱的，大概就是我了呢—。[p]
而且，能直接给家乡经济做贡献的机会，这大概是最后一次了。[r]
就让我来付吧[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
——最后一次？[p]

#makado:normal_c
(在说什么呢……？)[p]
[chara_mod name="nyudo" face="sad"]
#kawa:smileW
啊—那我来露个脸吧[p]

#marigan
哈？突然怎么了？[p]

#kawa:shame
老师觉得结账前的推让是这世上最浪费时间的事啊—。[r]
所以和你这样的人一起办事就是爽快呢—真的[p]
[chara_hide_all]
#
川铃木，[r]
和玛莉甘一起小跑着回到了店里——[p]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[font size="20"]
#marigan
……搞什么啊[p]
[delay speed="80"]
[chara_hide_all]
#店員
那、那就结账…………、[wait time="500"][font size="40"]噫！！[p]
[font size="20"]
#kawa
………………[p]
#店員
啊、啊啊、啊…… 够了，够了，饶了我吧…………[p]
[resetdelay]
#marigan
诶？什么？[l][r][delay speed="80"]
对不起姐姐，我没听清……[p]
#kawa
……[p]
[resetfont]
[resetdelay]
#店員
[quake time="30"]
[playse  volume="10" buf="0" storage="kaminari.ogg"]
那、那个、作为补偿，我给你打五折！！！[r]
就当是这样了，拜托了……！！[p]
[font size="20"]

#marigan
诶？[l][r]
…………啊哈哈，哇——谢谢您……[p]

[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse][resetfont]
;ＳＥ引き戸
[resetdelay]
[chara_show name="marigan" top="-10" face="hate" left="420" wait="false" zindex="2"]
#marigan
[chara_show name="kawa" top="-10" face="normal" left="-100" wait="false" zindex="2"]
……喂我说你[p]

#kawa
好——的[p]

#marigan:wow
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
你对那个店员做了什么啊！？[r]
根据情况我现在就立刻报警哦！[p]
[chara_mod name="marigan" face="worry"]
#kawa:sad
过分呐——我明明什么都没做啊——[l][r]
#kawa:smile
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
只是认识的人啦——以前短暂交往过而已——[p]
[delay speed="100"]
[chara_show name="nyudo" face="angryB" wait="true" time="100" top="-60" left="120" zindex="1"]
[font size="40"]
[playbgm storage=fuon.ogg loop=true volume="30"]
#nyudo
诶……原……前女友……吗……？[p][resetfont]
[delay speed="50"]
#kawa:normal
啊—对。这儿是她本家来着—[l][r]
交往第五年怀孕了—[r]
结果发现被劈腿就分手了—[p]
#kawa:smile
之后还经常去店里晃悠[r]
不知为啥就开始给我打折送赠品—[r]
现在可殷勤着呢—[p]
[resetdelay]
[font size="40"]
#marigan:wow
[playse  volume="20" buf="0" storage="garasu.ogg" ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
噫——————！！！[p][resetfont]
#kawa:normal
诶——？为什么尖叫啊？为啥要叫啊？[p]

#marigan:sad
对不起…我一个不小心就…[p]

#makado
作为同事你不觉得可怕吗？[p]

#nyudo:closeEye
那个……目前我还没受到什么影响所以……[p]

#kawa:smileW
所以说啊贤治郎——[r]
喝酒误事还是趁年轻时掌握好分寸比较好啊[p]
等到年纪大了再出洋相的话[r]
可就真的无法挽回了啊——[p]

#kawa:smile
不过啊、要是酒后乱性生的孩子[r]
就算没遗传基因也会像老子吧—。那家伙的儿子！[r]
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
哈哈哈！[p]
[delay speed="100"]

#marigan:hate
……………………[p]

#makado
……………………[p]
#nyudo:closeEye
……………………回、回去吧……[p]
[mask]
[fadeoutbgm time="2000"]
[chara_hide_all time="10"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
;街中
#makado
[bg storage="saka_ｎ.jpeg" time="10" wait="true" cross="false"]
;ＳＥ歩く
[mask_off]
[delay speed="50"]
（…………………………[wait time="500"]毫无反应）[p]
#
刚才发给纱罗纱的，[r][font color="0xf08080"]
「入道和川铃木是狮心教的眷属」[resetfont]这层关系[r]
的简讯。[p]

既未显示已读，也没收到回复。[p]

#makado
（——但愿那边别出什么乱子……）[p]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
[chara_show name="marigan" top="-10" face="angry" wait="false"]
#marigan
……那位前女友为什么不肯离开老家呢。[r]
虽说也有自作自受的成分，换我早搬走了[p]
#
手包被[r]
玛丽甘像中国功夫片里那样不停挥舞着。[p]
#
一直盯着那东西似乎想说什么的入道……[r][wait time="500"]
以先前她那句话为契机，终于开口了。[p]
[chara_hide name="marigan" time="10"]
[chara_show name="nyudo" top="-60" face="sad" wait="false" zindex="2"]
[delay speed="100"]
#nyudo
……那、那个……[p]

#marigan
嗯？[p]
[delay speed="50"]
[chara_move name="nyudo" left="-120" anim="true" wait="false"]
[chara_show name="marigan" top="-10" left="360" wait="false" face="smile"]
#marigan
呃，哈哈哈……怎么啦？入道老师。[r]
您刚才说了什么吗？[p]

#
被搭话的她，[r]
转向支支吾吾的入道，投以温柔的微笑。[p]

#nyudo
……。[l][r]
#nyudo:closeEye
……啊、是[p]
[delay speed="70"]
#nyudo:normal
并不是所有人…都能像玛丽甘小姐您这样……[wait time="500"][r]
这么坚强的。[p]
#nyudo:closeEye
……[p]
[delay speed="50"]
#marigan:normal
哎呀。这是在夸我？还是说我现在显得不可爱呢？[p]
[resetdelay]
[font size="20"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=nyudo keyframe=up time=300 wait="false"]
#nyudo:angryB
不是！那个、我不是这个意思，我……！[p][stop_kanim name=nyudo]
[resetfont]
#marigan:smileB
啊哈哈。开玩笑的啦。[r]
入道老师不像是会说这种挖苦话的人呢[p]
[delay speed="70"]
#nyudo:closeEye
哈……啊，非常感谢[p]
#
入道将手按在胸口，像是松了口气般轻叹一声，[r]
又继续开口道。[p]
#nyudo:sad
但、但是……我在想啊……[p]
#nyudo:smile
看着玛丽甘小姐的时候。[l][r]
像我这样的……[wait time="500"]大多数人恐怕，[r]
离开这座城镇就活不下去了[p]

#nyudo:closeEye
所以您才如此耀眼。[wait time="800"]　太耀眼了……令人憧憬[p]

#makado
（……入道老师）[p]
[delay speed="50"]
#
这或许是他拼尽全力的告白，[r]
此刻他的身体正渗出前所未有的汗珠。[p]
[fadeoutbgm time="2000"]
但无论观察多少次，那些流淌的汗液……[r]
都不具备汗液应有的黏稠质感。[p]

没错。他仿佛，[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
始终[wait time="500"][r]
就像被人从头顶泼了一盆水似的――[p]
[resetdelay]
#marigan:smileCE
讨厌啦～那只是你们擅自这么认为而已～[p]
#marigan:normal
被土地束缚的是你。是你自己束缚了自己。[r]
别擅自把人家当成憧憬对象啊[p]
[playbgm storage=summer-incect.ogg loop=true volume=20]
#nyudo:angryB
[quake time="30"]
……！[p]
#nyudo:angry
[delay speed="70"][font speed="20"]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
啊、啊……！对不起，对不起啦[p]
#nyudo:sad
呜……呜……[l][r]
[delay speed="100"]
#nyudo:closeEye
………………………………[p]
[resetfont]
[delay speed="50"]
[chara_show name="kawa" face="smile" time="100" wait="false" top="-10" left="-300"]
#kawa
哈哈哈。入道老师—[r]
踩到地雷了呢—[p]
#
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
川铃木生硬地连连拍打入道的后背。[p]
[chara_hide name="kawa" wait="false" pos_mode="false"]
[font size="50"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=nyudo keyframe=up time=300 wait="false"]
#nyudo:normal
！[l][r][resetfont]
………[p][stop_kanim name=nyudo]

#marigan:tweet
啊、糟了、我太孩子气了吧。[l]
#marigan:worry
……入道老师，您生气了吗？[p]
[delay speed="70"]
#nyudo
……呃、那个……我…………我啊[p]
[fadeoutbgm time="2000"]
[font size="20"]
#nyudo:closeEye
…………太羞耻了…………[p]
[chara_hide name="nyudo" wait="false" pos_mode="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]
;ＳＥ走る
[playbgm storage="lost-happy.ogg" loop=true volume="30" sprite_time="0000-105000"]
[resetdelay][resetfont]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=marigan keyframe=up time=300 wait="false"]
#marigan:wow
[playse  volume="20" buf="0" storage="kaminari.ogg"]
诶！　入道老师！？[p][stop_kanim name=玛丽甘]
[chara_show name="kawa" wait="false" time="100" face="normal" top="-10" left="-70"]
#kawa
啊—啊—。[r]
弄哭人家了—弄哭人家了—[p]
[font size="40"]
#marigan:hate
你们才是老师吧！！[l][r][resetfont]
#marigan:worry
等等、等一下，入道老师！[p]
[font size="40"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
要追上去了！　请跟我来！[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
;ＳＥ走る
#二人
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
[chara_mod name="kawa" face="think"]
[chara_mod name="marigan" face="wow"]
诶！？[resetfont][p]
#kawa
……………………[p]
#marigan
………………………[p]
#kawa
……………………[l][r]
#kawa:normal
那家伙居然把我当年长者对待啊—[p]
[chara_hide name="kawa" wait="false" pos_mode="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="1000"]
#marigan:hurry
穿高跟鞋的大姐姐也是这么看我的啊！[p]
#
[chara_hide name="marigan" wait="false" pos_mode="false"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="1000"]
[bg storage="brack.png" wait="true" cross="false"]
#
——边跑边准备注连绳。[p]
[delay speed="50"]
#makado
（如果入道老师和川铃木都是眷属的话……[wait time="500"][r][playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]这意味着拥有被御黑祟诅咒的资格。）[p][resetfont]

#makado
（假如入道老师要去的地方与志户田家有关，[r]
我必须阻止他――！）[p]
#
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]
[mask folder="bgimage" graphic="still/part3.png" time="1000"]
[showsave]

@jump storage="chapter_3/day2_vol2.ks"


;セーブしますか？

;この次第三章「彼が五霊に着替えたら[p]二日目後編にいきます
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------
[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
