;-------------------------------------------------------------------------------
*part4
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '四章一日目　前編'"]
[mask_off time="2000"]
[mask folder="bgimage" graphic="still/part4.png" time="3000"]

;
[chara_face name="sarasa" face="normal_o" storage="chara/sarasa/normal_o.png"]
[chara_face name="sarasa" face="sad_o" storage="chara/sarasa/sad_o.png"]
[chara_face name="sarasa" face="closeEye_o" storage="chara/sarasa/closeEye_o.png"]
[chara_face name="sarasa" face="angry_o" storage="chara/sarasa/angry_o.png"]
;ituki
[chara_face name="ituki" face="normal_o" storage="chara/ituki/isyo/normal_o.png"]
[chara_face name="ituki" face="normal_gs" storage="chara/ituki/isyo/normal_gs.png"]
[chara_face name="ituki" face="angryB_gs" storage="chara/ituki/isyo/angryB_gs.png"]
[chara_face name="ituki" face="hate_gs" storage="chara/ituki/isyo/hate_gs.png"]
[chara_face name="ituki" face="shout_gs" storage="chara/ituki/isyo/shout_gs.png"]
[chara_face name="ituki" face="tweet_gs" storage="chara/ituki/isyo/tweet_gs.png"]
[chara_face name="ituki" face="smileCE_gs" storage="chara/ituki/isyo/smileCE_gs.png"]
[chara_face name="ituki" face="smileH_gs" storage="chara/ituki/isyo/smileH_gs.png"]
[chara_face name="ituki" face="smileW_gs" storage="chara/ituki/isyo/smileW_gs.png"]
;
[chara_face name="riki" face="normal_o" storage="chara/riki/normal_o.png"]
[chara_face name="riki" face="angry_o" storage="chara/riki/angry_o.png"]
[chara_face name="riki" face="smile_o" storage="chara/riki/smile_o.png"]
;
[chara_face name="aki" face="normal_o" storage="chara/aki/normal_o.png"]
;
[chara_face name="hino" face="normal_o" storage="chara/hino/normal_o.png"]
[chara_face name="hino" face="angry_o" storage="chara/hino/angry_o.png"]
[chara_face name="hino" face="hurry_o" storage="chara/hino/hurry_o.png"]
;
[bg storage="brack.png" time="100"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[fadeinbgm storage=bigriver.ogg loop=true time=300 volume="10"]
[wait time="2000"]
@layopt layer=message0 visible=true
[mask_off time="3000"]
[resetdelay]
[delay speed="70"]
那么，请相信我吧[l][r]
[r]
抚慰心灵、引导方向、治愈创伤的正是信仰[l][r]
[r]
[r]
大家都过来！孩子们也过来！[l][r]
[r]
我来安慰你们 为了你们而存在[p]
[mask time="10"]
[resetdelay]
[wait time="1000"]
[playse  volume="20" buf="0" storage="basya2.ogg"]
[stopbgm]
[wse]

[playse storage="phone.ogg" loop="true" volume="30"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[wait time="3000"]
[bg storage="indoor/kinuyoRoom_n.jpeg" time="10" wait="true"]
[mask_off]
;ＳＥ電話
[stopse]
#kinuyo
……是的。我是志户田[p]
[delay speed="50"]
[playse storage="nail.ogg" loop="true" volume="70"]
#kinuyo
……嗯。是的。是的……[p]
[delay speed="60"]
#kinuyo
……20日，破茧之日？[p]

#kinuyo
哎呀呀，真是……[l][r]
嗯，好的[p]

#kinuyo
明白了。那么稍后再见[p]
[stopse]
#kinuyo
……………[l][r]
[delay speed="100"]
真是的，拿你没办法……[p]
[mask time="2000"]
[wait time="2000"]
[bg storage="indoor/sisin.jpeg" time="10"]
#
[mask_off]

;○襖の部屋

——8月20日，『茧之家』。[p]
[chara_show name="hino" top="-100" face="angry_o" wait="false" time="100"]
[delay speed="60"]
[font size="20"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
大家——！准备好了吗——！（小声）[p]
[chara_hide name="hino" time="10"]
#
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_o" time="100"]
[chara_show name="riki" top="-100" left="400" wait="false" face="angry_o" time="100"]
[chara_show name="sarasa" top="-100" left="120" wait="false" face="normal_o" time="100"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
哦——！（小声）[p]
[playbgm storage="hitoriboti.ogg" loop=true volume="20"]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" face="normal_o" time="300" wait="false"]
[resetfont]
[resetdelay]
#aki
嗯嗯 混进来的时机正好呢 纱罗纱[r]
这次的值班员是马虎的林同学真是太好了[p]
[chara_hide name="aki" time="10"]
[chara_show name="riki" top="-100" face="normal_o" time="300" wait="false"]
#riki
我最讨厌夏天的桑拿天了—……热死啦—……[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-100" face="normal_o" time="300" wait="false"]
[delay speed="60"]
#sarasa
（确实，一直这样下去可能会被蒸熟……）[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_o" time="200"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_o" time="200"]
[resetdelay]
#hino
[chara_show name="hino" top="-100" left="120" wait="true" face="angry_o" time="200"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
好嘞，那现在就开作战会议吧！[r]
你们两个去查看下周围情况[p]

#aki
知道啦—[p]
[chara_hide name="aki" wait="false" pos_mode="false"]
[chara_hide name="riki" wait="false"]
#
;ＳＥ去る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]
[delay speed="50"]
#sarasa
……[l]日野[p]
[resetdelay]
#hino:normal_o
嗯？那是墙壁，我在这边啊？[p]
[chara_move name="hino" left="-70" anim="true" wait="false"]
[chara_show name="sarasa" top="-100" face="normal_o" wait="false" left="360"]
[delay speed="50"]
#sarasa
啊……抱歉……[p]
[delay speed="10"]
#hino:angry_o
所以？找我有什么事！？想再战词语接龙吗！？[p]
[delay speed="50"]
#sarasa
之前……　[font color="0xf08080"]获得祝福时的事[resetfont]　可以告诉我吗，[r]
你不是说过……愿意帮忙的吗……[p]
#sarasa
	……今天同行的成员里，[r]
还没被诅咒的只有日野你了吧。[l]所以……[p]

#hino
………[p]
[resetdelay]
#hino:hurry_o
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
啊！是想先了解回忆的事对吧！[r]
确实，今天我要是被诅咒的话那可就[r]
要酿成大灾难了啊！[p][stop_kanim name=hino]
[delay speed="60"]
#sarasa:sad_o
呜……嗯。
如果、可以的话……这样就好[p]
[resetdelay]
#hino:normal_o
但是，关于[font color="0xf08080"][r]
诅咒人心脆弱部分的[resetfont]那个传说[r]
居然和御白姬的祝福有所关联啊[p]
#hino:angry_o
祈祷中……会暴露人心的脆弱……[r]
利用这一点的奥萝冥姬果然是与我们势不两立的存在[p]

#hino:normal_o
不过话说回来，[r][font color="0xf08080"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
同一个人再次被诅咒的风险[resetfont]真的可以不用担心吗？[p]
[delay speed="60"]
#sarasa:normal_o
那些已经被诅咒的人们的事……[p]
#sarasa:closeEye_o
既然已经……[font color="0xf08080"]将诅咒根源的意图剥离出来了[resetfont]的话……[l][r]
既然知道驱除方法……[r]
我觉得或许不用太过害怕……[p]
[resetdelay]
#hino
唔…确实，说不定是这样呢[p]
[delay speed="10"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
#hino:angry_o
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[font size="40"]
那么，让诸位久等了！[l][r][resetfont]
[delay speed="70"]
我要将从御白姬那里继承这簇火焰时的事情……[r]
娓娓道来！[p][stop_kanim name=火野]
[resetfont]
[mask time="3000"]
#
[clearfix]
[fadeoutbgm time="3000"]
[bg storage="still/hino_battle.jpeg" time="10"]
[wait time="3000"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[chara_hide_all time="10"]
[delay speed="50"]
[mask_off]
――两年前　市立医院内[l][r]
[r]
医生[r]
「……今晚可能是病情的关键期[r]　请家属们务必陪伴在旁」[p]
[playbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400"]
[r]
[r]
日野妈妈[r]
「孩子他爸……！」[l][r]
[r]
日野爸爸[r]
「岳父大人……！！」[l][r]
[r]
日野烂照[r][playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
「你…
　根本没资格叫我岳父……！！」[l][r]
[r]
日野爸爸[r][playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
「事到如今…………！！」[p]
[r]
[r]
国雄[r]
「爷爷……」[l][r]
[r]
日野烂照[r]
「……[l]喂　除了国雄其他人都给我滚出去……」[l][r]
[r]
日野妈妈[r]「诶……为、为什么……？」[p]
[resetdelay]
[r]
日野烂照[r]
「有些男人之间必须交代的事[r]　赶紧给我出去……！」[p]
[r]
日野爸爸[r][playse  volume="30" buf="0" storage="kaminari.ogg"][font size="40"]
[quake time="30"]
「岳父！我也是男人啊！[r]　把话托付给我[r]　完全没问题的啊！？」[l][r][resetfont]
[r]
日野烂照[r][playse  volume="30" buf="0" storage="kaminari.ogg"][font size="40"]
[quake time="30"]
「闭嘴！滚一边去！！」[p][resetfont]
[r][delay speed="100"]
日野爸爸[r][font size="20"]
「呜……国雄你……」[p][resetfont]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
;ＳEドアガラガラ
[delay speed="60"]
日野烂照[r]
「国雄……[l] 老夫 [playse  volume="20" buf="0" storage="sariin.ogg" ][r]　视你为日野家第一男儿　有事相托……」[l][r]
[r]
国雄[r]
「……嗯　爷爷　尽管说吧……！」[l][r]
[r]
日野烂照[r]
「……[l][playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="40"]
把书房、把书房烧了……！[resetfont]」[l][r]
[r]
国雄[r]「呃……」[p]
[delay speed="10"]
日野烂照[r]
[font size="20"]
「别问缘由……但务必全部烧光……[r][wait time="500"]　那里所有的东西，一件不剩，别查看内容统统烧掉」[l][r]
[resetfont][resetdelay]
[r]
国雄[r]「连内容……都不看，全部……！？」[l][r]
[r]
日野烂照[r][playse  volume="20" buf="0" storage="kakan.ogg" ]
[font size="40"][quake time="30"]
「全部！！！[r]　绝对不要看里面！！[r]　别从那个地方带出来，全部烧光！」[p][resetfont]
[mask time="2000"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="indoor/sisin.jpeg" time="10"]
[fadeoutbgm time="2000"]
[wait time="2000"]
#hino
[mask_off time="2000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=20]
[chara_show name="hino" wait="true" top="-100" face="normal_o"]
[delay speed="60"]
――烂照爷爷[r]
还是第一次看到他如此激动地拜托我……[r]
我也只能回应他的这份心意了[p]
书房里收藏着许多具有历史价值的资料[r]
烧掉它们实在不忍心……[l][r]
但我还是含泪执行了[p]

#sarasa
……难道就为了这件事……才成为御白姬的眷属吗？[p]
[resetdelay]
#hino:angry_o
[anim name="hino" top="+=30" time="300"]
[anim name="hino" top="-=30" time="300"]
啊，那时候我已经在出入狮心教了！[p]
#hino:normal_o
获得祝福的时候正好是，[r]
老爷子去世后第二天的晚上。[r]
不带走直接烧掉……我还想过这是不是某种谜题呢[p]
#hino
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
不过，在守灵前，我可是把书房里的……[r]
所有书籍都烧了个精光！！[p]
[delay speed="80"]
#sarasa
……爷爷他一定……[r]
非常不想让任何人看到那些资料吧……[p]
[resetdelay]
[chara_show name="riki" top="-100" face="smile_o" wait="false" time="100" left="400"]
#riki
嘛，那些大概是小黄书吧！[p]
#hino:hurry_o
[quake time="100"]
[font size="40"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[stopbgm]
你这混蛋——！！[r]
唯独践踏逝者尊严这件事[r]
绝对不能做啊——！！[p][resetfont]
[fadeinbgm storage="hitoriboti.ogg" loop=true time=5000 volume="20"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_o" time="100"]
#aki
日野的爷爷好像是考古学博士来着？[p]

#riki:normal_o
是色情博士[p]

#hino:angry_o
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
无脑蠢货登利！！快报告周边情况[p]

#riki:smile_o
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
未发现接近者！目前安全～日野队长～[p]

#hino
好！器乐堂队员呢？[p]
[delay speed="60"]
#aki
[anim name="aki" top="+=30" time="200"]
[anim name="aki" top="-=30" time="200"]
同上 日野队长[r]
如果有人来 我会想办法的[p]
[delay speed="10"]
#hino
好！拜托千万别来人啊！[l][r]
那么开始作战会议！[p]
[delay speed="50"]
[chara_hide_all wait="true"]
[playse storage=page.ogg volume="50"]
[image layer=0 folder="image" name="note" storage="item/note.png" width="500" x="230" y="30" time="800" ]

#hino
这是今天的日程表[p]

#hino
现在是10点……[l][r]
大人们都在茧家里最大的房间『丝纺之间』中[r]
正在和三位女官们交谈！[p]
[resetdelay]
#aki
等结束之后就是吃午饭的时间了对吧[r]
今天吃什么呀[p]

#riki
肯定是杉村家那莫名其妙的便当吧！最近老吃这个啊[r]
我啊 不太喜欢那种硬邦邦的米饭呢[p]
[delay speed="60"]
#sarasa
大家现在……那个…………[l][r]
『丝纺之间』那边……不在场真的没问题吗？[p]
[resetdelay]
#riki
啊— 没问提没问题。[r]
那种东西不过是例行近况汇报会啦[p]
比起那个，接下来的[font color="0xf08080"]簇之缘会[resetfont]才是今天的重头戏啊[p]
[delay speed="50"]
#hino
[font size="40"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
没错！[p][resetfont]
……唯有簇之缘会，才是我们眷族重复五日沉眠后[r]
终于得以迎来的、绝对不可或缺的仪式。[l][r]
今日集会所内全员都必须参加[p]
#aki
所以　那个时间段……[p]
[free layer=0 name="note" time="800" wait="false"]
[resetdelay]
[chara_show name="hino" top="-100" left="120" wait="false" face="normal_o"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_o"]
#aki
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_o"]
对御白姬连半点信仰心都没有的纱罗纱[r]
优君告诉我的、存放着[font color="0xf08080"]教典[resetfont]的房间就在[r]
直接过去就行了对吧[p]

#sarasa
那个……请问、放教典的房间是……[l][r]
沿着这条走廊直走、尽头就是……[l][r]
[delay speed="100"]
[font size="20"]
楼梯的、那个、下面……[p]
[resetdelay][resetfont]
#aki
因为地方很大嘛—　容易迷路呢[p]
没关系　那个房间　就在丝织厅的里间[r]
前半段路我们大家一起走[p]

#sarasa
啊……谢谢[p]
#
——忽然，从远处……[p]
[delay speed="70"]
大概就是现在大人们聚集的房间方向，[r]
隐隐传来婴儿的啼哭声。[p]

#sarasa
……宝宝也来了啊[p]
[resetdelay]
#riki
不是带着婴儿就是拖家带口的。[r]
大人们都，[r]
发现小孩子更容易获得'祝福'呢—[p]

#sarasa
…………[p]
[delay speed="50"]
#sarasa
……今天，大家……[r]
谢谢你们带我……来到这里。[p]
我会注意的……尽量不让狮心教的人[r]
感到不快……[p]

#aki
啊哈哈　在说什么呀。[r]
我们　又不是[r]
专门为了纱罗纱才做这些事的[p]

为了不让眷属中再出现更多的受害者[r]
必须尽快找到封印御黒障的方法才行[p]
[resetdelay]
#hino
话说回来，[r]
御黒障这种存在还真是棘手啊……[p]
居然专门把诅咒对象锁定在御白姬的眷属身上。[r]
#hino:angry_o
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
简直就是「恨和尚连袈裟也恨」呢[p]

#riki
和尚？是说贤治郎吗？[p]
#
[chara_hide_all time="100"]
;ＳＥ襖空く
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="kirie" top="-100" face="smile" wait="false" time="100"]
#kirie
力君～马门君家可是信奉神道的哦～[r]
要说多少次你才明白啊——？[p]
[chara_hide name="kirie" time="10"]
[chara_show name="riki" face="smile_o" top="-100" wait="false" time="100" zindex="1"]
#riki
啊～雾绘[p]
[chara_show name="aki" left="470" wait="false" face="normal_o" top="-60" reflect="true" zindex="2"]
[chara_move name="riki" wait="false" anim="false" left="250" top="-60"]
[chara_show name="kirie" left="-120" wait="false" top="-100"]
#kirie
真是的。别在这种角落里缩着，[r]
等心情平复了就回大家那边去吧～[p]

#aki
好～[p]
[mask time="100"]
[stopbgm]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="120" wait="false" face="normal_o"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_o"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_o" reflect="false"]
[wait time="2000"]
;暗転
#sarasa
[mask_off time="10"]
——诶[p]

#aki
怎么了？纱罗纱[p]
[delay speed="100"]

#sarasa
啊……[l][r]
…………………………[wait time="500"]唔、没什么……[p]
#
刚才的是――[l][r]
某个人的回忆吗。还是说……[p]

#sarasa
（…………）[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[delay speed="50"]
#hino
但是……果然[r]
贤治郎先生不在的情况下[r]
要面对御黑幕的诅咒 果然有点不安啊[p]

#aki
或者说贤治郎先生……[l][r]
那个……不能只把注连绳借出来用用吗？[p]
[delay speed="10"]
#hino:hurry_o
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[font size="40"]
笨、笨蛋！你在说什么啊！？[resetfont][r]
那可是马门神社的神器啊[p]
和我们毫无渊源的人用了也不会有效力的道具[r]
这也太乱来了！！[p]
[delay speed="50"]
#riki
阿奇秀娜[p]

#aki
呃……抱歉[p]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
#hino:angry_o
[playse  volume="20" buf="0" storage="kakan.ogg" ]
但是！有备无患！[p]
我正是为了打破这种令人不安的局面！[r]
才制定了这个计划——！[p][stop_kanim name=火野]
[delay speed="70"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
#riki:smile_o
哦！[r]
什么什么、你准备了什么神秘道具啊！？[p][stop_kanim name=树]
[font size="40"]
[resetdelay]
#hino
[quake time="100"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
是盐————！！[p]

#riki:angry_o
[playse  volume="30" buf="1" storage="kaminari.ogg" ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
啊 超厉害！！[r]
我今天也带了盐来！[p]

#aki
[playse  volume="30" buf="2" storage="kaminari.ogg" ]
我现在这块布下面也全是盐！[p]
#
[playse  volume="30" buf="3" storage="kansei.ogg" ]
[chara_mod name="riki" face="smile_o"]
[anim name="hino" top="+=60" time="200"]
[anim name="hino" top="-=60" time="200"]
[anim name="aki" top="+=30" time="200"]
[anim name="aki" top="-=30" time="200"]
[anim name="riki" top="+=80" time="200"]
[anim name="riki" top="-=80" time="200"]
[delay speed="100"]
[font color="0xb0e0e6"]～[font color="0xffc0cb"]Ｈ[font color="0xb0e0e6"]Ａ
[font color="0xffc0cb"]Ｐ[font color="0xb0e0e6"]Ｐ[font color="0xffc0cb"]Ｙ　
[font color="0xb0e0e6"]　Ｓ[font color="0xffc0cb"]Ａ[font color="0xb0e0e6"]
Ｌ[font color="0xffc0cb"]Ｔ　[font color="0xb0e0e6"]Ｔ[font color="0xffc0cb"]Ｉ
[font color="0xb0e0e6"]Ｍ[font color="0xffc0cb"]Ｅ[font color="0xb0e0e6"]～
[resetfont][wse][p]
…………[p]
[resetdelay]
#riki
喂喂——志户田呢？志户田也参加撒盐仪式吗？[p]
#sarasa
我……我就不撒盐了……[p]
[font size="40"]
[chara_mod name="riki" face="angry_o"]
[chara_mod name="hino" face="angry_o"]
#
[stopbgm]
[playse  volume="50" buf="0" storage="sariin.ogg" ]
[delay speed="100"]
[font color="0xb0c4de"]～ＵＮＨＡＰＰＹ　ＳＡＬＴ　ＴＩＭＥ～[resetfont]
[wse][p]
[resetdelay]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
#hino
这怎么行啊志户田！[r]
你明明才是最该全副武装准备对抗措施的人啊[p]

#aki
要不……分你一点我的盐？[p]
[delay speed="60"]
#sarasa
……不用了 我够用的。[l][r]
那个……我带了防身用的东西来……[p]
#
[chara_hide_all time="100"]
;ＳＥガラガラ
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="suguru" top="-100" face="normal_s" wait="false"]
#suguru
前辈们……我把便当带来了哦[p]
[resetdelay]
#hino
哦哦！聪君。演讲环节顺利结束了吗？[p]

#suguru:shame_s
啊、是、是的[p]
[delay speed="50"]
#suguru:sad_s
听说凑本同学家的虎彻君……今早去世了[r]
大家都在听这件事[p]
[resetdelay]
#hino
啊……这样啊……还是没挺过去吗……[p]
[chara_hide name="suguru" wait="false"]

#riki
今天的便当是什么呀—？[p]

#aki
啊— 是杉村同学家的[p]
[delay speed="50"]
#
狮心教的少年们自然地围成圆圈……[r]
就这样在膝盖上摊开了便当。[p]
那大概就是他们惯常的排列”吧。[p]
#
……在远处观望这一幕的我身边，[r]
优走近过来——屈膝蹲下。[p]
[chara_show name="suguru" wait="false" top="-100" face="normal_s" left="-70"]
[chara_show name="sarasa" top="-160" face="normal_o" left="360" wait="false"]
#suguru
志户田前辈也请用[p]

#sarasa
诶……可以吗……？[p]

#suguru:angry_s
因为……不吃午饭的话肚子会饿的[p]
#suguru:normal_s
这是今天没能来的虎彻同学的份。[r]
请好好品尝吧[p]

#sarasa:sad_o
虎彻同学……[p]

#suguru
享年15岁的法国斗牛犬[p]

#sarasa:closeEye_o
连、连狗都有便当啊……我开动了[p]
[chara_hide_all time="500"]
#
掰开一次性筷子，抓起略微发硬的饭团送入口中。[p]

正如刚才登利所说的那样，冷却后的口感……[r]
这绝非日常之物。[p]

#suguru
不太好吃吧[p]

#sarasa
诶……[p]
#
[bg storage="syotengai_n.jpeg" time="1000" wait="true" cross="false"]
#suguru
即便如此我还是很喜欢。[l][r]
……因为这是和大家一起吃的饭啊[p]
[delay speed="70"]
#sarasa
……[l]你最喜欢的是哪个？[p]

#suguru
呃……[l][r]
…………所、所以说……[l][font size="20"]是日野前辈啦[p]
[resetfont]
#sarasa
啊…………[l][r]
对、对不起。不是问喜欢的人的事……[wait time="800"][playse  volume="20" buf="2" storage="sariin.ogg" ]
是问便当的配菜……[p]

#suguru
……[l][r]
[delay speed="10"]
我、我今天先回房间休息了[p]
#sarasa
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
等等！优酱……！对不起啦！[r]
是我表达得不够清楚……[p]
[delay speed="24"]
#suguru
[font size="20"]
呜呜—，呜—，应、应该没听到吧，[r]
怎么办啊，要是被她听到了…[r]
不要啊…我这种丑八怪被说成有人喜欢肯定很恶心吧[p]
[delay speed="50"]
[resetfont]
#sarasa
没…没关系！不要紧的，她肯定没听到…！[r]
你看嘛！[p]
#
[bg storage="indoor/sisin.jpeg" time="500" wait="true" cross="false"]
[chara_show name="hino" top="-100" left="120" wait="false" face="normal_o" time="300"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_o" time="300"]
#aki
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_o" time="300"]
[resetdelay]
今天的便当怎么有点咸啊[p]

#riki
大概因为布丁下面全是盐吧[p]

#hino
黑糖酱油腌菜加盐调味也不错呢～[p]
[chara_hide_all time="500"]

#sarasa
你看，绝对没听到啦[r]
连一个字……都没能传达给她呢……[p]

#suguru
那、那就好……[p]
#
优重新坐到了我的正对面。[p]
[delay speed="60"]
#sarasa
……[p]

#sarasa
……呐，优……[p]

#suguru
嗯？[p]

#sarasa
……[l]喜欢上一个人……是什么样的感觉呢……？[p]
[delay speed="20"]
#suguru
这……这种事情问我有什么用啊。[r]
事先声明，我可不想当备胎啊[p]
[delay speed="60"]
#sarasa
啊……[l]对、对不起……[r]
我只是好奇……喜欢一个人到底是什么感觉呢……[p]
[delay speed="80"]
……………………因为从来没听一树提起过，[r]
这种事……[p]
[delay speed="50"]
#suguru
……[l][r]
志户田前辈……真的除了姐姐以外就没朋友了呢[p]
[delay speed="70"]

#sarasa
…………这样，就足够了……[p]

#suguru
……[p]
[resetdelay]
那个…关于狮心教，[r]
在八种地区算是被当成烫手山芋吧。[r]
你知道他们都很不受待见吗？[p]

#sarasa
……不知道[p]

#suguru
就是这样啊。[l][r]
所以作为眷属首领的女儿，又是三人巫女的我们……[l][r]
[bg storage="brack.png" time="3000" wait="false" cross="false"]
[fadeoutbgm time="3000"]
不仅难交到朋友，还经常被欺负呢[p]
[delay speed="50"]
即便如此，我的两个姐姐……你看，她们长得漂亮对吧。[l][r]
所以，[r]
就算被周围人嘲笑也能轻松应对…[p]

但我不一样。[l][r]
她们的戏弄…变成了对我的欺凌。[p]
[mask time="1500"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[delay speed="60"]
[font size="22"]
[mask_off time="2000"]
直到现在，只要听到关于外貌的话题，[r]
就算完全与我无关，胸口和视野[r]
都会突然变得狭窄。[l][r]
[fadeinbgm storage=bigriver.ogg loop=true time=8000 volume="10"]
就算找遍整座城市也没有的东西，电视里自然也不会有，[r]
能在恋爱剧录像里获得幸福的，清一色都是漂亮女孩子。[r]
意识到这点后更加难受了。[l][r]
[delay speed="80"]
…………这个世界上，和我有着同样烦恼的女孩子，究竟会有多少呢？[l][r]
[delay speed="60"]
但是，这种羞耻的心情根本没法找人商量。[r]
因为实在太悲惨了啊。[l]……这张丑陋的脸永远治不好才让人痛苦，[l][r]
[r]
[r]
顶着这张脸说出来的话，只会让人更加可怜我吧。[p]
――――――就这样怀着崩溃的心情活着，[r]
……那是我12岁的时候……大概一年前吧。[l][r]
有次和日野前辈参加狮心教活动，去河滩打扫的日子。[r]
大人们不在，就我们俩沿着花隅川捡易拉罐什么的。[l][r]
[r]
[r]
那时候………………[l]他们特意跑来找我麻烦了。[r]
就是那群总欺负我的高年级男生们……[p]
我和日野前辈一直装作没看见，继续捡着垃圾。[r]
——可那群家伙，说了很多我不想再回忆的话……[l][r]
[r]
只是站在那里，[r]
被人一直责难说活着本身就是种错误，[l][r]
[r]
不知不觉就会觉得，自己的存在对这个社会来说确实是种不良现象，[r]
这样的念头就会渐渐浮现。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetdelay]
[resetfont]
#hino
请现在立刻向这孩子道歉[p]
#
先前还保持着事不关己的沉默……[l][r]
默默往垃圾袋里装废弃物的日野前辈，[r]
突然这么说着抬起了头。[p]
#男子学生
「……哈？你算老几」[p]
[chara_show name="hino" top="-100" face="normal" wait="false"]
#hino
这已经不是能不能被原谅的问题了。[l][r]
不道歉的话  可是会关系到你们的尊严，我才特意来提醒的[p]
#男子学生
「……………」[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[delay speed="60"]
[font size="22"]
#
高年级生们对这突如其来的反击显得神经被刺痛了。[l][r]
[r]
他们小团体里领头的男生比日野前辈还要年长一岁，[r]
而身材矮小的日野前辈竟敢反抗包括年长者在内的四人，这在他们看来无疑是[r]
对他们长期以来建立的尊严”的最大冒犯。[l][r]
[r]
[r]
正因如此，四个男生才用恶狠狠的目光瞪着日野前辈，[l][r]
[r]
他们开始商量要用什么方式，让这个做了蠢事的家伙[r]
好好明白自己的愚蠢。[p]
[resetfont]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥドン
[playse  volume="50" buf="0" storage="book.ogg" ]
[quake time="30"]
[wse]
#hino:sad
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……为什么要撞过来？[p]
[chara_face name="hino" face="angry_NG" storage="chara/hino/angry_NG.png"]
[chara_face name="hino" face="tweet_NG" storage="chara/hino/tweet_NG.png"]
#男子学生
阴魂不散……[wait time="500"][font size="40"]
[playse  volume="20" buf="3" storage="kaminari.ogg"]
少他妈多管闲事！！！[p][resetfont]
#suguru
（啊、完了、要被打脸了……！）[p]
#
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="hino" wait="false" time="200"]
;ＳＥドン
[playse  volume="80" buf="0" storage="punch.ogg"]
[quake time="30"]
[wait time="1000"]
[delay speed="60"][font size="22"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
已经来不及移开视线了。[l][r]
[r]
我眼睁睁看着日野前辈被那个最高年级的学生一记横拳[r]
眼睁睁看着他被摔在惨白的碎石地面上。[l][r]
[r]
[r]
其他男生立刻摆出要扑倒在前辈身上的架势——[l][r]
[r]
[stopbgm]
……谁知日野前辈竟在旁人采取进一步行动前，[r]
一个鲤鱼打挺站了起来。[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wse]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="100"]
#hino
…………………………[p]
[chara_show name="hino" top="-100" face="tweet_NG" wait="true"]
#hino
……………………………………[l][r]
#hino:angry_NG
[quake time="100"][font size="40"]
[playse  volume="20" buf="2" storage="garasu.ogg" ]
[resetdelay]
眼镜都摔掉了啊——！！[p]
[playbgm storage="lost-happy.ogg" loop=true volume="30" sprite_time="0000-105000"]
[resetfont]
;ＳＥ喧嘩
[chara_hide name="hino" wait="false"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
#suguru
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
诶……！？！[p]
#
[delay speed="60"]
[font size="22"]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
我惊呆了。[l][r]
没想到…………[r]
日野前辈竟是那种挨打时愤怒先于震惊的人。[l][r]
[r]
[r]
就在我和高年级生们都被这意外爆发的怒火震慑住时，[r]
前辈已朝着四个体型比他更壮硕的对手，[r]
赤裸裸地带着敌意挥拳冲了上去……………………[p]
@layopt layer=message0 visible=false
[playse  volume="50" buf="0" storage="book.ogg" ]
[quake time="100" wait="true" hmax="5"]
[wse]
[playse  volume="50" buf="0" storage="book.ogg" ]
[quake time="100" wait="true" vmax="5"]
[wse]
@layopt layer="message0" visible="true"
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetdelay]
#hino
[quake time="30"][font size="40"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
你们这群混蛋——[p]
[chara_show name="hino" top="-100" face="angry_NG" time="300" wait="false"]
[playse  volume="30" buf="2" storage="kaminari.ogg"]
明明给过你们一次对话的机会[r]
流血的是你们这群混蛋啊啊啊！！！[p][resetfont]
#男子学生
[delay speed="60"]
「呜……闭嘴……！区区后辈……装什么聪明……」[p]
[resetdelay]
[font size="40"]
#hino
[playse  volume="40" buf="1" storage="shimeage.ogg" ]
手上别给我使劲啊啊啊[p]
[resetfont]
#男子学生
[font size="22"]
「咕呃呃呃　反对暴力犯罪啊啊啊」[p]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
#男子学生
「噫呀——你这家伙　还有没有人性啊混蛋——[r]
哪有这样抓着别人脑袋的啊——」[p]
#hino
[chara_hide name="hino" wait="false"]
[font size="40"]
[playse  volume="100" buf="3" storage="punch.ogg" sprite_time="0500-30000"]
闭嘴——[r]
老子连你脑袋一起揪过来！！！[p]
#男子学生
[font size="22"]
「呀啊啊啊——[r]
那是什么抓头方式啊　会做噩梦的——」[p]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[resetfont]
[chara_hide name="hino" time="2000" wait="true"]
;S Eボコボコ
#suguru
…………………………………………[p]
#
[delay speed="60"]
奇怪……我明明至今为止都觉得男人[l][r]
全都又坏又讨厌　只会做让人难受的事　所以最讨厌了[p]

但看着这个人　却不会觉得讨厌[l][r]
虽然是男性……却会为伤害我的事物　和我一起生气[p]
#suguru
……………[l]啊[p]
[resetdelay]
[font size="40"]
#suguru
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
日…日野前辈！！[r]
再继续就真的太过分了！！[p]
[resetfont]
#hino
没关系的，聪君！[p]

#suguru
诶……[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/hino_smile.png" time="3000" wait="true" cross="false"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#hino
这种家伙　根本不配让我动用好不容易获得的'祝福'！[r]　
我要用纯粹的实力让他们好好反省[p]
[delay speed="50"]
而且你……[r]
可是让我能实现爷爷遗言的恩人啊[p]
怎么能容忍他们侮辱对我如此重要的人，[r]
作为眷属的尊严也不允许！[p]

#
……………………………………[p]
[fadeoutbgm time="2000"]
#suguru
……才、才不是那样呢[p]

#hino
哈？[p]
[delay speed="60"]
#suguru
像我这种人…要不是身为三宫女的话，[r]
在家里的价值就………………[l][r]
[delay speed="100"]
……………………………………[p]
[delay speed="60"]
…………[wait time="500"]你、你一定会后悔的！[r]
像我这样的人…根本不值得男孩子弄伤手来保护，[l][r]
三宫女三宫女的，整天就只会说这个……[p]
#suguru
[quake time="30"]
[resetdelay]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
所以我才痛苦啊，被眷属们无谓地温柔对待！！[r]
在这座城市里……不叫我三宫女的人，[r]
明明更多！[l][r]
[delay speed="60"]
你也……[wait time="500"]请不要因为眷属的情分就对我这么好！[r]
男孩子什么的，[r]
大家、只要待在我不知道的地方就好了！！[p]
大家都欺负我，[wait time="500"][r]
看不起我…………………[l][r]
反正全都是这种人……！！[p]
[resetdelay]
[filter blur="4"]
#
——当我这样说完后，[r][wait time="500"][playse  volume="20" buf="0" storage="sariin.ogg" ]
日野前辈……就这样回应了我[p]
[free_filter]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
若你说自己不知道这些事，那从现在开始了解就好[l][r]
[delay speed="60"]
是男性也好，是眷属也罢，或是三宫女的身份……[r]
一个人有什么价值，应该由大家亲眼见证、自行判断吧[p]
[bg storage="still/hino_smile2.png" time="100" wait="false" cross="false"]
#hino
[resetdelay]
所以首先——来了解我这个男人吧！[p]
@layopt layer=message0 visible=false
[clearfix]
#
[mask time="3000"]
[bg storage="brack.png" time="3000" wait="true" cross="false"]
[mask_off]
[delay speed="60"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#suguru
大概，这一天……[l][r]
就是我喜欢上前辈的瞬间。[r]
当我想更加了解这个人的时候……[p]
#suguru
…………[wait time="500"]虽说现在也是[r]
前辈他……动不动就使用暴力这点…实在让人不敢恭维……[p]
[bg storage="indoor/sisin.jpeg" time="2000"]
[chara_show name="suguru" wait="false" top="-100" face="normal_s" left="-70" time="2000"]
[chara_show name="sarasa" top="-160" face="normal_o" left="360" wait="false" time="2000"]
#suguru
……开玩笑的。很无聊吧。这种恋爱话题……[r]
就算听说了也帮不上你什么忙吧[p]

#sarasa
……[l]
#sarasa:closeEye_o
一树也……[l][r]
如果……有了在意的人……该怎么办……[p]

#suguru:angry_s
……不知道呢。[r]
兄妹之间不会特意聊这种话题的[p]

[mask folder="bgimage" graphic="still/part4.png"]
[mask folder="bgimage" graphic="still/part3.png" time="3000"]
;---------------------------------------------------------
[eval exp="f.save_title = '三章二日目　前編'"]
;---------------------------------------------------------
[chara_hide_all time="10"]
[bg storage="school/rikasitu.jpeg" time="10"]
[chara_show name="nyudo" top="-60" face="normal"]
[playse storage=bell.ogg sprite_time="0000-6000" volume="5"]
[wse]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=8000 volume=50]
[wait time="1000"]
#makado
;【第三章】彼が五齢に着替えたら
[mask_off]
……啊，入道老师原来不是本地人啊[p]

#nyudo
嗯……川铃木老师也是从外县调来的……[p]
[delay speed="50"]
#makado
真是少见呢，居然会来到小谷坂。[r]
这里的教职员大多是校友或者……本地人吧？[p]

#nyudo:smile
两个外来者……相依为命呢[p]

#makado
啊哈哈……[r]
老师最好和那个人保持距离哦[p]

#nyudo:normal
马门君是打算……在本地就业吗？[r]
还是准备去县外发展呢？[p]

#makado
……是啊[p]

#makado
离开这个小镇什么的……我还真没怎么考虑过。[r]
就连升学去东京的时候，也只是稍微犹豫了一下……[p]

#nyudo:closeEye
……看来您很喜欢家乡呢。这是好事[p]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="kawa" top="-10" face="sad" wait="false" time="100" left="360" width="-=100"]
;ＳＥガラガラ
[resetdelay]
#kawa
入道老师——[r]
又——忘记带筷子啦——借我一下嘛——[p]
[chara_move name="nyudo" anim="true" left="-90" wait="false" time="800"]
#nyudo:sad
啊……川铃木学[wait time="800"][er]

#kawa:normal
[anim name="kawa" left="-=80" time=200 ]
[anim name="kawa" left="+=80" time=200 ]
啊对了我还想要个小碟子——今天吃寿司嘛。[r]
这个小不点儿我就拿走啦——[p]
[delay speed="60"]
[font size="20"]
#nyudo:closeEye
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
那个是……培养皿……[p][resetfont]

#makado
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
喂！！？川铃木老师！！？[p]
[resetdelay]
#kawa:normal
干嘛啊小和尚～再吵就把你送回寺庙哦～[p]

#makado
……[l][r]
那个、您是不是有点太旁若无人了！？[p]

那可是别人正要掰开的一次性筷子啊！[r]
请还给入道老师！！[p]

#kawa:smile
哎呀～小和尚那个炒面面包是在小卖部买的？[l][r]
俺最喜欢那个了～给我嘛～[p]
[delay speed="70"]
#makado
（这人……完全听不进人话啊……）[p]
#
川铃木以横扫教室的势头——[r]
硬是把折叠椅挤到我旁边坐了下来。[p]

#nyudo:normal
……川铃木老师……小卖部还开着……[r]
想吃的话去买就好了……啊……[p]
[resetdelay]
#kawa:shame
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
啊哈哈！入道老师总是说些有趣的玩笑呢～[p]
#kawa:think
哎呀？说起来你是和这家伙一起来的[r]
小姐姐去哪里了呀～？[p]
[delay speed="70"]
#nyudo
马利根女士说……午饭会在外面解决……那个……[p]
[resetdelay]
#kawa:normal
哼嗯。吧唧吧唧[p]

#makado
（可恶，川铃木……）[p]
[resetdelay]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
（偏偏放着入道老师的便当不碰[r]
非要用抢来的筷子夹我这份更容易用手抓的寿司……！）[p]
[delay speed="60"]
#makado
啊、对、对了……！[l][r]
[resetdelay]
刚才小卖部阿姨多给了我几把叉子呢。[r]
不嫌弃的话请用这个吧[p]
[delay speed="60"]
#nyudo:sad
啊……[r]
让您费心了……真是抱歉……[p]
#kawa:smile
[playse  volume="30" buf="0" storage="kansei.ogg" ]
太好了呢！入道老师！[p]
#nyudo:smile
嗯……得救了…………[p]
#
………………………………[p]
#makado
[resetdelay]
（……既然入道老师觉得可以……那就算了吧……？[l][r]
[delay speed="60"]
………………嗯，算了…………）[p]
#
――当气氛终于融洽起来时，我环顾四周，[l][r]
突然注意到一件事。[p]

#makado
（说起来……）[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（现在趁着闲聊的氛围提到信仰话题的话，[r]
或许不会显得突兀）[p]
[resetdelay]
#
对了……必须认真完成纱罗纱委托的事，[r]
不能再失职了。[p]

若再暴露自己的无能，[r]
只会进一步加深她对我的不信任感吧。[p]

#makado
（那些孩子们现在也在努力着，[r]
我也必须尽己所能才行……）[p]

#makado
那个………………[wait time="800"][er]

#kawa
话说啊——[p]
[fadeoutbgm time="3000"]
[delay speed="50"]
#kawa:normal
你前阵子来的时候，不是在和志户田跟登利聊天吗？[r]
而且听说你和日野也认识？[p]
[chara_mod name="nyudo" face="normal"]
#kawa:smileW
[font color="0xf08080"]
该不会是想打探狮心教的情报吧？[p][resetfont]

#makado
诶……[p]

#kawa:normal
就是说啊。[p]
[chara_mod name="kawa" face="hate"]
是熊老师班上的。[r][font color="0xf08080"]
那些[resetfont]小组的成员吧？一个不落。[p]
[delay speed="100"]
#kawa:normal
[fadeinbgm storage=fuon.ogg loop=true time=3000 volume="30"]
果然很诡异啊，被家里的宗教束缚得死死的……[p]
#kawa:smile
对付那群难缠的家长群体，只有熊老师能做到吧。[r]
您不这么认为吗？入道老师[p]
[delay speed="70"]
#nyudo:sad
……熊老师毕竟是……资深教师了[p]

#nyudo:closeEye
但是……我也……[r]
对于狮心教这个存在……[l]作为马门神社的公子究竟[r]
抱持着怎样的……想法呢……很在意呢……啊……[p]

#nyudo:smile
马门君……对于狮心教和……御白姬……[r]
究竟有怎样的……看法呢……？[p]

[mask time="3000"]
[bg storage="indoor/sisin.jpeg" time="10"]
[chara_hide_all time="10"]
#sarasa
[mask_off time="2000"]
……喂 优君……[p]
[chara_show name="suguru" top="-100" face="angry_s" wait="false" time="100"]
[delay speed="10"]
#suguru
干嘛啦 大家早就吃完午饭了哦[r]
别磨磨蹭蹭的 快把便当盒打开啦[p]
[resetdelay]
#sarasa
刚才……[l]
[delay speed="70"]
狮心教在[r]
八种町被当作烫手山芋……你是这么说的吧。[p]
那是为什么？[p]
[delay speed="80"]
#suguru:normal_s
………………………………………………。[r]
这种事……[p]
[resetdelay]
[font color="0xf08080"]
#suguru:normal_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
狮心教的眷属们[r]
通过牢固的羁绊 排斥那些仅凭猎奇心理接近的人[r]
这不是明摆着吗 他们有强烈排外的历史传统啊[p]
[resetfont]
祝福的具体内容对非眷属成员都是保密的，[r]
其真实状况也只有受祝福者之间才能互相确认。[p]
#suguru:smile_s
由这位御白姬所赐予的欢愉[r]
对那些怀着半吊子心态想要窥探的家伙[r]
必须施以制裁　[font color="0xf08080"]即便是伴侣也不例外[p][resetfont]
[delay speed="50"]
#suguru:normal_s
像这样 在城镇里形成双重社群结构的[r]
狮心教的存在 自然会让其他八种居民感到厌恶。[r]
在某些人眼中 他们就是破坏秩序的法外之徒呢[p]
#suguru
而且……[l][r]
[delay speed="70"]
#suguru:sad_s
即便是怀着真诚心意靠近的人[r]
眷族里也有不少想将其排除在外的成员哦？[p]

#sarasa
排除…………？[l][r]
……这究竟是为何……[p]

#suguru:normal_s
因为……[p]
#suguru:wow_s
[playse  volume="20" buf="2" storage="sariin.ogg" ]
有价值的'自己人'若是增加了，[r]
等待着我的祝福究竟何时才会降临呢。[p]
#
[chara_hide name="suguru" wait="false" time="2000"]
[bg storage="brack.png" wait="false" time="2000" cross="false"]
[wait time="2000"]

#makado
……[p]

#makado
[fadeoutbgm time="3000"]
……我的青梅竹马中……有个与狮心教渊源颇深的家伙。[r]
托他的福，我对教团内情还算略知一二[p]
[delay speed="50"]
#makado
而且关于御白姬，[r]
就连我们神社里也设有供奉她的祠庙。[r]
从信奉同一位神明这点来说　镇上过半居民都与她血脉相连[p]

#makado
为了更深入了解御白姬[r]
我想借助狮心教众人的力量[l][r]
这就是我现在的想法[p]
[bg storage="school/rikasitu.jpeg" wait="false" cross="false"]
[chara_show name="kawa" top="-10" face="normal" wait="false"  left="360" width="-=100"]
[chara_show name="nyudo" top="-60" face="normal" left="-90" wait="false"]

#makado
……当然　前提是他们愿意接纳我……[p]
[delay speed="100"]
#nyudo
…………………………………………[p]

#makado
（……………………）[p]

#kawa
……………………………………[p]
[delay speed="50"]
[font size="40"]
#kawa:whistle
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
哔——————！！！！[p]

#makado
[quake time="30"]
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
诶！？[p]
[resetdelay]
[font size="20"]
#nyudo:closeEye
[fadeinbgm storage=sicilienne.ogg loop=true time=8000 volume="30"]
川铃木老师……请停下那个……[p][resetfont]

#kawa:smileW
我最不擅长应对沉默的氛围了……[p]
[delay speed="50"]
#nyudo:closeEye
抱歉呢，马门君……[r]
……突然抛出这么复杂的话题……[p]

#makado
啊、不、完全没关系的……[p]
[delay speed="60"]
#nyudo:sad
那些狮心教的学生们……在其他学生和家长眼中，[r]
经常会被投以异样的目光……[r]
我们也不得不相对地用过度保护的眼光看待他们[p]
[delay speed="80"]
#nyudo:normal
所以……[r]
只是想了解下……[r]
作为和他们有交集的你……究竟站在什么立场……[p]
[resetdelay]
#nyudo:angryB
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
啊、啊啊！对、对不起我这样怀疑你……！[r]
伤到你了吗？！[p]
#
慌慌张张的入道，[r]
连比带划地表达着关切。[p]
[delay speed="60"]
#makado
（…………………………）[p]
（熊先生也是这样，[r]
入道老师也是个真诚关心学生的好老师呢……）[p]
[font size="40"]
#kawa:whistle
哔！　哔！　哔！　哔哔！[p]
[resetfont]
#makado
（……这个人看起来完全不行啊……）[p]
[resetdelay]
#makado
川铃木老师。[l][r]
请不要跟着入道老师的动作用笛子打拍子[p]
[chara_mod name="nyudo" face="closeEye"]
#kawa
啊。[l][r]
[chara_mod name="kawa" face="smileW"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
说到底——你潜入狮心教调查这事是真的对吧——？[p]

#makado
！[l][r]
……是的[p]

#kawa:normal
哼。[l][r]
#kawa:smile
嘛、不过也没啥大不了的啦—[p]
[delay speed="60"]

#
川铃木依然保持着那副飘然自若的态度……[p]


#makado
――那么，就让我继续讲些无关紧要的事吧[p]

#makado
川铃木老师，您的信仰……到底是什么呢[wait time="200"][er]

#kawa:whistle
[font size="40"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
哔咿咿——————！！！[p][resetfont]

#makado
（呜哇……)[p]
[chara_mod name="kawa" face="smile"]
#
川铃木全力演奏出令人不快的声响后……[r]
突然松开了笛子。[p]
[resetdelay]
#kawa
秃驴——我说啊——[r]
社会上存在『三大禁忌话题』这玩意。[r]
知道不——[p]
#kawa:think
就是棒球、宗教和政治话题——[r]
酒桌上的常识懂不懂啊——给我记住——[p]
[delay speed="70"]
#makado
但是……这里……又不是酒桌吧……[p]
[resetdelay]
#kawa:shame
所以说啊—。我呢—，天生就爱唱反调嘛—[p]
#
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
;ＳＥガラッ
[wse]
[chara_show name="marigan" top="-10" left="100" width="-=100" wait="false" face="smileB" time="100"]
#marigan
那　在酒桌上就允许聊这些话题吗？　你[p]
[chara_move name="nyudo" left="-200" wait="false" anim="true"]
[chara_move name="kawa" anim="true" wait="false" left="400"]
#nyudo:shame
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font size="20"]
（！！居然追到理科教室来了……）[resetfont][p]

#makado
诶？　玛丽甘小姐……？！[p]

#marigan:sad
居然自称唱反调……[r]
就像先有鸡还是先有蛋那种问题一样荒唐可笑！[p]
[delay speed="50"]
#marigan:tweetLA
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
但同时也正合我意。[r]
不如在酒桌上……聊聊禁忌话题如何？[p]
[delay speed="80"]
#nyudo:sad
[font size="20"]
（呜哇……成人向的……）[resetfont][p]
[resetdelay]
#kawa:normal
可以啊—。就今晚怎么样？[p]
#marigan:smile
太感谢了川铃木老师。那待会儿见[p]
[delay speed="50"]
#marigan:smileB
啊……入道老师。[r]
您要是方便的话　也请务必一起[p]

#nyudo:shame
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=nyudo keyframe=up time=300 wait="false"]
……！　好、好的！[p]
[stop_kanim name=nyudo]

#nyudo:closeEye
[font size="20"]
（怎么办、被邀请了……　但像我这样的人一起参加、好难为情……）[p]
[resetfont]
#makado
[delay speed="50"]
………………[p]
[chara_hide_all time="300"]
#
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="50" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
#
擦肩而过的瞬间。[l][r]
玛丽甘凑近耳边低语道。[p]
[font size="20"]
#marigan
——放弃在校园里套话吧。真正的行动在晚上[p]
[resetfont]
#marigan
你啊，和保密工作八字不合呢～[p]
@layopt layer=message0 visible=false
[clearfix]

#
;ＳＥ歩いて行く
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="1000"]
[playse  volume="40" buf="0" storage="hikidopen2.ogg"]
[wse]
[mask folder="bgimage" graphic="still/part3.png" time="1000"]
[fadeoutbgm time="1000"]
;セーブしますか？
[wait time="1000"]
[showsave]
@jump storage="chapter_4/day1_vol2.ks"

;4章
;パート2へ
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
