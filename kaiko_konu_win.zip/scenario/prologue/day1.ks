;回顧来ぬ
*start
;序章　「桑畑で誰かが誰かを捕まえたら」

[cm  ]
[clearfix]
[start_keyconfig]

;メッセージウィンドウの設定
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
;文字が表示される領域を調整
[position layer=message0 page=fore margint="35" marginl="25" marginr="25" marginb="10"]
;メッセージウィンドウの表示
@layopt layer=message0 visible=true
;効果ブライトネス、表情切り替え秒 非表示後も表情を記憶する
[chara_config talk_focus="brightness" memory="true" time="0"]
;キャラクターの名前が表示される文字領域
[ptext name="chara_name_area" layer="message0" color="white" size=28 bold=true x=36 y=520]
;-------------------------------------------------------------------------------
[font size="22"]
本故事纯属虚构。　此外，游戏内含有[r]
血液描写·昆虫·自残·恐怖演出等猎奇表现。[r]
仅推荐13岁以上且能接受上述演出效果的玩家体验。[p]
[mask time="3000"]
[bg storage="still/first.png" time="10"]
;-------------------------------------------------------------------------------
;sarasa
[chara_new  name="sarasa" storage="chara/sarasa/normal.png"  color="0xffd700" jname="志戸田紗羅紗"]
[iscript]
TYRANO.kag.stat.charas['sarasa'].jname = '志戸田 紗羅紗'
[endscript]
;通常
[chara_face name="sarasa" face="normal" storage="chara/sarasa/normal.png"]
[chara_face name="sarasa" face="angry" storage="chara/sarasa/angry.png"]
[chara_face name="sarasa" face="wow" storage="chara/sarasa/wow.png"]
[chara_face name="sarasa" face="smile" storage="chara/sarasa/smile.png"]
[chara_face name="sarasa" face="smileCE" storage="chara/sarasa/smile_CE.png"]
[chara_face name="sarasa" face="smileSP" storage="chara/sarasa/SPsmile.png"]
[chara_face name="sarasa" face="sad" storage="chara/sarasa/sad.png"]
[chara_face name="sarasa" face="sadB" storage="chara/sarasa/Bsad.png"]
[chara_face name="sarasa" face="closeEye" storage="chara/sarasa/closeEye.png"]
[chara_face name="sarasa" face="worry" storage="chara/sarasa/worry.png"]
[chara_face name="sarasa" face="worryLA" storage="chara/sarasa/LAworry.png"]
[chara_face name="sarasa" face="lookback" storage="chara/sarasa/lookback.png"]
[chara_face name="sarasa" face="lookAway" storage="chara/sarasa/lookAway.png"]
;紗羅紗　傘さし
[chara_face name="sarasa" face="normal_k" storage="chara/sarasa/kasa/normal_k.png"]
[chara_face name="sarasa" face="angry_k" storage="chara/sarasa/kasa/angry_k.png"]
[chara_face name="sarasa" face="closeEye_k" storage="chara/sarasa/kasa/closeEye_k.png"]
[chara_face name="sarasa" face="lookAway_k" storage="chara/sarasa/kasa/lookAway_k.png"]
[chara_face name="sarasa" face="sad_k" storage="chara/sarasa/kasa/sad_k.png"]
[chara_face name="sarasa" face="sadB_k" storage="chara/sarasa/kasa/sadB_k.png"]
[chara_face name="sarasa" face="smile_k" storage="chara/sarasa/kasa/smile_k.png"]
[chara_face name="sarasa" face="smileCE_k" storage="chara/sarasa/kasa/smile_CE_k.png"]
[chara_face name="sarasa" face="tweet_k" storage="chara/sarasa/kasa/tweet_k.png"]
[chara_face name="sarasa" face="worry_k" storage="chara/sarasa/kasa/worry_k.png"]
[chara_face name="sarasa" face="worryLA_k" storage="chara/sarasa/kasa/worryLA_k.png"]
[chara_face name="sarasa" face="wow_k" storage="chara/sarasa/kasa/wow_k.png"]
;紗羅紗　傘持ち
[chara_face name="sarasa" face="angry_kt" storage="chara/sarasa/kasaT/angry_kt.png"]
[chara_face name="sarasa" face="closeEye_kt" storage="chara/sarasa/kasaT/closeEye_kt.png"]
[chara_face name="sarasa" face="lookAway_kt" storage="chara/sarasa/kasaT/lookAway_kt.png"]
[chara_face name="sarasa" face="normal_kt" storage="chara/sarasa/kasaT/nomal_kt.png"]
[chara_face name="sarasa" face="sad_kt" storage="chara/sarasa/kasaT/sad_kt.png"]
[chara_face name="sarasa" face="sadB_kt" storage="chara/sarasa/kasaT/sadB_kt.png"]
[chara_face name="sarasa" face="smile_kt" storage="chara/sarasa/kasaT/smile_kt.png"]
[chara_face name="sarasa" face="worry_kt" storage="chara/sarasa/kasaT/worry_kt.png"]
[chara_face name="sarasa" face="worryLA_kt" storage="chara/sarasa/kasaT/worryLA_kt.png"]
[chara_face name="sarasa" face="wow_kt" storage="chara/sarasa/kasaT/wow_kt.png"]
;紗羅紗　私服
[chara_face name="sarasa" face="normal_s" storage="chara/sarasa/sihuku/normal_s.png"]
[chara_face name="sarasa" face="normal_c" storage="chara/sarasa/sihuku/normal_c.png"]
[chara_face name="sarasa" face="angry_s" storage="chara/sarasa/sihuku/angry_s.png"]
[chara_face name="sarasa" face="wow_s" storage="chara/sarasa/sihuku/wow_s.png"]
[chara_face name="sarasa" face="smile_s" storage="chara/sarasa/sihuku/smile_s.png"]
[chara_face name="sarasa" face="smile_c" storage="chara/sarasa/sihuku/smile_c.png"]
[chara_face name="sarasa" face="sad_s" storage="chara/sarasa/sihuku/sad_s.png"]
[chara_face name="sarasa" face="sadB_s" storage="chara/sarasa/sihuku/sadB_s.png"]
[chara_face name="sarasa" face="closeEye_s" storage="chara/sarasa/sihuku/closeEye_s.png"]
[chara_face name="sarasa" face="closeEye_c" storage="chara/sarasa/sihuku/closeEye_c.png"]
[chara_face name="sarasa" face="worry_s" storage="chara/sarasa/sihuku/worry_s.png"]
[chara_face name="sarasa" face="worry_c" storage="chara/sarasa/sihuku/worry_c.png"]
[chara_face name="sarasa" face="worryLA_s" storage="chara/sarasa/sihuku/worryLA_s.png"]
[chara_face name="sarasa" face="worryLA_c" storage="chara/sarasa/sihuku/worryLA_c.png"]
[chara_face name="sarasa" face="lookAway_s" storage="chara/sarasa/sihuku/lookAway_s.png"]
;紗羅紗　オシラ
[chara_face name="sarasa" face="normal_gs" storage="chara/sarasa/shirakinu/normal_gs.png"]
[chara_face name="sarasa" face="angry_gs" storage="chara/sarasa/shirakinu/angry_gs.png"]
[chara_face name="sarasa" face="lookAway_gs" storage="chara/sarasa/shirakinu/lookAway_gs.png"]
[chara_face name="sarasa" face="pray_gs" storage="chara/sarasa/shirakinu/pray_gs.png"]
[chara_face name="sarasa" face="sad_gs" storage="chara/sarasa/shirakinu/sad_gs.png"]
[chara_face name="sarasa" face="sadB_gs" storage="chara/sarasa/shirakinu/sadB_gs.png"]
[chara_face name="sarasa" face="smile_gs" storage="chara/sarasa/shirakinu/smile_gs.png"]
[chara_face name="sarasa" face="worry_gs" storage="chara/sarasa/shirakinu/worry_gs.png"]
[chara_face name="sarasa" face="worryLA_gs" storage="chara/sarasa/shirakinu/worryLA_gs.png"]
[chara_face name="sarasa" face="wow_gs" storage="chara/sarasa/shirakinu/wow_gs.png"]
[chara_face name="sarasa" face="closeEye_gs" storage="chara/sarasa/shirakinu/closeEye_gs.png"]
;紗羅紗　幼少期
[chara_face name="sarasa" face="normal_w" storage="chara/sarasa/waka/normal_w.png"]
[chara_face name="sarasa" face="angry_w" storage="chara/sarasa/waka/angry_w.png"]
[chara_face name="sarasa" face="closeEye_w" storage="chara/sarasa/waka/closeEye_w.png"]
[chara_face name="sarasa" face="monaka_w" storage="chara/sarasa/waka/monaka_w.png"]
[chara_face name="sarasa" face="sad_w" storage="chara/sarasa/waka/sad_w.png"]
[chara_face name="sarasa" face="smile_w" storage="chara/sarasa/waka/smile_w.png"]
[chara_face name="sarasa" face="smileCE_w" storage="chara/sarasa/waka/smileCE_w.png"]
;-------------------------------------------------------------------------------
;makado
[chara_new  name="makado" storage="chara/makado/normal.png" jname="馬門賢治郎"]
[iscript]
TYRANO.kag.stat.charas['makado'].jname = '馬門 賢治郎'
[endscript]
;通常
[chara_face name="makado" face="normal" storage="chara/makado/normal.png"]
[chara_face name="makado" face="angry" storage="chara/makado/angry.png"]
[chara_face name="makado" face="angrySH" storage="chara/makado/SHangry.png"]
[chara_face name="makado" face="closeEye" storage="chara/makado/closeEye.png"]
[chara_face name="makado" face="closeEyeB" storage="chara/makado/closeEyeB.png"]
[chara_face name="makado" face="hurryB" storage="chara/makado/hurryB.png"]
[chara_face name="makado" face="lookAway" storage="chara/makado/lookAway.png"]
[chara_face name="makado" face="sad" storage="chara/makado/sad.png"]
[chara_face name="makado" face="smile" storage="chara/makado/smile.png"]
[chara_face name="makado" face="smileSP" storage="chara/makado/SPsmile.png"]
[chara_face name="makado" face="smileMini" storage="chara/makado/miniSmile.png"]
[chara_face name="makado" face="shout" storage="chara/makado/shout.png"]
[chara_face name="makado" face="tweet" storage="chara/makado/tweet.png"]
[chara_face name="makado" face="tweetB" storage="chara/makado/tweetB.png"]
[chara_face name="makado" face="tweetLA" storage="chara/makado/LAtweet.png"]
[chara_face name="makado" face="worry" storage="chara/makado/worry.png"]
[chara_face name="makado" face="worryB" storage="chara/makado/Bworry.png"]
[chara_face name="makado" face="wow" storage="chara/makado/wow.png"]
[chara_face name="makado" face="wowB" storage="chara/makado/Bwow.png"]
[chara_face name="makado" face="wowCM" storage="chara/makado/CMwow.png"]
;賢治郎　帽子かぶり
[chara_face name="makado" face="normal_c" storage="chara/makado/cap/normal.png"]
[chara_face name="makado" face="angry_c" storage="chara/makado/cap/angry.png"]
[chara_face name="makado" face="angrySH_c" storage="chara/makado/cap/angrySH.png"]
[chara_face name="makado" face="bike_c" storage="chara/makado/cap/bike.png"]
[chara_face name="makado" face="closeEye_c" storage="chara/makado/cap/closeEye.png"]
[chara_face name="makado" face="lookAway_c" storage="chara/makado/cap/lookAway.png"]
[chara_face name="makado" face="sad_c" storage="chara/makado/cap/sad.png"]
[chara_face name="makado" face="smile_c" storage="chara/makado/cap/smile.png"]
[chara_face name="makado" face="smileMini_c" storage="chara/makado/cap/smileMini.png"]
[chara_face name="makado" face="shout_c" storage="chara/makado/cap/shout.png"]
[chara_face name="makado" face="tweet_c" storage="chara/makado/cap/tweet.png"]
[chara_face name="makado" face="worry_c" storage="chara/makado/cap/worry.png"]
[chara_face name="makado" face="worryB_c" storage="chara/makado/cap/worryB.png"]
[chara_face name="makado" face="wow_c" storage="chara/makado/cap/wow.png"]
[chara_face name="makado" face="wowB_c" storage="chara/makado/cap/wowB.png"]
[chara_face name="makado" face="wowCM_c" storage="chara/makado/cap/wowCM.png"]
[chara_face name="makado" face="tweetLA_c" storage="chara/makado/cap/tweetLA.png"]
[chara_face name="makado" face="rady_c" storage="chara/makado/cap/rady.png"]
;賢治郎　縄持ち
[chara_face name="makado" face="bike" storage="chara/makado/bike.png"]
[chara_face name="makado" face="normal_r" storage="chara/makado/rady/normal.png"]
[chara_face name="makado" face="worry_r" storage="chara/makado/rady/worry.png"]
[chara_face name="makado" face="closeEye_r" storage="chara/makado/rady/closeEye.png"]
[chara_face name="makado" face="shout_r" storage="chara/makado/rady/shout.png"]
[chara_face name="makado" face="wow_r" storage="chara/makado/rady/wow.png"]
;賢治郎　目元の色
[chara_face name="makado" face="normal_e" storage="chara/makado/trueEye/normal_e.png"]
[chara_face name="makado" face="hurryB_e" storage="chara/makado/trueEye/hurryB_e.png"]
[chara_face name="makado" face="lookAway_e" storage="chara/makado/trueEye/lookAway_e.png"]
[chara_face name="makado" face="shout_e" storage="chara/makado/trueEye/shout_e.png"]
[chara_face name="makado" face="smileMini_e" storage="chara/makado/trueEye/smileMini_e.png"]
[chara_face name="makado" face="tweetB_e" storage="chara/makado/trueEye/tweetB_e.png"]
[chara_face name="makado" face="worry_e" storage="chara/makado/trueEye/worry_e.png"]
[chara_face name="makado" face="wowB_e" storage="chara/makado/trueEye/wow_e.png"]
;賢治郎　目元の色＋帽子
[chara_face name="makado" face="normal_ce" storage="chara/makado/trueEye_Cap/normal_ce.png"]
[chara_face name="makado" face="angry_ce" storage="chara/makado/trueEye_Cap/angry_ce.png"]
[chara_face name="makado" face="bike_ce" storage="chara/makado/trueEye_Cap/bike_ce.png"]
[chara_face name="makado" face="lookAway_ce" storage="chara/makado/trueEye_Cap/lookAway_ce.png"]
[chara_face name="makado" face="shout_ce" storage="chara/makado/trueEye_Cap/shout_ce.png"]
[chara_face name="makado" face="smile_ce" storage="chara/makado/trueEye_Cap/smile_ce.png"]
[chara_face name="makado" face="smileMini_ce" storage="chara/makado/trueEye_Cap/smileMini_ce.png"]
[chara_face name="makado" face="tweetB_ce" storage="chara/makado/trueEye_Cap/tweetB_ce.png"]
[chara_face name="makado" face="tweetLA_ce" storage="chara/makado/trueEye_Cap/tweetLA_ce.png"]
[chara_face name="makado" face="worry_ce" storage="chara/makado/trueEye_Cap/worry_ce.png"]
;賢治郎
[chara_face name="makado" face="cut1_g" storage="chara/makado/ghost/cut1.png"]
[chara_face name="makado" face="cut2_g" storage="chara/makado/ghost/cut2.png"]
[chara_face name="makado" face="closeEye_g" storage="chara/makado/ghost/closeEye_g.png"]
[chara_face name="makado" face="ghost_g" storage="chara/makado/ghost/ghost_g.png"]
[chara_face name="makado" face="lookAway_g" storage="chara/makado/ghost/lookAway_g.png"]
[chara_face name="makado" face="tweet_g" storage="chara/makado/ghost/tweet_g.png"]
[chara_face name="makado" face="worry_g" storage="chara/makado/ghost/worry_g.png"]
;賢治郎　過去
[chara_face name="makado" face="normal_w" storage="chara/makado/waka/normal_w.png"]
[chara_face name="makado" face="angry_w" storage="chara/makado/waka/angry_w.png"]
[chara_face name="makado" face="closeEye_w" storage="chara/makado/waka/closeEye_w.png"]
[chara_face name="makado" face="smile_w" storage="chara/makado/waka/smile_w.png"]
[chara_face name="makado" face="smileCE_w" storage="chara/makado/waka/smileCE_w.png"]
[chara_face name="makado" face="smileMini_w" storage="chara/makado/waka/smileMini_w.png"]
[chara_face name="makado" face="worry_w" storage="chara/makado/waka/worry_w.png"]
[chara_face name="makado" face="wow_w" storage="chara/makado/waka/wow_w.png"]
[chara_face name="makado" face="wowCM_w" storage="chara/makado/waka/wowCM_w.png"]
;-------------------------------------------------------------------------------
;ituki
[chara_new name="ituki" storage="chara/ituki/normal.png" color="0xffd700" jname="宗方いつき"]
[iscript]
TYRANO.kag.stat.charas['ituki'].jname = '宗方 いつき'
[endscript]
;通常
[chara_face name="ituki" face="normal" storage="chara/ituki/normal.png"]
[chara_face name="ituki" face="angry" storage="chara/ituki/angry.png"]
[chara_face name="ituki" face="cry" storage="chara/ituki/cry.png"]
[chara_face name="ituki" face="hate" storage="chara/ituki/hate.png"]
[chara_face name="ituki" face="sad" storage="chara/ituki/sad.png"]
[chara_face name="ituki" face="shame" storage="chara/ituki/shame.png"]
[chara_face name="ituki" face="smile" storage="chara/ituki/smile.png"]
[chara_face name="ituki" face="smileCE" storage="chara/ituki/CEsmile.png"]
[chara_face name="ituki" face="smileW" storage="chara/ituki/Wsmile.png"]
[chara_face name="ituki" face="tweet" storage="chara/ituki/tweet.png"]
[chara_face name="ituki" face="tweetB" storage="chara/ituki/Btweet.png"]
[chara_face name="ituki" face="choise" storage="chara/ituki/choise.png"]
[chara_face name="ituki" face="choiseS" storage="chara/ituki/choiseS.png"]
;いつき　私服
[chara_face name="ituki" face="normalG_s" storage="chara/ituki/sihuku/normalG_s.png"]
[chara_face name="ituki" face="angry_s" storage="chara/ituki/sihuku/angry_s.png"]
[chara_face name="ituki" face="angryB_s" storage="chara/ituki/sihuku/angryB_s.png"]
[chara_face name="ituki" face="angryN_s" storage="chara/ituki/sihuku/angryN_s.png"]
[chara_face name="ituki" face="cry_s" storage="chara/ituki/sihuku/cry_s.png"]
[chara_face name="ituki" face="cry1_s" storage="chara/ituki/sihuku/cry1_s.png"]
[chara_face name="ituki" face="cry2_s" storage="chara/ituki/sihuku/cry2_s.png"]
[chara_face name="ituki" face="cry3_s" storage="chara/ituki/sihuku/cry3_s.png"]
[chara_face name="ituki" face="cry4_s" storage="chara/ituki/sihuku/cry4_s.png"]
[chara_face name="ituki" face="cry5_s" storage="chara/ituki/sihuku/cry5_s.png"]
[chara_face name="ituki" face="hate_s" storage="chara/ituki/sihuku/hate_s.png"]
[chara_face name="ituki" face="hateG_s" storage="chara/ituki/sihuku/hateG_s.png"]
[chara_face name="ituki" face="lookAway_s" storage="chara/ituki/sihuku/lookAway_s.png"]
[chara_face name="ituki" face="sad_s" storage="chara/ituki/sihuku/sad_s.png"]
[chara_face name="ituki" face="sadB_s" storage="chara/ituki/sihuku/sadB_s.png"]
[chara_face name="ituki" face="sadG_s" storage="chara/ituki/sihuku/sadG_s.png"]
[chara_face name="ituki" face="shame_s" storage="chara/ituki/sihuku/shame_s.png"]
[chara_face name="ituki" face="shout_s" storage="chara/ituki/sihuku/shout_s.png"]
[chara_face name="ituki" face="smile_s" storage="chara/ituki/sihuku/smile_s.png"]
[chara_face name="ituki" face="smileLA_s" storage="chara/ituki/sihuku/smileLA_s.png"]
[chara_face name="ituki" face="smileW_s" storage="chara/ituki/sihuku/smileW_s.png"]
[chara_face name="ituki" face="tweet_s" storage="chara/ituki/sihuku/tweet_s.png"]
[chara_face name="ituki" face="tweetB_s" storage="chara/ituki/sihuku/tweetB_s.png"]
[chara_face name="ituki" face="tweetG_s" storage="chara/ituki/sihuku/tweetG_s.png"]
[chara_face name="ituki" face="tweetLA_s" storage="chara/ituki/sihuku/tweetLA_s.png"]
;-------------------------------------------------------------------------------
;riki
[chara_new name="riki" storage="chara/riki/normal.png" color="0xffd700" jname="登利力"]
[iscript]
TYRANO.kag.stat.charas['riki'].jname = '登利 力'
[endscript]
;通常
[chara_face name="riki" face="normal" storage="chara/riki/normal.png"]
[chara_face name="riki" face="angry" storage="chara/riki/angry.png"]
[chara_face name="riki" face="wow" storage="chara/riki/wow.png"]
[chara_face name="riki" face="smile" storage="chara/riki/smile.png"]
[chara_face name="riki" face="smileCE" storage="chara/riki/smileCE.png"]
[chara_face name="riki" face="smileH" storage="chara/riki/smileH.png"]
[chara_face name="riki" face="sad" storage="chara/riki/sad.png"]
[chara_face name="riki" face="hate" storage="chara/riki/hate.png"]
[chara_face name="riki" face="lookAway" storage="chara/riki/lookAway.png"]
[chara_face name="riki" face="think" storage="chara/riki/think.png"]
[chara_face name="riki" face="worry" storage="chara/riki/worry.png"]
[chara_face name="riki" face="ghost" storage="chara/riki/ghost.png"]
[chara_face name="riki" face="ghostG" storage="chara/riki/ghostG.png"]
[chara_face name="riki" face="shame" storage="chara/riki/shame.png"]
[chara_face name="riki" face="tweetLA" storage="chara/riki/tweetLA.png"]
[chara_face name="riki" face="smileG" storage="chara/riki/smileG.png"]
[chara_face name="riki" face="smileB" storage="chara/riki/smileB.png"]
[chara_face name="riki" face="shoutG" storage="chara/riki/shoutG.png"]
;登利　私服
[chara_face name="riki" face="normal_s" storage="chara/riki/normal_s.png"]
[chara_face name="riki" face="angry_s" storage="chara/riki/angry_s.png"]
[chara_face name="riki" face="wow_s" storage="chara/riki/wow_s.png"]
[chara_face name="riki" face="smile_s" storage="chara/riki/smile_s.png"]
[chara_face name="riki" face="smile1_s" storage="chara/riki/smile1_s.png"]
[chara_face name="riki" face="smile2_s" storage="chara/riki/smile2_s.png"]
[chara_face name="riki" face="smile3_s" storage="chara/riki/smile3_s.png"]
[chara_face name="riki" face="smileCE_s" storage="chara/riki/smileCE_s.png"]
[chara_face name="riki" face="smileH_s" storage="chara/riki/smileH_s.png"]
[chara_face name="riki" face="sad_s" storage="chara/riki/sad_s.png"]
[chara_face name="riki" face="hate_s" storage="chara/riki/hate_s.png"]
[chara_face name="riki" face="lookAway_s" storage="chara/riki/lookAway_s.png"]
[chara_face name="riki" face="think_s" storage="chara/riki/think_s.png"]
[chara_face name="riki" face="worry_s" storage="chara/riki/worry_s.png"]
[chara_face name="riki" face="shame_s" storage="chara/riki/shame_s.png"]
[chara_face name="riki" face="tweetLA_s" storage="chara/riki/tweetLA_s.png"]
[chara_face name="riki" face="smileB_s" storage="chara/riki/smileB_s.png"]
[chara_face name="riki" face="shoutG_s" storage="chara/riki/shoutG_s.png"]
;-------------------------------------------------------------------------------
;aki
[chara_new name="aki" storage="chara/aki/normal.png" color="0xffd700" jname="器楽堂アキ"]
[iscript]
TYRANO.kag.stat.charas['aki'].jname = '器楽堂 アキ'
[endscript]
;通常
[chara_face name="aki" face="normal" storage="chara/aki/normal.png"]
[chara_face name="aki" face="hate" storage="chara/aki/hate.png"]
[chara_face name="aki" face="hurry" storage="chara/aki/hurry.png"]
[chara_face name="aki" face="sad" storage="chara/aki/sad.png"]
[chara_face name="aki" face="smile" storage="chara/aki/smile.png"]
[chara_face name="aki" face="smileB" storage="chara/aki/Bsmile.png"]
[chara_face name="aki" face="tweet" storage="chara/aki/tweet.png"]
[chara_face name="aki" face="tweetLA" storage="chara/aki/LAtweet.png"]
[chara_face name="aki" face="worry" storage="chara/aki/worry.png"]
[chara_face name="aki" face="wow" storage="chara/aki/wow.png"]
[chara_face name="aki" face="ghost" storage="chara/aki/ghost.png"]
;アキ　私服
[chara_face name="aki" face="normal_s" storage="chara/aki/normal_s.png"]
[chara_face name="aki" face="hate_s" storage="chara/aki/hate_s.png"]
[chara_face name="aki" face="hurry_s" storage="chara/aki/hurry_s.png"]
[chara_face name="aki" face="sad_s" storage="chara/aki/sad_s.png"]
[chara_face name="aki" face="smile_s" storage="chara/aki/smile_s.png"]
[chara_face name="aki" face="smileB_s" storage="chara/aki/smileB_s.png"]
[chara_face name="aki" face="tweet_s" storage="chara/aki/tweet_s.png"]
[chara_face name="aki" face="tweetLA_s" storage="chara/aki/tweetLA_s.png"]
[chara_face name="aki" face="worry_s" storage="chara/aki/worry_s.png"]
[chara_face name="aki" face="wow_s" storage="chara/aki/wow_s.png"]
[chara_face name="aki" face="ghost_s" storage="chara/aki/ghost_s.png"]
;-------------------------------------------------------------------------------
;hino
[chara_new name="hino" storage="chara/hino/angry.png" color="0xffd700" jname="日野くにお"]
[iscript]
TYRANO.kag.stat.charas['hino'].jname = '日野 くにお'
[endscript]
;通常
[chara_face name="hino" face="normal" storage="chara/hino/normal.png"]
[chara_face name="hino" face="angry" storage="chara/hino/angry.png"]
[chara_face name="hino" face="happy" storage="chara/hino/happy.png"]
[chara_face name="hino" face="sad" storage="chara/hino/sad.png"]
[chara_face name="hino" face="shame" storage="chara/hino/shame.png"]
[chara_face name="hino" face="smile" storage="chara/hino/smile.png"]
[chara_face name="hino" face="lookAway" storage="chara/hino/lookAway.png"]
[chara_face name="hino" face="tweet" storage="chara/hino/tweet.png"]
[chara_face name="hino" face="ghost" storage="chara/hino/ghost.png"]
;日野　私服
[chara_face name="hino" face="normal_s" storage="chara/hino/normal_s.png"]
[chara_face name="hino" face="angry_s" storage="chara/hino/angry_s.png"]
[chara_face name="hino" face="happy_s" storage="chara/hino/happy_s.png"]
[chara_face name="hino" face="sad_s" storage="chara/hino/sad_s.png"]
[chara_face name="hino" face="shame_s" storage="chara/hino/shame_s.png"]
[chara_face name="hino" face="smile_s" storage="chara/hino/smile_s.png"]
[chara_face name="hino" face="lookAway_s" storage="chara/hino/lookAway_s.png"]
[chara_face name="hino" face="tweet_s" storage="chara/hino/tweet_s.png"]
[chara_face name="hino" face="ghost_s" storage="chara/hino/ghost_s.png"]
;-------------------------------------------------------------------------------
;suguru
[chara_new name="suguru" storage="chara/suguru/normal.png" color="0xffd700" jname="宗方すぐる"]
[iscript]
TYRANO.kag.stat.charas['suguru'].jname = '宗方 すぐる'
[endscript]
;通常
[chara_face name="suguru" face="normal" storage="chara/suguru/normal.png"]
[chara_face name="suguru" face="angry" storage="chara/suguru/angry.png"]
[chara_face name="suguru" face="sad" storage="chara/suguru/sad.png"]
[chara_face name="suguru" face="sadB" storage="chara/suguru/Bsad.png"]
[chara_face name="suguru" face="shame" storage="chara/suguru/shame.png"]
[chara_face name="suguru" face="smile" storage="chara/suguru/smile.png"]
[chara_face name="suguru" face="smileSP" storage="chara/suguru/SPsmile.png"]
[chara_face name="suguru" face="wow" storage="chara/suguru/wow.png"]
;すぐる　私服
[chara_face name="suguru" face="normal_s" storage="chara/suguru/normal_s.png"]
[chara_face name="suguru" face="angry_s" storage="chara/suguru/angry_s.png"]
[chara_face name="suguru" face="sad_s" storage="chara/suguru/sad_s.png"]
[chara_face name="suguru" face="sadB_s" storage="chara/suguru/sadB_s.png"]
[chara_face name="suguru" face="shame_s" storage="chara/suguru/shame_s.png"]
[chara_face name="suguru" face="smile_s" storage="chara/suguru/smile_s.png"]
[chara_face name="suguru" face="smileSP_s" storage="chara/suguru/smileSP_s.png"]
[chara_face name="suguru" face="wow_s" storage="chara/suguru/wow_s.png"]
;-------------------------------------------------------------------------------
;kuma
[chara_new  name="kuma" storage="chara/kuma/normal.png" color="0xffd700" jname="熊明子" ]
[iscript]
TYRANO.kag.stat.charas['kuma'].jname = '熊 明子'
[endscript]
;通常
[chara_face name="kuma" face="normal" storage="chara/kuma/normal.png"]
[chara_face name="kuma" face="angry" storage="chara/kuma/angry.png"]
[chara_face name="kuma" face="wow" storage="chara/kuma/wow.png"]
[chara_face name="kuma" face="smile" storage="chara/kuma/smile.png"]
[chara_face name="kuma" face="smileW" storage="chara/kuma/Wsmile.png"]
[chara_face name="kuma" face="closeEye" storage="chara/kuma/closeEye.png"]
[chara_face name="kuma" face="hurry" storage="chara/kuma/hurry.png"]
;-------------------------------------------------------------------------------
;kawa
[chara_new  name="kawa" storage="chara/kawa/normal.png" color="0xffd700" jname="川鈴木仁" ]
[iscript]
TYRANO.kag.stat.charas['kawa'].jname = '川鈴木 仁'
[endscript]
;通常
[chara_face name="kawa" face="normal" storage="chara/kawa/normal.png"]
[chara_face name="kawa" face="hate" storage="chara/kawa/hate.png"]
[chara_face name="kawa" face="sad" storage="chara/kawa/sad.png"]
[chara_face name="kawa" face="smile" storage="chara/kawa/smile.png"]
[chara_face name="kawa" face="smileW" storage="chara/kawa/smileW.png"]
[chara_face name="kawa" face="think" storage="chara/kawa/think.png"]
[chara_face name="kawa" face="shame" storage="chara/kawa/shame.png"]
[chara_face name="kawa" face="whistle" storage="chara/kawa/whistle.png"]
;-------------------------------------------------------------------------------
;入道
[chara_new  name="nyudo" storage="chara/nyudo/normal.png" color="0xffd700" jname="入道永海" ]
[iscript]
TYRANO.kag.stat.charas['nyudo'].jname = '入道 永海'
[endscript]
;通常
[chara_face name="nyudo" face="normal" storage="chara/nyudo/normal.png"]
[chara_face name="nyudo" face="angry" storage="chara/nyudo/angry.png"]
[chara_face name="nyudo" face="angryB" storage="chara/nyudo/angryB.png"]
[chara_face name="nyudo" face="closeEye" storage="chara/nyudo/closeEye.png"]
[chara_face name="nyudo" face="ghost" storage="chara/nyudo/ghost.png"]
[chara_face name="nyudo" face="sad" storage="chara/nyudo/sad.png"]
[chara_face name="nyudo" face="shame" storage="chara/nyudo/shame.png"]
[chara_face name="nyudo" face="smile" storage="chara/nyudo/smile.png"]
;-------------------------------------------------------------------------------
;kinuyo
[chara_new  name="kinuyo" storage="chara/makado/normal.png" color="0xffd700" jname="志戸田絹世"]
[iscript]
TYRANO.kag.stat.charas['kinuyo'].jname = '志戸田 絹世'
[endscript]
;通常
[chara_face name="kinuyo" face="normal" storage="chara/kinuyo/normal.png"]
[chara_face name="kinuyo" face="angry" storage="chara/kinuyo/angry.png"]
[chara_face name="kinuyo" face="back" storage="chara/kinuyo/back.png"]
[chara_face name="kinuyo" face="closeEye" storage="chara/kinuyo/closeEye.png"]
[chara_face name="kinuyo" face="sad" storage="chara/kinuyo/sad.png"]
[chara_face name="kinuyo" face="smileSP" storage="chara/kinuyo/SPsmile.png"]
;-------------------------------------------------------------------------------
;kirie
[chara_new  name="kirie" storage="chara/kirie/normal.png"  color="0xffd700" jname="宗方 きりえ"  ]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = '宗方 きりえ'
[endscript]
;通常
[chara_face name="kirie" face="normal" storage="chara/kirie/normal.png"]
[chara_face name="kirie" face="lookAway" storage="chara/kirie/lookAway.png"]
[chara_face name="kirie" face="sad" storage="chara/kirie/sad.png"]
[chara_face name="kirie" face="smile" storage="chara/kirie/smile.png"]
[chara_face name="kirie" face="wow" storage="chara/kirie/wow.png"]
;おばけ
[chara_face name="kirie" face="ghost" storage="chara/kirie/ghost.png"]
[chara_face name="kirie" face="ghost_2" storage="chara/kirie/ghost_2.png"]
[chara_face name="kirie" face="ghostC" storage="chara/kirie/ghostC.png"]
[chara_face name="kirie" face="long" storage="chara/kirie/long.png"]
;きりえ　冬
[chara_face name="kirie" face="normal_w" storage="chara/kirie/winter/normal_w.png"]
[chara_face name="kirie" face="hate_w" storage="chara/kirie/winter/hate_w.png"]
[chara_face name="kirie" face="angry_w" storage="chara/kirie/winter/angry_w.png"]
[chara_face name="kirie" face="lookAway_w" storage="chara/kirie/winter/lookAway_w.png"]
[chara_face name="kirie" face="sad_w" storage="chara/kirie/winter/sad_w.png"]
[chara_face name="kirie" face="shame_w" storage="chara/kirie/winter/shame_w.png"]
[chara_face name="kirie" face="smile_w" storage="chara/kirie/winter/smile_w.png"]
[chara_face name="kirie" face="smileW_w" storage="chara/kirie/winter/smileW_w.png"]
;-------------------------------------------------------------------------------
;marigan
[chara_new name="marigan" storage="chara/marigan/normal.png" color="0xffd700" jname="紀伊マリガン"]
[iscript]
TYRANO.kag.stat.charas['marigan'].jname = '紀伊 マリガン'
[endscript]
;表情
[chara_face name="marigan" face="normal" storage="chara/marigan/normal.png"]
[chara_face name="marigan" face="angry" storage="chara/marigan/angry.png"]
[chara_face name="marigan" face="hate" storage="chara/marigan/hate.png"]
[chara_face name="marigan" face="sad" storage="chara/marigan/sad.png"]
[chara_face name="marigan" face="hurry" storage="chara/marigan/hurry.png"]
[chara_face name="marigan" face="smile" storage="chara/marigan/smile.png"]
[chara_face name="marigan" face="smileCE" storage="chara/marigan/smileCE.png"]
[chara_face name="marigan" face="smileB" storage="chara/marigan/smileB.png"]
[chara_face name="marigan" face="tweet" storage="chara/marigan/tweet.png"]
[chara_face name="marigan" face="tweetLA" storage="chara/marigan/tweetLA.png"]
[chara_face name="marigan" face="worry" storage="chara/marigan/worry.png"]
[chara_face name="marigan" face="wow" storage="chara/marigan/wow.png"]
;-------------------------------------------------------------------------------
;mokke
[chara_new  name="mokke"  storage="chara/mokke/sankakuBlack.png" color="0xffd700" jname="男子生徒" ]
[chara_face name="mokke" face="kuroda" storage="chara/mokke/sankakuBlack.png"]
[chara_face name="mokke" face="marigan"  storage="chara/mokke/longRed.png"]
[chara_face name="mokke" face="sisyo" storage="chara/mokke/womenWhite.png"]
[chara_face name="mokke" face="kaiko" storage="chara/mokke/kaiko.png"]
[chara_face name="mokke" face="akira" storage="chara/mokke/menBlack.png"]
[chara_face name="mokke" face="oji" storage="chara/mokke/menWhite.png"]
[chara_face name="mokke" face="womanStudent" storage="chara/mokke/womenStudent.png"]
[chara_face name="mokke" face="womenBlack" storage="chara/mokke/womenBlack.png"]
[chara_face name="mokke" face="longYellow" storage="chara/mokke/longYellow.png"]
[chara_face name="mokke" face="tibiYellow" storage="chara/mokke/tibiYellow.png"]
[chara_face name="mokke" face="motiWhite" storage="chara/mokke/motiWhite.png"]
[chara_face name="mokke" face="pink" storage="chara/mokke/pink.png"]
;オシラヒメ
[chara_face name="mokke" face="normal" storage="chara/mokke/osira/normal.png"]
[chara_face name="mokke" face="hate" storage="chara/mokke/osira/hate.png"]
[chara_face name="mokke" face="closeEye" storage="chara/mokke/osira/closeEye.png"]
[chara_face name="mokke" face="shout" storage="chara/mokke/osira/shout.png"]
[chara_face name="mokke" face="smile" storage="chara/mokke/osira/smile.png"]
[chara_face name="mokke" face="smileMini" storage="chara/mokke/osira/smileMini.png"]

[eval exp="f.save_title = '序章一日目'"]

;上記で定義した領域がキャラクターの名前表示であることを宣言（これがないと#の部分でエラーになります）
[chara_config ptext="chara_name_area"]
;-------------------------------------------------------------------------------
*op
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=false
[clearfix]
[mask_off time="100"]
[stopbgm]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="20"]
[wse]
;-------------------------------------------------------------------------------;-------------------------------------------------------------------------------
[mask time="8000"]
[fadeinbgm storage=rain.ogg loop=true time=10000 volume=50 sprite_time="2000-61000"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

;メニューボタンの表示
@showmenubutton
[bg storage="op_one.png" time="100"]
[position layer=message0 page=fore margint="35" marginl="25" marginr="25" marginb="10"]
@layopt layer=message0 visible=true
[mask_off]
[playse storage=page.ogg volume="50"]
[delay speed="70"]
[resetfont]
#
……蚕若无人为条件便无法存活[r]
是被驯化的昆虫……[p]

纯白的幼虫无法融入外界　柔弱到[r][wait time="500"]
风一吹便连叶片都抓不住。[p]
[delay speed="60"]
因此，蚕不存在于野生环境。[r][wait time="500"]
无法独自生存。[p]

[bg storage="op_two.png" time="500" wait="false"]
[playse storage=page.ogg volume="50"]
而且，[wait time="500"]从茧中羽化的蚕成虫丧失了进食能力……[r][wait time="500"]
也就是说，[wait time="500"]它们在茧里遗忘了赖以生存的能力。[p]

[bg storage="op_four.png" time="500" wait="false"]
[playse storage=page.ogg volume="50"]
正因如此，蚕蛾拥有着[wait time="500"]毫无用途的口器[r][wait time="500"]
以及在品种改良尽头获得的、无法飞翔的翅膀[p]

羽化后大约[wait time="500"]一周左右[wait time="500"]就会死去。[p]

在这座小镇里，[p]
@layopt layer=message0 visible=false
[clearfix]
[stopbgm]
[playse storage=bell.ogg sprite_time="0000-7000" volume="5"]
[bg storage=./school/croom_n.jpg time="1500" wait=true]
[wse]
[resetdelay]
;-------------------------------------------------------------------------------
*part1
;-------------------------------------------------------------------------------

[wse]
[wait time="2000"]

[chara_show  name="sarasa" left=390 top=-160]
#sarasa
[delay speed="70"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]


…………………………[p]
#
[chara_show name="kuma" left=-150 top=-160 time=500]
#kuma
…………………………[p]
[playbgm storage="gymnopedies2.ogg" loop="true" volume="50"]
#kuma:hurry
[resetdelay]
哎呀，上课时间结束了吗？[p]
[chara_hide name="sarasa" pos_mode="false" wait="false" time="10"]
[chara_show name="riki" left=330 top=-100 wait="false" time="200"]
#riki:smile
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[wait time="10"]
喂——！小熊你在发什么呆啊！[r]
我们该回去了啦[p]
#kuma:closeEye
真是的……完全没注意到呢。[r][wait time="500"]
登利君很会看时间呢[p]
#riki:smileCE
没有啦，我这个人比较守时嘛[p]
[chara_move name="riki" left=400 anim="true" wait="false" time=500]
[chara_show  name="mokke" left=400 top=100 wait="false" time="200"]
#mokke
不是的老师！[r]
登利你只是着急想回家吧～？[p]
#kuma:wow
哎呀！[p]
#riki:hate
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[wait time="10"]
喂黑田 你这种话总是脱口而出啊！[p]
#kuma:smileW
好了好了安静[wait time="500"]　志户田同学的发表还没结束呢！[p]
[delay speed="50"]
#mokke
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[wait time="10"]
诶～差不多该结束了吧老师。[r]
下次再说也行嘛[p]
#riki:normal
就是啊～！[p]
#riki:smile
啊、还有、说到底……[r]
暑假还得被逼来学校才奇怪吧～[p]
[font size="40"]
#クラスメイト
[quake time="300" wait="false" vmax="4"]
[playse  volume="30" buf="0" storage="kansei.ogg"]
就是就是————！！！[p]
[resetfont]
[delay speed="60"]
#
看来大家都无法容忍课程多延长一秒啊。[p]
[resetdelay]
[link target=*serect1]【１】静观其变[endlink][r]
[call target="*Sub_hover"]

[s  ]

*serect1
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
[delay speed="50"]
#kuma:smile
呵呵……都怪志户田同学的发表太精彩了，[r]
听得入迷连时间都忘记确认了呢。[p]
#kuma:smileW
抱歉啦～[r]
正式发表时我会好好聆听的哦[p]
#kuma:normal
那么今天就满足大家的期待到此为止，[r]
各班同学，请为暑假结束后的发表会好好准备哦！[p]

[chara_mod name="riki" face="smileCE"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[wait time="10"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[wait time="10"]
[playse  volume="30" buf="0" storage="kansei.ogg"]
#
太好啦！[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all  wait="false" time="300"]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="800"]

[chara_show name="ituki" top=-160 wait="false" time=500 face="normal" left="140"]
[wait time="3000"]
#ituki:smile
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]


纱罗纱[p]
[chara_move name="ituki" left="-70" anim="true"]
[chara_show name="sarasa" left=360 top=-160 time=500 wait="false"]
#sarasa:smile
……一树[p]
#ituki:smileW
大家都没能完成发表呢～[r][wait time="500"]
人家超想听完纱罗纱的故事结尾的说～[p]
#ituki:hate
话说～黒田君他们根本就没做准备吧？[r][wait time="500"]
暑假两周时间到底在干什么呀～……[p]
#
今天好像有心情用方言说话呢[r]
树月正东张西望地环视四周。[p]
#ituki:hate
还有一个人从放假开始就让人担心他的动向……[r][wait time="500"]
#ituki:angry
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[wait time="10"]
……啊、找到了！[wait time="500"]　喂登利君！[p]
[chara_hide name="sarasa" pos_mode="false" time="10" wait="false"]
[chara_show name="riki" face="normal" left=360 top=-100 wait="false" time="100"]

#riki
啊？[p]
#ituki:sad
登利君也～肯定没写作业吧～。[r]
我们小组分配的内容[wait time="500"]　好好记着没～？[p]
#riki:smileCE
嘿嘿，记得记得。[l][r]
#riki:smile
我那个嘛[wait time="500"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]　「虫捕まえる」係！[p]
#ituki:hate
哎呀完全不是这么回事啦～。[p]
#riki:lookAway
哈哈～。[l][r]
[resetdelay]
#riki:smile
……那我[wait time="500"]　「黒田喜欢的人是谁」这个话题[r]
现在就要揭晓答案咯～！[p]
[chara_mod name="ituki" face="tweet"]
[chara_show  name="mokke" left=100 top=100 pos_mode="false" time="100" wait="false"]

[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
#mokke
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
哈？[wait time="500"]　等等登利！[p]
[delay speed="80"]
#riki:smileCE
黒田喜欢的人是～　咱们班学号13号的～～～[p]
[font size="40"]
[delay speed="50"]
#mokke
讨厌！[p]
#
[resetfont]
[chara_move name="riki" left=-520 anim="true" time=700 wait="false"]
[chara_move name="mokke" left=-520 anim="true" time=500 wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[chara_hide name="riki" pos_mode="false" time="10"]
[chara_hide name="mokke" pos_mode="false" time="10"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]
[wait time="800"]
……………………………………[p]
#ituki:sad
……13号不就是纱罗纱嘛～。[r]
真可怜～　黒田同学[p]
#
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="800"]
;aki
[chara_show name="aki" left=360 top=-100 wait="false"]
#aki:tweet
喂喂　一树　纱罗纱[r]
力他们已经回去了吗？[p]
#ituki:normal
啊～　阿基。[l][r]
[resetdelay]
#ituki:smile
那两个人啊～边闹腾边回去啦～[p]
#aki:sad
果然……[r][wait time="500"]
我有东西要交给力同学[r]
明明说了让他在我上厕所回来前等着的…[p]
#ituki:smile
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
要交什么呀～？[r]
该不会是挑战书之类的吧～[p]
#aki:hurry
真是的！才不是啦……[l][r]
[delay speed="50"]
#aki:normal
这本是想交给你们俩的东西。[wait time="500"]给[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all wait="true"]
;夏の課題について（持ち物画像表示）
[cm]
#
[image layer=0 name="memo" folder="image" storage="item/memo_class.png" width="500" x="250" y="52" time="800" wait="true"]
;アイテム「メモ」入手
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
[playse  volume="20" buf="0" storage="sariin.ogg"]
[font color="0xb0c4de"]
获得了〇班的笔记。[r]
可在→的「携带物品」按钮处确认。
[tip key="memo_class"][endtip]
[wse][p]
[resetfont]
#ituki
哇～[l]　阿基，你把暑假作业的事情都整理在备忘录里了吗？[r]
连返校日的安排都写好了呢～[p]
#aki
嘿嘿。因为力同学实在太让人操心了……[l][r]
不事先叮嘱好的话[r]
班会说不定一天都不会来开呢[p]
#
[free layer=0 name="memo" time="800"]
[chara_show name="aki" top="-100" face="smile" wait="false"]
#aki
剩下的两份我也会帮忙转交给他们的。[r]
一起加油完成暑假作业吧！[p]
[delay speed="60"]
[chara_hide name="aki" wait="false"]
#
……就这样，阿奇正要离开教室时。[l][r]
[fadeoutbgm time="7000"]
突然，在手搭上门把时停下动作……[wait time="500"][r]
转头望了过来。[p]
#aki
啊　对了　纱罗纱……[p]
;いつき少し左へ、紗羅紗登場
[chara_show name="aki" wait="false" left="-70" face="normal" top="-100"]
[chara_show name="sarasa" left="360" wait="false" face="normal" top="-160"]
#sarasa:normal
……？[p]
#aki:normal
[delay speed="50"]
这个月　２７日的　白绢祭。[l][r]
#aki:smile
我们全家都会去看的。[wait time="500"]御白姬角色　要加油哦[p]
#
[chara_hide name="aki" wait="false" pos_mode="false"]
[playse  volume="50" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]

;アキ消える、沙羅沙といつき移動（左）
[chara_show name="ituki" top="-160" left=-70 wait="false" time=100]
#ituki:smileCE
笔记谢啦～　拜拜～！[p]
……………………………………[p]
[resetdelay]
#ituki:smile
……好啦～。[p]
#ituki:normal
我们也差不多该回去啦～。[r]
我去准备下，稍微等我会儿哦纱罗纱～[p]
[fadeinbgm storage=rain.ogg loop=true time=5000 volume=50 sprite_time="2000-61000"]
#
[mask folder="bgimage" graphic="still/prologue.png" time="3000"]
[chara_hide_all wait="false" time="10"]
[wait time="3000"]
;-------------------------------------------------------------------------------
[bg storage="school/rouka_n.jpg" time="10" wait=true]
[chara_mod name="sarasa" face="normal"]
[chara_mod name="ituki" face="normal"]

;-------------------------------------------------------------------------------
[mask_off]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[chara_show name="ituki" time="10" top="-160" face="normal" wait="false"]

#ituki:smile
呐呐　纱罗纱。[r]
不是上学的日子也单独约出来玩吧～[p]
#ituki:smileCE
嘿嘿～去哪好呢～。[r]
最近新开的咖啡馆什么的去探店也不错啦～、[r]
纱罗纱　你有什么想去的地方吗？[p]
#
[delay speed="60"]
我、在那个问题之后，一如既往地观察着她的反应。[p]
#ituki:normal
…………。[l][r]
[resetdelay]
#ituki:tweet
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
……啊！对对对。差点忘了。[p][stop_kanim name=树]
#ituki:choiseS
好！[r][wait time="500"]
左手小拇指的话就去花隅商店街，右手小拇指就去向日葵花田哦！[p]
#
[link target=*hanasumi]【１】花隅商店街[endlink][r]
[link target=*himawari]【２】向日葵花田[endlink][r]
[call target="*Sub_hover"]

[s ]

;---------------------------------------------------------
*hanasumi
;---------------------------------------------------------
;はなすみ商店街
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[cm]
#
[delay speed="60"]
我、选择握住了她的左手小拇指。[p]
[resetdelay]
#ituki:tweet
诶～那就是说想来我家～？[p]
#ituki:hate
不要啦～我家可招待不起纱罗纱这样的孩子[r]
才不是要去你家啦～！[r][wait time="500"]
而且最近忙得团团转呢～……[p]
#ituki:smileW
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
真是的～公主殿下何必特意光临贫民区嘛[r]
太屈尊降贵了啦～[r][wait time="500"]
我会找个文艺点的咖啡厅～之类的等着你～[p]

@jump target="*syoko_guti"
;---------------------------------------------------------
*himawari
;---------------------------------------------------------
;ひまわり畑
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[cm]
#
[delay speed="60"]
我、选择握住了她的右手小拇指。[p]
[resetdelay]
#ituki:normal
噢～向日葵花田？不错嘛～感觉会很上镜哦～[r][wait time="500"]
去车站路上开得超级茂盛呢～[p]

#ituki:smileCE
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
啊、对了。我帮你带相机去～[r]
是离家出走的姐姐～留下的东西～[p]
这样就能给纱罗纱拍好多照片啦！[r]
呵呵、真期待呢～[p]


@jump target="*syoko_guti"
;---------------------------------------------------------
*syoko_guti
;---------------------------------------------------------

[mask]
;-------------------------------------------------------------------------------

[cm]
[bg storage="school/entrance_n.jpg" time="1500"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]

[chara_mod  name="sarasa" face="normal" ]
[chara_mod  name="ituki" face="normal" ]

;-------------------------------------------------------------------------------
[mask_off]
#ituki:tweet
[delay speed="50"]
唔～还是下着好大的雨啊～……[r]
感觉今天～从早上开始就是暴雨呢～[p]
#
[link target=*phone]【１】给妈妈打电话，让她来接我[endlink]
[call target="*Sub_hover"]

[s  ]

;---------------------------------------------------------
*phone
;---------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[cm]

#
我决定打电话让妈妈来学校接我。[r]
中途还要顺路去树月家一趟。[p]
#
……[wait time=900][l][r]
……………………………………[p]
#
[fadeoutbgm time="2000"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
咦？[p]
#ituki:normal
嗯？怎么了？[p]
#sarasa
……………………………………[p]
#
把手机拿给树月看。[p]
#ituki
……[l]
#ituki:tweet
哎呀～通话软件出问题了吗[p]
#ituki:tweet
…………………………[p]
#ituki:smile
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
……啊[l][r]
#ituki:smileCE
那我说～[p]
#ituki:normal
[resetdelay]
我　现在准备去图书馆[r]
想着要做发表会的准备嘛～，[r][wait time="500"]
纱罗纱你要不要一起来？[p]
#ituki:smile
天气预报说一小时左右后就会放晴～，[r]
到时候再试试APP能不能用不就好啦～？[l][r]
说不定是因为下雨才状态不好呢[p]
#ituki:smileCE
[delay speed="60"]
所以在雨停之前～一起等着吧～？[p]
#sarasa
…………………………[l][r]
也是呢……[p]
[resetdelay]
#ituki:smileCE
这样挺好。[r]
[anim name="ituki" top="+=60" time="150"]
[anim name="ituki" top="-=60" time="150"]
走吧走吧，纱罗纱！[p]
[mask time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[chara_move name="ituki" left="-70" time="10"]
[chara_show name="sarasa" top="-160" left="360" time="10" face="normal"]
#ituki:normal
;-------------------------------------------------------------------------------

[bg storage="school/library.jpeg" time="1500"]

;モブは一人のキャラとして扱って、表情変更で設定する
[chara_face name="mokke" face="sisyo" storage="chara/mokke/womenWhite.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '司書'
[endscript]

[fadeinbgm storage=gymnopedies2.ogg loop=true time="1000" volume="70"]

[cm]
;-------------------------------------------------------------------------------
[mask_off time="300"]
#ituki:smileCE
[font size="40"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
打扰啦～！[p]
[resetfont]
#ituki:smile
哇～[r]
完美地空无一人呢～[p]
#sarasa:worry
[delay speed="60"]
啊，一树……[p]
[resetfont]
#ituki:normal
嗯？[p]
[chara_hide name="sarasa" pos_mode="false" wait="false" time="10"]
[chara_hide name="ituki" pos_mode="false" time="10"]
#
[chara_show name="mokke" time="1000" face="sisyo" wait="true"]
[delay speed="120"]
#mokke
…………………………[p]

[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" left=360 top=-160 time=300 wait="false"]
[resetdelay]
#ituki:smile
[chara_show name="ituki" left=-70 top=-160 wait="false" time=300]
啊～没问题的纱罗纱。[p]
#ituki:normal
[delay speed="50"]
那个管理员好像是只在暑假期间来帮忙的人，[r]
超级放养主义？所以～[r][wait time="500"]
就算聊天也完全不会被骂哦～[p]
[chara_hide name="ituki" wait="false" pos_mode="false"]
[playse storage=walk_rouka.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="40" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=walk_rouka.ogg volume="30" sprite_time="0000-0300"]
[wait time="700"]
#
[playse  volume="20" buf="0" storage="book.ogg" ]
[delay speed="60"]
树月把书包放在桌上，[r]
拨开文件和笔记本开始寻找什么。[p]
[chara_mod name="sarasa" face="normal" time="0"]
在她整理物品的时候，[r]
我是不是该去书架的「乡土资料专区」转转……[p]
[resetdelay]
[link target=*saisin]【１】『白絹の町 新資料集』を読む[endlink][r]
[link target=*siryo]【２】『八種町民族資料集』を読む[endlink]
[call target="*Sub_hover"]

[s  ]
;---------------------------------------------------------
*saisin
;---------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#
『白绢之町 新资料集』被拿了起来。[p]
@layopt layer=message0 visible=true
[clearfix]
[playse storage=page.ogg volume="50"]
[image layer=message0 folder="image" name="siro_new" storage="item/siro_new.png" width="460" x="250" y="10" time="800" zindex="999"]
#
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[font size="22"]
咔嗒[p][free layer=message0 name="siro_new" time="300"]

@jump target="*kamisiba"
;---------------------------------------------------------
*siryo
;---------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#
『八种町民族资料集』被拿了起来。[p]
@layopt layer=message0 visible=true
[clearfix]
[playse storage=page.ogg volume="50"]
[image folder="image" layer=message0 name="hatane_minzoku" storage="item/hatane_minzoku.png" width="460" x="250" y="10" time="800" zindex="999"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[font size="22"]
咔嗒[p][free layer=message0 name="hatane_minzoku" time="300"]

@jump target="*kamisiba"
;---------------------------------------------------------
*kamisiba
;---------------------------------------------------------
[font size="40"]
[chara_show name="ituki" top="-160" wait="false" left="-70" face="hate" time="100"]
#ituki:hate
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
[chara_mod name="sarasa" face="wow"]
啊～～～～！[p]
[resetfont]
#sarasa:worry
什……什么！？[p]
#ituki:angry
[resetdelay]
等一下等一下～！[l][r]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
我、我可没对纱罗纱[font color="0xf08080"]『说什么都不准做』[wait time="500"]
[resetfont]这种话～！？[p]
#sarasa:worry
说……说过这种话啊[p]
#ituki:tweet
诶～？难道没说吗。[l][r]
#ituki:angry
不过算了没关系。[r]
总之先把那本书放下来啦！[p]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
树月一把夺走了我手中的书。[p]
[font size="20"]
#sarasa:closeEye
[delay speed="120"]
…………………………[p]
[resetfont]
[resetdelay]
#ituki:normal
别因为书被抢了就摆出那么难过的表情嘛～[p]
#ituki:smileCE
[anim name="ituki" left="+=60" time=200 ]
[anim name="ituki" left="-=60" time=200 ]
我有东西想给你看。[r]
所以　快过来！赶紧赶紧！[p]
[delay speed="60"]
#sarasa:normal
…………………………[l]
#sarasa:smile
嗯[p]
[mask time="300"]
[bg storage="still/kami_start.png" time="10"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
;-------------------------------------------------------------------------------

[chara_hide_all  wait="false" time="10"]

[cm]
;-------------------------------------------------------------------------------

[mask_off time="300"]
#ituki
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[quake time="300" wait="false" vmax="4"]
[font size="40"]
锵锵～！[p]
[resetfont]
#
[delay speed="50"]
树月夸张地向我展示的东西，[r]
活像连环画剧。[p]
#ituki
这个呢～？是假期结束后为发表会准备的，[r][wait time="500"]
专门介绍这个小镇传说的成果物哦～[p]

明明特意赶在返校日完成……[r]
发表顺序还没轮到树月对吧？[l][r]
总觉得这样太浪费了嘛～[p]
所以特别想让纱罗纱看看～[r]
想让你当我的第一位观众嘛～[p]
[resetdelay]
所以纱纱、快点！[wait time="500"]　坐下、坐下！[p]
#
我按照催促，在树月对面坐了下来。[p]
#ituki
[delay speed="50"]
结束后要记得鼓掌哦。[l][r]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[delay speed="100"]
八种町纸戏剧《御白姬传说》开场咯～！[p]
#
[fadeoutbgm time="3000"]
[mask time="3000"]
[cm]
[bg storage="still/kami_1.png" time="10"]
[fadeinbgm storage=onedari.ogg loop=true time="1000" volume=50 sprite_time="0200-21000"]
[mask_off]
[delay speed="70"]
#
在这个八种町　有位养蚕之神[r]
那位神明是蚕神大人　也是公主殿下[p]
她的名字是　御白姬[r]
[font size="18"]
※养蚕……指为了从蚕茧中取丝而饲养蚕的活动[p]
[resetfont]
她的肌肤　如同丝绸般　洁白[r]
她的眼眸　宛若黑珍珠般　闪耀着光辉[p]
[playse storage=page.ogg volume="50"]
[bg storage="still/kami_2.png" time="500"]
御白姬是位　温柔体贴的公主[r]
今天也会为陷入困境的人们　送去祝福[p]
为病痛之人　治愈伤痛[r]
向贫困之人　施予钱财……[l][r]
「希望大家都能展露笑颜就好了呢」[p]
[playse storage=page.ogg volume="50"]
[bg storage="still/kami_3.png" time="500"]
某日　当御白姬　路过街市之时……[r][wait time="500"]
咦？[wait time="500"]　那边有人在哭耶？[l][r]
御白姬询问道　「怎么啦？」[p]
[playse storage=page.ogg volume="50"]
[bg storage="still/kami_4.png" time="500"]
那人　回答道[r][wait time="500"]
[font size="38"]
「乌漆魔在使坏啦！」[resetfont][p]
乌漆魔是只　坏心眼的　漆黑妖怪[r]
镇上的人们　都被它吓得够呛[p]
[playse storage=page.ogg volume="50"]
[bg storage="still/kami_5.png" time="500"]
[font size="38"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
「乌漆魔！不可饶恕！」[r][resetfont]
[resetdelay]
砰砰砰　枪战开始了[p]
[playse storage=page.ogg volume="50"]
[bg storage="still/kami_6.png" time="500"]
大获全胜的御白姬，消失在了夜幕笼罩的街道中。[r]
[bg storage="still/kami_end.png" time="500"]
剧终[p]
[fadeoutbgm  time="3000"]
[mask time="3000"]
;-------------------------------------------------------------------------------

;暗転
[cm]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=5000 volume="70"]
[bg storage="school/library.jpeg" time="100"]

[chara_show name="ituki" left=-70 top=-160 wait="false" time=0 face="smileCE"]
[chara_show name="sarasa" left=360 top=-160 time=0 face="normal"]

;suguru
[mask_off time="3000"]
#sarasa:normal
[delay speed="120"]
………………………………[p]
#sarasa:worry
那个……[p]
#ituki:normal
………………………………[p]
[resetfont]
#ituki:normal
[font size="40"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[resetdelay]
快鼓掌呀！[p]
[resetfont]
#sarasa:closeEye
[font size="20"]
[delay speed="60"]
……还、还是重做比较好吧……[p]
[resetdelay]
#ituki:angry
[font size="40"]
为什么啦～！[p]
#sarasa:normal
[resetfont]
这、这种个人……解读成分也太多了吧[p]
#ituki:tweet
故事传承的时候不都会变成这样吗？[p]
#ituki:normal
[delay speed="60"]
……不过，既然你说要重做的话[r]
那就重做吧。[p]
[resetdelay]
#ituki:smileW
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
我做到一半都忘记原本要做什么风格了☆[r]
所以啦～，[r]
就硬是照着家里漫画参考着完成的说～[p]
[delay speed="70"]
[chara_mod name="sarasa" face="normal"]
#
……树月就是有这种，有点健忘的小毛病呢。[p]
[delay speed="50"]
#ituki:smileW
啊——不过嘛……反正暑假才刚开始☆[r]
修改的时间还多得是呢～！[r]
树月，要加油！[p]
#sarasa:normal
……加油啊，一树[p]
#ituki:smile
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
但是但是～我画得还挺不错的对吧～？[p]
#ituki:smileCE
御白姬什么的呀～[r]
我可是照着纱罗纱的样子画的哟～[wait time="500"]看得出来～？[p]
#
[delay speed="60"]
树月用手指交替指着纸剧里的御白姬和我。[p]
#ituki:smileCE
你看，肌肤像雪一样白的部分啊——[r]
还有那乌黑漂亮的眼睛什么的，简直一模一样！[p]
[resetdelay]
[stopbgm]
[chara_hide name="sarasa" pos_mode="false" wait="false" time="10"]
#
[chara_show name="suguru" left=360 top=-100 time=100 face="angry"]
……像个傻瓜似的[p]
#
[delay speed="60"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
——闻声回头，一名女学生站在那里。[l][r]
她好像是……[p]
[resetdelay]
#ituki:tweet
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
！[p][stop_kanim name=树]
#ituki:normal
优。[r]
你也没回家留在学校呢～？[p]
#suguru:angry
………………[p]
[chara_hide_all wait="false" time="500"]
[playse  volume="50" sprite_time="0000-0700" buf="0" loop="true" storage="walk_rouka.ogg" ]
[wait time=1400]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
[chara_show name="suguru" top="-100" wait="false" face="normal" left="360"]
[chara_show name="mokke" left="95" top="130" wait="false" face="sisyo"]
#suguru:normal
这些我全借走了[p]
#mokke:sisyo
……好的。是一年级的宗方同学对吧。[r]
要好好记住归还期限哦[p]
#suguru:normal
……多谢[p]
[fadeinbgm storage=rain.ogg loop=true time=10000 volume=50 sprite_time="2000-61000"]
[chara_hide name="suguru" pos_mode="false" wait="false" time="300"]
[playse  volume="50" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time=600]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time=600]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[chara_show name="ituki" left=390 top=-160 time=300 face="angry" wait="false"]
#ituki:angry
优！等一下～！[p]
#ituki:sad
……[r][wait time="500"]
干嘛啦～真是的，明明只是妹妹的臭毛病[p]
[chara_move name="mokke" anim="true" left=120 top=130 time="200" wait="false"]
#mokke
……喂[p]
#ituki:tweet
啊？[p]
#mokke
你和刚才那孩子是姐妹吗？[p]
#ituki:smile
咦？刚才的对话没看出来吗？[r]
反倒是你～[p]
#mokke
……诶～。[l][r]
[delay speed="50"]
所以你们就是宗方三姐妹里的妹妹二人组咯。[p]
#
图书管理员带着好奇的语气说完，[r]
从柜台探出身来，直勾勾地盯着树月。[p]
#mokke
啊……[wait time="500"]　哈哈，确实很像呢。跟我姐姐。[r][wait time="500"]
不过最小的妹妹长得最普通呢[p]
#ituki:normal
……你认识我姐姐吗？[p]
#mokke
何止认识，我和宗方可是同班同学。[r]
高中时候的事儿了。[p]
不过她是从内部升学上来的，[r]
虽然也没多熟就是了……[p]
[resetdelay]
话说，你们三姐妹都是从初中部升到小谷坂的？[r]
哎～呀，宗方同学家果然超厉害呢～[p]
#ituki
…………………………[l][r]
#ituki:hate
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[font size="20"]
……走吧，纱罗纱[p]
[resetfont]
#sarasa
诶……[p]
#ituki
[font size="20"]
………………我最讨厌这家伙了[p]
[resetfont]
[mask time="300"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
;-------------------------------------------------------------------------------
[bg storage="school/entrance_n.jpg" time="10"]
[chara_hide_all time="10"]
;-------------------------------------------------------------------------------

[mask_off time="3000"]
#ituki
……哈～。[p]
[chara_show name="sarasa" left=360 top=-160 wait="false" face="normal"]
#ituki
[chara_show name="ituki" left=-70 top=-160 face="sad" wait="false"]
[delay speed="60"]
从亲戚熟人那里听来的家事闲话[r]
还真是无聊透顶呢～[p]
#ituki:smile
那个，[r][wait time="500"]
[resetdelay]
#ituki:smileW
啊哈哈，抱歉抱歉！不小心让你听了奇怪的牢骚呢！[p]
#ituki:sad
[delay speed="50"]
唉～。[r]
明明在纱罗纱面前应该尽量保持开朗的[p]
#
她一边这么说着，[r]
一边在鞋柜之间转来转去。[p]
#ituki:tweet
……二班三班……连四班的人，也都不在了呢～。[r][wait time="500"]
今天不是社团活动日　大家好像都早早回去了呢[p]
#
正如树月所说，校园里早已人去楼空。[l][r]
手表上的短针正指向数字5。[r]
在学校待到这么晚，或许还是第一次。[p]
#
#ituki:normal
……[l][r]
呵呵……[p]
#sarasa
……怎么了？[p]
#ituki:smile
总觉得～没人的学校啊～[r]
不就很像恐怖片里的感觉吗？[p]
#ituki:smileCE
一般来说这种场景下～。[r]
很快就会变得没法从教学楼出去～[p]
得边被鬼追边找逃生方法才行[r]
最后会变成这样对吧～[p]
@layopt layer=message0 visible=false
[clearfix]
#
[keyframe name=up]

[frame p=25% y=50 ]
[endkeyframe]
[playse  volume="80" buf="0" storage="kaminari.ogg" ]
[stopbgm]
[bg storage="school/entrance_b.jpeg" time="10"]

[chara_mod name="sarasa" face="wow" time="10"]
[chara_mod name="ituki" face="tweet" time="10"]
[kanim name=sarasa keyframe=up time=300 wait="false"]
[kanim name=ituki keyframe=up time=300]
[wait time="300"]
[bg storage="school/entrance_n.jpg" time="10"]
[wait time="500"]


[stop_kanim name=sarasa]
[stop_kanim name=ituki]
[bg storage="school/entrance_b.jpeg" time="100"]
[wse]
[playbgm storage=rain.ogg loop=true volume=70 sprite_time="2000-61000"]
[wait time="1000"]
#ituki
[delay speed="60"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

……………[p]
#sarasa
……………[p]
#ituki:sad
[font size="20"]
……这种老套的桥段～。[r]
没必要连停电都搞出来吧……[p]
[resetfont]
#
[resetdelay]
树月的低语，被以落雷为开端的愈发猛烈的雨声[r]
彻底淹没。[p]
[chara_mod name="sarasa" face="worry"]
#
我被难以名状的不安驱使着，[r]
试图打开通话应用。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
──但是，应用又一次，无法启动。[p]
#ituki:tweet
……咦～？果然还是不能通话呢？[p]
#sarasa
[delay speed="60"]
…………………………[l][r]
#sarasa:closeEye
嗯、嗯……[p]
#ituki:tweet
[delay speed="50"]
手机坏掉了吗～？[l][r]
#ituki:smile
要不试试充电看看？[r]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
好！[p]
#
[font color="0xb0c4de"]
[playse  volume="20" buf="0" storage="sariin.ogg"]
[image layer=0 folder="image" name="moba" storage="item/moba.png" width="460" x="270" y="107" time="800"]
获得了〇移动电源。[tip key="moba"][endtip]
[wse][p]
[resetfont]
#sarasa:normal
…………真的可以吗？[p]
#ituki:smileCE
当然！[r][wait time="500"]
只要是能帮上纱罗纱的忙，[r]
我什么都愿意做！[p]
#sarasa:smile
…………谢谢……[p]
[free layer=0 name="moba" time="800"]
#
在她的催促下，[r]
我将自己的手机和借来的移动电源连接起来。[p]
[delay speed="50"]
#ituki:normal
………………………………[l]
#ituki:smileW
啊哈哈！[p]
#sarasa:normal
…………………………？[p]
[fadeoutbgm time="300"]
[resetdelay]
#ituki:normal
就算充电了信号和应用也恢复不了的啦[r][wait time="500"]
才没关系呢[p]
#sarasa:wow
诶……[p]
#ituki:smile
纱罗纱真是对手机电脑之类的一窍不通呢[r][wait time="500"]
什么都不懂[wait time="500"]　也完全不想去懂[p]
[playbgm storage=rain.ogg loop=true volume=70 sprite_time="2000-61000"]
#
树月愉快地继续说着。[p]
#ituki:smile
[delay speed="50"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
呐～纱罗纱家啊。[r][wait time="500"]
比我家离学校更近的地方对吧？[p]
#sarasa:normal
…………………………嗯[p]
#ituki:normal
………………………………[p]
#sarasa
………………怎么了？[p]
#ituki:smileCE
[chara_move name="ituki" anim="true" left=-20 top=-160 time="400" wait="false"]
……一起回家吧？[p]
#ituki:shame
[delay speed="60"]
我呢～……[r]
一直想试试和纱罗纱一起放学回家呢～[r]
因为你总是一个人回去嘛～[p]
#sarasa
……………………[p]
#ituki:tweet
…………[wait time="300"]不行吗？[p]
#sarasa
……………………[l][r]
#sarasa:smile
嗯……知道了[p]
#ituki:smileCE
[playse  volume="30" buf="0" storage="kansei.ogg"]
[resetdelay]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[font size="40"]
真的吗！？太好啦～！[r][resetfont]
虽然伞有点碍事，但我们可以尽情聊天啦～！[p]
[wse]
#
树月蹦蹦跳跳地[r]
把室内鞋塞进鞋柜后，从伞架取出了桃红色的伞。[p]

——那抹桃红色，[r]
这抹桃红色从过去就与树月十分相配。[p]
[mask]

;全キャラクター非表示
[chara_hide_all time="500"]
;シナリオ移動
[showsave]
@jump storage="prologue/day1_2.ks"



;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------
[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
