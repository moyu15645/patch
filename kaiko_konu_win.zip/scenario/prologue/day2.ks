;序章　「桑畑で誰かが誰かを捕まえたら」
;二日目
[eval exp="f.save_title = '序章二日目'"]

;-------------------------------------------------------------------------------
*part3
;-------------------------------------------------------------------------------

[mask folder="bgimage" graphic="still/prologue.png" time="100"]
[cm  ]
[clearfix]
[start_keyconfig]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = '？？'
[endscript]
[fadeinbgm storage=onedari.ogg loop=true time="1000" volume=50 sprite_time="0200-21000"]
[mask_off]
[bg storage="still/den_1.png" time="1000"]
#
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="50"]
很久很久以前 八种的村子　[wait time="300"]「暗御前」[r]
被这样的妖怪　诅咒了[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/den_2.png" time="500"]
因为暗御前会诅咒　[font color="0xf08080"]人心的脆弱之处[resetfont][l][r]
穷人会因饥饿的诅咒　去杀害富人[r][wait time="500"]
丑女因嫉妒的诅咒[wait time="500"]　杀害了美丽的家人[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/den_3.png" time="500"]
目睹这一切的村里年轻男子说道[l][r]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[resetdelay]
「让我来当人柱[r]
镇压暗御前吧！」[p]
于是　男子正欲投身于四ツ山的深潭之中[r]
就在这瞬间！[p]
[delay speed="60"]
[bg storage="still/den_4.png" time="500" cross="false"]
[playse  volume="70" buf="1" storage="sariin.ogg" ]
一位肌肤如雪　美得不似凡尘的[wait time="500"]　神秘女子　现身了[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_5.png" time="500"]
[delay speed="50"]
女子开口说道[l][r]
「我是名为御白姬的养蚕女神」[p]
[bg storage="still/den_6.png" time="100"]
「只要你好好养育　我的这些蚕宝宝们[r]
将其化作美丽的丝绢供奉[l][r]　
我便将这暗御前　封印于那绢布之中吧」[p]

「你说什么？」[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_7.png" time="500"]
「养蚕根本不可能[r]
因为这个村子根本没有蚕要吃的桑叶」[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_8.png" time="500"]
「那就把你的头发给我吧[r][wait time="500"]
我会让村里长出和你头发数量相同的桑树」[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_10.png" time="100"]
男子立即剃光所有头发[wait time="500"]　交给了女子[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_11.png" time="100"]
作为交换[wait time="500"]　他得到了与她肌肤同样雪白的幼虫[r]
多得几乎要从手中掉落[r]
他飞奔着回到了村子[p]
然后…………[p]
[bg storage="still/den_12.png" time="500"]
[playse  volume="30" buf="1" storage="kansei.ogg"]
村子正中央的大河畔 竟矗立着一棵[r]
前所未见的雄伟桑树 而且连绵不绝一眼望不到头！[p]
「太好啦！那个女人真的是女神啊！」[p]

时光飞逝 转眼到了蝉鸣的盛夏……[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_13.png" time="500"]
当男子如约织好丝绸前来供奉时[r]
[font size="40"]
[quake time="30"]
「啊啊啊 御白姬 你给我记住——」[p]
[resetfont]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_14.png" time="500"]
原本洁白美丽的绢布　此刻正吸收着邪恶化怪物的气息[r]
眼看着就　渐渐变成了漆黑颜色[p]
妖魔终被封印[wait time="500"]　村民们都　获救了[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[bg storage="still/den_15.png" time="500"]
八种的人们　对御白姬感激涕零[r]
为报恩情　开始大力发展养蚕业[r]
城镇因此　愈发繁荣昌盛了[p]
[delay speed="70"]
这便是　御白姬传说的全部[r][wait time="500"]
八种之地　万物起源的开端！[l][r]
[font size="20"]
【よくわかる八種町民話　オシラヒメ伝説】　制作：[wait time="300"]志户田纤维[p]
[resetfont]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="0"]
[mask time="100"]
[stopbgm]
[wse]
[bg storage="/indoor/sitodrouka.jpg" time="100"]
[fadeoutbgm time="2000"]
[wait time="2000"]
#

[mask_off time="2000"]

#
――8月5日。晴[p]
[resetdelay]
#mokke
纱罗纱～换好衣服了吗？[p]
真认真啊。暑假期间的规矩什么的，[r]
根本形同虚设嘛[p]
不愧是志户田家的大小姐呢！那咱们出发吧[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="50" buf="0" storage="hikidopen2.ogg" ]
[bg storage="shitodaEnt_m.jpeg" wait="true" cross="false"]
[wse]
;〇志戸田家　玄関（昼）
;蝉　（外の基本ＢＧＭ）
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
[wait time="1000"]
;ＳE	引き戸
#
[delay speed="50"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
从敞开的门口涌入的，[r][wait time="500"]
是令人连呼吸都嫌烦的暑热，与阵阵蝉鸣……[p]
[chara_show name="makado" top="-40" face="normal_c" wait="true"]
然后，[wait time="500"]在屋檐下笔直站立的贤治郎先生的身影。[p]
[resetdelay]
说实话，这一切几乎让人窒息。[p]
#makado
……[l]
#makado:lookAway_c
早上好[p]
#mokke
那就拜托贤治郎照顾好大小姐啦！[p]
#makado:normal_c
好的，我会确保傍晚前能回来[p]
#
;SE　引き戸
[playse  volume="50" buf="0" storage="hikidopen2.ogg" ]
[chara_move name="makado" left="-90" anim="true" wait="false"]
[chara_show name="sarasa" left="360" top="-100" time="500" face="closeEye_k" wait="true"]
[wse]
#makado:normal_c
……纱罗纱，昨晚睡得好吗？[p]
[delay speed="60"]
[chara_mod name="sarasa" face="normal_k"]
#
[link target="*yes"]【１】回答[endlink][r]
[link target="*no" exp="f.white+=1"]【２】不回答[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#sarasa:closeEye_k
……嗯，还算可以……[p]
#makado:lookAway_c
……这样啊[p]
#sarasa
……[p]
@jump target="*sando"
;-------------------------------------------------------------------------------
*no
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;白の繭
#
我、没有回应那句话，[r]
而是静静地观察着他。[p]
#sarasa:normal_k
……………………[p]
#makado:normal_c
……………………[p]
#sarasa
……………………[p]
#makado:lookAway_c
………………………………[p]
@jump target="*sando"
;-------------------------------------------------------------------------------
*sando
;-------------------------------------------------------------------------------
#makado:tweet_c
[delay speed="50"]
今天本打算只是把昨天没能说明的事情[r]
向你转达一下就好……[p]
#makado:normal_c
但果然还是想让你亲眼看看实物。[r][wait time="500"]
[resetdelay]
虽然要稍微绕点远路，[r]
要不要一起从四ツ山的山路去我家的神社？[p]
#
[mask]
[bg storage="mountainRoad_m.jpeg" time="10"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
;〇山道　（昼）
[chara_hide_all time="10"]
[wait time="1000"]
[mask_off time="2000"]
;ＳE	歩く
;立ち絵消す

#makado
……你不觉得语言是很不可思议的东西吗？[p]
[delay speed="50"]
若是无知便永远无法理解其中含义，[r]
可一旦掌握了上下文就再难逃脱──[p]
小黑和目目连也是如此。[r][wait time="500"]
它们自古以来就是这样的存在啊[p]
#sarasa
……………………。[l][r]
[delay speed="60"]
您是说……只对知情者才有意义吗？[wait time="500"]

#makado
没错[p]

只有当人们理解[r][font color="0xf08080"]
『小黑目连』[resetfont]这个名词是指[r]
『诅咒人类的恶灵』时，[wait time="500"]它们才会附身并……盯上你[p]
[resetdelay]
所以封印被解开这件事[r]
在这个镇上是不能公开谈论的。[p]
保守秘密顶多只能算自我安慰式的防护手段……[r]
但总比什么都不做要强吧[p]
[delay speed="60"]
#sarasa
（……所以昨天晚上也是，[r]
一到家就把我和妈妈强行分开了）[p]
#
贤治郎先生看起来完全不像是开玩笑的样子。[p]
他绝对是认真按照御白姬的传说[r]
他是打算要除掉御白姬”吧。[p]
这种态度反而[wait time="500"]更激起了对他的不信任感。[p]
#makado
……[l][r]
……你变得相当沉默了呢[p]
#sarasa
…………………………[l]啊？[p]
#makado
我爸爸…………[wait time="500"]　不，[p]
[resetdelay]
以前你经常来我家玩的时候，纱罗纱……[r][wait time="500"]
我记得明明是个更爱说话的孩子啊[p]
#sarasa
[delay speed="50"]
……………………[l][r]
……以前的事，我已经不太记得了……[p]
[resetdelay]
#makado
不，也是啊。[l][r]
很正常，毕竟还是小学生时候的事[p]
[delay speed="50"]
自己都遗忘的往事，[wait time="500"]你肯定没兴趣听吧[p]
@layopt layer=message0 visible=false
[clearfix]
#
[mask]
[bg storage="hall_m.jpg" time="10"]
[wait time="2000"]
;〇お堂（昼）
[mask_off time="3000"]
[wait time="2000"]
#makado
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……就是这里[p]
[chara_show name="makado" left="-90" top="-40" face="tweet_c" wait="false"]
[chara_show name="sarasa" left="360" top="-100" face="normal_k" wait="false"]
#makado:tweet_c
其实我现在偶尔也会迷路——[r]
今天能这么快找到真是太好了[p]
#sarasa:worry_k
那个、这里到底是……[p]
#makado:normal_c
啊。现在打开[p]

;SE 扉開ける
[mask]
[playse  volume="50" buf="0" storage="hikidopen2.ogg" ]
[wse]
[chara_hide_all time="10"]
[bg storage="brack.png" time="100"]
;蝉の声を下げる
[fadeoutbgm time="800"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=800 volume=20]

[mask_off]
#
在敞开的空气中弥漫着，古旧木材与尘埃的气味……[l][r]
[fadeoutbgm time="4000"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
还隐约残留着物体燃烧后的痕迹。[p]
[delay speed="60"]
从窗户斜射进来的光线中央，摆放着一个木制台座，[r]
上面端坐着一个被熏得乌黑的[font color="0xf08080"]物体[resetfont]。[p]

#sarasa
……这是[p]
#makado
没错。[wait time="500"]被烧毁的，上次的――[l][r]
这是你母亲担任御白姬那年供奉的[wait time="500"]绢布。[p]
#makado
就在[font color="0xf08080"]两天前[resetfont]、我来这里打扫的时候[r]
已经……[p]

原本上锁的挂锁被破坏，[r]
连绢布也被烧毁了[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
这里是白绢祭之年[r][font color="0xf08080"]
只有祭主和担任御白姬的人[resetfont]才能进入的祠堂，[r]
知道地点的也只有祭主和担任御白姬的姑娘[p]

正因如此才毫无头绪。[r]
究竟是谁专程来到这么隐蔽的地方，[r]
特意只烧毁绢布就离开…………[p]
[delay speed="50"]
……[l]不过至少可以确定的是，[r]
那家伙肯定知道御白姬传说吧[p]
[mask]
;SE 鍵を閉める
[bg storage="hall_m.jpg" time="10"]
[chara_show name="sarasa" left="360" top="-100" face="normal_k" wait="false" time="10"]
#makado
[chara_show name="makado" left="-90" top="-40" face="tweet_c" wait="false" time="10"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg" ]
[wse]
[mask_off]
……好了，大热天带你四处奔波真不好意思。[r]
先回我家吧，不休息会中暑的[p]

[mask]
[bg storage="porch_m.jpeg" time="10"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=8000 volume=50]
;〇馬門神社縁側（昼）
[chara_mod name="makado" face="normal"]
[chara_mod name="sarasa" face="normal"]
[wait time="1000"]

[mask_off]


#makado:tweet
……抱歉。虽然找了果汁之类的，[r]
只有麦茶是冰镇的……[p]
#
贤治郎先生递给我的那个杯子，[r]
在这朴素的寺院里显得格格不入 外观异常华丽。[p]
[image layer=0 folder="image" name="mugicha" storage="item/mugicha.png" width="460" x="270" y="107" time="800" ]
#sarasa:closeEye
不……非常感谢您的关心[p]
#sarasa:normal
…………[p]
#sarasa:closeEye
[free layer=0 name="mugicha" time="800"]
……………………[p]
#makado:normal
……[p]
#makado:lookAway
……………………[p]
#sarasa:normal
……………………[p]
#makado:tweet
真是精致的餐具呢[p]
#sarasa:normal
…………咦？[p]
#makado:normal
就是、纱罗纱你现在用的那个玻璃杯[p]
#sarasa:normal
…………[p]
#
[link target="*kirei"]【１】回答说：“好漂亮的餐具啊。”[endlink][r]
[link target="*nohenji" ]【２】不回答[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*kirei
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#sarasa:normal
……是的。[r]
很有夏天的感觉，……[p]
#makado:smileMini
嗯。确实呢[p]
#sarasa
…………………………[l][r][wait time="500"]
#sarasa:closeEye
你喜欢向日葵吗？[p]
#makado:worry
诶？[p]
#makado:wowCM
[delay speed="100"]
…………………………[resetdelay]
#makado:wow
啊、啊啊不是。[r]
倒也不是这个意思……[p]
#makado:smileMini
[delay speed="50"]
该怎么说呢，正因为是平时不用的东西，[r]
偶尔拿出来用反而能沉浸于回忆中呢[p]
#sarasa:normal
回忆？[p]
#makado:smileMini
对。[r]
这还是它们出现在餐桌上时候的事了……[p]
#makado:tweet
比如妈妈给我榨果汁什么的，[r][wait time="300"]
本来是配对玻璃杯的，但有一只被爸爸打碎了呢[p]
#makado:lookAway
[delay speed="60"]
——向日葵在这个小镇上随处可见，[r]
所以算不上喜欢[p]
#makado:tweetLA
能用上好餐具这件事啊，[r]
真是优渥的生活啊……[p]
……………………[p]
@jump target="*sorry"
;-------------------------------------------------------------------------------
*nohenji
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="*sorry"
;-------------------------------------------------------------------------------
*sorry
;-------------------------------------------------------------------------------
[cm]

#makado:closeEye
[resetdelay]
……不，抱歉。[r]
从你的立场来看，这种悠闲的话题会显得不合时宜吧。[p]
#makado:normal
关于今后如何处理阿黑封印的事，[r]
我还没告诉你呢[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="50" buf="0" storage="sariin.ogg" ]
[image layer=0 folder="image" name="kenpu" storage="item/kenpu.png" width="460" x="250" y="107" time="800" ]
[wse]
[wait time="1000"]
#sarasa:wow
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
这是……？[p]
#makado:tweet
今年白绢祭上你要供奉的绢布。[r]
也就是说，[font color="0xf08080"]"由御白姬来封印污秽之物"[resetfont]啊[p]
#
[delay speed="60"]
确实，传说中……[r][wait time="500"]
「御白姬通过将污秽之物吸收进绢布[r]
从而将其封印」是这么记载的……[p]
#sarasa:worry
[font size="20"]
难、难不成要我……[r][wait time="500"]
去封印污秽之物……[wait time="500"]你是这个意思吗？[p]
[resetfont]
#makado:normal
[resetdelay]
老实说[r]
该委派你什么职责，连我也难以定夺。[p]
[delay speed="50"]
#makado:closeEye
但是……[font color="0xf08080"][playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
恶灵黑气正在袭击担任御白姬的姑娘[resetfont][r]
这是目前唯一能确认的事实。[p]
#makado:normal
正因如此，我们也只能按照传说来制定对策。[p]
#makado:tweet
所以，[r]
暂且作为护身符……[wait time="500"]这个就交给你了[p]
#sarasa
…………[l][r]
#sarasa:lookAway
…………………[p]
#
[free layer=0 name="kenpu" time="800"]
[playse  volume="20" buf="0" storage="sariin.ogg"]
[font color="0xb0c4de"]
获得了〇绢布	。[tip key="kenpu"][endtip]
[wse][p]
[resetfont]
;封印の絹布　を手に入れた[p]
[chara_hide name="sarasa" wait="false"]
我将收到的绢布收进了口袋。[p]
#makado:tweetLA
……没能给出具体对策实在抱歉。[p]
[fadeoutbgm  time="3000"]
#makado:lookAway
至少若能锁定可能被「御黑御劫」诅咒的人选，[r]
本还能设法应对……[p]
[chara_hide_all time="10"]
[chara_show name="kirie"  top="-40" pos_mode="false" time="10" face="normal" wait="false"]
#kirie:smile
被御黑御劫诅咒的人？[p]
#kirie:normal
为什么？不是说那东西被封印了吗？[p]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
――！[p]
[chara_show name="makado" top="-40" left="-90" face="wowCM" wait="false"]
[chara_move name="kirie" left="360" time="300"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
――！[p]
[resetdelay]
#makado:tweet
……您好。是来参拜的客人吗？[p]
#kirie:smile
……啊哈！？神社里怎么会有BOSE君啊！？[p]
#makado
啊、不是――[r]
现在是因祭祀仪轨需要才剃发的，[r]
我也算是神职家族出身……[p]
#kirie:wow
………………………………[l][r]
#kirie:smile
[delay speed="70"]
呜哇、有点恶心[p]
#makado:worry
咦？[p]
#kirie:lookAway
「我」什么的。[r][wait time="300"]
[delay speed="50"]
再怎么说对我也太见外了吧？[wait time="500"]　马门君[p]
#makado:worry
…………[p]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = 'きりえ'
[endscript]
#kirie:normal
是我啊，雾绘[p]
#kirie:lookAway
[resetdelay]
你居然没认出来。[r]
我可是你剃成光头都能一眼认出来的[p]
#makado:wowB
……呐[p]
#kirie:smile
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[font size="45"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=1000 volume=50]
真是的！[r]
差劲！　差劲！[p]
[resetfont]
#
[playse  volume="100" buf="0" storage="book.ogg" ]
自称雾绘的女子说完这句话，[r]
用力敲了下贤治郎先生的脑袋。[p]
#sarasa
（……朋友？）[p]
#makado:wow
[delay speed="70"]
……雾绘？　真的是雾绘吗？[r]
难道你回来了！？[p]
#kirie:smile
[resetdelay]
回来有什么不行啊～！？[wait time="500"]　八种町可是咱们老家吧！[p]
#makado:worryB
[delay speed="70"]
…………………………………………[p]
#kirie
[playse  volume="100" buf="0" storage="book.ogg" ]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[resetdelay]
喂喂、够了够了！别吵啦！秃子！[p]
#makado
[delay speed="70"]
……………………[l][r]
#makado:sad
……所以说我不是秃子啊……[p]
#kirie:smile
[resetdelay]
可秃子就是秃子嘛。[r]
秃子对秃子闹叛逆，一点都不时髦。好好画你的画。[p]
#kirie:lookAway
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
所以呢～？刚才在说什么。[r]
什么母亲显灵的诅咒啊～之类的[p]
#makado:angry
……你到底是从哪儿听来的？[p]
#kirie:smile
啊哈哈！你慌什么呀？[p]
#kirie:normal
我只是觉得，有些人就喜欢借着传说之类的名头搞恶作剧[r]
这种无聊的家伙[r]
世界上总会有那么几个啦～[p]
#kirie:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
哈哈哈，很有信长公的风范吧？[p]
#makado
[delay speed="70"]
……………………………[l][r]
#makado:closeEye
…………………………………………[p]
#kirie:wow
……然后！[r]
#kirie:sad
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[resetdelay]
这孩子怎么回事！皮肤好白！[r]
该不会是深闺大小姐类型吧？[p]
#makado:tweetLA
[delay speed="70"]
……是志户田家的千金，纱罗纱。[r]
如假包换的大小姐哦[p]
[mask]
[stopbgm]
[chara_hide_all time="10"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
[bg storage="still/kirie_smile.png" time="10"]
[wait time="700"]
#
;〇スチル
[mask_off]
#kirie
嘿～～～……[p]
;〇スチル（笑顔に切り替え）
[bg storage="still/kirie_smile2.png" time="10"]
感觉，好可爱。[r]
我超憧憬这种类型的脸蛋呢[p]
;〇スチル（閉じる目）
[bg storage="still/kirie_smile3.png" time="10"]
大家好呀～我叫雾绘。[r]
现在是活力满满的美少女哦～[r]
不过在外面遇到我可别搭讪哟♡[p]
#makado
喂，雾绘。[l][r]
……抱歉，她就是这样的人。从小时候就……[p]
#kirie
这样的人是什么样的人？[p]
[mask]
[bg storage="porch_m.jpeg" time="10"]
[chara_show name="kirie" left="360" top="-40" time="300" face="normal"]
[chara_show name="makado" left="-90" top="-40" time="300" face="lookAway"]
[mask_off]
#kirie:smile
[resetdelay]
话说马门君居然带着这么小的女孩子到处转悠[r]
这算诱拐犯罪吧！？要完！[p]
#
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
雾绘这么说着，[r]
一边踢着贤治郎的膝盖下方一边闹腾起来。[p]
#makado:sad
[playse  volume="140" buf="0" storage="book.ogg"]
痛……、等、[wait time="500"]别这样[p]
#kirie
[playse  volume="140" buf="0" storage="book.ogg"]
啊哈哈！这叫天罚哦天罚～！[p]
#makado:angry
等、等等。[wait time="500"]雾绘，你――[p]
#kirie:sad
啊哈哈哈！超有意思！[r]
果然这个镇上全是些危险的家伙呢！[p]
#kirie:smile
[delay speed="50"]
马门君也是这样的话――，[r]
已经没一个正常人了！[p]
#makado:worry
…………………………[p]
[fadeoutbgm  time="3000"]
#makado:angry
…………雾绘。[r]
如果有什么事就告诉我吧[p]
#kirie:smile
…………………………[p]
#kirie:normal
哈？[p]
#makado:closeEye
我不会强迫你说的。[l][r]
#makado:angry
但是，你已经[r]
我不该回到这个地方来的吧[p]
#makado:worryB
[delay speed="60"]
到底是发生了什么事，[wait time="300"]让你非要回来不可？[r]
竟然会沦落到要回老家这种地步……[p]
#kirie:normal
……[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
#kirie:sad
…………[p]
啥？你算老几？[p]
#makado
算老几……不是这个问题吧。这是[p]
#kirie:wow
哈————…………[p]
#kirie:smile
那我问你，要是我说了你有把握能搞定吗？[r]
马门神社的贤治郎[p]
#makado:wowCM
……！[p]
#kirie:sad
……[p]
#kirie:smile
啊哈哈……突然觉得好扫兴！[p]
#kirie:wow
明明什么都做不到，还总想硬来的莽撞劲儿。[r]
还是老样子呢，马门君[p]
#makado:angry
………………………………[l][r]
#makado:closeEye
——雾绘[p]
#kirie:smile
再见啦[p]
;砂利を歩く
[chara_hide name="kirie" time="300" pos_mode="false" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[chara_show name="sarasa" left="390" top="-100" time="500" face="normal" wait="false"]
#makado:tweetLA
………………………………[r][wait time="500"]
#makado:sad
抱歉。让你看着不舒服了吧[p]
#makado:tweet
[delay speed="50"]
雾绘大约两年前离开了八种。[l][r]
#makado:lookAway
所以　你可能不认识她——[r][wait time="500"]
但说不定会对她的样貌有点印象[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
样貌…………？[l][r]
…………………………………………[p]
#sarasa:wow
啊……[p]
#sarasa:normal
[delay speed="60"]
难道说，[wait time="500"]她的姓氏是宗方吗？[p]
#makado:lookAway
嗯，没错。[l][r]
#makado:tweetLA
宗方雾绘……[wait time="500"]是宗方家三姐妹的长女[p]
#
原来如此，对她的既视感原来是这么回事。[r]
宗方雾绘就是，[wait time="500"]宗方树和宗方优的姐姐――[p]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = '宗方 きりえ'
[endscript]
#makado:lookAway
…………………………………………[p]
#makado:sad
[resetdelay]
……今天我会送你回家哦，纱罗纱[p]
#
[mask]
[cm]
[chara_hide_all time="10"]
[bg storage="brack.png" time="10"]
[fadeoutbgm time="3000"]
[wait time="3000"]
[clearfix]
@layopt layer="message0" visible="true"
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[mask_off time="3000"]
[delay speed="60"]
;暗転fi

;SEひぐらし
#
「呐。」[l][r]
[r]
「我最开始感到开心的事[r]
可以告诉你吗？」[l][r]
[r]
什么？[l][r]
[playbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400"]
[r]
「是你说我的书包很可爱这件事」[l][r]
[r]
[r]
因为和其他孩子不一样，很特别嘛。[p]
「特别啊—」[l][r]
[r]
嗯。很特别。[l][r]
[r]
[r]
[r]
特别的回忆。[r][wait time="600"]
你书包背面的颜色。[l][r]
[r]
「因为是姐姐传下来的旧物嘛。[r]
所以很特别哦。」[p]
[mask time="4000"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[fadeoutbgm time="4000"]
[wait time="4000"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]
[wait time="1000"]
[bg storage="indoor/sarasaRoom_n.jpeg" time="10"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '？？'
[endscript]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]
[wait time="1000"]
;makado表情追加\?
;〇志戸田家　自室
[mask_off time="2000"]

;SE夜の夏

#sarasa
（……刚才好像做了个梦。）[p]

;SEコンコン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]

#
………[p]

;SEコンコン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="500"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]

#
……是什么呢？[r]
从窗户那边传来声响。[p]

确认了下时钟，[r]
现在大约是凌晨一点半……[p]

是野鸟吗？[p]
还是说，外面在下雨呢。[p]

;SEコンコン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="800"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="800"]

#
这些细微的外部因素，[wait time="500"]正妨碍着睡眠。[p]

为了明天能像往常一样按时起床，[r]
必须尽快处理这个声音的来源。[p]

;SEコンコン
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wait time="800"]
[playse storage="kon.ogg" sprite_time="0000-0300" volume="20"]
[wse]

#
………………………………[p]
我，[r][wait time="500"]
为了确认窗户的情况，从床上爬了起来。[p]

;SEフローリング歩く
[mask]
;スチル　カーテンの向こうに人影
[bg storage="still/curtain_s.png" time="10"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[mask_off time="2000"]

#
………………………………………[l][r]
不对。[p]

这不是。既不是鸟，也不是雨。[r]
在这扇窗户外的是──[p]
[delay speed="100"]
人类。[p]
#sarasa
[quake time="30"]
──噫[p]
[resetdelay]
#
骗人的……这也太奇怪了。[p]

窗外，[wait time="500"]站着一个人。[r][wait time="500"]
光是确认这点，就足够可怕了。[p]

──这个，我的房间，[wait time="500"]可是在二楼啊。[p]
[playbgm storage=fuon.ogg loop=true time=1000 volume="30"]
;SE 窓をどんどん叩く
[playse storage="kon.ogg" loop="true" sprite_time="0010-0500" volume="40"]
#mokke
[quake time="30"]
[font size="50"]
喂————[r]
开窗啊————[p]
御白姬————[r]
救命啊————[p]
[resetfont]
#
带着独特颤抖声线的、单调女声，[r]
从窗外传来。[p]
[delay speed="60"]
而且还喊着御白姬……[r]
会这样称呼我的人，[p]

窗外的难道是，[wait time="500"]………………[p]
#mokke
[quake time="30"]
[font size="50"]
呐————[r]
好想见你啊————[p]
呐————[p]
[playse  volume="30" buf="1" storage="kaminari.ogg"]
[quake time="30"]
[font size="38"]
明明好想见你的！[r]
明明好想见你的！明明好想见你的！[l][r]
明明好想见你的！！！！[p]
[resetfont]
;暗転
[mask time="10"]
[bg storage="indoor/sarasaRoom_n.jpeg" time="10"]
#
[resetdelay]
[mask_off time="10"]

#
……刚从梦境中苏醒的大脑，[r]
令人不适地高速运转着。[p]

到底、我该、如何是好──[p]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
啊……！[l][r]
[delay speed="50"]
对了，这间房间的尽头就是母亲的卧室。[p]

而且，今晚阿基拉也[r]
应该住在一楼。[p]

虽然深夜打扰不太合适，[r]
但眼下绝对是紧急事态。[p]
[delay speed="60"]
把他们叫来想办法吧。[l][r]
用颤抖的手，[wait time="500"]缓缓搭上房门把手──[p]

;SE止む
[stopbgm]
[stopse]
#mokke
………[wait time="500"][r]
想找人帮忙？[p]
[delay speed="100"]
你以为这样做可以吗？[wait time="500"][r]
我们家[wait time="500"]可从来没人帮过忙[p]
要是敢把、[wait time="500"]人叫来这里。[l][r]
我就连那家伙一起、[wait time="500"]宰了哦[p]
#
@layopt layer=message0 visible=false
[clearfix]
; ３秒
[wait time="2000"]

;　SE電話
[playse storage="phone.ogg" loop="true" volume="60"]
[wait time="500"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[quake time="30"]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
──！[p]
[mask]
;紗羅紗自室（立ち絵なしで）
[wait time="300"]
[mask_off]
确认发信来源。[p]
[delay speed="50"]
#sarasa
（啊……[l][r]
[playse  volume="20" buf="1" storage="sariin.ogg" ]
是贤治郎先生打来的！）[p]
（……窗外的那个人，肯定……[r]
电话那头是谁，应该还猜不到……！）[p]
#
我，[r]
怀着祈祷般的心情，将手机贴在耳边。[p]
[stopse]
;SE 電話に出る
[font color="0xb0c4de"][font size="25"]
#makado
……喂。[wait time="500"]纱罗纱？[p]
[delay speed="60"]
这么晚打扰真抱歉。[r]
实在是有急事要联系你[p]

其实……、[l]那个，等等、[wait time="500"]纱罗纱？能听到吗？[r]
信号不好吗。[wait time="500"]喂——[p]

………………………………………[p]
难道说，[r][wait time="500"]
那边已经发生了什么吗？[p]
[resetfont]
;はい
#

[link target="*hai" ]【１】是的[endlink][r]

[call target="*Sub_hover"]
[s]
;-------------------------------------------------------------------------------
*hai
;-------------------------------------------------------------------------------
[cm]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="50"]
#sarasa
……请救救我[p]
[font color="0xb0c4de"][font size="25"]
#makado
──明白了。我马上过去。　这个时间能联系上真是太好了。[p]
[resetdelay]
你现在是在家里对吧？[p]
[resetfont]
#
电话那头，贤治郎先生似乎已经跑动起来了。[r]
为了向他说明情况，我强行压下了恐惧感。[p]
#sarasa
[delay speed="60"]
二楼房间的……[wait time="500"]窗户，外面。[l][r]
有个称呼我为御白姬的人。[r][wait time="500"]
说要杀、[wait time="500"]了我……[p]
#makado
[resetdelay]
[font color="0xb0c4de"][font size="25"]
二楼窗外有人……？不是动物对吧？[p]
[resetfont]
#sarasa
是的……[l][r]
因为、[wait time="500"]那个影子、[wait time="500"]是人的形状……[p]
#makado
[font color="0xb0c4de"][font size="25"]
这样啊。明白了。[r]
大概再过两分钟就能到。我会尽快赶来的[p]
[resetfont]
#sarasa
……两、[wait time="500"]两分钟……骗人、[l][r]
[delay speed="50"]
因为、[wait time="500"]从神社到我家至少需要十分钟以上……[p]
#makado
[font color="0xb0c4de"][font size="25"]
不，其实我已经出门了。[r]
为了某个目的被召集过来的[p]
[fadeoutbgm  time="1000"]
雾绘、[wait time="500"]好像失踪了。[wait time="500"][r]
所以，我们附近的人正在一起搜寻………………[p]
[resetfont]
#sarasa
[delay speed="100"]
……………………………[p]
#
一瞬间。[l][r]
我、[wait time="500"]屏住呼吸……抬头望向窗户。[p]
[delay speed="60"]
#
没错。[r]
总觉得这个人的声音似曾相识。[p]
稍有些特别，[wait time="500"]听起来很开朗的，[r]
女性的声音──[p]
[mask]
[bg storage="still/curtain_s.png" time="10"]
[wait time="300"]
[mask_off]
#sarasa
……[l][r]
[delay speed="100"]
你、[wait time="500"]是雾绘小姐……吗？[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="1000"]
;暗転挟んで切り替え
;スチル　カーテン通常
[bg storage="still/curtain.png" time="10"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
[wait time="300"]
;ＳＥしゅばっ
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
啊……！[p]
#makado
[resetdelay]
[font color="0xb0c4de"][font size="25"]
怎么了！？发生什么事了！？[p]
#sarasa
[resetfont]
窗户对面的人，突然不见了……[p]
#
难道说，跳下去了吗！？[r]
从这种高度摔下去的话，绝对不可能安然无恙——[p]
[quake time="30"]
[bg storage="indoor/sarasaRoom_n.jpeg" time="10"]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="220"]
[mask time="200"]
[wait time="200"]
;ＳＥドア　開ける
;〇志戸田家廊下（夜）
[bg storage="/indoor/sitodarouka_n.jpg" time="10"]
[wait time="300"]
[mask_off time="100"]


;紗羅紗立ち絵なし
;ＳＥ　走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="220"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="220"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="220"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="30"]


[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[mask time="300"]
[wse]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="700"]
;〇志戸田家庭（夜）
[bg storage="shitodaGarden_n.jpg" time="10"]

[fadeinbgm storage=summer-incect.ogg loop=true time=3000 volume="30"]
;ＳＥ　夏の夜の虫の音
[mask_off time="2000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="600"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
#
[camera wait="true" x="0" time="10"]
[camera x="60" y="0" wait="true" zoom="1.10"]
[camera x="-100" y="0" wait="true"]
[reset_camera]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="60"]
………………………………[l][r]
…………………………………………………[p]
我房间的窗下，并没有任何人坠落。[p]

那刚才那个女人，究竟消失到哪里去了呢。[p]
#kirie
纱罗纱。[p]
#sarasa
哎？[p]
[mask time="10"]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[chara_show name="kirie" left="135" top="-60" time="10" face="ghost" wait="false"]
[mask_off time="2000"]
[wait time="3000"]
#kirie
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
像你这样的年纪啊。[p]
#kirie
[chara_mod name="kirie" face="ghost_2" cross="false" time="500"]
虽然不知道是为什么，[r]
但你是不是总觉得唯独自己不会死？[p]
[fadeinse  volume="05" buf="2" storage="walk_rouka.ogg" loop="true" time="3000"]
#sarasa
…………[l][r]
哎…………？[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="kirie" time="10"]
[filter grayscale="100"]
;（スチルフラッシュバック）
[bg storage="still/kami_start.png" time="500" cross="false"]
[bg storage="still/ituki_smile.png" time="500" cross="false"]
[bg storage="still/first_contact.png" time="500" cross="false"]
[bg storage="shitodaGarden_n.jpg" time="500" cross="false" wait="false"]
[free_filter]
[chara_show name="kirie" left="135" top="-60" time="10" face="ghost_2" wait="true"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
眼前这个畸形的女人正缓缓向我靠近。[p]

;ＳＥ砂利を歩く

#kirie
[chara_move name="kirie" anim="true" left=110 top="-20" width="+=50" time=1000]
怎么说呢，就像被什么庞然大物缠住似的。[p]

总觉得有张看不见的帷幕——[r]
又厚实又巨大又坚固，一定会保护我的，所以肯定没问题[p]
[fadeoutbgm  time="3000"]
;ＳＥ砂利を歩く
[chara_move name="kirie" anim="true" left="90" top="-30" width="+=50" time=1000]
#kirie
但其实根本不存在那种东西。[r]
哪里都没有。[p]
;ＳＥ砂利を歩く
#kirie
所有人啊，该死的时候都会死的。[p]

无论多么清白、纯粹、无辜……[p]
[delay speed="100"]
绝对会被守护的生命[r]
根　本　不　存　在　啊[p]
[quake time="30"]
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
[chara_move name="kirie" anim="true" left="70" top="-40" width="+=50" time=1000]
[wse]
#sarasa
[resetdelay]
（——好痛！）[p]
#
她突然用力抓住了我的肩膀……！[p]
#sarasa
[font size="20"]
呜……[wait time="500"]　住[wait time="500"]　住手　[wait time="500"]…………[p]
#kirie
[resetfont]
住　手？[p]
…………………………要是能听我这么说[p]
[quake time="30"]
[font size="50"]
#kirie:smile
就此停手的话[r]
该有多好！！！[p]
[resetfont]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="220"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="220"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[chara_move name="kirie" anim="true" left="360" top="-10" width="-=150" time="1000" wait="false"]
[chara_show name="makado" left="-100" top="-10" time="300" wait="false" face="angrySH"]
#makado:angrySH
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
雾绘！[p]
#sarasa
……！　贤治郎先生！[p]
#makado
在这种地方干什么！[p]
#
贤治郎先生猛地冲过来，[r]
挡在了我和雾绘中间。[p]
#makado:angry
[resetdelay]
你家里人全都急疯了似的在找你[p]
你父母和亲戚，还有妹妹们都在……[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
——！对、一树也……[p]
#makado:worryB
……雾绘，你到底[r]
到底发生什么了？[p]
[delay speed="60"]
难道[wait time="500"]　是被诅咒了吗……！？[p]
#kirie
………………………………[p]
#makado:angrySH
[resetdelay]
[quake time="30"]
雾绘、快回答我！雾绘！[p]
#kirie
………………………………………………[p]
[delay speed="60"]
#
——在我眼前，雾绘依然挂着浅笑[r]
任凭贤治郎先生摇晃着她的身体。[p]
唯独视线，始终不曾从我身上移开————[p]
#sarasa
（…………为什么，[wait time="500"]……会是那副模样，[wait time="500"]…………）[p]
#
……我对雾绘的事其实并不了解。[p]

但是，目睹了迄今为止的种种景象……[wait time="500"][r]
不禁让我心生疑虑。[p]

#sarasa
（雾绘小姐身上，究竟发生了什么————————）[p]
[stopse buf="2"]
@layopt layer=message0 visible=false
[clearfix]
[stopbgm]
;ＳＥシャン
[mask time="10"]
[playse  volume="60" buf="0" storage="sariin.ogg"]
[chara_hide_all time="10"]
[bg storage="still/kaiko_1.png" time="10"]
[mask_off time="10"]
;〇スチル
[wse]
[wait time="300"]
[mask time="10"]
[bg storage="shitodaGarden_n.jpg" time="10"]
[chara_show name="makado" left="-100" top="-10" time="10" wait="false" face="angry"]
[chara_show name="kirie" left="360" top="-10" time="10" face="wow"]
[fadeinbgm storage=summer-incect.ogg loop=true volume="30" time="2000"]
[mask_off time="1000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[quake time="30"]
…………………………………………！？[l][r]
[delay speed="100"]
…………刚才那是——[p]
#
………………………………就在刚才，[wait time="500"][r]
涌入脑海的画面，……………[p]
[stopbgm]
[resetdelay]
#kirie
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
不要！！[p]
#makado:worry
[resetfont]
啊……！？[p]
#kirie:ghost_2
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[font size="50"]
[quake time="30"]
[quake time="30"]
[playbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
不要啊啊啊啊啊啊啊！！[p]
[resetfont]
[chara_hide name="kirie" time="300" pos_mode="false"]
;ＳＥ走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="220"]
#makado:wow
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
雾……雾绘！？[p]
#
[resetdelay]
当我回头时已然发现，[r]
雾绘的身影已不在庭院之中。[p]
[delay speed="60"]
被留下的我们呆立在原地，[r]
陷入无尽的茫然————————[p]
#makado:wow
雾绘……[p]
#makado:angry
…………[p]
#makado:angrySH
[anim name="makado" top="+=30" time="150"]
[anim name="makado" top="-=30" time="150"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
纱罗纱，你先回屋里去！[r]
我去追她……！[p]
#sarasa
诶……[p]
（…………………………）[p]
; ついていく　家に残る
#
[link target=*tuiteiku]【１】跟上[endlink][r]
[link target=*nokoru]【２】留在家里[endlink][r]
[call target="*Sub_hover"]

[s ]

;---------------------------------------------------------
*nokoru
;---------------------------------------------------------
#
;家に残る
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[cm]

#sarasa
明白了……。[r]
我会留在家里[p]

; 〇暗転
[mask]
[cm]
[chara_hide_all time="10"]
[bg storage="brack.png" time="10"]
[stopbgm]
[wait time="3000"]
#
[mask_off]
#
次日清晨……[p]

关于雾绘和贤治郎，[r]
在四ツ山失踪的传闻已传遍八种町。[p]

他们究竟坠入了何处呢？[p]

结局１　　桑田的捕手[p]
[cm  ]
[clearfix]
@jump storage="first.ks"

; END１　　桑畑の捕手


;---------------------------------------------------------
*tuiteiku
;---------------------------------------------------------
; ついていく
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[cm]

#sarasa
[quake time="30"]
……………我、我也要去[p]
#makado:wowCM
……诶？[p]
#
[fadeoutbgm time="3000"]
当这个念头，[wait time="500"]从口中吐露的瞬间。[r]
我竟无法相信这是自己的决定。[p]
#sarasa
[delay speed="60"]
雾绘小姐变成了那样恐怖的怪物模样……[p]
………………一定……[r]
一树她，也一定很担心吧……[p]
#sarasa
[delay speed="100"]
………………[wait time="500"]一树、她…………[p]
[resetdelay]
#makado:worry
……像怪物一样的模样？[p]
#sarasa
…………[p]
果然，[l]贤治郎先生他……[r]
看不见雾绘小姐那副姿态呢[p]
[stopbgm]
#makado:wowCM
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
！[l][r]
纱罗纱……[wait time="500"]难道说[p]
#makado:wow
在你眼里她的模样很异常吗？[p]
#
我朝着贤治郎先生点了点头。[p]
#makado:lookAway
……[p]
#makado:sad
……不，原来如此。[l][r]
#makado:angry
[resetdelay]
那就赶快行动吧。详细情况边追边问。[p]
#
@jump target="*tunnel_night"
;---------------------------------------------------------
*tunnel_night
;---------------------------------------------------------

[mask]
; 〇トンネル夜
[bg storage="ton_n.jpg" time="10"]
[chara_hide_all time="10"]
[fadeinbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
[wait time="700"]
[mask_off time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="220"]
在黑暗中，勉强能追踪到的深度处，[r]
雾绘的背影正逐渐远去。[p]
#makado
能描述下你看到的状况吗？[p]
#sarasa
[delay speed="60"]
……很难、用语言表达清楚……[p]
雾绘小姐已经……[wait time="500"][r]
不再是人类的姿态了[p]
#makado
——这样啊[p]
[playse  volume="20" buf="1" storage="sariin.ogg"]
恐怕，雾绘已经被诅咒了吧[p]
[bg storage="mountainRoad_n.jpeg" cross="false" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[delay speed="50"]
雾绘她……把你称作『御白姬』[r]
「在电话里说过「要杀掉」这种话对吧？[p]
[font color="0xf08080"]
对扮演御白姬的姑娘展露出了『御白姬』应有的敌意。[resetfont][r]
所以雾绘已经是被诅咒之人”了[p]
#makado
——也就是说你拥有[font color="0xf08080"]辨识诅咒的能力[resetfont]啊[p]
[resetdelay]
#
贤治郎先生说出这句话的瞬间……[l][r]
将手中绳索般的东西[wait time="500"]如鞭子般凌空抽响。[p]

; SE叩く音
[quake time="30"]
[mask time="10"]
[playse  volume="70" buf="0" storage="punch.ogg" ]
[wait time="500"]
[mask_off time="10"]
[quake time="10"]

;（立ち絵出す）
[wait time="700"]
[chara_show name="kirie" top="-10" time="10" wait="false"]
#kirie
呜！[p]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="+=800" time="800"]
[chara_hide name="kirie" time="200"]
[playse  volume="50" buf="0" storage="book.ogg"]
[wse]
#sarasa
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
什……什么！？[p]
[chara_show name="makado" top="-10" time="600" wait="false" face="normal_r"]
#makado:normal_r
我家代代相传的……类似拖延时间的东西。[r]
能够镇压被恶灵附身的人类。[p]
#makado:closeEye_r
但这样无法驱除诅咒。[r]
因为我没有那样的本事……[p]
#makado:normal_r
[delay speed="60"]
但是纱罗纱，[wait time="500"]你不一样[p]
#sarasa
……诶……[p]
#makado:normal_r
就像叫不住不知姓名的人那样，[r]
诅咒，只有能看见其形态的人才能驱除[p]
[playse  volume="20" buf="0" storage="sariin.ogg"]
你能够通过观测诅咒的能力，[r]
应该可以直接干涉「御黑妄怪」[p]
[resetdelay]
#makado:closeEye_r
纱罗纱。[r]
作为八种町的居民之一，我恳求你。[p]
#makado:shout_r
[delay speed="60"]
希望你能将御黑妄怪……[wait time="500"]再次封印[p]
[chara_hide name="makado" wait="false"]
#sarasa
………………………………[p]
#
我朝着贤治郎先生的方向，[wait time="500"]轻轻点了点头。[p]
#makado
谢谢。[r]
我也会尽力协助的。[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
…………要破除诅咒，必须揭示其[font color="0xf08080"]根源[resetfont]。[p]
#sarasa
[delay speed="60"]
揭示……[wait time="500"]根源？[p]
#makado:normal_r
关于御黑妄怪如何施加诅咒的，[r]
你还记得相关传说吗？[p]
[cancelskip]
#
御黑妄怪的诅咒方式……[r]
那应该确实在传承中有记载。[p]
;message１レイヤの表示(問題文用)
[layopt layer="message1" name="message_q" visible=true]
[position layer="message1" opacity="200" left="50" top="25" width="850" height="450" margint="15" marginr="15" marginb="10" color="0xfefff5" radius="10" vertical=true]
;使用するレイヤの選択ー＞問題文表示
[current layer="message1"]
;問題文の色を黒にする
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
御黑妄怪会诅咒＿＿[r][r]
[glink color="btn_12_black" target="*but1" text="对遇到的女性下手" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good1" text="人心的脆弱之处" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but1" text="马门神社的祭主" width="20" x="580" y="60" ]
[resetfont]

[s]
;-------------------------------------------------------------------------------
*but1
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[current layer="message0"]
;下のメッセージウィンドウに移動
[position vertical=false]
#makado
不，不对。[p]
御黑妄怪会窥探人心的阴暗面、[wait time="500"]薄弱环节──[l][r]
[font color="0xf08080"]是借由负面情感作为媒介来施加诅咒的[resetfont]恶灵[p]

@jump target="*question2"
;-------------------------------------------------------------------------------
*good1
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
;遷移後変数変化
[eval exp="f.white = f.white+ 1"]
[current layer="message0"]
[position vertical=false]

#makado
没错。[r]
御黑妄怪会窥探人心的阴暗面、[wait time="500"]薄弱环节──[l][r]
[font color="0xf08080"]是借由负面情感作为媒介来施加诅咒的[resetfont]恶灵[p]
;-------------------------------------------------------------------------------
*question2
;-------------------------------------------------------------------------------
[anim name="message_q" opacity=1 time=0]
[anim name="message_q" opacity=0 time=500]
@layopt layer="message1" visible="false"
[delay speed="0"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
正因如此，要消除诅咒必须追溯源头。[r]
御黑妄怪究竟诅咒了那人灵魂的哪个部分……[p]

要从[wait time="500"]回忆中找出它的意图[p]
[chara_hide_all time="10"]
#
宗方雾绘───[p]
[delay speed="50"]
#sarasa
（她……为何会遭受诅咒。[r]
答案就藏在过去之中）[p]
[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]
;message１レイヤの表示(問題文用)
[layopt layer="message1" name="message_q" visible=true]
[position layer="message1" opacity="200" left="50" top="25" width="850" height="450" margint="15" marginr="15" marginb="10" color="0xfefff5" radius="10" vertical=true]
@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------

;使用するレイヤの選択ー＞問題文表示
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
＿＿的＿＿＿从＿＿＿[r]
[glink color="btn_12_black" target="*but2" text="时隔许久重逢的幼时玩伴" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but2" text="自己" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but2" text="没能得到对方的理解" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but2" text="紗羅紗" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but2" text="讨厌" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*good2" text="御黑祟" width="20" x="430" y="60" exp="f.flag1=true"]
[glink color="btn_12_black" target="*but2" text="解放" width="20" x="380" y="60" ]
[glink color="btn_12_black" target="*but2" text="早就知道了" width="20" x="330" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[current layer="message0"]
[position vertical=false]
#sarasa
不，不对！只要仔细查阅传说就能明白……！[p]

[if exp="f.flag2==true"]
@jump target="good3"
[endif]
[if exp="f.flag1==true"]
@jump target="*good2"
[endif]

@jump target="*loop"
;-------------------------------------------------------------------------------
*good2
;-------------------------------------------------------------------------------
;使用するレイヤの選択ー＞問題文表示
[current layer="message1"]
[position vertical=true]

[font color="0x000000" face="serif" shadow="0xffffff"]

#
【选择正确的选项】[r]
御黑妄怪的＿＿＿从＿＿＿[r]
[glink color="btn_12_black" target="*but2" text="时隔许久重逢的幼时玩伴" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but2" text="自己" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but2" text="没能得到对方的理解" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but2" text="紗羅紗" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but2" text="讨厌" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*good3" text="解放" width="20" x="380" y="60" exp="f.flag2=true" clickse="tapSE.ogg" ]
[glink color="btn_12_black" target="*but2" text="早就知道了" width="20" x="330" y="60" ]

[resetfont]

[s]
;-------------------------------------------------------------------------------
*good3
;-------------------------------------------------------------------------------
;使用するレイヤの選択ー＞問題文表示
[current layer="message1"]
[position vertical=true]

[font color="0x000000" face="serif" shadow="0xffffff"]

#
【选择正确的选项】[r]
御黑妄怪的解放从＿＿＿[r]
[glink color="btn_12_black" target="*but2" text="时隔许久重逢的幼时玩伴" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but2" text="自分" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but2" text="没能得到对方的理解" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but2" text="紗羅紗" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but2" text="讨厌" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*good4" text="早就知道了" width="20" x="330" y="60" ]

[resetfont]

[s]
;-------------------------------------------------------------------------------
*good4
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
;問題文用ウィンドウ非表示
@layopt layer="message1" visible=false

[current layer="message0"]
[position vertical=false]
#sarasa
（没错）[p]
[resetdelay]
（雾绘小姐一定是『得知』了封印解除的传闻，[r]
才会被列入御黑妄怪的诅咒对象）[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
她究竟是从何处听说这个消息的？[r]
在马门神社听贤治郎先生讲述的时候？[l][r]
[r]
但是[r]
贤治郎先生究竟向她透露了多少信息　被质问时的她[r]
表现得仿佛一无所知。[l][r]
[r]
简直像在烟雾中周旋……[p]
与我们分别后，她主动前往祭主守护的『秘密场所』[r]
去佛堂查看实物的可能性很低……[l][r]
[r]
[r]
既然如此，难不成……[l][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
其实在那一刻就已经[font color="0xf08080"]"知晓了"[resetfont]？[p]
#
;問題文用ウィンドウをフェードアウトさせる
[cm]

;問題文用ウィンドウ非表示
[layopt layer="message1" visible=false]

; ＳＥ　弾ける
[playse  volume="60" buf="0" storage="sariin.ogg"]
[mask time="100"]
[stopbgm]
[wse]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[bg storage="still/kaiko_1.png" time="10"]
[wait time="1000"]
;回想スチル
[mask_off time="100"]
#
……为什么！[p]
[bg storage="still/kaiko_2.png" time="10"]
[font size="50"]
为　什　么[r][wait time="500"]
为　什　么　见　不　到　你　啊[wait time="600"][er]
@layopt layer=message0 visible=false
[clearfix]
[resetdelay]
[mask time="100"]
[bg storage="mountainRoad_n.jpeg" time="10"]
[wait time="1000"]
[mask_off time="100"]
[quake time="30"]
[wait time="1000"]
#sarasa
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
（……！？）[p]
#
……又来了…………………[wait time="500"]现在、有什么东西……[p]
#kirie
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="45"]
啊啊啊啊啊啊啊！[p]
[chara_show name="kirie" top="-10" time="10"]
#kirie
[resetfont]
[delay speed="60"]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
不要啊！！！[r]
人家只是想见你而已！[r]
别再追过来了啊──……！[p]
#
因为见不到、[wait time="500"]"想见你"……？[p]
[delay speed="100"]
到底是、[wait time="500"]想见谁？[p]
#kirie
……呜呜！[p]
[chara_hide name="kirie" time="300" pos_mode="false"]
;ＳＥ走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="220"]
[resetdelay]
; ＳＥ草を分け逃げる
#sarasa
[quake time="30"]
啊！等等……！[p]
[chara_show name="makado" top="-10" face="worryB" wait="false" time="300"]
#makado
……果然凭我的力量只能做到这种程度……。[l][r]
#makado:angry
我要再追一次！[p]
@layopt layer=message0 visible=false
[clearfix]
; ＳＥ走る
[mask]
[chara_hide name="makado" time="10"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="220"]
; 〇はなすみ滝（夜）
[bg storage="hanasumiFalls_n.jpg" time="10"]
[mask_off]
[quake time="30"]
[mask time="10"]
[playse  volume="70" buf="0" storage="punch.ogg" ]
[wait time="500"]
[mask_off time="10"]
[quake time="10"]
;ＳＥ叩く音
[chara_show name="kirie" top="-10" time="10"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#kirie
[quake time="30"]
呀啊！[p]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="+=800" time="800"]
[chara_hide name="kirie" time="200"]
[playse  volume="50" buf="0" storage="book.ogg"]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="normal_n" storage="chara/makado/normal/normal.png"]
[chara_face name="makado" face="wowCM_n" storage="chara/makado/normal/wowCM.png"]
[chara_face name="makado" face="closeEye_n" storage="chara/makado/normal/closeEye.png"]
[chara_face name="makado" face="tweet_n" storage="chara/makado/normal/tweet.png"]
[chara_face name="makado" face="tweetLA_n" storage="chara/makado/normal/tweetLA.png"]
[chara_face name="makado" face="lookAway_n" storage="chara/makado/normal/lookAway.png"]
[chara_face name="makado" face="wowB_n" storage="chara/makado/normal/wowB.png"]
[chara_face name="makado" face="worryB_n" storage="chara/makado/normal/worryB.png"]
;-------------------------------------------------------------------------------
[chara_show name="makado" top="-10" face="normal_r" time="10"]
#makado
虽然于心不忍，但这是为了让你恢复原状[p]
[chara_hide name="makado" wait="false"]
[delay speed="50"]
#
[playse  volume="40" buf="0" storage="shimeage.ogg"]
贤治郎先生将绳状物像绳索般挥舞着，[r]
缠住了雾绘的双脚。[p]
#kirie
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
住手……快住手！[p]
[chara_show name="makado" top="-10" face="closeEye" wait="false"]
#makado
纱罗纱、拜托了[p]
#sarasa
（因为知晓了奥陆盲盒的解放[r]
雾绘小姐才被诅咒……）[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
中午在神社相遇时[r]
她其实早已知晓真相，[l][r]
[r]
进入祠堂打扫的贤治郎先生[r]
从确认绢布烧毁的[font color="0xf08080"]两天前[resetfont]开始[r]
直到今天与我相遇之前……[l][r]
[r]
不，或许比那更早之前[r][font color="0xf08080"]
「封印解除」[resetfont]的事就已经知晓了。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
（这个时间线，该从何处开始梳理才好……）[p]
@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
*question3
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

;フォントカラー黒
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
为探究被诅咒的原因 需要知晓的事实是？[r][r]
[glink color="btn_12_black" target="*good5" text="你是什么时候回到这个镇子的" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but3" text="你是怎么出现在二楼窗户的" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but3" text="你打算杀了纱罗纱吗" width="20" x="580" y="60" ]
[resetfont]

[s]
;-------------------------------------------------------------------------------
*but3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[current layer="message0"]
[position vertical=false]
#sarasa
不对，不是这个！现在我应该弄清楚的是另一件事……！[p]

@jump target="*question3"
;-------------------------------------------------------------------------------
*good5
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[layopt layer="message1" visible="false"]
[current layer="message0"]
[position vertical=false]


#sarasa
……贤治郎先生[p]
在神社时　[font color="0xf08080"]"为什么要回到这个小镇"[resetfont]这样[wait time="500"][r]
向雾绘小姐打听过吧[p]
#makado:wowCM
啊、啊啊[p]
#sarasa
那个、问出结果了吗……？[p]
[delay speed="60"]
具体是什么事、从什么时候回来的、之类的……[p]
#makado:tweet
[playse  volume="20" buf="0" storage="sariin.ogg" ]
……！[l][r]
#makado:normal
[resetdelay]
…………………………[r]
是吗，你……。[p]
#makado:lookAway
[delay speed="60"]
…………………………[l][r]
#makado:tweetLA
……如果解除诅咒需要的话，[wait time="500"]我可以告诉你。[r]
她，[wait time="500"]在这个小镇……[p]
[chara_hide name="makado" time="10"]
[chara_show name="kirie" top="-10" time="10"]
[stopbgm]
#kirie
[layermode name="kirie" graphic=kirie.png time=300 mode="lighten"]
[playse  volume="30" buf="0" storage="garasu.ogg"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=kirie keyframe=up time=300 wait="false"]
[chara_move name="kirie" top="-200" width="+=200" wait="false" anim="true" left="20"]
闭嘴！！[chara_hide name="kirie" wait="false" time="10"][p]
[wait time="400"][er][stop_kanim name=kirie]
;ＳＥカーンみたいな音
[chara_show name="makado" time="10" face="wowB" top="-10"]
#makado
[font size="50"]
[quake time="30"]
！！[p]
[resetfont]
;〇画面特殊効果・キープアウトテープ
[fadeoutbgm  time="3000"]
#makado:worryB
[delay speed="100"]
…………………………[r]
……呜、[wait time="500"]雾、[wait time="500"]雾绘……[p]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥ倒れる:punch
[anim name="makado" top="+=30" time="150"]
[anim name="makado" top="+=800" time="800"]
[chara_hide name="makado" time="200"]
[playse  volume="50" buf="1" storage="book.ogg" ]
[wait time="1000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……………………………………呃[l][r]
………………………………贤治郎先生……[p]
[fadeinse  volume="05" buf="2" storage="walk_rouka.ogg" loop="true" time="3000"]
[chara_show name="kirie" top="-10" face="ghost" wait="false" time="500"]
#kirie
…………………………[r][wait time="500"]
呜呃………………咕……哈啊[p]
#sarasa
[font size="20"]
……为、[wait time="500"]为什么、[wait time="500"]你在做什么[p]
[resetfont]
#
[resetdelay]
[font color="0xf08080"]
··········[p]
像是要掐住倒在地上的贤治郎先生的脖子一般，[r]
缠绕着黄黑相间的警戒胶带。[p]
这一瞬间，[wait time="500"]究竟[wait time="500"]发生了——[p]
[resetfont]
#sarasa
[delay speed="100"]
贤、贤治郎先生，[wait time="500"]等、等一下…………[p]
#makado
……………………………………………………[p]
[delay speed="50"]
#
怎么呼唤都没有回应。[p]
他自俯身倒下后就纹丝不动的躯体，[wait time="500"][r]
我根本没有勇气[wait time="500"]亲手翻过来确认呼吸。[p]
[delay speed="60"]
不知从何处出现的危险区域标识胶带——[p]
这正是[wait time="500"]　刚刚让我确信其真实存在的[r]
和御黒もっけ　如出一辙的[r]
绝非人类智慧所能企及的存在。[p]
#sarasa
（………………………)[p]

……难道……[l][r]
刚才的、[wait time="500"]是雾绘小姐做的吗？[p]
#
我战战兢兢地向眼前情绪激动的雾绘搭话。[p]
#kirie
哈啊……、哈啊……[p]
#sarasa
你也、[wait time="500"]真的要、[wait time="500"]对御白姬……………[r]
…………………………起杀心吗？[p]
#kirie
…………哈啊、哈啊[p]
哈哈、哈哈哈[p]
[font size="45"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
哈哈　哈哈哈哈！！[r]
哈哈哈哈哈哈哈…………[p]
#sarasa
[resetfont]
有什么……[l][r]
[quake time="30"]
有什么好笑的……？[p]
#
声音、[wait time="500"]不由自主地颤抖着。[p]
#sarasa
[delay speed="100"]
住……住手……[p]
[resetdelay]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
快停下这种事、[r][wait time="500"]
一树的[wait time="500"]　姐姐……！[p]
[stopse buf="2"]
#kirie
——因为人家已经是杀人犯了嘛[p]
[free_layermode name="kirie" time="10"]
[chara_hide name="kirie" time="300" pos_mode="false"]
;ＳＥ走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="220"]
;ＳＥ草を分け逃げる
#sarasa
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……！[l][r]
等等！[p]
#
;ＳＥ走る
[mask time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
#
[cm]
[chara_hide name="kirie" time="10"]
[bg storage="brack.png" time="10"]
[wait time="3000"]
@layopt layer=message0 visible=false
[clearfix]
[mask_off time="2000"]
;暗転（ＳＥ走ってる）
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible=true
#
[delay speed="70"]
我追向了雾绘。[l][r]
[r]
穿着家居服的我，[wait time="500"]不顾一切地[wait time="500"]拨开草木。[l][r]
[r]
[r]
……就在此时，[wait time="500"]我忽然意识到一件事。[p]

即使运动神经差如我也能毫不费力追上，[r]
雾绘的脚步虚浮不稳。[l][r]
[r]
[r]
…她恐怕已经，[wait time="500"][r]
没剩下多少力气了吧………………[p]

#
[mask]
;〇四ツ山・橋（夜）
[bg storage="yotuyamabridge_n.jpg" time="10"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
;ＳＥ草むらガサガサ
[wait time="500"]
[fadeinbgm storage=bigriver.ogg loop=true time=3000 volume="10"]
[wait time="1000"]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥ川の近く
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[mask_off time="2000"]
[wait time="2000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……………………………………………………[l][r]
……这里是……桥？[l][r]
四ツ山里居然还有这种地方……[p]
[resetdelay]
——现在可不是想这些的时候！[r]
雾绘究竟去了哪里……[p]

…………[p]
[quake time="30"]
[font size="50"]
——！[p]
[resetfont]
;滝
#
;スチル『橋の上のきりえ』
[mask time="10"]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/kirie_bridge.jpeg" time="10"]
[wait time="3000"]
[mask_off time="2000"]
[wait time="3000"]
[delay speed="60"]
#kirie
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
纱罗纱。[r]
我有话要托你转告树月[p]
真正的诅咒，[wait time="500"]是永远不会消失的。[r]
少自恋了[p]
……哈啊——！[r]
我的命只属于我自己！[p]
@layopt layer=message0 visible=false
[clearfix]
#
;スチル足
[bg storage="still/kirie_legs.jpeg" time="1000" cross="false" wait="true"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
终于，[wait time="500"]能去见你了。[p]
@layopt layer=message0 visible=false
[clearfix]
[mask time="10"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[stopbgm]
;スチル『紗羅紗の瞳』
[bg storage="still/sarasa_eye.jpeg" time="10"]
[wait time="400"]
;ＳＥ川に飛び込む　暗転
[mask_off time="10"]
[wait time="2000"]
[mask folder="bgimage" graphic="still/prologue.png" time="10"]
[bg storage="brack.png" time="10"]
[wait time="700"]
[playse  volume="50" buf="0" storage="basya2.ogg"]
[wse]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[showsave]
;SEと暗転と文字出るタイミング全部同じにしたらめちゃかっこいいとおもう
@jump storage="chapter_1/day1.ks"







;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;---------------------------------------------------------
*Sub_hover_q
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#e14f4b");
},
function() {
  $(this).css("color", "#000000");
　}
);
[endscript]
[return]

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
