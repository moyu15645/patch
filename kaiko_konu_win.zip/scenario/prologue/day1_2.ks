;序章　「桑畑で誰かが誰かを捕まえたら」
;一日目、途中から
;-------------------------------------------------------------------------------
*part2
;-------------------------------------------------------------------------------


[cm  ]
[clearfix]
[start_keyconfig]

[mask]
[bg storage="hataneR.jpg" time="100"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

[mask_off]

#ituki
[delay speed="60"]
总觉得今天阴沉得奇怪呢～[r]
明明是夏天却像冬天一样日落呢？[l][r]
或许是雨云太厚了吧。真是奇特的雷阵雨呢[p]
[resetdelay]
啊、话说纱罗纱你的遮阳伞是晴雨两用的吧！？[r]
说不定是第一次知道呢[p]
[delay speed="50"]
真不容易呢～保持白皙肌肤也是～。[r]
白绢祭明明一天就结束了，准备工作却[r]
要花上一年以上呢～[p]
[delay speed="80"]
………………………………[l][r]
[delay speed="50"]
……呐、纱罗纱[p]
#ituki
刚才我[wait time="500"]把画册里的御白姬画得像纱罗纱[wait time="500"]这样的[r]
说了呢。[p]
[delay speed="60"]
其实那是……有我的理由的！[r]
虽然被妹妹优说成『笨蛋』什么的[p]
#ituki
但对我来说～[wait time="500"]　纱罗纱就是御白姬……[r][wait time="500"]
我觉得简直就是女神大人本身，所以才那样做的[p]

你啊，[r]
不只是因为你要在今年白绢祭扮演御白姬这件事……[p]
[resetdelay]
应该说～从第一次见面开始～？[r]
纱罗纱对我来说就是御白姬本人哒！[p]
[delay speed="50"]
所以我才在那个纸话剧里[wait time="500"]把女神大人画成你的样子哒[p]
#
[fadeoutbgm  time="6000"]
[wait time="6000"]
#ituki
……啊咧，下雨了……[p]
[mask time="300"]
[bg storage="fork_n.jpg" time="100"]

[chara_show name="ituki" left=-70 top=-160 wait="false" time=0 face="smileCE"]
[chara_show name="sarasa" left=360 top=-160 time=0 face="normal"]

[fadeinbgm storage=gymnopedies2.ogg loop=true time=6000 volume="50"]

[mask_off]

#ituki:smileCE
[resetdelay]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
太好啦～突然就放晴了呢～[r]
说不定我们俩是晴天娃娃转世呢～☆[p]
#ituki:smile
啊～今天返校日虽然超麻烦的说～[r]
但是给纱罗纱看了纸话剧，[r]
好好去上学真是太好啦！[p]
#sarasa:smile
[delay speed="60"]
……我也，能和一树久违地聊天真是太好了[p]
[resetdelay]
#ituki:smileCE
嘿嘿～[wait time="500"]　那八月十一日的讨论会上再见……[r][wait time="500"]
#ituki:tweet
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
啊、等等！[p]
#ituki:smile
[delay speed="50"]
对对　差点忘了的说～[r]
必须把这个交给纱罗纱才行～[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg"]
[font color="0xb0c4de"]
〇白绢町 新资料集[r][tip key="shiro_new"][endtip]
〇八种町民俗资料集[tip key="hatane_minzoku"][endtip]			已获得。
[wse][p]
[resetfont]
#ituki:smileCE
我把图书馆里几份不错的资料都复印好啦～[r]
纱罗纱做作业需要的话尽管拿去用！[p]
#sarasa:normal
[delay speed="100"]
…………………………[l]
[delay speed="60"]
#sarasa:smile
谢谢……一树[p]
[resetdelay]
#ituki:smile
没事的没事的～[r]
就当是今天看纸话剧的回礼啦！[p]
[delay speed="60"]
#
说完这句话的树月，朝着岔路前方小跑了几步。[p]
[chara_hide_all time="300"]
[fadeoutbgm  time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
#ituki
……呐，纱罗纱！[p]
@layopt layer=message0 visible=false
[clearfix]
[mask time="300"]
[bg storage="still/ituki_smile.png" time="100"]
[chara_hide name="sarasa" time="10"]
[wait time="1000"]
[fadeinbgm storage=faure-op84-5.ogg time="3000" loop=true volume="50" sprite_time="0000-76400"]
[mask_off time="2000"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#ituki
从今往后，你永远都会是我的御白姬对吧？[p]
[delay speed="60"]
在我身边……[r][wait time="500"]
永远，在这座小镇。[wait time="500"]　永远做我不变的好闺蜜……[r]
这个约定。你会答应的对吧？[p]

#
[delay speed="100"]
……………………[p]
[delay speed="60"]
#ituki
呵呵……[wait time="500"]我最喜欢纱罗纱你这点了！[l][r]
即使被逼着做决定，[wait time="500"]也迟迟给不出答案，[wait time="500"]不肯表明自己的心意……[p]
[delay speed="50"]
永远纯白无瑕地，[wait time="500"]在被精心呵护的状态下，[wait time="500"]继续活下去呢。[p]

从今往后，直到长眠于八种墓地都不会改变……[r][wait time="500"]
希望你永远保持现在的模样呢[p]

[mask time="300"]
[bg storage="fork_n.jpg" time="10"]
[fadeoutbgm  time="3000"]
[wait time="3000"]
[chara_show name="ituki" left=-70 top=-160 wait="false" time=0]
[chara_show name="sarasa" left=360 top=-160 time=0]
#ituki
[chara_mod name="sarasa" face="normal"]
[chara_mod name="ituki" face="smileCE"]
[mask_off time="300"]
[resetdelay]
……这种话，其实不用特意说我们也～[r]
永远都是最好的朋友对吧[p]
#ituki:smile
啊哈哈～那就这样～拜拜！[p]
[chara_hide name="ituki" time="500" pos_mode="false" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="700"]
#
[delay speed="60"]
……我向树月挥手道别后，[r]
将收到的资料收好…………[wait time="500"]踏上了归途。[p]
@layopt layer=message0 visible=false
[clearfix]
[mask]
[bg storage="ton_n.jpg" time="100"]
;[fadeoutbgm  time="2000"]
;[fadeinbgm storage=rain.ogg loop=true time=5000 volume=100 sprite_time="2000-61000"]

[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '？？'
[endscript]
[chara_face name="mokke" face="kaiko" storage="chara/mokke/kaiko.png"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="900"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="900"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="900"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[mask_off time="3000"]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
[wait time="2000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
――四ツ山山脚。[l][r]
青涩的气息，直刺鼻腔深处。[r]
潮湿的森林里闷热异常。[p]
[chara_hide name="sarasa" time="10"]
[chara_show  name="mokke" width="900" top=-190 pos_mode="false" time="2000" face="kaiko" wait="true"]
#mokke
[delay speed="60"]
――――――――――――[p]
#
……[p]
#mokke
――――――――――――[p]
#
……隧道前，[wait time="500"]站着一个人。[l][r]
那人似乎正目不转睛地凝视着这边。[p]
#mokke
――――――――――――[p]

#sarasa
（……不认识的人）[p]
#
八种町是彻头彻尾的乡下小镇。[p]

所以，很罕见。[wait time="500"]　会有陌生人在。[l][r]
而且，还在人迹罕至的上学路上，[wait time="500"][r]
就这样凝视着这边伫立着，[wait time="500"]实在不寻常。[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[stopbgm]
[delay speed="80"]
…………………………[l][r]
被这诡异的存在感震慑，不由停下了脚步。[p]
#
──就这样，在那个人与我之间的时间停滞数秒后。[l][r]
[resetdelay]
『某人』[wait time="500"]　开始朝这边靠近。[p]
[chara_move name="mokke" width="+=20" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[chara_move name="mokke" width="+=100" left="-=50" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[chara_move name="mokke" width="+=100" left="-=50" top="-=100" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[chara_move name="mokke" width="+=100" top="-=100" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]

#
[font color="0xf08080"]
从他的身影中，[wait time="500"]隐约感觉到了某种[wait time="500"]危险的气息。[p]
[link target="*run" exp="f.white+=1"]【１】跑着逃走[endlink][r]
[call target="*Sub_hover"]
[resetfont]
[s ]
;-------------------------------------------------------------------------------
*run
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;ＳＥ　走る
;変数white+=1　白い繭
[chara_hide name="mokke" time="100" wait="false"]
[playbgm storage=fuon.ogg loop=true time=300 volume="30"]
[bg storage="brack.png" time="100" wait="false"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
#
我蹬着浸水的乐福鞋，踢开泥泞的土块，向来时的路折返。[p]

完全不明白那个人究竟是什么来头。[r]
但若被他抓住，恐怕会遭遇可怕的事——这种预感挥之不去。[p]

所以才拼了命地、仿佛要榨干生命般奔跑着……[p]

残酷的是　从背后又传来一声，[r]
不属于自己的脚步声正在逼近。[p]

[chara_hide_all time="10"]
[bg storage="still/first_contact.png" time="100"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[quake time="30"]
[fadeinse  volume="05" buf="0" storage="walk_rouka.ogg" loop="true" time="3000"]

[font color="0xf08080"]
[font size="40"]
#
！！！！！[p]
[resetfont]
全身都回荡着剧烈的心跳声。[r]
在这阵颤抖中，我的身体已经止不住发抖。[p]
[font color="0xf08080"]
[playse  volume="40" buf="1" storage="shimeage.ogg" ]
被那具高过自己一头的魁梧身躯缠住，完全动弹不得。[p]
[resetfont]
#mokke
哈啊[wait time="500"]　呜[wait time="500"]　呃[wait time="500"]　救[wait time="500"]　命[p]

普拉[r][wait time="500"]
求[wait time="500"]　你[wait time="500"]　了[p]
#sarasa
[font size="20"]
[delay speed="100"]
………………………………[l]咦？[p]
[delay speed="50"]
[resetfont]
#mokke
哈 咕 呃 救 我[r][wait time="500"]
普拉 求 你 帮帮[p]
#sarasa
…………………………………………[p]
#
[quake time="30"]
--什么都无法理解。[p]
[delay speed="50"]
就像是脑海中所有的东西[r][wait time="500"]
都化成了水的错觉[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
构成身体的全部存在[r][wait time="500"]
仿佛整个身体都被塑料替换的错觉[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[delay speed="70"]
接着[wait time="500"]　至今包裹着自己的存在[r][wait time="500"]
被强行剥离般的撕裂感[wait time="200"][er]
[resetdelay]
[resetfont]
[mask time="100"]
[stopse]
[stopbgm]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[wse]
[bg storage="brack.png" time="10"]
;SE倒れる
[playse  volume="100" buf="0" storage="book.ogg"]
[wse]
[iscript]
TYRANO.kag.stat.charas['makado'].jname = '？？'
[endscript]
[fadeoutbgm  time="3000"]
[wait time="5000"]
[mask_off time="3000"]
#makado
[font size="20"]
……喂 喂[l][r]
[font size="40"]
[quake time="30"]
喂！你没事吧！？[p]
[resetfont]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
[bg storage="still/first_contact2.png" time="3000" wait="true" cross="false"]
[wait time="2000"]
#makado
[delay speed="60"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……太好了……[r]
清醒了吗 有没有受伤？[p]

[bg storage="still/first_contact3.png" time="10"]
………………………………抱歉，[r]
要是能早点发现的话……[p]
[delay speed="100"]
………………………………[l]
[delay speed="50"]
[bg storage="still/first_contact2.png" time="10"]
能站起来吗？[p]
#
………………………………[l][r]
青年向我伸出了手。[p]
#
[mask time="6000"]
[bg storage="ton_n.jpg" time="100"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="900"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="900"]
[chara_show name="sarasa" left=390 top=-100 time="10" face="closeEye"]
#makado
[chara_show name="makado" left="-100" top="-40" time="10" face="tweetLA"]
[mask_off time="5000"]
[resetdelay]
绢世小姐她们也联系不上你，正担心着呢。[r]
快去让她们看看吧。纱罗纱[p]
[fadeoutbgm time="5000"]
#sarasa:worry
[delay speed="60"]
………………[p]
#sarasa:sadB
………………………………[p]
#makado:normal
嗯？[p]
#sarasa
………………………………[p]
#makado
………………………………[p]
[resetdelay]
#makado:wow
[anim name="makado" top="+=30" time="150"]
[anim name="makado" top="-=30" time="150"]
……啊、啊啊。好久不见了呢。[r]
我都认不出来了。[p]
#makado:lookAway
是吗，上次见面还是小学时候吧……[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=1000 volume=50]
[iscript]
TYRANO.kag.stat.charas['makado'].jname = '馬門 賢治郎'
[endscript]
[delay speed="50"]
#makado:tweet
我是贤治郎　马门神社的………[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
今年祭典的主祭者[p]
#sarasa:worry
……………[l]
#sarasa:wow
[font size="20"]
啊……[p]
[resetfont]
#makado:smileMini
剃光头后就认不出是谁了呢。[r][wait time="500"]
听说这是主祭者必经之路呢，[r]
『谁啊？和尚吗？』总被这么问……[p]
[delay speed="60"]
#
他……没错。我认识他。[p]
这人不是别人，正是今年白绢祭的主祭……[r][wait time="500"]
是马门贤治郎先生。[p]
#makado:normal
……………[r][wait time="500"]
#makado:lookAway
——总之，先一起回家吧。[p]
[resetdelay]
#makado
在你遭遇不幸时打扰实在冒昧……[l][r]
我有件重要的事[wait time="500"]要告诉你[p]
;足音
[mask]
[bg storage="shitodaGarden_n.jpg" time="100"]
[chara_hide_all time="50"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
#
[mask_off time="2000"]

;SE（門を開ける)
[delay speed="50"]
——贤治郎先生的父亲与我父亲是旧交，[l][r]
或者说……[wait time="500"]因为白绢祭的关系　两家本就常有往来。[p]

但我最后一次见到马门家的人　已是约两年前。[r][wait time="500"]
经过这么长的时间空白……贤治郎先生几乎算是陌生人了。[p]

[chara_show name="sarasa" left=360 top=-100 wait="false" time="500" face="normal"]
#makado
[chara_show name="makado" left="-70" top="-40" time="500" face="normal" wait="false"]
差不多该冷静下来了吧[p]
#
[chara_mod name="sarasa" face="closeEye"]
我朝着贤治郎先生的方向点了点头。[p]
[delay speed="100"]
#makado:worry
……………[p]
#sarasa
…………………………[p]
#makado:lookAway
………………………………………[p]
#sarasa
………………………………………[p]
#makado:tweet
……那个[p]
[resetdelay]
#sarasa:normal
……嗯[p]
#makado:lookAway
……抱歉这个……刚才捡到却忘记还给你了。[r]
应该是纱罗纱的吧？[p]
[delay speed="50"]
#
贤治郎先生说着递过来的，[r]
是我的手机。[p]

从屏幕上的裂痕来看，[r]
应该是躲避那个可疑人物时不小心掉落的。[p]
#sarasa:closeEye
……非常感谢[p]
[resetdelay]
#makado:tweetLA
不用在意[p]
#makado:lookAway
……………[p]
#sarasa:sad
[delay speed="60"]
…………………………[p]
#makado:tweet
为什么会在这种时间点……出现在那种地方呢。[r]
[resetdelay]
绢世小姐她们因为联系不上你，一直很担心啊[p]
#sarasa:worry
[delay speed="60"]
……………[l][r]
#sarasa:closeEye
手机……坏掉了所以[p]
#makado:worry
坏掉了？　[l]…………………………[p]
#makado:tweetLA
[resetdelay]
可以让我看一下吗？[p]
[chara_hide name="sarasa" wait="false"]
#
贤治郎先生查看我的手机状态。[p]
#makado:lookAway
……[l]
[stopbgm]
#makado:tweetLA
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
这个，[font color="0xf08080"]飞行模式开着呢[resetfont][p]
#sarasa
诶？[p]
#makado:tweet
[resetdelay]
你看，这里不是有个飞机图标嘛。[l][r]
有这个标志时，手机是不能通信的[p]
#makado:lookAway
顾名思义就是坐飞机的时候啦，[r]
这是个用来减少电池耗电的功能……[p]
#makado:tweet
纱罗纱，不是你自己打开的飞行模式吧？[p]
#
……[l][r]
我摇了摇头。[p]
#makado:closeEye
[delay speed="60"]
……嗯。这样啊………………[p]
#makado:tweet
[resetdelay]
飞行模式即使在锁屏状态下[r]
也能随时切换开关的[p]
#makado:normal
[delay speed="60"]
所以，说不定……[wait time="500"][r]
你的手机可能是被人远程操控了[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
……是谁？为了什么？[p]
#makado:tweetLA
——从今往后你身边[r]
会越来越多这种莫名其妙的事件[p]
#makado:tweet
但所有这些事 都有确切的缘由[r][wait time="500"]
我今天来见你 就是要告诉你这个缘由[p]
#
[mask]
[chara_move name="makado" left="-70"]
[bg storage="indoor/sitodarouka_n.jpg" time="10"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'アキラさん'
[endscript]
;左にアキラを登場させておく
[chara_show name="mokke" width="290"  left="1000" top="58" pos_mode="false" time="300" face="akira" zindex="3"]
;ドアが開く音
[chara_mod name="makado" face="normal"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
#makado:tweet
[mask_off]
打扰了。[r]
绢世小姐，我是马门。[p]
#
[chara_show  name="kinuyo" left="360" top="-160" pos_mode="false" time="1000" face="normal" wait="true" face="sad"]
#kinuyo:sad
纱罗纱[p]
;[chara_hide name="sarasa" time="300" pos_mode="false"]
[chara_move name="mokke" left="350" top="58" time="700" anim="true" wait="false"]

#mokke
[resetdelay]
[font size="40"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
讨厌啦！纱罗纱真是的！[r]
您到底去哪儿了！？[p]
[resetfont]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
大家担心得都出去找您了！[r]
而且还联系不上，真的吓死人了……[p]
#kinuyo:sad
阿基拉 快通知大家[p]
#mokke
啊，好的[p]
[chara_hide name="mokke" wait="false" pos_mode="false" face="normal_n"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="400"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="400"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
#makado:lookAway
纱罗纱的手机是坏了还是怎么回事……[r]
她说她那边也联系不上绢世小姐他们[p]
#kinuyo:normal
原来是这样……[p]
#kinuyo:closeEye
[delay speed="50"]
给马门先生家添了这么多麻烦，真是抱歉。[r]
在这个繁忙的时期，还劳烦伯母亲自出来寻找[p]
#makado:normal
没事 我父母那边完全没关系。[r]
让我妈稍微脱岗一会儿根本不算什么……[l][r]
所以这次的事请别放在心上[p]
#kinuyo:normal
[delay speed="60"]
………………[l]
#kinuyo:smileSP
贤治郎先生能继承祭主的职位，真的是[r]
太好了呢[p]
#makado:closeEye
[resetdelay]
不，您言重了……[p]
[chara_mod name="kinuyo" face="normal"]
#
——母亲向贤治郎先生轻轻鞠躬后，[r]
和服的衣袂翩然翻飞，在我面前跪坐下来。[p]
#
[chara_move name="kinuyo" left="100" anim="true" width="+=10" wait="false"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="900"]
[chara_move name="kinuyo" anim="true" width="+=10" wait="false"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[chara_move name="kinuyo" anim="true" width="+=10" wait="false"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="900"]
[chara_move name="kinuyo" anim="true" width="+=10" wait="false"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
#kinuyo:normal
纱罗纱[p]
#kinuyo:sad
[delay speed="60"]
居然从学校走那么暗的路回来……[r]
你到底在想什么？[p]
#sarasa
妈妈……[l]我、[wait time="500"]刚才……[er]
[fadeoutbgm time="300"]
#makado:normal
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[resetdelay]
绢世小姐。[p]
#makado:tweet
我有些话想和纱罗纱小姐说，[r]
能稍微占用您一点时间吗？[p]
#kinuyo:normal
诶？[p]
#sarasa
[delay speed="50"]
（………………？）[l][r]
#
——————话语，被打断了。[p]
#makado:lookAway
是关于白绢祭流程的事想商量一下。[r]
今年与往年不同，祭主和御白姬都由未成年人担任……[p]
#kinuyo
[delay speed="100"]
………………………………[l][r]
#kinuyo:closeEye
啊，如果是这样的话……[p]
#kinuyo:normal
[resetdelay]
纱罗纱，请带贤治郎先生去会客室。[r]
稍后会让阿基拉送茶过来[p]
[chara_hide name="kinuyo" time="500" pos_mode="false"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="400"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="400"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="400"]
[chara_show  name="sarasa" left="360" top="-100" pos_mode="false" wait="false" face="worry"]
#sarasa:wow
呃、那个，妈妈…[p]
#makado:tweet
很快就结束，不必费心了。[r]
#makado:tweetLA
纱罗纱，我们走吧[p]
#sarasa:worry
[delay speed="60"]
…………………………[p]
#
明明是想告诉妈妈，[r]
刚才经历了很可怕的事……[p]
[mask time="4000"]
[bg storage="indoor/sitodaHouse.jpg" time="10"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[chara_hide name="sarasa" wait="false" time="10"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="900"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_move name="makado" top="-40"]
[chara_mod name="sarasa" face="worry"]
[chara_mod name="makado" face="normal"]

[mask_off time="3000"]
#sarasa:worry
(……[l]
#sarasa:worryLA
究竟打算做什么呢……？)[p]
#makado:tweetLA
[resetdelay]
抱歉。虽然你现在还不明白目的是什么，[r]
但这也是为了你好……[p]
#sarasa:worryLA
……………………[p]
#
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
#makado:normal
[delay speed="50"]
你对[font color="0xf08080"]御白姬传说[resetfont]应该也很熟悉吧[p]
#
[chara_mod name="sarasa" face="normal"]
我点了点头。[p]
#makado:closeEye
也是啊……[wait time="500"]八种人从幼儿园就开始在课堂上学这个，[r]
更何况纱罗纱是今年的御白姬[r]
肯定被绢世阿姨逼着背得滚瓜烂熟了吧[p]
;立ち絵消す
#makado:lookAway
[delay speed="50"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
根据这个传说举办的[font color="0xf08080"]白绢祭[resetfont]上，[r]
[font color="0xf08080"]举行由扮演御白姬的少女献上绢布的仪式。[resetfont][p]
#makado:tweetLA
而那匹能封印附身妖魔的绢布[wait time="500"][r]
[font color="0xf08080"]相传如此便能封印「御黑祟」……[resetfont][p]
;BGM止まる

;立ち絵出す
[stopbgm]
#makado:tweet
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font color="0xf08080"]
前几天被人纵火烧毁了[l][r]
[resetfont]
[resetfont]
#makado:normal
也就是说，御黑祟的封印被解开了[p]
#sarasa:worry
[delay speed="80"]
………………………………[l][r]
#sarasa:worryLA
………………………………[l]
#sarasa:wow
诶？[p]
#makado:normal
[resetdelay]
所以说，原本封印着御黑祟的结界。[wait time="500"][r]
已经被解开了啊。[p]
#sarasa:worry
[delay speed="80"]
………………………………[l][r]
#sarasa:worryLA
………………………………[p]
[playbgm storage=sicilienne.ogg loop=true volume="30"]
#makado:tweetLA
[delay speed="50"]
现在这个八种町，御黑祟的封印已经被解开了。[r]
御黑祟会利用镇上的人们来袭击你吧[p]
#makado:tweet
因为纱罗纱是今年[font color="0xf08080"]御白姬的继任者[resetfont]啊[r][wait time="500"]
对御黑祟他们而言，你就是[font color="0xf08080"][font size="40"]等同于宿敌的存在[resetfont][p]
[chara_move name="makado" left="100" wait="false" anim="true"]
[resetdelay]
#makado:tweet
[playse  volume="20" buf="0" storage="sariin.ogg" ]
而且，[font color="0xf08080"]御黑祟封印被解开这件事[r]
绝对不能声张。[l][r][resetfont]
言语即是诅咒，[wait time="500"]会直接成为记忆被反复回顾的[p]
#makado:lookAway
所以绢布烧毁的事至今还被隐瞒着，[r]
已经存在想要加害于你的家伙这件事……[p]
[fadeoutbgm time="5000"]
[delay speed="50"]
『烧毁绢布解开封印之人，[r]
与擅自操作你手机者乃同一人物』这件事[r]
作为可能性之一……[p]
#makado:worry
……………………………………[l]
纱罗纱？[p]
#
似乎注意到了对面蜷缩着的我，[r]
贤治郎先生出声搭话。[p]
[resetfont]
#makado
………………………………[p]
#makado:lookAway
[resetdelay]
……………你有在好好听我说话吧？[p]
#makado:normal
[delay speed="50"]
………………………[p]
#makado:tweet
若没有你的回应，我不知该如何是好。[r]
我刚才说的那些话，你确实听进去了吗？[p]
#
[chara_mod name="makado" face="normal"]
[delay speed="70"]
[chara_mod name="sarasa" face="worry"]
………………………………[l][r]
#
他似乎正在等待我用语言作出回应。[p]
#
[wse]
[link target="*no"]【１】没有[endlink][r]
[link target="*yes"]【２】有[endlink][r]
[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*no
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#sarasa
……没有[p]
[resetdelay]
#
啊。糟糕了。[r]
当那句话脱口而出的瞬间，我立刻就后悔了。[p][stop_kanim name=sarasa]

[delay speed="60"]
明明只要回答「是」，这个话题就能就此结束的……[p]
[resetdelay]
#makado:tweet
这是为什么呢。是我说话方式有问题吗？[r]
还是说内容太离奇，让人难以置信？[p]
#sarasa
…………[p]

@jump target="mokke_later"
;-------------------------------------------------------------------------------
*yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#sarasa
[delay speed="60"]
[font size="20"]
…………………………是[p]
[resetfont]
#makado
………………………………[l][r]
#makado:lookAway
……………………………[p]

@jump target="mokke_later"
;-------------------------------------------------------------------------------
;SE襖スパン
*mokke_later
;-------------------------------------------------------------------------------
#
就在这一刻，[r]
我对贤治郎先生产生了[r]
方才对那个可疑人物相同的情绪。[p]
[delay speed="60"]
那是一种对危险又……[r]
令人毛骨悚然的存在，想要保持距离的心情。[p]
对某些事物过分虔诚的姿态，[r]
会让非此类人”下意识地疏远。[p]
这一现象，此刻正在这间客厅里，骤然上演。[p]
[chara_show name="mokke" width="290" left="500" top="100" pos_mode="false" time="10" face="akira" zindex="5" wait="false"]
#mokke
[resetdelay]
[font size="40"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
打扰啦！[playbgm storage=gymnopedies2.ogg loop=true volume=50]　请用茶——！！[p]
[chara_move name="makado" wait="false" left="-70" anim="true"]
#makado:closeEye
[resetfont]
啊、谢谢……。真是太感谢了[p]
[delay speed="60"]
#sarasa:closeEye
……………………………[p]
[delay speed="50"]
#mokke
讨厌啦～贤治郎！精神吗？清爽多了吧～[r][wait time="500"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
头脑也清醒多了呢！怎么样？神社工作辛苦吗？[p]
#makado:normal
[delay speed="50"]
不、[r]
多亏大家都很照顾我，还算勉强………[p]
#
话题的矛头被转移了。[r]
我稍微松了一口气。[p]
#mokke
真是认真又了不起呢～！[r][wait time="500"]
明明和我们家琉璃同龄，简直不敢相信！[p]
#makado:normal
[delay speed="50"]
啊…。琉璃小姐，您还好吗[p]
#mokke
[resetdelay]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
整天不是社团活动就是跨校联谊什么的，[r]
从没见她认真学习过！[r]
将来可怎么办呀[p]
[delay speed="50"]
#makado:lookAway
……………………………[p]
#
――就在阿基拉拖长的语尾消失的同时，[r]
贤治郎先生抓起茶碗一饮而尽。[p]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
#makado:normal
……明早我会再来接她。[r]
关于祭祀事宜，有些部分需要和纱罗纱小姐商讨[p]
#sarasa
……诶[p]
#makado:closeEye
就算现在难以置信也是没办法的事。[p]
#makado:tweet
[resetdelay]
但对我来说，[r]
作为祭主，我有义务保护你安全完成白绢祭典[p]
#makado:tweetLA
更何况你明明什么错都没有，[r]
却因这个传统而陷入危险之中。[r][wait time="500"]
为了负起这个责任，我会带你离开这里。[p]
[delay speed="60"]
#makado:tweet
为了让你卸下御白姬的职责[p]
#
……………………………。[p]
#makado:lookAway
[resetdelay]
…………[l]
#makado:tweet
去和绢世小姐打声招呼，今天就先回去了。[r]
打扰到这么晚真是不好意思[p]
#mokke
啊、[wait time="500"]呃[wait time="500"]　好的[p]
#
;SEピシャリ
[chara_hide name="makado" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wait time="1000"]
#
····[p]
#mokke
[playse  volume="30" buf="0" storage="kansei.ogg"]
[font size="40"]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
…………一点都不浪漫嘛〜！[p][resetfont]
虽然不太明白你在说什么，[r]
但清醒状态下能说出这种台词，不愧是贤治郎呢～！[r][wait time="300"]
J-POP的化身？[p]
#sarasa
[delay speed="100"]
（………………………………）[p]
#mokke
[delay speed="60"]
啊、对了对了。[l][r]
纱罗纱小姐，你没事吧？[r]
被那样搭话肯定很讨厌吧[p]
#mokke
因为纱罗纱小姐你、[wait time="300"]已经没法正常和人、[wait time="300"]聊天了呢[p]
#
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all time="2000"]
[bg storage="brack.png" time="2000" wait="true" cross="false"]
[fadeoutbgm time="4000"]
[wait time="5000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
今天发生了太多事，已经累坏了……[r]
赶紧泡个澡睡觉吧。[p]

;暗転

#
洗完澡后要做些什么呢？[p]
[link target="*mother"]【１】和妈妈说话[endlink][r]
[link target="*akira"]【２】和阿基拉说话[endlink][r]

[call target="*Sub_hover"]

[s]

;-------------------------------------------------------------------------------
*mother
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask]
[cm]
[bg storage="indoor/kinuyoRoom_n.jpeg" time="10"]
[chara_show  name="kinuyo" top="-160" time="10" face="back"]
[fadeoutbgm time="4000"]
[wait time="4000"]
;image(絹世の部屋)
[mask_off]

;(襖の開く音)
;bgm爪切りS
[playse storage="nail.ogg" loop="true"]

#kinuyo:back
啊啊，纱罗纱……。[r]
我从贤治郎先生那里听说了哦[p]
毕竟承蒙他照顾了，[r]
明天再来的时候要好好道谢哦[p]

别让人家担心啊。[r]
白绢祭也快到了　你得加把劲才行……[p]

作为志户田纤维的千金，别给父亲添麻烦。[r]
明天要出门，记得注意防晒[p]
[stopse]
#
@jump target="sleep"
;-------------------------------------------------------------------------------
*akira
;-------------------------------------------------------------------------------
;(志戸田家)
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask]
[bg storage="indoor/sitodaHouse.jpg" time="100"]
[chara_show name="mokke" width="290" top="58" pos_mode="false" time="10" face="akira"]
[cm]
[fadeoutbgm time="4000"]
[wait time="4000"]
[mask_off]

#mokke
哎呀纱罗纱小姐。[r]
这个时间还醒着真是少见呢[p]

……啊，该不会是来打听贤治郎的事吧？[p]
[delay speed="50"]
听说他在高中时也是个优等生哦。[r]
跟体育特招入学的我简直是天壤之别——[r]
我家孩子经常这么说呢[p]

……悄悄告诉你，琉璃高中那会儿啊，[r]
我总觉得她可能是喜欢贤治郎君呢。[p]
[resetdelay]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[font size="40"]
哎呀，所以真是太可惜啦～！[r][resetfont]
要是能和琉璃上同一所大学的话，说不定都结婚了呢[r]
也说不定哦！[p]

啊不过，要是和那个马门家结婚的话感觉会很麻烦。[r]
是寺庙对吧？[wait time="300"]　啊不对是神社。我家孩子可受不了这种！[p]
………………………………[p]
[resetdelay]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[font size="40"]
开～玩～笑[resetfont]的啦～～～。[r]
其实哪家的孩子都无所谓啦～～[p]
[delay speed="60"]
只要能和真心喜欢的人在一起就好啦～～。[r][wait time="300"]
对琉璃来说。[p]

#

@jump target="sleep"
;-------------------------------------------------------------------------------
*straight
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="sleep"
;-------------------------------------------------------------------------------
*sleep
;-------------------------------------------------------------------------------
[mask]
[cm]
[chara_hide_all time="10"]
[bg storage="brack.png" time="100"]
[mask_off]
;暗転(メッセージは出すから黒の画像)
#sarasa
…………………………………………[p]
(今天真是吓死我了……)[p]
(总之明天起床后……[r]
等做完功课什么的，就得去马门神社了……)[p]
[delay speed="70"]
(……[l]非去不可的吧……）[p]
#
……今天发生的事，在脑海中盘旋。[p]
[filter grayscale="100"]
;（スチルフラッシュバック）
[bg storage="still/kami_start.png" time="500" cross="false"]
[bg storage="still/ituki_smile.png" time="500" cross="false"]
[bg storage="still/first_contact.png" time="500" cross="false"]
[bg storage="brack.png" time="500" cross="false"]
[free_filter]

#
………………[l][r]
[delay speed="50"]
记忆在脑海中不断盘旋 我被搅得心神不宁[r]
辗转反侧难以入眠。[p]
现在几点了？[r][wait time="300"]
为了确认时间 终于伸手去拿手机。[p]
这时。[p]
#sarasa
(……啊)[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="70"]
(……………向一树借的移动电源……[r][wait time="400"]
忘记还了…………………)[p]
#
[mask folder="bgimage" graphic="still/prologue.png" time="3000"]
[wait time="2500"]
;セーブしますか？
[showsave]
@jump storage="prologue/day2.ks"
;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
;--------------------------------------------------------
*save
;--------------------------------------------------------

[showsave]

@jump storage="prologue/day2.ks"
