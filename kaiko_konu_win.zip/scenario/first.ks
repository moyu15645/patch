;一番最初に呼び出されるファイル

[title name="回顧、来ぬ"]
;最初は右下のメニューボタンを非表示にする
[hidemenubutton]
;メッセージボックスは非表示
@layopt layer="message" visible=false
[stop_keyconfig]
@bg storage ="click.png" time=100
……[p]

;ティラノスクリプトが標準で用意している便利なライブラリ群
;コンフィグ、CG、回想モードを使う場合は必須
@call storage="tyrano.ks"

;ゲームで必ず必要な初期化処理はこのファイルに記述するのがオススメ
[plugin name=custom_ruby]
[plugin name=tip]

;非表示(回顧録)
[clearfix]

[free_filter]
[resetdelay]
;タイトル画面へ移動
@jump storage="title.ks"

[s]
