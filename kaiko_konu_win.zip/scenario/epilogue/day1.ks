*epilogue
;↓章と日付変わるごとにフォルダの頭に書き換えて入れておいてほしい(できれば)
[eval exp="f.save_title = '最終章'"]
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=true
#
[font size="22"]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]
[wait time="2000"]
[mask_off time="4000"]
――我呢[p]
[clearfix]
[delay speed="80"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
「其实　我从来没说过一句　要继承神社　这种话啊」[l][r]
[r]
[r]
「诶―[l]　那马门君是擅自想当神官的意思吗？」[l][r]
[r][quake time="30"]
[delay speed="50"]
「擅自……倒也说不上啦！？[r][wait time="500"]　雾绘同学说话还挺毒舌的呢」[l][r]
[r]
「不过啊……[l][r]　我是想告诉贤治郎[r]　他明明还有很多其他可能性的」[p]
[r]
「就算当学校的老师也好　他能有自己的目标我就很开心了」[l][r]
[r]
「但是……从小学开始　那孩子连这种梦想都不敢跟父母说[r]　实在让人心疼得受不了」[l][r]
[r]
[r]
「即便如此　我觉得马门君最终还是会继承神社的」[p]
[fadeoutbgm time="3000"]
[wait time="6000"]
「………」[l][r]
[r]
[r]
「……[l]怎么了？」[l][r]
[r]
[delay speed="70"]
「……虽然见到马门君了。[l][r]　但果然[wait time="500"]　　　在我们家还是见不到呢。」[l][r]
[r]
[r]
「………………………………………」[p]
[delay speed="90"]
「――……一旦放手的孩子[l]我们[wait time="500"]　就已经无能为力了」[l][r]
[r]
「不[wait time="500"]这么认为吗…………。」[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
;-------------------------------------------------------------------------------
#
[mask]
[bg storage="op_one.png" time="10"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[wait time="6000"]
[playse storage=page.ogg volume="50"]
[mask_off]
[resetfont]
[delay speed="70"]
……蚕要是没有人为条件就活不下去[r]
是被驯化的昆虫……[p]

纯白的幼虫无法融入外界 力量也过于弱小[r]
只要起风 连抓住叶片都做不到。[p]

所以 蚕无法在野外生存。[r]
根本活不下去。[p]

[bg storage="op_two.png" time="1500"]

而且 从茧中羽化的成虫连进食能力……[r]
也就是生存所需的能力 都会在茧里退化殆尽。[p]

[bg storage="op_four.png" time="1500"]

正因如此 蚕蛾只剩无用的口器与[r]　
经过品种改良后 徒具形骸的残翅[p]
羽化后大概[wait time="500"]　一周左右[wait time="500"]　就会死去。[p]
在这个小镇上，[p]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=bell.ogg sprite_time="0000-7000" volume="5"]
[bg storage=./school/croom_m.jpg time="1500" wait=true]
[wse]
[resetdelay]
[chara_show name="kuma" left=-150 top=-160 time=2000 face="normal"]
#kuma
@layopt layer=message0 visible="true"
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
…………………………[p]
#
[chara_show  name="sarasa" left=390 top=-160 face="normal" time="2000"]
#sarasa
[delay speed="30"]
…………………………[p]
[playbgm storage="gymnopedies2.ogg" loop="true" volume="50"]
;ＳEチャイム
#kuma:hurry
[resetdelay]
哎呀哎呀，又到下课时间了呢[p]
[chara_hide_all wait="true" time="100"]
[chara_show name="riki" top="-100" wait="false" time="300" face="angry"]
#riki
喂——小熊！这段之前也讲过啦——[p]
[chara_move  name="riki" left=-70 time="300" wait="false"]
[chara_show  name="hino" face="normal" left=-230 top=-100 time="300" wait="false"]
[chara_show  name="ituki" face="normal" left=490 top=-160 time="300" wait="false"]
#aki
[chara_show  name="aki" left=250 top=-100 time="300" face="normal"]
又在纱罗纱的环节中断掉了呢[p]

#ituki:smile
肯定是因为日野同学的发表蠢得要死还超长啦！[p]

#hino:shame
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
等等等等、等等！？小组发表可是同生共死的，[r]
把责任全推给一个人绝对不是上策啊——！[p]
#
[delay speed="90"]
——9月1日。下午1点。[p]
@layopt layer=message0 visible=false
[clearfix]
[delay speed="60"]
[chara_hide_all wait="true" time="300"]
[bg storage="hataneM.jpg" time="1500" wait="true"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
窗外的景色，和八月时没太大差别。[l][r]
明明暑假已经结束了[r]
唯独夏天仍迟迟不肯离开这座小镇。[p]
[mask folder="bgimage" graphic="still/epilogue.png" time="3000"]
[wait time="3000"]
[bg storage=./school/croom_m.jpg time="1500" wait="false"]
[chara_show name="mokke" top="100" face="kuroda"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
[resetdelay]
[mask_off]
#mokke:kuroda
不过说真的，经历了那么多事的志户田[r]
能做出这么详尽的资料超厉害啊。[p]
[delay speed="80"]
穿着血淋淋的服装通宵排练的志户田啊……[p]
[font size="22"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke:womenBlack
…………………………[l]真的亏她能面不改色做到这份上……[r]
穿着那种状态的服装呢[p]
#sarasa
[resetfont]
[chara_move name="mokke" left="100" wait="false" anim="true"]
[chara_show name="sarasa" top="-160" face="normal" left="390" wait="false"]
……………………[p]
#sarasa:smile
谢谢 饭岛同学[wait time="500"]　你来看我了吧[p]
[resetdelay]
#mokke:womenBlack
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font size="40"]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
！[l][r]
[font size="22"]
…………才、[wait time="500"]才不是在夸你呢[p]
[chara_show name="riki" top="-100" time="10" wait="false" face="smileCE" left="100"]
[keyframe name=up]

[frame p=25% y=50 ]
[endkeyframe]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[stopbgm]

[chara_mod name="sarasa" face="wow" time="10"]
[kanim name="sarasa" keyframe=up time=300 wait="false"]
[kanim name="mokke" keyframe=up time=300]
[wait time="300"]


[stop_kanim name="sarasa"]
[stop_kanim name="mokke"]
#riki
[font size="36"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
是是是——！！[r]
既然发表结束了那就由我来说吧！！[p]
[resetfont]
#
[delay speed="60"]
登利说着突然站起身——[r]
径直走到了我所站的黑板前。[p]
[chara_hide_all time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[chara_show name="riki" top="-100" face="smile" time="100"]
#riki:smile
熊老师——我可以的对吧！？[r]
我在这儿说话总可以吧！？[p]
[chara_move name="riki" left="330" time="300" wait="false" anim="true"]
#kuma:smileW
[chara_show name="kuma" left="-150" top="-160" face="smileW"]
哎呀呀……[p]
#kuma:normal
这是怎么了呢，登利君。[r]
在完成问候前可不能擅自离席哦？[p]
#
[delay speed="80"]
温柔的熊老师只是轻轻责备了学生突兀的行为。[l][r]
然而登利却对着这样的老师浮现出挑衅的笑容。[p]
[delay speed="60"]
#riki:smileCE
嘿嘿，呵呵～………[p]
#riki:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[resetfont]
我们狮心教眷属的学生啊—，[r]
今天就到这儿　特别逃跑啦——！！[p]
#kuma:normal
[delay speed="100"]
………………………………[l][r]
#kuma:wow
[quake time="30"]
……哎！？　逃跑？[p]
[playbgm storage="lost-happy.ogg" loop=true volume="30" sprite_time="0000-105000"]
[delay speed="60"]
#
全班骚动起来。[p]
[resetdelay]
#riki:smileCE
可以吧——这可是宗教原因哦。[l][r]
[chara_move name="riki" left=-600 anim="true" time=700 wait="false"]
那就——先溜为敬————！！！[p]
;ＳEガラガラ
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[chara_hide name="riki" pos_mode="false" time="10"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]
[wait time="800"]
#kuma:smileW
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="kuma" left="-=10" time=50 ]
[anim name="kuma" left="+=10" time=50 ]
[anim name="kuma" left="-=10" time=50 ]
[anim name="kuma" left="+=10" time=50 ]
等……我可没听说啊，登利君！[p]
[chara_show name="hino" top="-100" face="smile" time="100" left="330"]
[chara_mod name="kuma" face="wow" wait="false"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg"]
[font size="38"]
噗哈哈哈！！[l][r]
[resetfont]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
年轻人有时就需要这样无序的冒险啊——！！[p]
[chara_move name="hino" left=-520 anim="true" time=700 wait="false"]
;ＳEガラガラ
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[chara_hide name="hino" pos_mode="false" time="10"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="aki" top="-100" face="smileB" left="330" time="300" wait="false"]
#aki
[delay speed="60"]
虽然我刚才说了「别这样」呢。[wait time="500"][r]
对不起　待会儿请好好教训我吧[p]
[chara_hide name="aki" pos_mode="false" time="1000" wait="false"]
;ＳEガラガラ
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="400"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="400"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="400"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wait time="1000"]
#kuma
…………唉，真是…………[p]
[chara_hide name="kuma" wait="false" time="300"]
#
与狼狈不堪的熊老师形成鲜明对比，班上同学们对突然发生的[r]
非日常事件显得兴奋不已。[p]
[fadeoutbgm time="4000"]
目送三人离开后，[wait time="500"]来到我身边的，[l][r]
就只剩最后一人了。[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="800"]
[chara_show name="ituki" top=-160 wait="true" time=500 face="normal" left="140"]
[wait time="1500"]
#ituki:choiseS
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
走、走吧，纱罗纱[p]
#
[delay speed="60"]
树月像往常一样朝我伸出小拇指。[p]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=40]
于是我将——[wait time="500"]她的整只右手，紧紧握在掌心。[p]
[chara_move name="ituki" left="-70" anim="true"]
[chara_show name="sarasa" left=360 top=-160 time=500 wait="false" face="normal"]
#sarasa
…………[l]
#sarasa:smile
走吧！[p]
[mask time="10"]
@layopt layer=message0 visible="false"
[clearfix]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_hide_all]
[wait time="2000"]
;ＳEガラガラ
[bg storage="school/rouka_m.jpg" time="10" wait=true]
[mask_off time="3000"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[wait time="1000"]
;○廊下
;ＳE走る
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
@layopt layer=message0 visible=true
从背对着的教室方向，[r]
传来大家轰然爆发的笑声。[l][r]
[r]
跑啊跑啊，那笑声也越来越远。[p]
@layopt layer=message0 visible="false"
[chara_show name="nyudo" top="-60" face="normal" time="300"]
@layopt layer=message0 visible="true"
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#nyudo
……………………嗯？[p]
#nyudo:angryB
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[delay speed="80"]
嘻……！！狮心教的孩子们，齐刷刷冲出教室……[r]
难不成那是，班级暴动……！？[p]
[resetdelay]
[font size="22"]
#nyudo:sad
川铃木老师……现在正是吹哨的时候吧……[p]
[resetfont]
[chara_move name="nyudo" left="-140" anim="true" wait="false"]
[chara_show name="kawa" top="-10" face="normal" time="300" wait="false" left="380" width="-=100"]
#kawa
嗯——？嘛～……[p]
#kawa:smile
现在先放着不管吧。[r]
那种家伙，等改天抓起来审问就行啦！[p]
#kawa:shame
还有啊，[wait time="500"]被人命令的话我就会失去干劲。[l][r]
这方面还请体谅下嘛～，入道老师。[p]
#nyudo:angry
[font size="22"]
[delay speed="80"]
哎、哎哎～……。就算你这么说也…………[p]
#
@layopt layer=message0 visible=false
[clearfix]
[mask time="1000"]
[chara_hide_all time="100"]
[resetfont]
[resetdelay]
[bg storage=./school/croom_m.jpg time="300" wait="true"]
[chara_show name="suguru" top="-100" face="normal"]
;○教室
[mask_off]
#suguru
[delay speed="100"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
（…………………………）[p]
#suguru:wow
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name="suguru" keyframe=up time=300 wait="false"]
[stop_kanim name="suguru"]
[resetdelay]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（……啊！是日野前辈在操场♡[l]
#suguru:angry
[font size="22"]　……と、お姉ちゃん達一行）[p]
[resetfont]
[delay speed="60"]
#suguru:normal
（——真好啊[wait time="500"]　姐姐们看起来玩得好开心）[p]
#
[mask time="300"]
[chara_hide name="suguru"]
[bg storage=./school/kotei_m.jpeg time="300" wait="true"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="2000"]
@layopt layer=message0 visible="false"
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
;○学校
[mask_off time="3000"]
[wait time="2000"]
[font size="22"]
@layopt layer=message0 visible="true"
——祭典当天，[l][r]
不知为何只有我被留在那个白色空间里，[wait time="500"]先一步回到了原来的八种町。[l][r]
[r]
一树她——[wait time="500"]在白色世界里，[r]
「我已经把雾绘和御白姬都埋葬了哦」[r]
这样告诉了我。[l][r]
[r]
但我觉得，恐怕……[l][r]
[r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="80"]
是贤治郎先生用注连绳击打雾绘小姐肉身的那个瞬间开始，[r]
[delay speed="50"]
说不定只有我[wait time="500"]　被独自抛回了原来的世界，我这样想着。[p]
@layopt layer=message0 visible="false"
[wait time="1000"]
[bg storage=./koen_m.png time="2000" wait="true" wait="true" cross="false"]
@layopt layer=message0 visible="true"
神厩舍注连绳的效力应该是[font color="0xf08080"]「警戒封锁线」[resetfont][font size="22"]
才对。[l][r]
[r]
所以那具躯体里【必须被驱逐的存在】与我的共同点……[l][r]
也就是[font color="0xf08080"]"八种的生命"[resetfont][font size="22"]
这一部分，被送回了应去之地。[l][r]
[r]
[delay speed="60"]
那一瞬间，从祝福构筑的雾绘小姐躯体中，[r]
理应已完全驱逐了作为女神的存在。[l][r]
[r]
[delay speed="80"]
……若这番推测属实……[l][r]
[r]
[r]
雾绘小姐[wait time="500"]是我认识的人里最出色的演员。[p]
@layopt layer=message0 visible="false"
[wait time="1000"]
[bg storage=./hataneM.jpg time="4000" wait="true" wait="true" cross="false"]
@layopt layer=message0 visible="true"
[resetdelay]
关于雾绘小姐自杀原因的回忆，贤治郎先生一无所知。[r]
因为她一定……非常不愿让他知晓这些。[l][r]
[r]
[r]
[r]
[r]
[r]
[r]
[r]
[wait time="800"]
[delay speed="60"]
……这是[wait time="500"]唯有生前的她与我共同知晓的[wait time="500"]秘密记忆。[p]
#ituki
[resetfont]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
小纱罗[p]
#
@layopt layer=message0 visible=false
[clearfix]
[wait time="500"]
[bg storage=./inaka_m.jpeg time="3000" wait="true" wait="true" cross="false"]
[chara_show name="sarasa" left=360 top=-160 time=500 wait="false" face="normal"]
[chara_show name="ituki" left="-70" wait="true" face="normal" top="-160" time="500"]
;○坂
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……？怎么了？[p]

#ituki:tweet
刚才说的——暑假作业呀[p]
[fadeoutbgm time="3000"]
#ituki:smile
[resetdelay]
"在这个镇上"[wait time="500"]　之后　你本来想说什么的？[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" face="smile" time="10"]
#aki
啊　那个我也　很在意[p]
[chara_hide name="aki" pos_mode="false" time="10"]
[chara_show name="hino" top="-100" face="smile" time="10"]
#hino
哦！确实！一直都没机会问呢—[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=4000 volume=40]
[chara_hide name="hino" pos_mode="false" time="10" pos_mode="false"]
[chara_show name="sarasa" top="-160" face="normal" time="300"]
#sarasa
[delay speed="100"]
……………………………………[l][r]
在这个镇上”、[p]
[delay speed="60"]
#sarasa:closeEye
那位如蚕茧般[r]
拥有纯白肌肤的女神大人依然活着“[p]
#sarasa:smile
“她的名字　各位也都很熟悉[l][r]
正是御白姬“[p]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=40]
[resetdelay]
[chara_hide name="sarasa" time="10" pos_mode="false"]
[chara_show name="riki" face="smileCE" top="-100" time="10"]
#riki
[playse  volume="30" buf="2" storage="kaminari.ogg"]
[quake time="30"]
没错啊——！！[r]
你刚才难道是想做自我介绍吗——！？[p]
[chara_hide name="riki" wait="true" time="300"]
#
[delay speed="60"]
五个人的笑声同时响起。[p]
笑声毫无疑问在镇子上空回荡着，[l][r]
从群山中，[wait time="500"]带着清晰的轮廓传了回来。[p]
虽然大家都笑得开心，但谁都没有停下前往目的地的脚步。[r]
比起暑假期间，现在逃课出来反而更让人心跳加速。[p]
我们正奔跑在[wait time="500"]夏日之中。[p]
@layopt layer=message0 visible=false
[clearfix]
[mask time="2000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[bg storage=./himawari_1.jpeg time="1000" wait="true" wait="true"]
[mask_off time="2000"]
[wait time="2000"]
;s E走る

;○ひまわり畑
[chara_show name="riki" top="-100" face="smileCE" time="10"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#riki
[quake time="30"]
[font size="38"]
健治————！！！[p]
[chara_hide name="riki" wait="false" time="300" pos_mode="false"]
#
[resetfont]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[chara_show name="makado" top="-10" face="worry_ce" time="300" wait="false"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
———！　[l]
#makado:angry_ce
你们……！！在干什么，学校呢！？[p]
[chara_move name="makado" wait="false" left="-90" anim="true" wait="false"]
[chara_show name="hino" left="360" top="-60" face="smile" time="300"]
#hino
这是超级大逃亡哦！[r]
[resetdelay]
[anim name="hino" top="+=30" time="200"]
[anim name="hino" top="-=30" time="200"]
因为人家想来送行嘛[p]

#makado:worry_ce
[delay speed="100"]
………………………………………[l][r]
#makado:tweetLA_ce
………………………………………[p]
#makado:normal_ce
……………………………………
[resetdelay]
#makado:smileMini_ce
[wait time="500"]全員不良だな[p]
#
[delay speed="60"]
贤治郎先生[playse  volume="30" buf="0" storage="book.ogg" ]
把手中的行李放到地上，[r]
静静笑了。[p]
[resetdelay]
[chara_hide name="hino" time="100" wait="false" pos_mode="false"]
[chara_show name="aki" top="-60" face="normal" time="300" left="360"]
#aki
嗯 坏孩子其实也不错呢[r]
我还是第一次 从学校逃出来什么的[p]
#aki:smile
[delay speed="50"]
…………现在心还砰砰直跳呢！[r]
可能也有在这么热的天里奔跑的原因吧[l][r]
#aki:smileB
要是被那个人知道了会说什么呢　啊哈哈！[p]

#makado:normal_ce
……这样真的好吗？器乐堂他………………[p]

#aki:smileB
呵呵　好不好的…………[p]
#aki:normal
我最近啊　很想快点长大成人[r]
变成大人的话　至少就不用听小孩子的话了[p]
#aki:smileB
[delay speed="60"]
所以贤治郎先生也　尽管继续当你的优等生吧[wait time="500"][r]
然后　一起成为　了不起的大人吧[p]
#makado:smileMini_ce
…………这样啊。[r]
一起加油吧，我们彼此都是[p]
[chara_hide name="aki" time="500" wait="true" pos_mode="false"]
[chara_show name="hino" time="10" face="smile" top="-60" left="360"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[resetdelay]
太好了呢，大学那边看来能顺利解决！[r]
请继续努力直到取得好成绩！[p]
#makado:smile_ce
啊，谢谢你了日野。[l][r]
#makado:smileMini_ce
从你这里真的学到了很多呢，有事随时联系我[p]
#hino:tweet
[delay speed="100"]
……………………[l][r]
#hino:smile
……………………嗯，说的对呢，[p]
[delay speed="60"]
#hino:happy
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
当然！　我还有太多想了解的事情呢[r]
请告诉我学校发生的事，我等你分享哦！[p]
[chara_hide name="hino" time="500" wait="true" pos_mode="false"]
[chara_show name="riki" top="-50" left="340" time="300" wait="false" face="smileCE"]
#riki
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[resetdelay]
贤治郎～贤治郎～，我也要听！
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]　俺も連絡していい？[l][r]
#riki:normal
嘛、虽然我根本没什么想问你的啦～[p]

#makado:normal_ce
联系我倒没关系，[r]
但别总缠着叔叔说『绑架我吧』[r]
差不多该适可而止了。上次不还吓得发抖吗[p]

#riki:shame
切～真没劲～明明觉得是个优质猎物来着～[p]
#riki:tweetLA
[delay speed="60"]
…………………[l][r]
不过……这次你父亲的事，真是遗憾呢。[wait time="500"][r]
[resetdelay]
毕竟，早就已经死掉了吧？[p]
#riki:worry
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
居然照顾尸体好几年。警察都吓一跳吧！[r]
最后到底怎么处理的！？[p]

#makado
[delay speed="60"]
……………………[l]
#makado:lookAway_ce
妈妈也大吃一惊呢。[l][r]
……警察们倒是意外地通情达理，[r]
最后以原因不明的自然现象结案了……[p]
#makado:tweetLA_ce
————嗯。[r]
但从今往后我们家会[wait time="500"]逐渐回归正轨的。[p]
#makado:normal_ce
[resetdelay]
看着登利君，我才发现自己一直在逃避面对父亲[r]
尽是些令人醒悟的事。[r]
哥哥的事，我也希望他能好起来啊[p]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
#riki:shame
哈啊————，够了够了！[r]
再许愿也没啥用啊[p]
#riki:angry
那家伙的事，我和我的家人会好好考虑的。[l][r]
#riki:smile
其实我想拜托你啊，帮我找个离家出走的地方之类的，[wait time="500"]就是这类事吧，[l][r]
#riki:lookAway
[font size="22"]
嘿嘿……我这么说你是不是开始期待了？[p]
[resetfont]
#makado
[delay speed="100"]
……………………[p]
[resetdelay]
#makado:smileMini_ce
知道了，等你来东京的时候我会收留你的。[r]
有空来找我玩啊[p]
#riki:smileCE
[playse  volume="30" buf="0" storage="kansei.ogg"]
[anim name="riki" top="+=50" time="300"]
[anim name="riki" top="-=50" time="300"]
[delay speed="60"]
[font size="37"]
哇——真的吗——！？太棒啦——！！[r]
[resetfont]
我想去涩谷吃可丽饼！[p]
#makado:smile_ce
啊哈哈……[r]
车站前面臭得要死啊。[p]
[resetdelay]
[chara_hide name="riki" time="10" pos_mode="false"]
[chara_show name="ituki" top="-50" face="tweet" wait="false" left="360"]
#ituki
[delay speed="100"]
……………………[p]
#ituki:hate
啊、这啥啊。[wait time="500"][r]
[resetdelay]
这是在轮流说告别词吗？我可没想这样[p]

#makado:normal_ce
一树，[l]
[delay speed="100"]
#makado:lookAway_ce
…………我…………………[p]
[resetdelay]
#ituki:normal
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
别用酱字叫我[p]

#makado:bike_ce
[delay speed="100"]
…………[l][r]
树、树月先生[p]

#ituki
…………[p]
[delay speed="60"]
#ituki:hate
贤治郎先生和纱罗纱也是，[r]
都只会说些愚蠢的借口呢。[l][r]
白绢祭那时候的事，全都是树”……[p]
[delay speed="100"]
#makado:normal_ce
………啊啊……[p]
[mask time="1000" effect="fadeInRightBig"]
[bg storage="indoor/sitodrouka.jpg" time="10"]
[chara_hide_all]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '叔父'
[endscript]
[chara_show name="mokke" wait="false" time="100" top="100" face="oji"]
[mask_off time="300"]
#mokke
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[resetdelay]
[font size="36"]
诶！？！？！？！[r]
你这血淋淋的手是怎么回事！？！？[p]
[font size="22"]
[chara_move name="mokke" left="500" anim="true" wait="false"]
[chara_show name="makado" top="-10" face="lookAway_e" wait="true" time="300" left="-90"]
#makado
[delay speed="100"]
………………[l]木、[wait time="500"]木头……[p]
[resetfont]
#makado:sad
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
被木头刺中，[wait time="500"][r]
摔倒用手撑地时碰到了木头[p]

#mokke
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
[font size="38"]
木头！？[r]
Wood！？！？[p]
[chara_hide name="makado" time="300" wait="true" pos_mode="false"]
[resetdelay]
[resetfont]
而且纱罗纱后背全是血这又是什么情况！？！[p]
[chara_move name="mokke" left="60" anim="true" wait="false" time="600"]
[chara_show name="sarasa" face="closeEye_gs" top="-160" left="360"]
#sarasa
[delay speed="100"]
………木……[wait time="500"]木头。[p]
#sarasa:angry_gs
[playse  volume="20" buf="0" storage="sariin.ogg" ]
被木头划伤的。[r]
靠过去的地方……有棵树……[p]
[resetdelay]
#mokke
[anim name="mokke" top="+=60" time="150"]
[anim name="mokke" top="-=60" time="150"]
[playse  volume="30" buf="1" storage="garasu.ogg" ]
[font size="37"]
所以说那棵树到底在哪！？！[r]
我现在就去把它砍了！！[p]
[mask time="10"]
[chara_hide_all]
[chara_show name="ituki" top="-50" face="tweet" wait="true" left="360"]
[chara_show name="makado" left="-90" top="-10" face="normal_ce"]
[bg storage=./himawari_1.jpeg time="100" wait="true" wait="true"]
[resetfont]
#
[mask_off time="1000"]
#ituki
给我想个像样点的借口啦。[r]
这样下去你一辈子都会是个没用的废物呢[p]

#makado
……啊啊。[r]
谢谢你担心我。树月……[wait time="500"]同学。[p]
#makado:tweetLA_ce
[playse  volume="20" buf="0" storage="sariin.ogg" ]
我、[l]
#makado:closeEye_c
[delay speed="100"]
…………………………[wait time="500"][r]
[delay speed="60"]
#makado:smileMini_ce
我会努力让你认可我的[p]
#ituki:normal
[delay speed="100"]
…………………………[p]
[delay speed="60"]
#ituki:smileCE
[playse  volume="20" buf="0" storage="sariin.ogg" ]
呵呵[p]
#ituki:hate
[font size="38"]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[playse  volume="30" buf="3" storage="garasu.ogg" ]
闭嘴！！恶心的日本流行乐自慰男！[p]

#makado:shout_ce
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
！？……！？[r]
[resetfont]
[anim name="makado" left="-=10" time=50 ]
[anim name="makado" left="+=10" time=50 ]
[anim name="makado" left="-=10" time=50 ]
[anim name="makado" left="+=10" time=50 ]
咦………咦？哎……[wait time="500"]那……[p]
#
[chara_hide_all wait="true" time="10"]
[chara_show name="sarasa" top="-160" face="closeEye" wait="false" time="200" wait="true"]
#sarasa
[delay speed="60"]
一树……离别的时候，不可以说闭嘴啊[p]

#ituki
[playse  volume="20" buf="1" storage="sariin.ogg" ]
纱罗纱！　但是……[p]
#
[chara_hide name="sarasa" wait="true" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal" time="100"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal" time="100"]
#aki
[chara_show name="aki" top="-100" left="-150" wait="true" face="normal" time="100"]
你看　一树　接下来轮到纱罗纱了嘛[r]
今天就让给她说几句吧[p]

#riki:angry
就是啊—。这个夏天和贤治郎待最久的是志户田，[r]
要说寂寞的话他比我们更寂寞吧[p]

#hino:smile
毕竟是祭主大人和御白姬的最后分别了。[l][r]
#hino:happy
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="hino" top="+=60" time="200"]
[anim name="hino" top="-=60" time="200"]
嗯嗯，我们就默默拿着花成全他们吧！！[p]
[resetdelay]
#makado
没人要追究刚才那句骂人的话吗？[p]
[chara_hide_all wait="300"]
[chara_show name="ituki" left="140" face="hate" top="-160" wait="false" time="100"]
#ituki
给我闭嘴啦—[p]
[delay speed="80"]
#ituki:sad
[fadeoutbgm time="4000"]
……………………………………[l][r]
[delay speed="100"]
#ituki:tweet
……………………………………[p]
#ituki:normal
……………………………………[wait time="500"]嗯。决定了。[p]
#
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
树月慢慢走到离贤治郎先生很近的地方，[wait time="500"][r]
[playse  volume="15" buf="0" storage="sariin.ogg" ]
紧紧攥住了他的袖角。[p]
[delay speed="70"]
#ituki:tweet
我绝不会原谅你。[l][r]
#ituki:smile
所以你也不用原谅我，马门贤治郎[p]
#
少女留下这句话后，[r]
优雅地转身，———与他渐行渐远。[p]
@layopt layer=message0 visible=false
[clearfix]
#
[chara_hide name="ituki" wait="false" time="300"]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="1000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
;ＳE去っていく
[chara_show name="makado" top="-10" left="-90" wait="false" time="500" face="lookAway_ce"]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……四位眷属正隔着些许距离守望此地。[p]
[chara_show name="sarasa" face="smile" top="-50" left="360" wait="true" time="700"]
#sarasa
……贤治郎先生[p]
#makado
[chara_mod name="makado" face="normal_ce"]
[wait time="2000"]
#makado:smileMini_ce
纱罗纱[p]

#sarasa:smile
白绢祭……平安结束了吧[p]
#makado:normal_ce
[delay speed="100"]
――――――――[wait time="500"]
#makado:tweetLA_ce
[delay speed="70"]
不　或许不该说平安吧。[l][r]
今年的仪式成为契机，我们挖掘出了这座小镇的本质[r]
尤其是你……[p]
#makado:lookAway_ce
……[wait time="500"]都怪我太不中用，才让你不得不代替女神[p]

#sarasa:normal
贤治郎先生――――[p]
#
能感受到他比我更为敏感纤细的特质[r]
恍惚间听见他掌心里传来指甲崩裂的脆响。[l][r]
那指甲盖上还残留着狰狞的刺痕。[p]
[resetdelay]
#makado:closeEye_c
果然[wait time="500"]　无论如何都说不出「平安结束了」这种话[p]

#makado:tweetLA_ce
[delay speed="80"]
舍弃迄今为止的存在……[wait time="500"][r]
要取代女神这件事，究竟有多令人不安[p]
[delay speed="50"]
#makado:normal_ce
考虑到被束缚在这片土地上的前任御白姬的遭遇，[r]
你甚至能否离开这座八种小镇都——[wait time="500"]不得而知[l][r]
超自然现象对纱罗纱身体造成的影响也难以估量[p]
#makado:closeEye_c
[resetdelay]
会加速衰老吗，还是会产生精神异变？[r]
你的自我意识今后会不会在某处消失，[wait time="500"][r]
让你变成了谁都想象不到的存在。竟以这种方式收场……[p]
#makado:tweetB_ce
[delay speed="100"]
――――――[wait time="500"]抱歉[l][r]
#makado:tweetLA_ce
[resetdelay]
虽然已经说过很多次　但我还是回来了[r]
这次一定会好好承担起责任…………[p]

#sarasa
那个，贤治郎先生[p]
[fadeoutbgm time="3000"]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="40" buf="0" storage="sariin.ogg" ]
[image layer=0 folder="image" name="glass" storage="item/glass.png" width="460" x="270" y="107" time="800"]
[wse]
;アイテムスチル：コップ
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado:angry_ce
[delay speed="100"]
…………………………[l]
#makado:worry_ce
咦……这是？[p]

#sarasa:closeEye
[delay speed="60"]
还给您。我找到了相同的东西……[r]
请在那边的家里使用吧[p]
#
我强行把玻璃杯塞进了贤治郎先生的行李里。[p]
[free layer=0 name="glass" time="800"]
#makado:normal_ce
啊……[wait time="500"]您这么体贴专程送来，谢谢……[p]
#sarasa
非常感谢[p]

#makado
[delay speed="100"]
…………[p]
[delay speed="60"]
#sarasa
非常感谢[p]

#makado:worry_ce
[delay speed="100"]
……………………………………[l][r]
[resetdelay]
#makado:smile_ce
哈哈，总觉得，[wait time="500"]之前好像也进行过这样的对话呢……[p]

#sarasa
[delay speed="60"]
因为，[wait time="500"]这样就没问题了吧[p]

#makado:worry_ce
咦？[p]

#sarasa:normal
还是说…[wait time="500"]您依然在担心我会改变呢？[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=8000 volume=50]
[chara_face name="makado" face="smileSP_ce" storage="chara/makado/trueEye_Cap/smileSP.png"]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado:tweetLA_ce
…………[l]
#makado:smileSP_ce
真厉害啊……[wait time="500"]你…………[p]

#sarasa
请不要太过害怕。我肯定不会让您担心的[p]
[delay speed="50"]
#sarasa:closeEye
而且……前任的她，也绝对不是……[wait time="500"][r]
什么超出人类理解的可怕存在啊[p]

#makado:worry_ce
诶？怎么会，可是那家伙……[p]
#makado:lookAway_ce
[resetdelay]
……那是个一直处心积虑想要夺取自己子孙身体的怪物啊。[r]
仅仅为了这个目的，就用暴力操控着收集来的眷属……[p]

#sarasa:normal
这些行动的、规律性――[l][r]
#sarasa:smile
[playse  volume="20" buf="0" storage="sariin.ogg"]
[delay speed="60"]
……在规则之中，存在着能让人联想到她心意的东西[p]

#makado:normal_ce
………………………………[l][r]
[resetdelay]
#makado:smileMini_ce
这是最后的推理了。[wait time="500"]好，让我们来思考吧[p]
#
[delay speed="60"]
我朝着贤治郎先生点了点头。[p]

#sarasa:normal
在我们之间，[r][font color="0xf08080"]
明明是世代相传、一直仰仗的重要情报[resetfont]……[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]即便在御白姬传说[resetfont]中也未曾记载
[wait time="500"]　[font color="0xf08080"]即便在白绢祭的起源故事中也未曾记载[resetfont][r]
其实存在着与诅咒毫无关联的条件对吧[p]
[chara_mod name="makado" face="lookAway_ce"]
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=false
@layopt layer="message1" visible="true"
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
从最初就存在的诅咒条件中，
[font color="0xBB3E50" face="serif" shadow="0xffffff"]御白姬传说[font color="0x000000" face="serif" shadow="0xffffff"]
又与[r]
[font color="0xBB3E50" face="serif" shadow="0xffffff"]白绢祭起源的故事[font color="0x000000" face="serif" shadow="0xffffff"]
完全无关的是哪一项？[r]
[glink color="btn_12_black" target="*but" text="御黑祟会诅咒人心的脆弱之处" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*good" text="知晓绢布被毁者将遭受诅咒" width="20" x="430" y="60" ]
[glink color="btn_12_black" target="*but" text="御白姬的眷属将遭受诅咒" width="20" x="330" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*but
;-------------------------------------------------------------------------------
@layopt layer=message1 visible=false
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
#
@layopt layer=message0 visible=true
[current layer="message0"]
[position vertical=false]
不对…………[wait time="500"]错了。[r]
这种时候可不能选错。[p]
@jump target="*loop"
;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
@layopt layer=message1 visible=false
#sarasa:closeEye
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
@layopt layer=message0 visible=true
[current layer="message0"]
[position vertical=false]
是的[p]
#sarasa:angry
先代御白姬大人，一直……[p]
[font color="0xf08080"]知晓绢布已消失[resetfont][wait time="500"][r]
即[font color="0xf08080"][font size="36"]仅允许解放御黑眷属[resetfont]之人[r]
持续施加着诅咒[p]

#makado:normal_ce
啊……确实。[p]
#makado:tweetLA_ce
[resetdelay]
战争时期绢布燃烧事件的报道里也有相关记载，[r]
就连我也早就把这个条件列为重要参考依据了[p]

#sarasa:normal
这个法则……[l][r]
#sarasa:closeEye
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="70"]
御白姬在[font color="0xf08080"]御黑眷属尚未存在的时代犯下的过错[resetfont]所[r]
[resetdelay]
蕴含着她对历史重演的恐惧[p]

#makado:worry_ce
[delay speed="50"]
恐惧……？你在说什么啊。[p]
#makado:closeEye_c
[delay speed="80"]
说什么"不存在的时代"这种话，[wait time="500"][r]
御黑眷属本就是虚构的存在――[p]

#makado:normal_ce
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……！[r]
[font size="38"]
是在『御白姬传说』被杜撰之前[resetfont]的意思吗！[p]

#sarasa:normal
是的。[p]
[mask time="300"]
[chara_hide_all]
[delay speed="50"]
[bg storage="still/den_27.png" time="1000"]
[mask_off time="10"]
[playse  volume="70" buf="1" storage="punch.ogg" ]
御白姬在明治初年企图占据亲生女儿的躯体时[r]
因操控眷属而被封印，[p]
[bg storage="still/den_28.png" time="1000" wait="false" cross="false"]
之后她的妻子与两个女儿三人，[wait time="500"][r]
「作为「怪物家族」在城镇中遭受迫害[p]
随之而来的是――[r]
她亦经历了作为其手足的眷属集团『狮心教』的没落[p]

这段经历让她[r]
对在无御黑眷属之地施展诅咒产生了[r]
变得畏惧起来了[p]
#
[fadeoutbgm time="3000"]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=page.ogg volume="50"]
[bg storage="still/den_19.png" time="3000" wait="true" cross="false"]
[wait time="4000"]
@layopt layer=message0 visible=true
[delay speed="70"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font size="22"]
为了不让自己的本性再次暴露[l][r]
[r]
得以持续栖身于『童话』的庇护之中[l][r]
[r]
[r]
[r]
[resetdelay]
所以才如此谨慎[r]
[r]
[r]
【解除了封印】只有掌握着这类情报的眷属[r]
才没有出手[p]
[resetfont]
[playse storage=page.ogg volume="50"]
@layopt layer=message0 visible=false
[mask time="3000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[free_filter]
[wait time="1000"]
[chara_show name="sarasa" top="-50" face="closeEye" wait="true" left="360"]
[chara_show name="makado" left="-90" top="-10" face="lookAway_ce"]
[bg storage=./himawari_1.jpeg time="100" wait="true" wait="true"]
[mask_off time="1000"]
[wait time="2000"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
[delay speed="80"]
…………………………………………[l][r]
#makado:tweetLA_ce
一切都是为了多增加一个人类成为眷属……吗[p]

#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[resetdelay]
――或许也有这方面的原因吧[p]
[delay speed="50"]
#sarasa:normal
但更重要的是……[wait time="500"][r]
我想他一定最想守护家族的荣誉。[p]
尤其是对那位[wait time="500"][r]
赐予『御白姬』之名的女性――[p]

#makado:normal_ce
[delay speed="60"]
………………………[p]

#sarasa:worryLA
她也是那种……所谓拥有祈愿”的生命，[r]
这件事我一直想告诉贤治郎先生[p]
#sarasa:closeEye
………………………………[l]
#sarasa:worry
………………抱歉。[r]
我是否、[wait time="500"]冒犯到你了？[p]

#makado:lookAway_ce
[resetdelay]
不会。你做的事怎么会让我不高兴呢[p]
#makado:sad_c
[delay speed="50"]
但我不像纱罗纱那样，对那位御白姬抱有感情。[l][r]
只是、[wait time="500"]觉得……这样啊……[p]
[fadeoutbgm time="3000"]
#sarasa:normal
[delay speed="100"]
……………………………………[l]
#sarasa:smile
没关系。[l][r]
我很高兴，即便是这样[p]
#
[delay speed="60"]
我朝着贤治郎先生的方向，露出了笑容。[l][r]
真的，就像发生在自己身上一样开心。[p]
就在我们这样交谈的时候，[r]
从山间吹来的风掠过向日葵花田，[wait time="500"]几秒钟后。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="100"]
――――――――[delay speed="60"]贤治郎先生身后，道口的警报声突然响起。[p]
#makado:angry_ce
[fadeinbgm storage=sicilienne.ogg loop=true time="3000" volume="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
啊……！[p]
#makado:bike_ce
不好，得走了。[r]
下一班就赶不上从名古屋出发的车了[p]
#
[resetdelay]
贤治郎先生慌忙拎起脚边的行李。[p]
[chara_hide_all time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[chara_show name="riki" face="smileCE" top="-100" time="800" wait="false"]
#riki
[delay speed="60"]
贤治郎——下次见啦！[p]
[chara_hide name="riki" wait="true" time="1500"]
[chara_show name="aki" top="-100" face="normal" time="800"]
#aki
保重啊[p]
[chara_hide name="aki" wait="true" time="1500"]
[chara_show name="hino" top="-100" face="smile" time="800"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
祝你武运昌隆——！！[p]
[chara_hide name="hino" wait="true" time="1500"]
[chara_show name="ituki" top="-160" face="smileCE" time="800"]
#ituki
别回来啦♡[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="ituki" wait="true" time="1500"]
#
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible="true"
[font size="22"]
[delay speed="100"]
黄黑相间的道闸缓缓落下，[l][r]
[r]
[r]
贤治郎先生[wait time="500"]朝着车站检票口跑去。[p]
[resetfont]
#sarasa
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
――[l]………………………………[l][r]　[wait time="500"]
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="100"]
[font size="36"]賢治郎さん！！[p]
[resetfont]
[clearfix]
#
@layopt layer=message0 visible=false
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="2000"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible="true"
[font size="22"]
我追上去，用双手紧紧抓住他的手。[l][r]
[r]
[r]
[r]
[r]
[wait time="500"]
他转过头来。[p]
@layopt layer=message0 visible="false"
[chara_show name="makado" top="-10" face="normal_ce" time="1500" wait="true"]
#makado
[wait time="2000"]
[resetfont]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
@layopt layer=message0 visible="true"
[resetdelay]
怎么了？[p]
#sarasa
…………[p]

#sarasa
[delay speed="100"]
………………………………[r]
………………………………[p]
[filter blur="4"]
……………………………………………………………………[r]
……………………………………………………………………[p]
[free_filter]
[delay speed="60"]
#sarasa
这个夏天结束之后，[wait time="500"]贤治郎先生也……[l][r]
我坐旋转木马的时候，[wait time="500"]你会看着我吗[p]

#makado
………………………………[l][r]
#makado:smileMini_ce
啊啊，当然[p]

#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[resetdelay]
我[wait time="500"]　一定会和一树一起去海边，[r]
也绝对要履行和你的约定[p]

就算成为女神[wait time="500"]　也不想忘记自己的祈祷和愿望[p]

#makado:normal_ce
纱罗纱[p]
#makado:lookAway_ce
[delay speed="100"]
………………………………[p]
#
[resetdelay]
#
贤治郎先生转身面向我。[p]
[delay speed="100"]
#makado:smileMini_ce
――――――――[wait time="500"]
#makado:smile_ce
你喜欢这个小镇吗？[p]
#
[resetdelay]
我毫不犹豫地回答。[p]

#sarasa
喜欢！[wait time="500"]　因为――[p]
@layopt layer=message0 visible=false
[clearfix]
#
[mask time="3000"]
[chara_hide name="makado" time="10"]
[fadeoutbgm time="2000"]
[bg storage=./still/epi.png time="10"]
[wait time="4000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=50]
[wait time="3000"]
#sarasa
[mask_off time="3000"]
[delay speed="70"]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
大家　都在这座小镇里――――[r]
因为我们是无可选择地来到这个世界的！[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage=./still/epi2.png time="800" cross="false" wait="true"]
[wait time="6000"]
[mask time="5000"]
[bg storage="still/den_29.png" time="300" wait="true"]
[wait time="2000"]
[fadeoutbgm time="4000"]
[wait time="4000"]
[mask_off]
[playse storage=page.ogg volume="50"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="50"]
蚕在死亡时，[wait time="500"]会怨恨人类吗？[p]

作为仅有数日生命的生灵破茧而出的瞬间，[r]
它们望着自己洁白的翅膀，[wait time="500"]　究竟在思索什么呢？[p]
[delay speed="100"]
而我，[p]
[delay speed="70"]
衷心期盼着那无依无靠的身影[wait time="500"][r]
能够沐浴在祈祷与祝福之中。[p]

请把你的故事说给我听吧。[r]
然后……[p]
无论以何种方式坠落于这个世界[wait time="800"][r]
请你一定[wait time="500"]　不要放弃自己的生命。[p]
[delay speed="100"]
[wait time="500"]――――――――――――紀伊マリガン[p]
[cancelskip]
#
[playse storage=page.ogg volume="50"]
[mask folder="bgimage" graphic="still/epilogue.png" time="3000"]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@hidemenubutton
[wait time="3000"]
[filter grayscale="100"]
[font size="40"]
[wait time="2000"]
[mask_off time="3000"]
[wait time="2000"]
[playbgm storage=gymnopedies2.ogg volume=50]
[wait time="1000"]
[mask]
[wait time="1000"]
[r][r][r][r][r]　　　　　　　　 回顧、来ぬ
[resetdelay]
[mask_off time="2000"]
[wait time="4000"]
[mask time="3000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/kami_start.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【作成ツール・プラグイン】[r]
[font size="22"]
[r]　ティラノスクリプト（https://tyrano.jp/）さま[r]
[r]　hororo（http://hororo.wp.xdomain.jp/）さま[r]
[r]　ねこの（https://milkcat.jp/）さま[r]
[mask_off]
[wait time="2000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/hold_2.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="3000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【画像素材】[r]
[font size="22"]
[r]　COCOON（http://cocoon.daa.jp）さま[r]
[r]　ぱくたそ（www.pakutaso.com）さま[r]
[mask_off]
[wait time="2000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/hebi_2.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【画像素材】[r]
[font size="22"]
[r]　きまぐれアフター さま[r]
[r]　ぐったりにゃんこ さま[r]
[mask_off]
[wait time="4000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/first_contact2.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【画像素材】[r]
[font size="22"]
[r]　Paper-co（http://free-paper-texture.com/）さま
[mask_off]
[wait time="4000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/hino_ticket.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【音声素材】[r]
[font size="22"]
[r]　On-Jin ～音人～（https://on-jin.com/）さま[r]
[r]　ポケットサウンド（https://pocket-se.info/）さま
[mask_off]
[wait time="4000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/mokke_3.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【音声素材】[r]
[font size="22"]
[r]　効果音ラボ さま[r]
[r]　フリーBGM DOVA-SYNDROME さま[r]
[mask_off]
[wait time="4000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/yakiniku1.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【シナリオ・演出】[r]
[font size="22"]
[r]　荒々ツゲル[r]
[mask_off]
[wait time="4000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/ituki_te1.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="1000"]
[bg storage="still/ituki_te2.png" cross="false"]
[wait time="1000"]
[mask time="1000"]
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
@layopt layer=message0 visible="true"
[font size="40"]
[r]
[r]
[r]
【システム】[r]
[font size="22"]
[r]　荒々ハイケン[r]
[mask_off]
[wait time="4000"]
[mask time="1000"]
[er]
@layopt layer=message0 visible="false"
[bg storage="still/omotya.png" time="10" wait="true"]
[wait time="1000"]
[mask_off]
[wait time="2000"]
[mask time="1000"]
@layopt layer=message0 visible="true"
[bg storage="still/den_29.png" time="10" wait="true"]
[wait time="500"]
[font size="40"]
[r]
[r]
[r]
【企画】[r]
[font size="22"]
[r]　らいてうファミリー[r]
[mask_off]
[wait time="4000"]
[mask time="4000"]
[er]
@layopt layer=message0 visible="false"
[free_filter]
[bg storage="still/dance3.png" time="10" wait="true"]
[wait time="2000"]
[mask_off time="8000"]
[wait time="3000"]
[bg storage="siro1.png" time="8000" wait="true"]
[fadeoutbgm time="5000"]
[wait time="6000"]
@jump storage="first.ks"
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
;--------------------------------------------------------
;【回顧、来ぬ】kaiko_kinu Ver5.00　（C）らいてうファミリー（https://raiteusisters.wixsite.com/kaikokinu）

;本ゲームは、らいてうファミリーが企画し制作したフィクション作品です。
;実在する人物、団体等には一切関係がありません。

;■ガイドライン■
;本ゲーム内コンテンツ全ての再配布、抽出・流用・改造を禁じます。
;○本ガイドラインは予告なく変更・追加される場合がございます。あらかじめご了承ください。​​

;お借りした素材、モチーフ以外の「回顧、来ぬ」にまつわる著作権は、すべてらいてうファミリー（以下、制作者）
;が所有しております。

;【プレイ動画について】
;・是非感想や、考察など、いろいろしていただけたらと思います。
;・本ゲームに関連する動画を投稿される際には、
;　タイトル・説明文のいずれかに「回顧、来ぬ」と表記をしていただけると幸いです。
;・動画投稿などに関するご連絡は任意で結構です。

;【二次創作について】
;・作品への誹謗中傷目的や、舞台・モチーフとなった題材が尊厳を損なうような創作はおやめください。
;・公序良俗に反する創作活動はおやめください。
;・本作品は様々な素材をお借りして制作しております。ゲーム内の画像・音声等の素材を利用した作品制作は、
;　お断りいたします。
;​・許可なき商業利用、営利目的での二次創作は禁止いたします。
;・本ゲームの制作者を騙るような活動はおやめください。

;【その他】
;以下の行為を禁止いたします。
;・公序良俗に反するゲームの利用
;・本ゲームの商業利用
;・制作者の許可のない翻訳
;・作品内データの抽出・流用・改造


;■免責事項■

;本ゲームによって損害・不利益・事故等が
;発生した場合でも、らいてうファミリーは一切の責任を負いません。

;■クレジット■

;【作成ツール・プラグイン】

;ティラノスクリプト（https://tyrano.jp/）さま
;hororo（http://hororo.wp.xdomain.jp/）さま
;ねこの（https://milkcat.jp/） さま

;【画像素材】

;COCOON（http://cocoon.daa.jp）さま
;ぱくたそ（www.pakutaso.com）さま
;きまぐれアフター さま
;ぐったりにゃんこ さま
;Paper-co さま

;【音声素材】

;On-Jin ～音人～（https://on-jin.com/）さま
;ポケットサウンド（https://pocket-se.info/）さま
;効果音ラボ さま
;フリーBGM DOVA-SYNDROME さま

;■連絡先■

;・メール
;raiteusisters●gmail.com
;（●→＠へ変換をお願いします）

;・Twitterアカウント
;@raiteu00
;---------------------------------------------------------------------
