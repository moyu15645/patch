;第1章『可、孵化』
;一日目、途中から
;-------------------------------------------------------------------------------
[bg storage="school/rouka_m.jpg" time="100"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=30]
#
;ＳＥ歩く
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[mask_off]
[chara_show name="riki" top=-100]
#riki:tweetLA
太久没去图书室连地方都忘了—。[r]
知道在哪儿吗？[p]
#
[delay speed="50"]
我朝着登利点了点头示意。[p]
#riki:angry
[resetdelay]
阿奇那家伙太蛮横了—。[r]
明明不是班长　却对我们下达强制调班命令什么的—[p]
#riki:worry
嘛，不过……现在那个班长也是那副德性—。[r]
树月那家伙……[p]
#riki:shame
[anim name="riki" top="+=60" time="200"]
[anim name="riki" top="-=60" time="200"]
哈—啊，虽然很可怜　但也没办法呢—！[r]
家里发生的那些破事儿 不管我怎么折腾—[r]
都他妈逃不掉干系啊[p]
#riki:smileCE
等等[wait time="400"]啊——！图书室！！[r]
居然真的还在学校里面啊——！！[p]
#
登利在走廊上跑了起来。[p]
[chara_hide name="riki" wait="false"]
;ＳＥ走る
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[mask time="100"]
[playse  volume="100" buf="0" storage="book.ogg"]
[wse]
[mask_off]
[quake time="30"]
;ＳＥ笛デカ音
[chara_show name="riki" face="wow" top="-100" time="10"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
#riki:wow
哇靠！[stop_kanim name=riki][p]
[chara_show name="kawa" time="1000" face="smile" top="-10"]
#kawa:smile
喂喂— 登利— 别跑啊— 走廊上—[r]
不然下次比赛就让你光脚上场啊—[p]
#riki:sad
那……[p]
#riki:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
出现了啊川神！[r]
区区两米程度的违反校规就别滥用职权了！[p]
#kawa:normal
给我好好叫川铃木老师啊—。[r]
被钉鞋踩到脚背可是超痛的哦—。会流血的哦—[p]
#riki:sad
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
可恶—、搞什么啊。明明是顾问却只是个副的……！[p]
#riki:angry
就算队员都变成优等生[r]
小谷坂足球部就是弱鸡啊！[p]

;ＳＥ笛吹く
#kawa
[delay speed="70"]
……………………………………[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
#kawa:whistle
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[resetdelay]
[font size="50"]
哔——————！！！[p]
#riki:shame
呜哇————！[p]
#kawa:whistle
[quake time="30"]
哔——————！！！[p]
[resetfont]
[chara_hide_all time="10" wait=true]
#
川铃木一边逼近登利，[r]
一边用惊人的肺活量持续吹着哨子……[r]
每当对方试图逃跑就穷追不舍地抓回来。[p]
[chara_show name="riki" top=-100 time="10"]
#riki:wow
[quake time="30"]
啊啊————！[r]
耳朵————！！　耳朵————！！！[p]
[chara_hide name="riki" pos_mode="false" time="10"]
[chara_show name="kawa" top=-10]
#kawa:smile
哈哈哈。看小鬼痛苦的样子真有意思啊[p]
[chara_hide name="kawa" pos_mode="false" time="10"]
[chara_show name="riki" top=-100 time="10"]
#riki:sad
呜呜、[r]
为什么这种缺德教师能堂而皇之霸占教育岗位！！[r]
教育委员会都在干什么！[p]

;ＳＥ笛吹く
[chara_hide name="riki" pos_mode="false" time="10"]
[chara_show name="kawa" face="whistle" top=-10 time="200"]
#kawa:whistle
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="50"]
哔————！！！[p]
[chara_hide name="kawa" pos_mode="false" time="10"]
[chara_show name="riki" top=-100 time="10"]
#riki:wow
[quake time="30"]
早点被告上法庭吧！[p]
[resetfont]
[chara_hide name="riki" pos_mode="false" time="10"]
[chara_show name="sarasa" face="normal" wait="false" top=-160 left="350" time="300"]
#sarasa:normal
（川铃木老师很喜欢”这种”指导方式呢）[p]
[chara_show name="riki" top=-100 face="angry" left="-70" time="10"]
#riki:angry
志户田你也好歹帮下忙啊……[r]
至少装出担心的样子啊！？[p]
[chara_show name="kawa" face="shame" wait="false" top=-10 time="100"]
#kawa:shame
哈哈，志户田真是个坚强的学生呢[p]
[fadeoutbgm time="2000"]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥガラガラ
[chara_hide_all time="300"]
[playse  volume="100" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="makado" face="tweet" top=-40 time="100"]
#makado:tweet
[delay speed="50"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
那个…发生什么事了吗？[p]
[chara_hide name="makado" pos_mode="false" time="10"]
[chara_show name="sarasa" top=-100 time="10"]
#sarasa:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
！[p]
[chara_move name="sarasa" left="350" top="-100" wait="false" anim="true"]
[chara_show name="makado" face="worry" top=-60 left="-70" time="100" wait="false"]
#makado:worry
声音都传到图书室里面了。[r]
虽然是在指导教学，但图书管理员都起疑了[p]
[fadeinbgm storage=sicilienne.ogg loop=true time=6000 volume="30"]
#
贤治郎先生……！？为什么会在小谷坂学园——[p]
#makado:normal
……？[l][r]
#makado:wowCM
！[wait time="500"]　纱罗纱亲[wait time="200"][er]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
[chara_hide_all time="10" wait=true]
[chara_show name="kawa" face="whistle" top=-40 time="10"]
#kawa:whistle
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="50"]
哔————！！[p]
[chara_show name="makado" face="wow" top=-40 time="10"]
[resetfont]
#makado:wow
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
诶！？连我也！？[p]
#kawa:smileW
[resetdelay]
光头小子不准进校门。[r]
乖乖回寺庙去吧～[p]
#makado:angry
这、这种校规[r]
四年前根本不存在对吧！？[p]
#kawa:normal
切。毕业生啊……[p]
#
[fadeoutbgm time="3000"]
;ＳＥ去っていく
[chara_hide name="kawa" pos_mode="false" time="500"]
[playse  volume="50" sprite_time="0000-0500" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0500" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[wait time="2000"]
#makado:bike
现在学校里可是有位风格大变的老师任教呢……[l][r]
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
#makado:tweet
啊、还有我不是和尚是神社世家的！[p]
[chara_show name="riki" top=-100 time="200" wait="false" left="350"]
#riki:tweetLA
川神这人根本听不进人话，没用的[p]
#makado:closeEye
……[p]
#riki:normal
[delay speed="50"]
喂喂。大哥你是志户田的熟人吗？[r]
刚才不是喊名字了嘛[p]
#makado:normal
啊、嗯。是又怎样……[p]
#riki:smileCE
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[resetdelay]
嘿～什么、什么关系啊？难不成是SP？[p]
#makado:tweet
……大概算是当保镖之类的吧。[r]
我是今年白绢祭的祭主啦 可不是和尚哦[p]
#riki:smileCE
保～镖～？牛逼啊。不愧是志户田。[r]
果然会经常遇到绑架什么的吗？[p]
#makado:tweetLA
[delay speed="60"]
……所以才需要我来防止这种事发生[p]
#riki:smileCE
[resetdelay]
嘿～真羡慕[p]
#riki:smile
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
哈哈！我是登利力～[r]
志户田那个关系一般的同班同学！[r]
请多关照啊小和尚！！[p]
[chara_move name="riki" left=-520 anim="true" time=700 wait="false"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[chara_hide name="riki" pos_mode="true" time="10" wait="true"]
;ＳＥ扉を締める
[playse  volume="100" buf="0" storage="hikidopen2.ogg" ]
[wse]
#makado:normal
……[l]
#makado:closeEye
嗯。[r]
纱罗纱你还有这么活泼的同学啊[p]
[delay speed="50"]
#makado:lookAway
我是这里初中部毕业的。今天来看乡土资料。[r]
八种町内关于奥露姆克的情报[r]
我觉得还是查清楚比较好……[p]
#makado:tweetLA
……但是，[r]
果然像样的资料似乎都已经借出去了啊。[r]
我打算先等那些资料归还[p]
#sarasa
原来是这样啊……[p]
[fadeoutbgm time="3000"]
#makado:normal
[delay speed="70"]
………………[l]喂，[r]
有件事，我有点担心——[p]
#makado:lookAway
…………你后来和宗方家的人……[r]
还有镇上的居民　都没发生什么事吗？[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg"]
——那之后，[p]
;暗転
[mask time="5000"]
;ＳＥ夜の夏の森
[fadeinbgm storage="bigriver.ogg" loop="true" time="4000" volume="30"]
[chara_hide name="makado" time="1000"]
[bg storage="brack.png" time="100" cross="true"]
[delay speed="50"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[mask_off time="2000"]
#
……………………………………[p]
#makado
…………………啊、纱罗纱！[r]
总算找到你了！[p]
……没受伤吧？对不起、让你一个人追过去……[r]
我、不知道为什么好像晕过去了[p]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
那个、雾绘呢？[l][r]
跟丢了也无所谓、只要知道她往哪个方向去就行……[p]
[delay speed="70"]
……………？[wait time="500"]　……怎么了？[p]
[delay speed="50"]
那家伙、是从这座桥过去的吗？[r]
对岸那边很久没人打理已经相当荒芜——[p]
[delay speed="70"]
…………………[l][r]
喂。[wait time="500"][r]
该不会、是下面？[p]
#
……………[p]
[delay speed="50"]
#makado
——不、明白了。[r]
我现在送你回家。能站起来吗？[p]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="2000"]
[playse storage="phone.ogg" loop="true" volume="60"]
[wait time="2000"]
[stopse]
;ＳＥ電話
[resetdelay]
#makado
喂喂。我是马门。[l][r]
…………听说雾绘从四ツ山的桥上掉进河里了……[p]
是的。天亮前行动太危险了。[r]
因为下雨河水涨了很多。[r]
我现在也往回赶，请先召集一下人手[p]
[delay speed="70"]
………………不，是我……那个。[p]
[resetdelay]
雾绘闯进了志户田先生家里。[r]
刚好被那家女儿发现，给我打了电话……[r]
我现在先送她回去，之后马上赶过来[p]
好的，好的…………[r]
不过说到底，[p]
[delay speed="60"]
她只是被我们牵连进来的无辜者。[r]
我会亲自向她父母道歉的[p]
实在、[wait time="500"]没能帮上忙，非常抱歉。[p]
#
[resetdelay]
[fadeoutbgm time="2000"]
[mask time="2000"]
[bg storage="school/rouka_m.jpg" time="1500" cross="true"]
[chara_show name="sarasa" left="360" top="-100" time="300" wait="false" face="closeEye"]
[chara_show name="makado" face="normal" left=-70 top="-60" time="300" wait="false"]
[fadeinbgm storage=sicilienne.ogg loop=true time=8000 volume="30"]
[mask_off time="3000"]
#sarasa:closeEye
………………………………[p]
#sarasa:normal
这几天里，什么都没……[r]
只和警方那边谈过一次…………[p]
[resetdelay]
#makado:smileMini
嗯，这样啊……那就好。[r]
既然没被任何人说什么的话[p]
#makado:normal
[delay speed="60"]
——真是对你做了很过分的事啊。[r]
从一开始就该让你远离这件事的[p]
#makado:tweetLA
没想到被御黑家诅咒的人[r]
会因精神错乱而选择自杀。[r]
可我却如此轻率地将你卷了进来……[p]
#makado:lookAway
…………………………………………[r][wait time="500"]
#makado:closeEye
不、抱歉[p]
#makado:tweet
今后我会独自寻找解决的办法。[l][r]
#makado:normal
所以直到白绢祭当天……[r]
希望你能暂时忘掉御黑家的事[p]
#sarasa:normal
[playse  volume="20" buf="0" storage="sariin.ogg" ]
………………………………[p]
#
[link target="*unaduku"]【１】点头[endlink][r]
[link target="*muri"]【２】回答“不行”[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*unaduku
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#
我将这番话语……未经思索地咀嚼，吞咽了下去。[p]
#makado:tweetLA
……啊啊。那就拜托了[p]

@jump target="*muriowari"
;-------------------------------------------------------------------------------
*muri
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#sarasa:worry
……我觉得不行[p]
#makado
……诶[p]
[delay speed="60"]
#sarasa:worryLA
…………[l][r]
#sarasa:worry
你说因为我扮演御白姬才会被盯上……。[p]
#sarasa:closeEye
说这句话的人，是贤治郎先生啊[p]
#makado:wowCM
…………[l][r]
#makado:wow
啊，是这样啊――[p]
#makado:tweetLA
…………………………是这样啊。[p]
#sarasa:closeEye
……[p]
[delay speed="50"]
#makado:tweetLA
――抱歉，[r]
从刚才开始就完全慌了神[l][r]
无论如何都忘不掉雾绘的事……[p]
#makado:closeEye
…………嗯 不[p]
#makado:smile
简直像在给自己下咒一样[r]
已经得出的结论 可不能忘记啊[p]
#makado:smileMini
谢谢[p]
[resetdelay]
#sarasa:closeEye
……非常感谢[p]
#makado:worry
诶？[p]
#sarasa:closeEye
……非常感谢[p]
#makado:tweet
……[l]
#makado:tweetLA
居、居然这么郑重地道谢两次[p]
#sarasa:worry
[delay speed="60"]
对我来说……这已经是第二次得救了[p]
#makado:wowCM
啊……不、[l][r]
#makado:closeEye
那种事根本不算帮忙，别放在心上[p]
#sarasa:worryLA
因为你救了我两次……所以我也要道谢两次[p]
#makado:tweet
…………………………[p]
#makado:smileMini
哈哈……真是一板一眼呢。[r]
不过下次开始，一次性道谢就行啦。[p]
要是每件事都分开道谢的话，[r]
我就算道多少次歉都不够啊[p]
#makado:normal
[resetdelay]
如果今后再有什么事，记得立刻联系我。[r]
希望能依靠能够视见并祛除诅咒的你[p]
#makado:tweetLA
让我们共同将白绢祭顺利结束吧。[r]
为了让你能卸下作为御白姬的职责[p]

@jump target="*muriowari"
;-------------------------------------------------------------------------------
*muriowari
;-------------------------------------------------------------------------------
;ＳＥ学校のチャイム
#
[playse storage=bell.ogg sprite_time="0000-7000" volume="5"]
[chara_mod name="makado" face="lookAway"]
[wse]
[resetdelay]
#makado:normal
……说起来，纱罗纱今天是要上学的日子吧。[r]
果然你们也拿到了《小镇与我”的课题作业吗？[p]
[chara_mod name="sarasa" face="normal"]
#
我向贤治郎先生点头示意。[p]
#makado:smileMini
这样啊。和我当年在校时完全没变呢。[p]
虽说初中生能调查到的事情终究有限，[r]
这是了解自己所居住小镇的绝佳机会呢。[p]
你选的什么课题？[p]
#sarasa:normal
我……是关于哈种町的昆虫，蚕……[p]

;ＳＥ扉があく
[playse  volume="100" buf="0" storage="hikidopen2.ogg" ]
[chara_show name="riki" face="wow" top="-100" left="-550" time="10"]
[chara_move name="riki" top="-100" left="150" anim="true" wait="false"]
[chara_mod name="sarasa" face="wow"]
[chara_mod name="makado" face="wowCM"]
[font size="45"]
#riki:wow
[playse  volume="30" buf="1" storage="kaminari.ogg"]
[quake time="30"]
[quake time="30"]おいー！　志戸田ーーー！[r]
糟了出大事了！[p]
[resetfont]
[chara_move name="sarasa" left="500" anim="true" wait="true"]
[wait time="0"]
[chara_move name="makado" left="-150" anim="true" wait="true" time="300"]
#makado:tweet
啊，你是……登利君对吧。怎么了？[p]
#riki:angry
还问怎么了出大事了啊！[r]
[delay speed="70"]
我刚想借本写着养蚕的书就发现……[p]
[resetdelay]
#riki:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]ほっとんど借りられちゃってんだよ！　もう！　既に！[p]
[chara_mod name="sarasa" face="normal"]
#makado:normal
啊……果然是这样啊。[r]
这个时期，能当参考资料的书籍可是抢手货啊[p]
#riki:angry
诶——！？真的假的！[r]
早知道的话我也早点去借了啊！[p]
#makado:tweet
喂喂，整个年级的学生同时[r]
都在做同一个课题的调研学习啊[p]
虽说选题方向可能略有不同，[r]
资料被抢光也是理所当然的[p]
#riki:angry
哈啊！？这种事自己不仔细想想怎么知道啊！[p]
#makado:closeEye
……你都没好好考虑过吧[p]
#riki:shame
啊——真是的。我最讨厌这种事了——[r]
在学校还要未雨绸缪拼命努力什么的[p]
#riki:tweetLA
志户田你打算怎么办——？[r]
我们养蚕小组要是发表准备没做完的话[p]
#sarasa:worry
诶……？[p]
#makado:tweetLA
登利君……[r]
别问纱罗纱这种问题了，她很为难的[p]
#riki:angry
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
啊——！ 搞什么搞什么，[r]
别因为认识就偏袒啊！[p]
再说了，没书本发愁的又不是只有我一个人。[r]
志户田不也是因为作业没进展才被逼来图书室的吗！[p]
#riki:smileCE
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
也就是说，要是我准备不顺利的话志户田也会倒霉。[r]
明白了吗小和尚！[p]
#makado:normal
所以都说了不是小和尚啊。[p]
#makado:worry
但是，原来如此……。[r]
这几天的缘故已经影响到学校生活了啊。[p]
#makado:closeEye
仔细想想也是理所当然，[r]
是我考虑不周。抱歉[p]
#sarasa:closeEye
[delay speed="60"]
不……。[r]
不是贤治郎先生的错[p]
#riki:normal
啊？什么？这小和尚叫贤治郎？[r]
感觉好老土！[p]
#makado:worry
所以都说不是小和尚……[l][r]
#makado:closeEye
你小子，现在绝对是故意在逗我玩吧？[p]
#sarasa:lookAway
（绝对是故意的……）[p]
#makado:lookAway
[delay speed="70"]
不过……蚕，关于蚕的事啊……嗯。[p]
#makado:normal
是啊。[wait time="500"][r]
[resetdelay]
你们……要是有兴趣的话，要不要来看看我们神社的资料？[p]
#sarasa:normal
[playse  volume="20" buf="0" storage="sariin.ogg" ]
诶？去马门神社……吗？[p]
#makado:tweet
对。[r]
我们神社直到几年前，夏天都会开办私塾。[r]
那时候用的白绢祭相关书籍还留着几本。[p]
#makado:lookAway
所以，只要你们方便的话，[r]
可以随意使用那些资料……[r]
怎么样？[p]
[keyframe name=up]
; [frame] アニメーション25%完了時には上に50px動いているということを定義します。
[frame p=25% y=50 ]
[endkeyframe]
[chara_mod name="riki" face="smileCE" time="10"]
[kanim name=riki keyframe=up time=300 wait="false"]
[delay speed="20"]
#riki:smileCE
[playse  volume="30" buf="0" storage="kansei.ogg"]
哇——！！ 什么什么！[r][stop_kanim name=riki]
我要去我要去！绝对要去——！[p]
[resetdelay]
#makado:wowCM
呜哇。这、这么积极啊[p]
#makado:tweet
纱罗纱你怎么想？[r]
你家里可能已经有很多资料了……[p]
#sarasa:worry
[delay speed="70"]
啊、我、那个……[p]
#riki:angry
[font size="50"]
哎！？当然要来啊志户田！[p]
[resetdelay]
[resetfont]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
这种气氛下说不来的家伙绝对是神经病啊神经病！[r]
和川神一起！[p]

#sarasa:closeEye
……………………………………[p]
[mask]
[fadeoutbgm time="3000"]
[wait time="3000"]
;教室
[chara_hide_all wait="true"]
[bg storage=./school/croom_a.jpg time="10" wait=true]
[chara_show name="riki" face="smileCE" top="-100"]
#
[mask_off]

#riki:smileCE
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
——就这么定了，[l][r]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
我们12号就出发去做调研学习！[p]
[chara_show  name="aki" face="normal" left=250 top=-100 wait="false"]
[chara_move  name="riki" left=-70 top=-100 anim="true" wait="false"]
[chara_show  name="hino" face="shame" left=-230 top=-100 wait="false"]
[chara_show  name="ituki" face="normal" left=490 top=-160 wait="false"]
#hino:shame
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
什么——————！！！！[p]
#ituki:normal
怎么了国雄君？[p]
#hino:angry
[delay speed="70"]
[font size="20"]
你……马……马……马门神社！要去吗！[p]
#riki:normal
[resetdelay]
[resetfont]
啊—贤治郎的神社是叫这个名字来着[p]
#hino:shame
[font size="45"]
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
贤治郎！[r]
今年的祭主，叫贤治郎！？[p]
[resetfont]
#riki:sad
吵死了烦不烦啊—[r]
怎么叫都无所谓吧[p]
#hino:sad
是啊。可以啊。可以倒是可以……[p]
[font size="45"]
#hino:shame
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
我也要去！！！！[p]
[resetfont]
#aki:wow
啊 原来是这么回事[p]
#ituki:normal
让人带你去不就行了嘛[p]
#hino:sad
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
可、可是！这种时候去真的合适吗……！？[p]
#riki:tweetLA
为啥不行。人家都说可以去了才去的啊？[p]
#hino:angry
笨蛋登利笨蛋……！[r]
现在不是马上要举办白绢祭最忙的时候吗。[p]
#hino:sad
这种时候、像我们这样的初中生去添乱的话……[r]
肯定会给人造成困扰的！[p]
[font size="40"]
#riki:angry
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
你这家伙——！[r]
笨蛋都说了两遍了——！[p]
#hino:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
哼！就让我说个痛快——！[r]
因为人家就是很羡慕嘛！！[p]
[resetfont]
#riki
再说了带人过去这种事[r]
我们可是连一句话都没被通知到啊——[r]
喂——志户田！[p]
#hino
唔唔…………[p]
#ituki:tweet
吵死了——你们两个。[p]
#ituki:smileCE
呐、纱罗纱。[r]
纱罗纱你怎么想？[p]
#sarasa
…………[p]
#sarasa
哎？[p]
[delay speed="60"]
#ituki:normal
[stopbgm]
因为纱罗纱你，[wait time="500"]和贤治郎先生关系很好对吧？[r]
[chara_hide_all wait="true" time="200"]
[chara_show name="ituki" face="smile" top="-180" wait="false"]
#ituki:smile
你觉得呢？去神社的话会不会给人添麻烦？[p]
[resetdelay]
[chara_mod name="ituki" face="choise" time="200" wait="false" cross="true"]
#
——树月这么说着，[r]
像往常一样朝我伸出双手的小指。[p]
#ituki:choiseS
那——右手小指代表『去了会添麻烦』。[l][r]
左手小指代表『去了也不会添麻烦』！[p]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]

;→行ったら迷惑

;→行っても迷惑じゃない
#
[link target="*mewaku"]【１】去了会给人添麻烦[endlink][r]
[link target="*nomewaku"]【２】去了也不会添麻烦[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*mewaku
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;→行ったら迷惑
#
我决定握住她的右手小指。[p]
没错。[r]
而且还有奥露的事情要考虑，[r]
不能占用太多时间——[p]
[chara_show  name="aki" face="normal" left=250 top=-100 wait="false"]
[chara_move  name="ituki" left=490 top=-160 anim="true" wait="true"]
[wait time="0"]
[chara_mod name="ituki" face="normal"]
[chara_show  name="hino" face="tweet" left=-230 top=-100 wait="false"]
[chara_show  name="riki" face="angry" left=-70 top=-100 wait="false"]
[delay speed="20"]
#riki:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
喂——！志户田——！！[p]
这么说着，[r]
你一个人想偷偷去可不行啊——！！[p]
[resetdelay]
#sarasa
诶、不、不是这样………[p]
#riki:think
哈啊——，[r]
该不会是怕我们把贤治郎抢走吧？[p]
#riki:smileCE
想阻止可没门。[r]
贤治郎可是公共财产啊！[p]
#aki:worry
那个 用法 对吗？[p]
#riki:smileCE
总之我先走了！[r]
这样下去[r]
暑假结束前连发表准备都完不成了！[p]
#hino:angry
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
那还不是因为你之前什么都没做啊！[p]
#riki:hate
[delay speed="60"]
哦～？那国雄你不来咯～[r]
作业都搞定了确实不用来呢～[p]
#hino:sad
哎……我也可以去吗？[p]
[resetdelay]
#ituki:smileCE
啊哈哈，太好了呢！国雄君！[p]
@jump target="*mewakuato"
;-------------------------------------------------------------------------------
*nomewaku
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

;→行っても迷惑じゃない
#
我轻轻握住了她左手的小指。[p]
[chara_show  name="aki" face="normal" left=250 top=-100 wait="false"]
[chara_move  name="ituki" left=490 top=-160 anim="true" wait="true"]
[wait time="0"]
[chara_mod name="ituki" face="normal"]
[chara_show  name="hino" face="tweet" left=-230 top=-100 wait="false"]
[chara_show  name="riki" face="angry" left=-70 top=-100 wait="false"]
[resetdelay]
#riki:angry
看见没啊国雄？[r]　
话说你也别死撑着了 一起来不就得了[p]
#hino:sad
[delay speed="60"]
诶……真、真的可以吗！？[p]
#riki:think
啊咧。不过那家伙刚才说什么来着。[p]
这神社只能进两个人啊[r]
好像刚才确实这么说过呢[p]
#hino:angry
[resetdelay]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
诶！？[p]
#riki:lookAway
因为神社用地的产权问题[p]
#aki:sad
这也太挤了吧？那个神社[p]
#ituki:smileCE
啊哈哈～这不是挺好的嘛，国雄君。[r]
纱罗纱也说可以去呢[p]
@jump target="*mewakuato"
;-------------------------------------------------------------------------------
*mewakuato
;-------------------------------------------------------------------------------
#hino:sad
[delay speed="70"]
啊……啊啊……！[r]
我……我还有很多想调查想问的事情……！[p]
#riki:smileCE
哇啊，怎么感觉更恶心了！[p]
#hino:smile
[resetdelay]
[font size="50"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
闭嘴登利！谢啦登利！[r]
还有志户田！[p]
[resetdelay]
[chara_hide_all wait="true" time="200"]
[delay speed="60"]
[resetfont]
#
[playse  volume="20" buf="0" storage="sariin.ogg"]
日野用力抓住我的双手，用湿润的眼睛仰望着我……[p]
[resetdelay]
[chara_show  name="aki" face="normal" left=250 top=-100 time="10"]
[chara_show  name="riki" face="normal" left=-70 top=-100  time="10"]
[chara_show  name="hino" face="smile" left=-230 top=-100 time="10"]
[chara_show  name="ituki" face="hate" left=490 top=-160 time="10"]
[quake time="30"]
[font size="45"]
#ituki:hate
喂！！！！！[r]
[playse  volume="100" buf="0" storage="book.ogg" ]
[chara_move name="ituki" left="-230" anim="true" time="100"]
[playse  volume="100" buf="0" storage="book.ogg" ]
[chara_move name="hino" left="-500" anim="true" time="100"]
别随便碰纱罗纱！！[er]
[resetfont]
;ＳＥバシッ
[chara_hide name="hino" wait="false" pos_mode="false"]
#hino
疼疼疼！！对不起[p]
#riki:lookAway
流血了[p]
#aki:smile
哈哈……[r]
那今天就先到这里解散吧。[p]
明天要去神社的人记得再来汇报进度哦[p]
#riki:smileCE
噢！包在我身上！绝对会查个水落石出！[r]
给我好好期待下次上学日吧——！[p]

;ＳＥ椅子をひく
[mask]
[chara_hide_all time="300" wait="true"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wse]
#
[mask_off time="2000"]
[delay speed="50"]
众人各自收拾课桌，开始做回家准备。[p]

我余光瞥见有人正要离开教室[r]
那是树月的身影。[p]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
……啊[p]
#sarasa
一、一树！等等[p]
;ＳＥガラガラ
[mask]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[bg storage=./school/rouka_a.jpg time="10" wait=true cross="true"]
[chara_show name="ituki" top="-160" time="10"]
[chara_mod name="ituki" face="tweet"]
#ituki
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[mask time="300"]
[mask_off]
;廊下
#ituki:tweet
诶？[r]
……纱罗纱？[p]
[resetdelay]
#
;回想スチル：きりえ
[chara_hide_all time="200"]
[filter grayscale="100"]
[bg storage="still/kirie_bridge.jpeg" time="500"]
……我有些话必须和她说。[p]
[bg storage=./school/rouka_a.jpg time="500" wait=false]
[free_filter ]
[chara_show name="ituki" top="-160"]
#ituki:normal
怎么了？[p]
[chara_hide name="ituki" wait="false" time="10" pos_mode="false"]
[chara_show name="sarasa" top=-160 wait="false" left="120" face="lookAway"]
[delay speed="60"]
#sarasa:lookAway
……那……[p]
#sarasa:sad
……要一起回去吗？[r]
又……像之前那样……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="ituki" top=-160 face="smile" time="300"]
[resetdelay]
#ituki:smile
……之前？为什么？[p]
[chara_hide name="ituki" time="10"]
[chara_show name="sarasa" top=-160 face="sad" time="300"]
[delay speed="50"]
#sarasa:sad
[delay speed="60"]
……………………………………[p]
#sarasa:worryLA
……那个啊……[p]
#sarasa:worry
[delay speed="100"]
雾绘姐……[wait time="500"]有留言，说是……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="ituki" top=-160 face="tweet" time="300"]
#ituki
……雾绘[p]
[chara_hide name="ituki" time="10"]
[chara_show name="sarasa" top=-160 time="10" face="worry"]
#sarasa:worry
[delay speed="70"]
一树你也，知道的吧……[r]
我在雾绘姐跳下去的时候在场的事[p]
[delay speed="60"]
#sarasa:sad
那时候　我[wait time="500"]　雾绘姐对我说的话。[r]
说是给我和一树的留言　所以……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="ituki" top=-160 time="10" face="tweet"]
[resetdelay]
#ituki:tweet
[stopbgm]
我不想听[p]
[delay speed="60"]
[chara_hide name="ituki" time="10"]
[chara_show name="sarasa" top=-160 time="10" face="wow"]
#sarasa:wow
诶……？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="ituki" top=-160 face="smileW"]
#ituki:smileW
……现在还　不想听呢。[l][r]
#ituki:normal
对不起啊。纱罗纱[p]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥ歩いて行く
#
[chara_hide name="ituki" time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="3000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……今天已经，[r]
和她对话的机会似乎已经失去了。[p]


;第1章『可、孵化』　一日目　終
[mask folder="bgimage" graphic="still/part1.png" time="3000"]
[chara_hide_all]
[wait time="2000"]
[showsave]
;セーブしますか？
@jump storage="chapter_1/day2.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
