;第1章『可、孵化』
;一日目
[eval exp="f.save_title = '一章一日目'"]
[cm  ]
[bg storage="brack.png" time="100"]
[mask_off]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
[delay speed="50"]
#

听说了吗 听说了吗[r]
听说了啊 听说了啊[p]

真是可怜呢。雾绘ちゃん[p]

话说回来，到底是什么时候回来的啊[p]

那个啊，我……之前看到那孩子了哦。[r]
虽然没打招呼[p]

哎哟，在哪儿啊[p]

岩楠桑的医院那边[p]

骗人的吧[p]

怎么可能是假的 我亲眼看到的哦？[p]

要我说啊 岩楠医院那个地方……[p]

听说雾绘被奥库罗姆克诅咒了[p]

诶？[p]

呐。你们怎么看？[l][r]
你们相信吗？[p]
@layopt layer=message0 visible=false
[clearfix]
[stopbgm]
;志戸田家サンルーム（昼）
[bg storage="indoor/shitoda_shoji.jpg" time="1500" wait=true]
;ＢＧＭ爪切り
;SE 廊下を歩く
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[chara_show name="sarasa" left=390 top=-160 time=3000 wait="true"]
[wait time="500"]
#kinuyo
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

纱罗纱[p]
#sarasa:wow
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
！[p]
[resetdelay]
#
――隔着纸拉门，传来母亲的声音。[p]
[playse storage="nail.ogg" loop="true"]
#kinuyo
其实不去也没关系的[r]
我会给熊老师打电话说明的[p]
[delay speed="60"]
#sarasa:lookAway
……但是[p]
[resetdelay]
#kinuyo
但是？[wait time="500"]　怎么了[p]
#sarasa:worry
[delay speed="60"]
啊……。[l][r]
#sarasa:sad
那个[wait time="500"]　班级[wait time="500"]　今天是返校日……[p]
#kinuyo
[resetdelay]
应该有事比学校的安排更重要吧。[p]
#kinuyo
我只是担心你啊[l][r]
要是又像上次”那样[resetdelay]　卷入别人家的纠纷中[r]
可怎么办……[p]
#sarasa:worryLA
[delay speed="60"]
…………………………[p]
[stopse]
#kinuyo
听到了吗？[p]
[resetdelay]
作为志户田家的女儿要谨言慎行。[r]
绝对不要独自在外逗留、[r]
别多管闲事瞎掺和。[p]
#sarasa:closeEye
[delay speed="60"]
……好的[p]
#kinuyo
……真的[r]
第一次接到电话时真是吓死我了。[p]
虽说确实有人闯进了我们家的地界、[r]
但大半夜跑出去追人这也太……[p]
#kinuyo
真是……[r]
恐怕也是因为贤治郎先生在场的关系吧。[p]
[resetdelay]
你没必要特意去管镇上那些人的闲事。[l][r]
那些都是……[p]
[delay speed="60"]
和志户田家毫无关系的事情[p]
[playse storage="nail.ogg" loop="true"]
#sarasa:worry
……………………………………[p]
#sarasa:closeEye
[delay speed="100"]
…………………………[l][r]
#sarasa:sad
雾、雾绘小姐她……[p]
#kinuyo
……………………………………[l][r]
[resetdelay]
[stopse]
什么？[p]
#sarasa:worry
…………………………[wait time="500"][r]
#sarasa:closeEye
没、没什么……[p]

;ＳＥ廊下歩いて行く
[chara_hide name="sarasa" time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wse]

#kinuyo
……………………………………[l][r]
[delay speed="70"]
小心别、[wait time="500"]晒黑了。[wait time="500"]纱罗纱[p]
[resetdelay]
[mask]
;教室（昼）
[bg storage=./school/croom_m.jpg time="10" wait=true]
[chara_show name="aki" left=-70 top=-100]
[chara_show name="sarasa" left=390 top=-160 time=500]
#
[playse  volume="100" buf="0" storage="hikidopen2.ogg"]
[mask_off]
[playbgm storage="gymnopedies2.ogg" loop="true" volume="50"]
;ＳＥ扉開ける
#aki:smile
纱罗纱 早上好[p]
#
教室里不见树月的身影。[r]
是还没来上学吗……[p]
[chara_hide name="sarasa" pos_mode="false" time="10"]
[chara_show name="riki" left=350 top=-100 time="10"]
#riki:smile
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
哇！！真的假的！[r]
志户田你居然来了啊——！！[r]
心理素质太强了吧——！！！[p]
#aki:wow
力！[p]
#riki:worry
就是说啊——！[r]
要是成了自杀现场的第一发现者的话——[r]
一般人都会请假不来学校的！！[p]
#aki:tweetLA
严格来说…应该叫目击者才对……[l]
#aki:sad
没事吧？纱罗纱[r]
心情很差吧[p]
#riki:smileCE
志户田真厉害啊，[r]
我有点对你改观了。[r]
看着文静没想到神经这么粗！[p]

[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '女生徒たち'
[endscript]
[chara_face name="mokke" face="womanStudent" storage="chara/mokke/womenStudent.png"]

[chara_hide name="aki" pos_mode="false" time="10"]
[chara_show name="mokke"  left=-110 top=70 face="womanStudent" time="10" width="+=100"]

#mokke:womanStudent
登利君有点差劲。[r]
志户田，我们可是站在你这边的哦[p]
#riki:angry
喂女生们！[r]
别光把我当坏人啊！[r]
提出要打赌来不来的不就是你们吗！！[p]
#mokke
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
哈！？[r]
我们才没说过这种话啊！[p]
#riki:smileCE
赶紧把你们运动服上的反光条全撕下来给我！[r]
然后把黑田的运动服全身贴满金属色[p]

[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
[chara_move name="mokke" time="10" left=70]
[chara_face name="mokke" face="kuroda" storage="chara/mokke/sankakuBlack.png"]
#mokke:kuroda
我的！？[p]
[chara_hide_all time=300 wait=true]
#
[delay speed="60"]
登利和女生们开始争吵起来。[p]
虽然和远处围观的几个同学对上了视线，[r]
他们全都对我露出尴尬的表情，然后别过脸去。[p]
教室里，不见树月的身影。[p]

;第1章『可、孵化』
[mask folder="bgimage" graphic="still/part1.png" time="3000"]
[chara_show name="hino" left=0 top=-100 time="10"]
[wait time="2000"]
[mask_off time="10"]
[stopbgm]
#hino:angry
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[quake time="30"]
[font size="50"]
给我等着啊！！[p]
[resetfont]
;SE 机バン
#
……诶？[p]
[delay speed="100"]
#hino:angry
你们。[l][r]
#hino:smile
[resetdelay]
知道今天是什么日子吗？[p]
[chara_show name="riki" left=350 top=-100 time="10" face="worry"]
#riki:worry
什……什么日子啊[p]
#hino:smile
不知道吗。[r]
你们肯定不知道吧。[p]
#hino:shame
[delay speed="10"]
就算身边有接触文化的机会也毫不在意[r]
就凭你们这群人当然不会知道啦！[p]
[resetdelay]
[chara_show name="aki" left=-70 top=-100 time="10"]
#aki:sad
说得真快啊[p]
#hino:sad
今天可是……今天可是！[p]
#hino:shame
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[quake time="30"]
本镇出身的民俗学者·纪伊玛莉甘的著作[r]
[font size="45"]
『玛莉甘☆山物语2』[resetfont]的发售日啊！！！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '女生徒たち'
[endscript]
#mokke
那是谁啊[p]
#riki:normal
完全听不懂啊[p]
[fadeinbgm storage="gymnopedies2.ogg" time="2000" loop="true" volume="50"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
#黒田
国雄还是老样子，完全就是个莫名其妙的死宅嘛～[p]
#hino:smile
是宅男又怎样！[r]
[delay speed="10"]
在这等大喜之日仍被赶工催生出来的[r]
要我成为你们这些被迷信耍得团团转的家伙的同伙的话，[p]
我日野国雄，宁愿当民俗学的奴隶！[p]
[resetdelay]
#女生徒たち
恶……心……[p]
#hino:angry
哼！恶心就恶心呗！[l][r]
#hino:smile
纪伊玛莉甘可是这座城市的才女代表啊[r]
住在八种的你们不懂她的好真是可惜。[p]
[delay speed="10"]
#hino:smile
从拥有异国血统之人的视角出发描绘的[r]
各地传说甚至在调查过程中都蕴含着珍贵的民俗学价值[er]
[resetdelay]
[chara_hide name="hino" time="500" wait=false pos_mode="false"]
#aki:tweet
不过…确实。日野说得对[r]
我们为这次事件闹腾确实不对[p]
#riki:angry
搞、搞什么啊——阿奇你站女生那边吗？[p]
#aki:tweetLA
因为…你仔细想想嘛。[r]
作为目击者的纱罗纱肯定也很难受吧[p]
#aki:tweet
这个班级里还有一树在啊[p]
[delay speed="80"]
#女生徒たち
……………………[p]
#riki:worry
………………………………[p]
#aki:sad
[resetdelay]
我们既不是目击者　也和死者没有血缘关系[r]
本就没有深究这件事的权利[p]
#riki:shame
[delay speed="70"]
搞、搞什么啊—。[r]
我只要能拿到反光材料就满足了……[p]
[fadeoutbgm time="2000"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '男子生徒'
[endscript]
#男子生徒
——果然阿奇对宗方是区别对待的吧[p]
#aki:wow
……诶[p]
#男子生徒
[resetdelay]
要不就是那个原因？[l][r]
……宗方该不会是、[wait time="500"]我们的新妈妈！[wait time="500"]　之类的[p]
#riki:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="riki" left="-=30" time=100 ]
[anim name="riki" left="+=30" time=100 ]
喂、[wait time="500"]喂！你们几个！！[p]
#男子生徒
干嘛啊登利。[r]
你难道不是我们这边的吗[p]
#riki:angry
[font size="20"]
可、可是阿奇妈妈的事……[p]
[resetfont]
#aki:tweetLA
[delay speed="60"]
……没关系[wait time="500"]　力[p]
#riki:worry
诶…………………………[p]
#aki:normal
[delay speed="50"]
没事的[wait time="700"]　所以[p]
[resetdelay]
#riki:sad
……………………[p]
#
[chara_hide_all]
;ＳＥ扉開く
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
;ここめっちゃ固まりやすい
[chara_show name="kuma" top=-160 time=500 wait="false"]
#kuma:normal
好的，各位早上好。[l][r]
#kuma:wow
……哎呀，全都站着不动，怎么了？[p]
#kuma:normal
[delay speed="60"]
嘛，算了……[r]
今天开始前老师有话要说，[r]
能请大家先回到座位上吗[p]
#
[chara_hide name="kuma" pos_mode="false" wait="true" time="200"]
[chara_show name="aki" top=-100 face="hate" time="200"]
#aki:hate
[delay speed="100"]
……………………………………[p]
[chara_hide name="aki" wait="false"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
#
[delay speed="60"]
阿奇沉默不语地，[r]
穿过男生们面前，坐回了自己的座位。[p]
#男子生徒
[font size="20"]
……哼，娘娘腔[p]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=bell.ogg sprite_time="0000-7000" volume="5"]
[wse]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=30]
[resetfont]
[chara_show name="kuma" top=-160 face="closeEye" wait="true" time=1000]
#kuma:closeEye
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

……可能有些同学已经听说了，[r]
前几天　宗方同学的家人去世了。[l][r]
这实在是令人悲痛万分的意外[p]
#kuma:normal
这对全班同学来说都是如此，[r]
尤其对于树月同学来说更是如此这件事[r]
善良的你们应该能理解吧[p]
#kuma:closeEye
……对老师而言，学生先走一步这种事[r]
也是极其痛苦悲伤的[p]
#kuma:smileW
如果因为这次事件，有想要倾诉的心情或经历的人[r]
请不必顾虑尽管提出来。[r]
可以让学校的心理辅导老师　来帮助你们……[p]
[chara_hide_all  wait="false" time="300"]
#
熊老师深吸一口气后看到的，是树月的座位。[p]
自从前几日和她一起放学后[r]
就再也没见过面。[p]

;回想スチル　いつき
[filter grayscale="100"]
[bg storage="still/kirie_bridge.jpeg" time="500"]
#
[delay speed="70"]
雾绘最后——[r]
给我和树月留下了「口信」。[p]

想快点传达给她。[l][r]
想要传达……这份心情，也希望树月能够理解。[p]
[bg storage=./school/croom_m.jpg time="1500" wait=false]
[chara_show name="sarasa" top=-160 time="10"]
[free_filter]
[fadeoutbgm time="3000"]
#sarasa:normal
（可是……[l][r]
#sarasa:sad
（可能……短期内都不会来学校了）[p]

;ＳＥガラッ
[playse  volume="100" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_hide name="sarasa" pos_mode="false" time="10"]
[chara_show name="ituki" top=-160 time="10"]
#ituki:smile
[resetdelay]
早上好呀——[p]
[chara_hide name="ituki" pos_mode="false" time="50"]
[chara_show name="sarasa" top=-160 time="50"]
#sarasa:wow
[font size="50"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
！？[p]
[chara_hide name="sarasa" pos_mode="false" time="50"]
[chara_show name="kuma" top=-160 time="50"]
#kuma:wow
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
！？[p]
[chara_hide name="kuma" pos_mode="false" time="50"]
[chara_show name="riki" top=-100 time="50"]
[playse  volume="100" buf="3" storage="punch.ogg" sprite_time="0500-30000"]
#riki:wow
！？[p]
[chara_hide name="riki" pos_mode="false" time="50"]
[chara_show name="aki" top=-100 time="50"]
#aki:hurry
[playse  volume="100" buf="4" storage="punch.ogg" sprite_time="0500-30000"]
……！？[l][r]
#aki:worry
[resetfont]
一、一树？[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
;ここにｂｇｍ
[chara_move name="aki" left=-70 top=-100 wait="false" time="10"]
[chara_show name="ituki" face="shame" left="360" top=-160 pos_mode=false wait="false" time="10"]
#ituki:shame
哇啊！[r]
不小心睡过头了！真是抱歉啊[p]
[chara_hide name="aki" pos_mode="false" wait="false" time="20"]
[chara_show name="riki" face="worry" left=-70 top=-100]
#riki:worry
你……你这打扮是什么鬼[p]
#ituki:smileCE
哈哈——暑假过得太放松不小心就[r]
没想到自己也会犯这种错！[p]
#ituki
明明之前还严厉提醒过登利君的[r]
简直无地自容啦～[p]
[chara_hide name="riki" pos_mode="false" time="10"]
[chara_show name="aki" left=-70 top=-100 time="10"]
#aki:wow
诶 而且[r]
偏偏今天 还在玩角色扮演？[p]
[chara_hide_all time=100 wait="true"]
[chara_show name="kuma" face="wow" top="-160"]
#kuma:wow
……！[p]
#kuma:smile
树月同学、虽然稍微迟到了……[r]
但你能来我很开心哦。[r]
这样小谷坂学园初中部2年1班就全员到齐了呢！[p]
#kuma:normal
……好啦！既然人都到齐了，[r]
大家分好「城镇与我」小组开始准备发表吧！[p]
[mask]
#
[chara_hide_all time=100 wait="true"]
[chara_show name="sarasa" face="worry" top=-160]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wse]
[mask_off time="2000"]

#sarasa:worry
……[p]
[chara_hide name="sarasa" pos_mode="false" wait="true"]
[chara_show name="aki" face="worry" top=-100]
#aki:worry
……[p]
[chara_hide name="aki" pos_mode="false" wait="true"]
[chara_show name="riki" face="sad" top=-100 zindex="2"]
#riki:sad
……[p]
[chara_move name="riki" left=-120 top=-100　time="10" pos_mode=true]
[chara_show name="ituki" face="normal" left="400" top=-160 zindex="2"]
#ituki:normal
咋回事啊？[p]
[chara_show name="aki" left="160" face="worry" top=-100 time="10" zindex="1"]
#aki:worry
……那个……[p]
[chara_hide name="aki" time="10" pos_mode="false"]
[chara_show name="hino" zindex="1" face="angry" left="150" top=-100 time="10"]
#hino:angry
[playse  volume="20" buf="0" storage="kakan.ogg"]
不讨论的吗！？[p]
#riki:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
吵死了国雄！[r]
给我闭嘴！[p]
#hino:shame
[anim name="hino" left="-=10" time=50]
[anim name="hino" left="+=10" time=50]
[anim name="hino" left="-=10" time=50]
[anim name="hino" left="+=10" time=50]
你说啥！[p]
#riki:shame
啊——真是！别吵啦！[r]
我现在脑子已经乱成一团了……[p]
#riki:worry
[delay speed="60"]
喂——树月，[r]
你不用刻意装得这么开朗！[p]
搞得我浑身不自在！！[p]
#ituki:tweet
诶？不自在？哪里[p]
[chara_hide name="hino" time="500" wait=false pos_mode="false"]
#riki:tweetLA
当人遇到消沉的事情时，[r]
到处炫耀确实不太好啦……[p]
#ituki:smile
哈？消沉？[r]
我今天明明没什么精神啊[p]
#riki:wow
………………………………[p]
[chara_hide name="ituki" time="10" pos_mode="false"]
[chara_show name="aki" face="tweetLA" left="400" top=-100 time="10"]
#aki:tweetLA
力　已经够了。[p]
#aki:tweet
一树说她现在精神很好[r]
这比什么都重要[p]
#riki:sad
[resetdelay]
[font size="45"]
……是吗？[r]
原来是这样！？[p]
[resetfont]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all time="2000" wait="true"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

[delay speed="60"]
――树月，[r]
这几天究竟是怎么度过的呢……[p]
[chara_show name="ituki" face="tweet" top=-160]
[fadeoutbgm time="3000"]
#ituki:tweet
……怎么回事呀？[r]
纱罗纱[p]
[chara_hide name="ituki" time="10"]
[chara_show name="sarasa" face="wow" top=-160 time="10"]
#sarasa:wow
……啊？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="ituki" face="normal" top=-160 time="10"]
#ituki:normal
哎呀—，[r]
你刚才一直盯着我看吧！[p]
是有啥事儿吗？[p]
#sarasa
呃、那个……[p]

;「無理しないで」と声をかける
;そっとしておく
#
[link target="*muri"]【１】别太勉强自己[endlink][r]
[link target="*so"]【２】不去打扰[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*muri
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
[chara_hide name="ituki" time="10"]
[chara_show name="sarasa" face="closeEye" top=-160 wait="false"]
#sarasa:closeEye
[delay speed="60"]
……我、我和登利君一样……[p]
#riki
[resetdelay]
诶？我？[p]
#sarasa:worryLA
[delay speed="60"]
如、如果一树你现在勉强自己强颜欢笑的话……[r]
我希望你别勉强自己[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" face="wow" top=-100 wait="false" time="10"]
#aki:wow
……………………[p]
[chara_hide name="aki" time="10"]
[chara_show name="ituki" face="tweet" top=-160 wait="false"]
#ituki:tweet
诶？[p]
[chara_move name="ituki" left=-70 anim="true" wait="false"]
[chara_show  name="sarasa" left=400 top=-160]
#sarasa:closeEye
一树你现在感受到的情绪，[r]
我不想否定……。[p]
#sarasa:worryLA
那、那个，所以说……[l]
#sarasa:sad
[delay speed="70"]
别勉强自己，就是，[l][r]
那个……我是想说……[p]
#ituki:tweet
……………………[p]
[resetdelay]
[chara_show name="hino" face="smile" left="150" top=-100 wait="false"]
#hino:smile
[resetdelay]
哦？这可真稀奇啊！[r]
志户田居然会主动开口说话！[p]
#ituki:tweet
[delay speed="60"]
……………………[wait time="500"]不要勉强[p]
[chara_hide name="hino" time="500" wait=false pos_mode="false"]
#ituki:smileW
啊哈哈……。[r]
果然，纱罗纱你总是能看透一切呢。[r]
发生在我身上的事也好，我心里想的也好……[p]
#ituki:normal
——不过，没关系的。[r]
#ituki:smile
只要纱罗纱你在我身边的话，[r]
一切都会好起来的[p]
#sarasa:smile
……一树[p]
[resetdelay]
@jump target="*hino"
;-------------------------------------------------------------------------------
*so
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#sarasa:sad
（……还是什么都别说比较好吧。[r]
反正我也无能为力）[p]

@jump target="*hino"
;-------------------------------------------------------------------------------
*hino
;-------------------------------------------------------------------------------
#ituki:tweet
………………[p]
[chara_hide_all time="10" wait=true]
[chara_show  name="hino" face="smile" left=-100 top=-100 wait="false"]
[chara_show  name="riki" face="normal" left=360 top=-100 wait="false"]
#hino:smile
[quake time="30"]
[playse  volume="20" buf="0" storage="kakan.ogg"]
[font size="45"]
那么、发表准备怎么办！[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
;ＳＥ机バン
#riki:think
[resetfont]
……国雄要是参加KY检定考试的话[r]
不复习也能轻松考到二级吧—[p]
#hino:smile
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
哈哈哈！登利啊！笨蛋！[r]
这种资格证书根本不存在于我国啊！[p]
#riki:tweetLA
骗你的。其实一级也完全没问题[p]
[chara_show  name="aki" face="smile" left="160" top=-100 wait="false"]
#aki:normal
[delay speed="60"]
呜 嗯—[r]
不过日野说得确实没错呢。[p]
#aki:tweet
为了暑假结束后的发表会[r]　
这周要做什么就在这个时间内决定吧[p]
#ituki
大家各自课题的资料收集都进展到什么程度了捏？[p]
[chara_hide_all time=100]
;アイテムスチル：「町と私」班学習メモ
[cm]
#
[playse storage=page.ogg volume="50"]
[image layer=0 folder="image" name="memo" storage="item/memo_class.png" width="500" x="250" y="52"  visible="true"]
#aki
[delay speed="50"]
我现在正在四ツ山和花隅川[r]
在调查生物和植物哦[p]
#hino
[resetdelay]
嚯！[r]
这么说器乐堂已经[r]
已经去实地考察了吗？[p]
#aki
[delay speed="60"]
啊、遗憾的是还没呢。[l][r]
我想再多做些前期调查之后再去试试[p]
#hino
非常棒！[r]
连前期调查准备都一丝不苟……[p]
#hino
果然器乐堂才最适合我们地域研究部的人才。[r]
怎么样，[wait time="500"]要不要再来一次参观或体验入部……[p]
#aki
[resetdelay]
啊、虽然你老是这么说[r]
完全够用了……[p]
#hino
[quake time="30"]
可恶！为什么啊！[r]
为什么每次都被拒绝！[p]
#riki
因为啊。[r]
地域研究部除了幽灵部员就只剩些阴沉的家伙吧。[r]
看起来超没意思才不要加入呢[p]
#hino
哈？[wait time="500"] 我又没在邀请你？[p]
#riki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
咕……[p]
#aki
好啦好啦。[l][r]
日野 你的发表准备进展如何了？[p]
#hino
[delay speed="10"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
哦！问得好！问得妙啊！[r]
现在正是展现地研实力的时候！[p]
[fadeoutbgm time="2000"]
[image layer=0 folder="image" name="memo" storage="item/memo_class.png" width="500" x="250" y="52"  visible="false"]

;スチル：日野の『マリガン☆サイン会チケット』
[mask]
[wait time="2000"]
;-------------------------------------------------------------------------------
[bg storage="still/hino_ticket.png" time="500"]
[free layer=0 name="memo" time="10"]
;-------------------------------------------------------------------------------
[mask_off time="300"]
[fadeinbgm storage=onedari.ogg loop=true time="300" volume=50 sprite_time="0200-21000"]
[font size="50"]
#hino
[playse  volume="30" buf="0" storage="kansei.ogg"]
看招————！！[p]
[resetfont]
#riki
[resetdelay]
……………………啥？[p]
#hino
今早刚发售的 纪伊玛莉甘新书附赠[r]
签名会门票！[p]
[delay speed="60"]
虽然名义上是签名会，但通常参加的只有[r]
我和……其他几个铁杆粉丝而已。[r]
实际上变成了每人十分钟左右的交流会[p]
#aki
时间充裕 挺好的[p]
#hino
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="50"]
但——是！[p][resetfont]
反过来看这张票意味着[r]
能直接见到八种町的民俗学者玛莉甘女士！！[r]
这可是获得历史问题咨询机会的入场券！[p]
#ituki
嘿—，[r]
国雄同学真厉害呀。[r]
居然能让学者帮忙做暑假作业吗？[p]
#hino
[resetdelay]
哼，我可不打算把这次调查局限在[r]
『暑假作业』这种程度……[wait time="500"]　嘛，就是这么回事！[p]
#hino
时间是[font color="0xf08080"]8月19日[resetfont]……。[r]
有兴趣的人尽管来找我。[p]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
毕竟一张票最多可以带10个人参加！！[p]
#riki
没人气呢～[p]
#ituki
……………………………………[l][r]
[fadeoutbgm time="3000"]
喂喂国雄君。[p]
纪伊玛莉甘确实不错啦。[r]
关键的研究主题内容到底怎么样啦？[p]
;教室
[mask]
;-------------------------------------------------------------------------------
[bg storage="school/croom_m.jpg" time="300"]
[chara_show  name="aki" left=250 top=-100 time="10"]
[chara_show  name="riki" face="normal" left=-70 top=-100 time="10"]
[chara_show  name="hino" face="smile" left=-230 top=-100 time="10"]
[chara_show  name="ituki" face="smile" left=490 top=-160 time="10"]
#hino
;-------------------------------------------------------------------------------
[mask_off time="300"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
#hino:smile
啊？[p]
#ituki:smile
因为。[p]
#ituki:normal
国雄君选的课题”解读八种的历史”啊，[r]
太笼统了根本搞不懂你想研究啥啊[p]
#aki:normal
啊～确实[p]
#hino:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
咕、咕唔！？[p]
#ituki:angry
如果你原本也打算介绍御白姬传说的话，[r]
我会很困扰的。和我选题撞车了。[r]
我都已经做好纸板书了喂！[p]
#riki:smileCE
那御白姬传说就归树月负责了。[r]
绝对不准跟老子撞题啊国雄！[p]
#hino:shame
[delay speed="10"]
喂喂喂、少胡扯——！[r]
不提及御白姬就想讲述八种町的历史？[r]
这难度简直堪比挑战和天狗斗智啊！？[p]
[resetdelay]
#riki:smile
怎么～？没自信了吧。[r]
明明平时总把历史文化什么的挂在嘴边[p]
#hino:angry
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="45"]
历史只要漏掉哪怕一行记载[r]
就再也不是历史了——！！[p]
[resetfont]
#riki:smileCE
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
嘿嘿～怎么？想干架啊！[p]
#hino:smile
啊、树月先生。[r]
关于御白姬相关章节的部分[r]
我会适可而止地轻轻带过，这样折衷处理可以吗？[p]
#ituki:smileW
虽然不太明白，[r]
总之就拜托您了啦～[p]
#riki:angry
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
喂喂——别无视我啊！[p]
#hino:tweet
哼。[r]
我才不会幼稚到被怒火冲昏头脑和人争吵呢。[p]
#hino:angry
不对、应该说登利才对吧。[p]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
从刚才就一直在打岔、[r]
你自己的发表准备搞定了吗？[p]
#aki:wow
[delay speed="60"]
啊　这个　我也正想问呢。[r]
力、养蚕的那些设施都好好调查过了吗？[p]
#riki:think
……………………[p]
#ituki:normal
话说你真的明白养蚕这个词的意思吗？[p]
#riki:angry
[resetdelay]
过分！当然明白啊！我自己选的课题！[p]
#riki:lookAway
……嘛、不过我啥都没做呢。[p]
#ituki:tweet
这家伙啥都没干啊喂[p]
#aki:smile
哈哈……我就知道会这样。[p]
#aki:normal
[delay speed="60"]
那纱罗纱你呢？[p]
[chara_hide_all time=100]
[chara_show name="sarasa" face="normal" top=-160 time="300"]
[delay speed="70"]
#sarasa:normal
……啊？……[p]
[resetdelay]
#aki
从上回开始有什么进展吗？[p]
[delay speed="70"]
#sarasa:worry
啊……[p]
#sarasa:worryLA
对不起，完全没……[p]
[resetdelay]
[chara_hide name="sarasa" pos_mode="false"]
[chara_show  name="aki" left=250 top=-100 wait="false"]
[chara_show  name="riki" face="normal" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="normal" left=-230 top=-100 wait="false"]
[chara_show  name="ituki" face="normal" left=490 top=-160 wait="true"]
#ituki:normal
那你们这对养蚕二人组也没进展咯？[p]
#hino:smile
哼、完全没问题啊志户田！[p]
上周该发表的报告　应该已经准备好了吧？[r]
总比登利这种压根没开始调查的强多了！[p]
#riki:tweetLA
因为啊～。根本没时间调查嘛～。[r]
我这个人啊意外地很忙的啦[p]
#hino:angry
登利你这家伙。从暑假开始这三周，[r]
志户田那边可是过得天翻地覆吧[p]
#aki:tweetLA
[delay speed="70"]
那么……总之先[r]
剩下的时间就——[p]
[mask folder="bgimage" graphic="still/part1.png" time="3000"]
[chara_hide_all]
[fadeoutbgm time="2000"]
[wait time="2000"]
[showsave]

@jump storage="chapter_1/day1_2.ks"
;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
