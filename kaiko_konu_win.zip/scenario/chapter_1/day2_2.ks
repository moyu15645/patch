;第1章『可、孵化』
;二日目 途中から

;-------------------------------------------------------------------------------
*part2
;-------------------------------------------------------------------------------
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '一章二日目　中編'"]
[mask]

[bg storage="indoor/makado_ima_m.jpg" time="100"]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[wait time="1000"]
[mask_off]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=8000 volume=50]
;〇馬門家居間
[chara_show name="riki" wait="false" top="-100" face="smile"]
#riki:smile
打扰啦～！[r]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
呜哇～是超传统的榻榻米房间耶！[p]
#riki:smileCE
[resetdelay]
话说这可是别人家啊～！[r]
哇哈哈～超开心～～！！[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" time="10" top="-10" face="smileMini"]
#makado:smileMini
明明才刚进客厅……[r]
这有什么好开心的？[p]
[chara_move name="makado" wait="false" top="-10" left="350" face="normal" time="10"]
[chara_show name="riki" time="10" top="-70" left="-90"]
#riki:smileCE
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
就是很开心嘛！[r]
我啊，很少有机会去别人家做客的。[p]
能打游戏什么的简直像做梦一样～！[p]
#makado:normal
先说好，我可不会拿出来的。游戏机[p]
#riki:worry
诶——！！[p]
#makado:sad
真是的……今天不是来找资料的吗？[p]
#riki:lookAway
嘿嘿！对哦～[p]
[delay speed="60"]
[chara_mod name="makado" face="lookAway"]
#
桌面上已经放着几本书，[r]
还有两杯盛着麦茶的玻璃杯。[p]
[image layer=0 folder="image" name="mugicha" storage="item/mugicha.png" width="460" x="270" y="107" time="800" ]
其中一只杯壁挂着冷凝水珠的，[r]
这是之前贤治郎先生递给我的那个向日葵花纹的玻璃杯。[p]
[free layer=0 name="mugicha" time="800"]
#riki:think
唔——『养蚕农户的生活与文化』……[r]
这本好像不错诶。书名里带养蚕俩字[p]
;ＳＥペラペラ
[playse storage=page.ogg volume="50"]
[wse]
#riki:normal
喂——志户田——[r]
别傻站着啦，一起看嘛[p]
[chara_mod name="makado" face="normal"]
[resetdelay]
#riki:smileCE
不是要查资料吗？你也来啊！[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" face="worryLA" wait="false" top="-160"]
#sarasa:worryLA
唔……[p]
[chara_hide name="sarasa" wait="false"]
#
我在登利对面的坐垫上跪坐下来，和桌子隔开一段距离。[p]
[chara_show name="makado" top="-10" left="100"]
#makado:normal
………………………………[p]
[playse storage=page.ogg volume="50"]
[chara_show name="riki" left="350" top="-100" wait="false" face="tweetLA"]
[chara_move name="makado" left="-70" top="-60" anim="false"]
[wait time="0"]
#riki:tweetLA
[delay speed="50"]
诶[r]
养蚕农户居然要专门从蚕卵商那里买蚕种！[r]
我还以为是用自家产的蚕卵呢[p]
#makado:tweet
因为养蚕业以采集生丝为目的，[r]
蚕结茧后就会连茧带蛹一起煮。[p]

被煮死的蚕蛹来不及产卵就死去了。[r]
所以才要购买蚕卵啊[p]
#makado:tweetLA
嘛，毕竟农户们有各种不同的养殖方式[r]
也不能一概而论啦[p]
#riki:tweetLA
哦～……[l][r]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
#riki:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
卧槽！！这什么鬼东西！！？[stop_kanim name=riki][p]
#makado:normal
怎么了？[p]
#riki:shoutG
这……这一页！明明是讲养蚕的书……[l][r]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
居然印着一条超级大的蛇！！[p]
;ＳＥシャー
[delay speed="60"]
#makado:tweet
啊。蛇……[wait time="500"][r]
作为守护蚕的存在，很受养蚕农户们的欢迎呢。[p]
#makado:lookAway
因为还能驱赶会吃掉蚕的老鼠，[r]
听说以前还有人特意饲养过[p]
[delay speed="50"]
#riki:sad
呜哇～我最讨厌蛇了～。[r]
超可怕的啊。突然张开血盆大口什么的…………[p]
[resetdelay]
[chara_hide name="makado" time="10" wait="false" pos_mode="false"]
[wait time="0"]
[font size="50"]
[delay speed="20"]
#riki:smileG
[stopbgm]
[chara_move name="riki" anim="false" left="100" top="-110" width="+=50" time=100 wait="false"]
[wait time="0"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
喂！！！！[r]
志户田你也这么觉得吧！！？？[p]
[resetdelay]
;ＳＥガタッ
#sarasa
[quake time="30"]
！！[p]
[resetfont]
[chara_hide name="riki" time="10"]
#
[delay speed="50"]
突然凑近的登利让我吓了一跳，[r]
下意识地……把伸向资料的手缩了回来。[p]
[image layer=0 folder="image" name="mugicha" storage="item/mugicha.png" width="460" x="270" y="107" time="800" ]
那只手碰到了放在桌上的[r]
玻璃杯，[p]
[free layer=0 name="mugicha" time="800"]
杯子就这样猛地撞上墙壁——[wait time="500"]向日葵图案的杯子碎了。[p]
[playse  volume="30" buf="0" storage="garasu.ogg"]
[quake time="30"]
[wse]
;ＳＥガシャン
[chara_show name="sarasa" wait="0" face="worryLA" top="-160"]
#sarasa:worryLA
啊……！[p]
[chara_show name="makado" time="10" top="-10" face="wow" wait="false"]
#makado:wow
！[r]
纱罗纱，你没事吧！？[p]
[chara_hide_all time="10"]
[chara_show name="riki" time="10" top="-70"]
#riki:sad
啊啊。志户田你在搞什么啊。[r]
连茶水都打翻了[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" time="10" face="sadB"]
#sarasa
………………………………[l][r]
对、对不起……我[p]
#
在榻榻米干燥与湿润的交界线上，[r]
玻璃碎片正闪闪发亮。[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" top="-10" time="10" face="worry"]
#makado:worry
不用碰了，没受伤吧？[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-160" time="10" face="sad"]
#sarasa:sad
嗯……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" time="10" top="-70" face="smileH"]
#riki:smileH
……[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" wait="false" top="-10" face="worry"]
#makado:worry
那就好。没事了。[r]
不过碎片飞得到处都是呢……[p]
#makado:tweetLA
……我来收拾一下[r]
这段时间　你们能先去资料室吗？[p]
[chara_move name="makado" wait="true" anim="true" left="350" time="500"]
[wait time="0"]
[chara_show name="riki" top="-70" left="-90" face="tweetLA" wait="false"]
#riki:tweetLA
资料室？[p]
#makado:tweet
资料室就在前面走廊的尽头。[r]
为了防火所以光线比较暗的房间[p]
#makado:tweetLA
那里的话，有比带过来的书更简单易懂的好文献。[l][r]
#makado:smile
茶水也没洒……应该也没爬着蛇吧[p]
#riki:smileCE
啊哈哈！那可太好了！[p]
#makado:tweet
那么……我这就去准备新的饮料[r]
待会儿给你送过去[p]
#riki:normal
诶～我也想要你带过来～[r]
有啥好喝的？[p]
#makado:lookAway
不，其实种类没那么多。[r]
硬要说的话就麦茶、牛奶、水，或者梅子果汁吧[p]
#riki:worry
老土！连碳酸饮料都没有！[p]
#makado:normal
没人喝的饮料我们这里可不会备着。要哪种？[p]
#riki:tweetLA
诶～～～。[r]
……那就梅子果汁吧。话说梅子果汁是什么鬼[p]
#makado:tweet
知道了。[l][r]
纱罗纱你呢？[p]
#
[link target="*ume"]【１】麦茶[endlink]　　　[link target="*ume"]【２】牛乳[endlink][r]
[link target="*ume"]【３】水[endlink]　　　　[link target="*ume"]【４】梅子汁[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*ume
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#makado:tweetLA
……明白了。[p]
#riki:smileCE
那、走吧——！志户田！[r]
得把落后的进度调查清楚才行！[p]

#
登利笑着抓住了我的手腕。[r]
那只手掌却冰冷得令人发颤——仿佛虚假的温度。[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="wow" time="10"]
#sarasa:wow
……！[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-70" time="10" face="smileH"]
#riki:smileH
干嘛啊。你怎么了？[r]
不想去吗？[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" face="lookAway" time="10"]
#sarasa:lookAway
……贤、贤治郎啊[p]
#
当我喊出那个名字回头时[r]
贤治郎先生的身影已经消失了。[p]
#sarasa:sadB
…………[p]
[delay speed="80"]
#sarasa:closeEye
…………。[p]
[mask]
[resetdelay]
[bg storage="indoor/makado_zasiki.jpeg" time="100"]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" time="10" face="tweetLA"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
#
[mask_off time="3000"]
;〇馬門家座敷
#riki:tweetLA
[resetdelay]
嘿——这就是资料室？也太阴暗了吧。真压抑。[r]
志户田你也这么觉得吧？[p]
[delay speed="70"]
…………。[p]
[fadeoutbgm time="3000"]
#riki:normal
……喂。[r]
从刚才起就一直沉默不语，发生什么事了吗？[p]
#riki:smile
一看到我就转身逃跑。[r]
甚至把国雄一个人丢在商店街[p]
[resetdelay]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——！[r]
日、日野他……[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font size="27"]
被提到的那个少年，自己别后就音讯全无。[l][r]
[r]
就连拼命甩开他跑到这里的我，[r]
也在一瞬间被登利”追上了。[l][r]
拥有超越理解范畴异能的登利……[r]
在伤害日野后，朝这边袭来也不足为奇[r]
完全合乎逻辑。[l][r]
我甚至无法抑制这种不祥的预感，[r]
现在的登利对我来说，是完全无法理解的存在。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetfont]
[delay speed="20"]
#riki:smileH
哈？[wait time="500"]　哈？　等等、什么情况？[r]
现在突然想聊国雄的事？[p]
[resetdelay]
#riki:smileCE
搞什么啊搞什么啊，[r]
别给我一直沉默到底啊——你好歹坚持下闭嘴的立场啊。[p]
[playbgm storage=fuon.ogg loop=true time=8000 volume="30"]
[chara_move name="riki" anim="true" left=110 top="-110" width="+=50" time=500 wait="true"]
[filter saturate="40"]
#riki:smileB
…………御白姬大人！[p]
#sarasa
……！[p]
#
登利正……朝着这边，一点一点逼近。[r]
我也，随之，向后退去——[p]
[chara_move name="riki" anim="true" left="90" top="-130" width="+=50" time=1000 wait="true"]
[wait time="0"]
#riki:smileCE
哎呀—。哈哈，[r]
不用这么躲着我吧—。[p]
#riki:smileG
还是说，那个？果然是因为我的缘故吗—[p]
[delay speed="70"]
#riki:ghost
因为被诅咒了所以不想靠近吗？[p]
#sarasa
――[r]
　　　[er]
[mask time="10" effect="flipInX"]
[bg storage="indoor/makado_zasiki_sp.jpeg" time="10" cross="false"]
[playse volume="70" buf="0" storage="punch.ogg" ]
[stopbgm]
[wse]
[free_filter]
[mask_off time="10"]
;ＳＥ鞭
[resetdelay]
#riki:ghost
！？ 啊、怎、怎么回事……动、动不了，[p]
[chara_hide name="riki" time="200"]
#
;〇馬門家座敷（特殊）
;ＳＥ襖閉まる
[chara_show name="makado" wait="true" top="-40" face="normal_r"]
;馬門立ち絵鞭で
#makado:normal_r
你已经没法离开这个房间了。[r]
我设下了结界[p]
[chara_move name="makado" left="350" wait="false"]
[chara_show name="riki" face="ghost" left="-110" top="-70" width="-=50" wait="false"]
#riki:ghost
哈？ 什么啊，结界是……[p]
#makado:normal_r
这里是马门神社……[r]
是世代负责封印奥六目魔的家系领地[p]
居然毫无戒备地闯入这种地方，[r]
奥六目那家伙还真是自信过头啊[l][r]
……或者说，是被我小看了吗[p]
[fadeinbgm storage="lost-happy.ogg" loop=true time=6000 volume="50" sprite_time="0000-105000"]
[chara_hide_all time="10"]
#
[resetdelay]
鞭状武器以套索的手法[r]
精准缠住登利模糊的轮廓，骤然收紧。[p]
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
[wse]
;ここから馬門立ち絵を「縄なし」に
[chara_show name="sarasa" time="10" top="-100" face="wow"]
#sarasa:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
贤治郎先生！[p]
[chara_show name="makado" face="closeEye" time="10" top="-40"]
#makado:closeEye
抱歉让你担心了，纱罗纱。很不安吧。[p]
#
贤治郎先生似乎因内疚，略显尴尬地俯视着登利。[r]
之后又反复确认了好几次。[p]
#makado:tweet
登利君已经被诅咒了对吧！？[p]
#sarasa:closeEye
是的……！[p]
#makado:closeEye
明白了。[r]
既然如此，我们要做的事就只有一件了。[p]
#makado:normal
纱罗纱 你来解除他的诅咒吧[p]
#
[chara_mod name="sarasa" face="normal"]
我向贤治郎先生点头示意。[p]
[chara_hide_all time="100"]
#riki:smileG
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[delay speed="60"]
哈哈……哈哈哈！[r]
搞什么啊，原来贤治郎你也早就注意到我了！？[p]
[chara_show name="riki" top="-100" face="smileH" wait="false"]
#riki:smileH
嘛算了无所谓啦[r]
居然面不改色搞偷袭这种把戏啊？！[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-40" face="normal" time="10"]
#makado:normal
[resetdelay]
为了你，为了纱罗纱，[r]
也为了八种啊[p]
[chara_hide name="makado" time="10"]
[chara_show name="riki" top="-100" face="smileH" time="10"]
#riki:smileH
嘿。不过啊。[l][r]
#riki:smileG
[delay speed="100"]
恐怕志户田是解不开我的诅咒的？[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-40" face="normal" time="10"]
#makado
[resetdelay]
……什么意思[p]
#riki:smileCE
因为啊。[r]
志户田那家伙　对我们的事情根本一无所知嘛。[p]
[chara_hide name="makado" time="100"]
[chara_show name="riki" top="-100" wait="false"]
#
登利一边说着，一边轻轻摇晃着脑袋。[p]
#riki
我可是知道得很清楚。毕竟我是八种的人啊。[r]
听说御黑祟的诅咒会侵蚀心灵脆弱的地方……[l][r]
不过啊，[p]
#riki:smileB
班上能和志户田说上十句话以上的家伙[r]
除了树月之外应该没有别人了吧[p]
#riki:smileG
[delay speed="60"]
那种事情、[r]
至今都没和周围人有过交集的志户田啊……[p]
#riki:ghost
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="45"]
[resetdelay]
怎么可能理解我的、这个诅咒的根源！！[r]
根本不可能懂啊！！！[p]
#riki:ghost
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
对吧！！御白姬大人！！！[p]
[stopbgm]
#
[resetfont]
[mask time="100"]
[playse  volume="60" buf="0" storage="sariin.ogg" ]
[wse]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="riki" time="10"]
[bg storage="still/riki_battle.jpg" time="100"]
;ＳＥカーン
[mask_off time="100"]
[wait time="2000"]
[bg storage="indoor/makado_zasiki_sp.jpeg" time="10" cross="false"]
[mask time="100"]
[wait time="1000"]
[chara_show name="riki" top="-100" wait="false"]
[mask_off]
#riki:ghost
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
@layopt layer=message0 visible=true
[resetdelay]
[quake time="30"]
……！[wait time="500"]　呜……！？[p]
@layopt layer=message0 visible=false
#
[mask time="100"]
[chara_hide name="riki" time="10"]
[playse  volume="60" buf="0" storage="sariin.ogg" ]
[wse]
[bg storage="still/riki_battle.jpg" time="100"]
[mask_off time="2000"]
[wait time="2000"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[delay speed="100"]
;回想スチル
@layopt layer=message0 visible=true
……不该是这样的[p]

#
明明不该变成这样的[wait time="500"][r]
都是你干的好事　宫田阁下[wait time="500"][r]
不想变成和你一样[wait time="500"][r]
[r]
不想变得和你一样[wait time="500"][r]
[r]
不想看见你[p]
[mask time="100"]
[wait time="2000"]
[chara_show name="riki" top="-100" wait="false"]
[bg storage="indoor/makado_zasiki_sp.jpeg" time="10" cross="false"]
#riki:ghost
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[mask_off]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
……怎、怎么回事？这是……[p]
[mask time="100"]
#
[bg storage="still/riki_battle.jpg" time="100"]
[playse  volume="60" buf="0" storage="sariin.ogg" ]
[wse]
[chara_hide name="riki" time="10"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[mask_off time="3000"]
;回想スチル
[resetdelay]
;〇病院
……知贵、又恶化了吗。[l][r]
那么优秀的孩子，[r]
为什么要遭这种罪啊[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
――妈妈。我、给知贵折了纸鹤！[p]
#
……[p]
#
[delay speed="60"]
――[wait time="500"]妈妈？[p]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
[font size="43"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[resetdelay]
……哇啊啊啊啊！！！[r]
哇啊啊啊！！[r]
哇啊！[r][wait time="500"]
[quake time="30"]
啊啊啊啊啊啊啊啊[r]
啊啊啊啊啊啊[r][quake time="30"]
呜啊啊啊啊啊啊[wait time="500"][er][r]
[resetfont]
#
老妈看着我的纸鹤哭了起来[l][r]
[font size="45"]
「你啊！　[r]
连个纸鹤！　都折不像样！」[l][r]
[r]
[font size="50"]
「知贵！[r]
在你这个年纪时[r]
早就在幼儿园手工比赛拿金奖了！」[p]
[resetfont]
[font size="20"]
听到老妈的哭声，大家都围了过来。[p]
[font size="70"]
我已经！[r]
[r]
你的样子[r]
不想再看到了！！[r][wait time="500"]
[r]
不想看到啊[p]
[resetfont]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
#
[delay speed="100"]
老妈。[r]
我。[p]
[font size="20"]
我难道、[wait time="500"]不是和知贵一样的吗？[p]
[resetfont]
[mask time="3000"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="indoor/makado_zasiki_sp.jpeg" time="10" cross="false"]
[mask_off]
#riki:ghost
[delay speed="100"]
…………。[r]
喂，太狡猾了吧[p]
[bg storage="brack.png" time="300"]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（……刚才，我所看见的——）[p]
#
我方才还在注视着陌生的景象[r]
[bg storage="indoor/makado_zasiki_sp.jpeg"  cross="false"]
用手遮住了自己的眼睛。[p]
#riki:ghost
为什么……为什么啊[p]
[resetdelay]
[chara_show name="riki" top="-100" wait="false" time="300"]
太狡猾了[wait time="500"]　为什么、为什么你……[l][r]
为什么你这种从不顾及他人的家伙[p]
#riki:ghostG
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
[playse  volume="30" buf="0" storage="garasu.ogg"]
[quake time="30"]
[font size="43"]
会出现在我重要的记忆里，[r]
怎么能这么轻易就触碰啊呜呜呜呜呜！！！！[p]
[resetfont]
;ＳＥラップ音
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
这是我第二次经历这样的体验。[l][r]
第一次……是在与受诅咒的雾绘对峙的那一天。[l][r]
[r]
[r]
所以，[wait time="500"]正因为是第二次，我才能如此确信。[r]
这是……………………[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-60" face="tweet" time="10"]
#makado
[resetdelay]
——！ 纱、纱罗纱！[r]
你刚才做了什么！？[p]
#sarasa
我、我……[l][r]
#sarasa
[delay speed="100"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
刚才、我好像……看到了登利君的[font color="0xf08080"]过去[resetfont][p]
#makado:wowCM
………………诶……[p]
[chara_hide name="makado" wait="false"]
#sarasa
（虽然不明白为什么……）[p]
[resetdelay]
（如果继续下去的话，[r]
说不定能接近登利君诅咒的根源！）[p]
（首先必须理解刚才的回忆究竟意味着什么）[p]
@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]
#
[r]
【选择正确的选项】[r]
＿＿＿被＿＿＿＿＿＿告知后，＿＿＿＿的记忆。[r]
[glink color="btn_12_black" target="*but" text="父親" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but" text="知貴" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good" text="母親" width="20" x="580" y="60" exp="f.flag1=true" clickse="tapSE.ogg"]
[glink color="btn_12_black" target="*but" text="我不想看到你" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but" text="难过" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but" text="高兴" width="20" x="430" y="60" ]
[glink color="btn_12_black" target="*but" text="顶嘴" width="20" x="380" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*but
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[if exp="f.flag2==true"]
@jump target="good2"
[endif]
[if exp="f.flag1==true"]
@jump target="good"
[endif]
@jump target="loop"

;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
被母亲＿＿＿＿＿＿告知后，＿＿＿＿的记忆。[r]
[glink color="btn_12_black" target="*but" text="父親" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but" text="知貴" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good2" text="我不想看到你" width="20" x="530" y="60" exp="f.flag2=true" clickse="tapSE.ogg"]
[glink color="btn_12_black" target="*but" text="难过" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but" text="高兴" width="20" x="430" y="60" ]
[glink color="btn_12_black" target="*but" text="顶嘴" width="20" x="380" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good2
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
被母亲说不想见到你这样的孩子后，＿＿＿＿的记忆。[r]
[glink color="btn_12_black" target="*but" text="父親" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but" text="知貴" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good3" text="难过" width="20" x="480" y="60" clickse="tapSE.ogg"]
[glink color="btn_12_black" target="*but" text="高兴" width="20" x="430" y="60" ]
[glink color="btn_12_black" target="*but" text="顶嘴" width="20" x="380" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[wse]
#riki
[current layer="message0"]
[position vertical=false]

[font size="40"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
呃啊啊啊！！[r]
住、住手啊——！！[p]
[resetfont]
#makado
…………[p]
#makado
登利君，你现在根本不清醒。[r]
为了让你恢复原状，先给我老实待着！[p]
#
[playse  volume="20" buf="0" storage="shimeage.ogg" ]
登利被勒紧的身体扭曲挣扎着。[p]
[delay speed="70"]
——但在痛苦挣扎了片刻之后。[l][r]
[stopbgm]
他带着雾气般模糊的表情……露出了笑容。[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="1000"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[quake time="30"]
[wse]
;ＳＥ縄が落ちる
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
房间中央啪嗒一声[r]
绳索掉落了。[p]
随后…………[l][r]
[layermode name="riki" graphic=riki.png time=300 mode="lighten"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
登利在自己原先所在的位置只留下红色雾气，[r]
他的身影彻底消失了。[p]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=3000 volume="30"]
#makado
……！消、消失了……！？[p]

;〇もやがかる画面
#sarasa
（——！不对，不是消失……[l][r]
[resetdelay]
整个房间里，登利君——[font color="0xf08080"]
扩散[resetfont]了！！）[p]
#
当我目睹这一幕的瞬间，[r]
立刻弯腰伏地，捂住了嘴。[p]
#
就像火灾发生时那样，[r]
「就像曾经学过「弯腰避免吸入浓烟」时那样……[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[clearfix]
「啊哈哈哈！！嘎哈哈哈哈！！[r]
蠢货——！！」[l][r]
「所以说啊——[r]
从最开始你们就注定要被老子宰杀啊！」[l][r]
[r]
「就凭你们！！[wait time="500"][r]
搞偷袭！[quake time="30"][wait time="500"]　耍阴招……」[p]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
「还想玩弄人心！[r]
从出手的瞬间起就注定啦！！」[l][r]
[r]
[delay speed="70"]
仿佛置身于闭园前静谧的游乐园中。[l][r]
不知从何处传来的，是登利亢奋的声音。[l][r]
[r]
[resetdelay]
[font size="20"]
「呃……这、……」[l][r]
[resetdelay]
[resetfont]
[r]
就在被那声音分散注意的间隙，[r]
贤治郎先生在红雾深处按着胸口——颓然倒地。[p]
「……啊、……！」[r][l]
这样啊。[delay speed="90"]……不，原来如此。[l][r]
他什么都看不见。[r]
就像无法辨识雾绘那异形的姿态一般，[l][r]
登利这[wait time="500"]反常的突变也……！[p]
[resetdelay]
「咦？贤治郎先吸了……」[r]
「啊—啊—贤治郎真可怜。真可怜。[r]
要是没站在志户田那边，就不用死了嘛」[l][r]
[r]
发出声音的烟雾，[r]
逐渐聚拢——[wait time="500"]开始具现成形。[p]
[free_layermode name="riki" time="1000"]
化为缺了几根手指的『登利力』的它，[r]
俯视着倒在地上的贤治郎先生。[p]
[delay speed="60"]
[fadeoutbgm time="2000"]
[chara_show name="riki" top="-100" face="ghost" wait="false"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#riki:ghost
话说啊—要不是你们关住我[r]
也不至于落到这么被动的局面吧。[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
该怎么说呢，运气真背啊，贤治郎[p]
#makado
[font size="20"]
[delay speed="100"]
咳哈……你也能……[l][r]
像雾绘一样施展『某种能力”呢……[p]
#
[resetfont]
贤治郎先生与被诅咒的登利，和方才完全[r]
双方立场完全逆转。[p]
#riki:ghost
[resetdelay]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
哈？贤治郎你看不见”吗！？[r]
那可真没辙了。[r]
难怪能心安理得囚禁老子。[p]
[delay speed="70"]
不过这事，[wait time="500"][r]
要是志户田早告诉咱，本可以躲过吧？[r]
这混蛋真够薄情的，真的[p]
#sarasa
…………………………[p]
#
————登利始终没有将视线转向这边，[r]
背对着我露出轻蔑的神情。[p]
#makado
[font size="20"]
[delay speed="100"]
…………………………………………[l][r]
不存在……[p]
[resetfont]
[resetdelay]
#riki:ghost
？[l]……你说什么？[r]
[resetdelay]
贤治郎，你刚才说什么了？[p]
#makado
[delay speed="80"]
[font size="20"]
……根本不存在啊、咳……、[p]
#
[resetfont]
我的视线越过贤治郎先生与登利的背影交汇。[p]
#makado
[font size="20"]
[resetdelay]
这个小镇上，[wait time="500"]……………………[l][r]
根本不存在什么薄情寡义之人[p]
#
[stopbgm]
;ＳＥ鞭
[quake time="30"]
[mask time="10"]
[playse  volume="70" buf="0" storage="punch.ogg" ]
[wait time="500"]
[mask_off time="10"]
[quake time="10"]
#riki:ghost
——！[l][r]
#riki:ghostG
[font size="45"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
呜啊啊啊！！好痛啊！！！[p]
@layopt layer=message0 visible=false
[clearfix]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="+=800" time="800"]
[chara_hide name="riki" time="200"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
[chara_show name="sarasa" face="angry" wait="true" time="3000" top="-160"]
[delay speed="100"]
[resetfont]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
………………………………[l][r]
#sarasa:lookAway
………………………………[p]
#sarasa:closeEye
…………[p]
[resetdelay]
#sarasa:angry
……贤治郎先生、登利君他[r]
像烟雾一样改变形态袭击过来了！[r]
请小心不要被他吸入！[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
[chara_hide name="sarasa" wait="false"]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
我将手中沉重的鞭状武器[r]
抛回给贤治郎先生。[p]
实体化的登利被「这条鞭子」弹开后[r]
果然还是无法行动，[r]
与贤治郎先生交错着摔倒在房间角落。[p]
[chara_show name="makado" top="-10" face="closeEye"]
;ここから馬門の立ち絵縄装備に戻して
#makado:
……咳咳。谢谢。[r]
原来如此，登利君不是消失了，而是雾化散开了啊[p]
#riki
[font size="20"]
[delay speed="70"]
啊啊啊～就差一点就能抓住这个碍事男人的肺、直到捏爆它。[r]
明明只差最后一步了。啊，可恨、太可恨了……[p]
#makado:lookAway
[resetfont]
就算是我这样迟钝的人也完全明白了。[r]
必须尽快结束这种局面[p]
[resetdelay]
#makado:tweet
要是他再次雾化的话，[r]
像刚才那样束缚也是徒劳吧。[p]
#makado:normal
我们得采取对策来抵御诅咒！[r]
纱罗纱，请你集中精力为登利君驱邪[p]
#sarasa
是……！[p]
#
再一次，[r]
试图触碰他的回忆……磨砺精神。[p]

;▶ともきのかわりにあんたがきえればいい

@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
*kenno
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
;[glink color="btn_12_black" target="*kenno-yes" text="ともきのかわりに<br>あんたがきえればいい" width="200" x="450" y="60" ]
[r][r][r][r][r]
[r][r][r][r][r]
[link target="*kenno-yes"]「ともきのかわりに[r]あんたがきえればいい」[endlink][r]
[call target="*q_hover"]


[resetfont]
[s]
;-------------------------------------------------------------------------------
*kenno-yes
;-------------------------------------------------------------------------------
[cm]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]

;ＳＥカーン

;回想スチル
[mask time="100"]
#
[bg storage="still/riki_battle.jpg" time="100"]
[playse  volume="60" buf="0" storage="sariin.ogg" ]
[wse]
[chara_hide name="makado" time="10"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[fadeoutbgm time="3000"]
[wait time="3000"]
[clearfix]
[mask_off time="3000"]
[font size="22"]
#
知贵是我的哥哥。[r]
大我六岁，非常聪明。[l][r]
[r]
[r]
不，[wait time="500"]应该说曾经非常聪明。[p]

我所认识的知贵几乎都躺在病床上。[l][r]
从我出生时起[wait time="500"]　就出现了多到记不清的症状[r]
医生也治不好　因为是很难治的病。[l][r]
[r]
[r]
所以大概，[r]
现在我应该比知贵更聪明。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#知貴
[resetfont]
不过呢。我也在学习，[r]
至少比力要聪明些吧[p]
#riki
哈！不不。[p]
知贵的身体需要把营养优先供给大脑以外的地方[r]
反正症状多的是，[r]
干脆老实认输算了！[p]
#知貴
哎呀～。[r]
就算只用现在吊的这点点滴，[r]
感觉也比阿力聪明点儿呢～[p]
#riki
要干架吗！[p]
#知貴
才不要！会死人的！[p]
[font size="22"]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
像往常一样作势要扑过去打知贵时，[r]
知贵用输液管扯着绷紧的皮肤，吊得更高些笑了。[l]
[r]
然后我猛地回头看去。亲属们一个都不在。[l][r]
太好了。[l][r]
[r]
明明应该先确认好再玩这个游戏的[r]
每次都会后悔得要死，[r]
被教训多少次都改不掉。[l][r]
我就是个不会考虑周围情况的笨蛋啊。[p]
[delay speed="100"]
…………………………[resetdelay]不久后，电视里开始播放教育节目。[l][r]
今天好像要播《蜜蜂的秘密》呢。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#riki
[delay speed="60"]
[resetfont]
喂，知贵。[p]
#知貴
干嘛[p]
#riki
知贵你啊，就像蜂后一样。我们家的。[p]
#知貴
哈？[p]
#riki
本来就是嘛。你看。[p]
#
[resetdelay]
我指着电视屏幕说道。[p]
#
知贵就是我们家的蜂后。没错。[l][r]
而我、家人还有所有亲戚，全都成了工蜂。[p]
[bg storage="brack.png" time="5000" wait="true"]
后来不知怎的，我渐渐无法和知贵正常交谈，[r]
最终，知贵真的再也说不出话了。[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font size="22"]
三年过去，[r]
只有在看完录像后的片刻才能想起知贵的声音。[l][r]
我的声音变得比知贵更低沉，[r]
而长眠不醒的知贵面容，也一点一点改变了。[l][r]
[r]
[delay speed="50"]
那个会说话的知贵，从大家记忆中渐渐淡去。[p]

这到底是怎么回事？[l][r]
[r]
[r]
明明之前还很精神的。[p]

医院的人应该都记得吧，[r]
知贵他啊。[l][r]
[r]
[r]
那家伙以前[wait time="500"]可精神多了。[p]
[resetfont]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#母
必须……必须更加努力祈祷才行……[l][r]
别让知贵消失。别让知贵死掉。[p]
#
[delay speed="60"]
我也会祈祷。和妈妈、叔叔、婶婶一起，[r]
和堂兄妹、奶奶、爷爷一起。[p]
#
别让知贵消失。别让知贵死掉。[p]
#母
这样的。现在的，这孩子。不是知贵[p]
#
这不是知贵。[l][r]
——已经，不是知贵了吗？[p]
[resetdelay]
等等，妈妈。[r]
这家伙，是知贵啊！[p]

已经，不说话，也不睁开眼睛，[r]
就算什么都不再对我说，[l][r]
这家伙、就是我哥哥的、[wait time="500"]知贵对吧！[p]
[delay speed="60"]
因为我、[wait time="500"]之所以会出生、[p]

#母
——什么？[l][r]
只要满口漂亮话就行，小孩子真是轻松呢[p]

你这个派不上用场的备用品[p]
#
[wait time="2000"]
听到这句话我恍然大悟。[l][r]
从懂事起就一直不明白的、自己存在的意义[p]

[wait time="500"]俺は知貴の代わりになれないなら、[wait time="500"]消失なきゃいけない。[p]
[mask time="3000"]
[bg storage="indoor/makado_zasiki_sp.jpeg" time="10" cross="false"]
[layopt layer="message1" visible="true"]
[eval exp="f.flag1=false"]
;-------------------------------------------------------------------------------
*loop2
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]

[r]
【选择正确的选项】[r]
登利力希望以＿＿＿＿代替＿＿＿[r]
[glink color="btn_12_black" target="*good4" text="兄" width="20" x="680" y="60" exp="f.flag1=true"]
[glink color="btn_12_black" target="*but2" text="力" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but2" text="母親" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but2" text="自己" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but2" text="知道" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but2" text="变聪明" width="20" x="430" y="60"]
[glink color="btn_12_black" target="*but2" text="消失" width="20" x="380" y="60" ]
[mask_off time="3000"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[if exp="f.flag1==true"]
@jump target="*good4"
[endif]
@jump target="*loop2"
;-------------------------------------------------------------------------------
*good4
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
【选择正确的选项】[r]
登利力希望能代替兄长＿＿＿[r]
[glink color="btn_12_black" target="*but2" text="力" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but2" text="母親" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but2" text="自己" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but2" text="知道" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but2" text="变聪明" width="20" x="430" y="60"]
[glink color="btn_12_black" target="*good5" text="消失" width="20" x="380" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*good5
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]
;ＳＥカーン
[chara_show name="riki" wait="false" time="10" top="-100"]
#riki
[resetdelay]
[font size="35"]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
呃啊啊啊啊啊——！！[r]
搞什么啊、你这家伙到底想怎样！！[p]
[resetfont]
为什么只要稍微努力一下，[r]
就会践踏我们，[r]
你们凭什么能这样肆无忌惮践踏我们！！？？[p]
[font size="40"]
[playse  volume="30" buf="1" storage="kaminari.ogg"]
这根本就不公平——[r]
开什么玩笑怎么想都不公平啊！！！！！[p]
[resetfont]
#
登利已经单膝跪地，脑袋昏沉地摇晃着。[p]
#makado
……[p]
真的……只要触碰回忆，[r]
就能破除母亲的诅咒吗……[p]
#riki:ghost
呜——不可原谅、绝不原谅，[r]
太狡猾了…………！！！[p]
#riki:ghostG
[font size="40"]
[delay speed="60"]
这 太 狡 猾 了 啊啊啊！！！！！[p]
[chara_hide name="riki" wait="false"]
@layopt layer=message0 visible=false
[clearfix]
[resetdelay]
[layermode name="riki" graphic=riki.png time=300 mode="lighten"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
;ＳＥゴオッ
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible=true
#
[resetfont]
登利似乎用尽了最后的力气。[l][r]
[r]
弥漫在整个房间的锈色烟雾，[r]
每一粒都像是带毒的针。[r]
危险的雾气如同飞虫群般在四面八方流窜。[l][r]
[r]
我被这番景象震慑住了。[p]
[quake time="30"]
「睁开眼睛！你不看着的话登利君就……」[l][r]
[r]
贤治郎先生的声音异常坚定。[r]
可是、就算你这么说……[wait time="500"][r]
做不到的事情就是做不到。[l][r]
[r]
就这样紧紧闭着眼睛、僵在原地的瞬间。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
纱罗纱！[l][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
我们现在正处于[font color="0xf08080"]绳界[resetfont]内侧、无法干涉到登利君！[p]
#sarasa
诶……[p]
[free_layermode name="riki" time="1000"]
@layopt layer=message0 visible=false
[clearfix]
;スチル「登利戦」
[bg storage="still/battle_riki.png" time="5000" wait="true"]
[wait time="2000"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible=true
睁开眼睛时，[l][r]
以我和贤治郎先生所在的位置为中心，[r]
「无烟之域」[r]
正由地面那根鞭状武器逐渐成形――[l][r]
[r]
「来吧，现在就在这里驱邪！[r]
没问题的，对能看见回忆的你来说……」[p]
话音未落，[r]
雾气便咕哝着吐出怨恨之词。[p]
「御、御白姬……呜……御、御……志户田……！！」[p]
#riki
[font size="45"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
你这家伙！！　太差劲了！！！　[r]
你到底明不明白啊啊啊！？？[p]
#sarasa
[resetfont]
…………[l][r]
登利君、你在哭吗……？[p]
#riki
[font size="45"]
烦死了、烦死了、[r]
看啊、看了还不明白吗！！[p]
#sarasa
[resetfont]
………………………………[l]我不明白啊……[r]
因为……你一直都在消失啊……[p]
#riki
是啊。我、会消失的。[r]
该消失的人明明是我才对！[p]
而且不止是我一个人！[l][r]
可是……[wait time="500"][font size="45"]
为什么！！[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
凭什么、选中了知贵！？[r]
患上绝症的可以是其他任何人[r]
都可以啊！！[l]
[r]
[resetfont]
杀人犯、卑劣的遭人嫌恶的家伙、[r]
像我这样无能的废物要多少有多少！[r]
为什么！凭什么……[p]
[font size="50"]
[playse  volume="30" buf="1" storage="garasu.ogg"]
[quake time="30"]
凭什么[r]
大多数人都能像傻子一样心安理得地[r]
活着、[r]
知贵[r]
却非死不可啊啊啊！！！[p]
[resetfont]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]

@layopt layer="message1" visible="true"
[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]
[eval exp="f.flag3=false"]
[eval exp="f.position=570"]
;-------------------------------------------------------------------------------
*loop-kaiko
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
[font size="25"]
【从回忆中提取登利力的诅咒意图】[r]
力量源于＿的＿这句话与卧病在床的＿的身影
愿代替＿成为＿[r]

[glink color="btn_12_black" target="*kaiko-true1" text="母親" width="20" x="570" y="60" exp="f.flag1=true"]
[glink color="btn_12_black" target="*kaiko-false" text="兄" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="450" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="我不想看到你" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="逃跑" width="20" x="330" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="消失" width="20" x="270" y="60"]
[glink color="btn_12_black" target="*kaiko-false" text="活着" width="20" x="210" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*kaiko-false
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[if exp="f.flag3==true"]
@jump target="*kaiko-true3"
[endif]
[if exp="f.flag2==true"]
@jump target="*kaiko-true2"
[endif]
[if exp="f.flag1==true"]
@jump target="*kaiko-true1"
[endif]
@jump target="loop-kaiko"
;-------------------------------------------------------------------------------
*kaiko-true1
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
[font size="25"]
【从回忆中提取登利力的诅咒意图】[r]
力量源于母亲那句＿的话语与[r]
卧病在床的＿身影成为契机 愿代替＿成为＿[r]

[glink color="btn_12_black" target="*kaiko-false" text="兄" width="20" x="570" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-true2" text="我不想看到你" width="20" x="450" y="60" exp="f.flag2=true"]
[glink color="btn_12_black" target="*kaiko-false" text="逃跑" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="消失" width="20" x="330" y="60"]
[glink color="btn_12_black" target="*kaiko-false" text="活着" width="20" x="270" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*kaiko-true2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
[font size="25"]
【从回忆中提取登利力的诅咒意图】[r]
力量源于母亲那句不想见到你的话语与[r]
卧病在床的＿身影成为契机 愿代替＿成为＿[r]

[glink color="btn_12_black" target="*kaiko-true3" text="兄" width="20" x="570" y="60" exp="f.flag3=true"]
[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="逃跑" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="消失" width="20" x="330" y="60"]
[glink color="btn_12_black" target="*kaiko-false" text="活着" width="20" x="270" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*kaiko-true3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
[font size="25"]
【从回忆中提取登利力的诅咒意图】[r]
力量源于母亲那句不想见到你的话语与[r]
卧病在床的兄长身影成为契机 愿代替兄长成为＿[r]

[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="逃跑" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-true4" text="消失" width="20" x="330" y="60"]
[glink color="btn_12_black" target="*kaiko-false" text="活着" width="20" x="270" y="60" ]

[resetfont]
[s]
;ＳＥカーン
;-------------------------------------------------------------------------------
*kaiko-true4
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/ganmon.png" time="5000" wait="false"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="30"]
[wse]
;くはぬ　とばぬ　みず　なれば
;ねがひたてまつる　ひめあそばせ　ひめあそばせ
[wait time="2000"]
[mask time="3000"]
[fadeoutbgm time="3000"]
[wait time="4000"]
[bg storage="indoor/makado_zasiki_sp.jpeg" time="10" cross="false"]
[mask_off time="3000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
#
[wait time="2000"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="60"]
[resetfont]
……满屋弥漫的恶意逐渐凝聚，[r]
开始重新化作登利力的形态。[p]
#riki
……为什么？为什么啊……御白姬。[r]
希望你能告诉我……用我也能明白的方式…………[p]
#
[chara_show name="sarasa" top="-160" face="normal" wait="true" time="2000"]
#sarasa
……[p]
#
登利屈膝跪地，[r]
缓缓倒向地面。[p]
#riki
为什么……周围的人都能若无其事地活下去。[l][r]
唯独我们……就不行吗？[l][r]
回答我啊，御白姬[p]
[chara_hide name="sarasa" wait="false" time="10" wait="true" pos_mode="false"]
[chara_show name="makado" top="-10" face="tweetLA" wait="true" time="100"]
#makado:tweetLA
……喂、她根本不是什么御白姬――[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-160" wait="false" time="10"]
#sarasa:normal
怎么可能若无其事啊[p]
#riki
诶……[p]
#sarasa
大家、其实都不好受啊……[r]
就像登利君你一样难受。[p]
#sarasa:closeEye
……雾绘小姐，一定也是这样的吧[p]
#riki
……[l][r]
就是说啊。明明不止我一个人。[r]
想要从这里消失的念头……[p]
[filter blur="4"]
[resetdelay]
唉。[r]
就算只有我消失了，也什么都改变不了啊。[r]
果然我真是太蠢了——…………。[p]
[chara_hide name="sarasa" wait="false" time="4000"]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="brack.png" time="5000" wait="true" cross="false"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
@layopt layer=message0 visible=true
#
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetdelay]
从登利身上，敌意似乎消失了。[p]

;【第一章】2日目『可、孵化』　終
;セーブしますか？
[mask folder="bgimage" graphic="still/part1.png" time="3000"]
[fadeoutbgm time="2000"]
[wait time="2000"]
[showsave]

@jump storage="chapter_1/day3.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------
;---------------------------------------------------------
*q_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#f08080");
},
function() {
  $(this).css("color", "#000000");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
