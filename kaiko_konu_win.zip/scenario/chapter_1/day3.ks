;第1章『可、孵化』
;三日目
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '一章二日目　後編'"]
[cm  ]
[mask folder="bgimage" graphic="still/part1.png" time="10"]

[mask_off]
;-------------------------------------------------------------------------------
;あとでけす
[chara_config talk_focus="brightness" memory="true" time="0"]
;-------------------------------------------------------------------------------
;暗転
[delay speed="60"]
#riki
…………[p]

……呜……呜呜……[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="indoor/makado_ima_m.jpg" time="2000" wait="true"]
[free_filter]
[chara_show name="riki" face="worry" wait="true" top="-100"]
;〇馬門家居間
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#riki
………咦[p]
;-------------------------------------------------------------------------------
[chara_face name="mokke" face="oji" storage="chara/mokke/menWhite.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '叔父'
[endscript]
;-------------------------------------------------------------------------------
[chara_show name="mokke" top="100" time="100" wait="false"]
[resetdelay]
#mokke:oji
醒了吗？[p]
#riki:shoutG
[quake time="30"]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[wait time=0]
[font size="40"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
哇啊啊啊！！？？　[r]
你谁啊大叔小偷啊啊啊！！？？？[p][resetfont]
[chara_hide_all time="10"]
[chara_show name="sarasa" wait="false" top="-160" face="closeEye"]
[delay speed="50"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=2000 volume=50]
#sarasa
……是贤治郎先生的叔叔……[p]
[chara_move name="sarasa" left="360" anim="false" wait="false" time="100"]
[wait time=0]
[chara_show name="riki" top="-100" left="-80" face="sad" wait="false"]
[wait time=0]
#riki
啊……　志户田[p]
[chara_hide_all time="10"]
[chara_show name="mokke" top="100" face="oji" wait="false" time="100"]
[resetdelay]
#mokke
哈哈哈。说我是小偷可太冤枉人啦。[r]
我可是暂时管理这座神社的人啊。[p]
[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" left="360" wait="false" top="-160" time="100" face="normal"]
[chara_show name="riki" top="-100" left="-80" face="worry" wait="false" time="100" wait="false"]
[delay speed="60"]
#riki
……啊—，是贤治郎的亲戚啊……[r]
确实感觉长得是有点像……[p]
[delay speed="50"]
#riki:normal
诶？但是大叔你说在管理这里，[r]
那贤治郎和这座神社是什么关系？[r]
至少是住在这里吧？打工之类的？[p]
[chara_hide_all time="10"]
[chara_show name="mokke" top="100" face="oji" wait="false" time="100"]
#mokke
不，他还不是正式神职人员。[r]
作为这里的独生子，目前是东京神道系大一学生。[l][r]
[delay speed="70"][font size="20"]
…………恐怕，原计划只待到这个暑假结束吧[wait time="500"][er][resetfont]
[chara_move name="mokke" time="100" wait="false" left="500" anim="false"]
[wait time=0]
[chara_show name="riki" top="-100" time="100" wait="false" left="-100" face="worry"]
[wait time=0]
#riki
诶？[p]
[resetdelay]
#mokke
嗯。[wait time="500"][er]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[wait time=0]
所以今年的白绢祭可是惊天大新闻！[r]
要让学生来当祭典主祭！[l][r]
所以作为附近的神官，我就来帮忙了[p]
#riki:smile
[playse  volume="30" buf="0" storage="kansei.ogg"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[wait time=0]
哇——太厉害了——！！[r]
那大叔你岂不是要管两座神社——！！[p]
#mokke
唔…暂且这么理解也行吧[p]
#riki:smileCE
超厉害啊！那香火钱能收双倍了吧？[r]　
零钱太多反而很麻烦呢！[p]
#mokke
你这人真是现实得可怕……[p]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[wait time=0]
总之能平安醒来就好。[r]
我去叫贤治郎过来[p]
[chara_hide name="mokke" wait="false"]
;ＳＥ　廊下歩いて行く
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
#riki:smile
……。[l][r]
#riki:lookAway
要是那个大叔的话，说不定会绑架我呢[p]
#sarasa
诶……？[p]
#riki:tweetLA
绑架　[wait time="500"]我一直　很喜欢被绑架的感觉[r]
虽说喜欢　其实也就被绑过三次左右啦[p]
[fadeoutbgm time="2000"]
#riki:smileH
能体验到离家出走的快感呢。[r]
假装是别人家的孩子……[l][r]
要是厌烦了，逃跑就行啦[p]
#riki:shame
但是……每次啊。[r]
[delay speed="50"]
结果绝对会在第二天就跑回家里来啊。[r]
就算隔了几天……[wait time="300"]家里人也什么都不说[p]
[chara_face name="riki" face="back" storage="chara/riki/back.png"]
#riki:back
总觉得知贵已经痊愈了[p]
[delay speed="80"]
在我去探望之前。[r]
觉得知贵……会突然坐起来，又开始说话[p]
……[p]
[delay speed="100"]
…………………………………………[p]
……………怎么可能会………痊愈啊………[p]
#
……………………[p]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[resetdelay]
[chara_hide name="riki" time="10"]
;ＳＥスパン
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_show name="makado" top="-10" time="100" wait="false" face="angrySH"]
[quake time="30"]
[font size="40"]
#makado
[fadeinbgm storage=gymnopedies2.ogg loop=true time=2000 volume=50]
登利君！[p]
[resetfont]
[chara_move name="makado" time="100" wait="false" left="-100" anim="false"]
[wait time=0]
[chara_show name="riki" top="-70" time="100" wait="false" face="wow" left="360"]
[wait time=0]
#riki:wow
贤、贤次郎[font size="20"][r]
表情好可怕[p]
#makado
[resetfont]
[delay speed="15"]
有没有记忆混乱或者过度求死的倾向？[p]
#riki:tweetLA
没……没有。感觉和平时一样[p]
[delay speed="60"]
#makado:wowCM
这样啊……[l][r]
……………………[p]
#makado:smileMini
你平安无事真是太好了。[r]
登利君[p]
#riki:wow
……啊[r][wait time="400"]
#riki:worry
我？　我还活着？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" wait="false" face="closeEye" top="-160"]
#sarasa
嗯[l][r]
#sarasa:smile
……登利君能平安回来，我很高兴。……我也是[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" wait="false" face="wow"]
#riki
……[l][r]
…………………………[p]
#riki:smileCE
哈……哈哈 你怕什么呀？[r]
先庆祝咱们还活着吧—[p]
[delay speed="100"]
#riki:shame
………………[l][r]
#riki:back
抱歉 志户田[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" face="normal" time="100" wait="false"]
#sarasa
………………[l][r]
#sarasa:closeEye
……对不起[p]
[resetdelay]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" time="100" wait="false" face="worry"]
#riki
……………………[p]
#riki:sad
啊？这有什么好道歉的？[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" face="closeEye" time="100" wait="false"]
[delay speed="50"]
#sarasa
因为擅自看了……你的记忆……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" time="100" wait="false" face="sad"]
#riki
……啊——[p]
#riki:tweetLA
无所谓啦……[r]
关于知贵的事，不只志户田，该知道的人都知道啦[p]
#riki:angry
田径社超有名的！[r]
我家有个卧床不起的病人这种事很可怜是吧！[r]
你这家伙果然对别人完全没兴趣啊—[p]
[chara_move name="riki" top="-10" time="300" wait="false" left="360" anim="false"]
[wait time=0]
[chara_show name="makado" top="-10" face="normal" left="-100" wait="false"]
[wait time=0]
#makado
卧床不起？　[r]
登利君家里有需要照顾的病人吗[p]
[resetdelay]
#riki:tweetLA
……嗯……算是吧　在医院……[r]
县医院里住着我大哥　从我一出生就在那儿了[p]
#riki:shame
所以我家可忙了！　要照料什么的……[r]
因为要照顾知贵嘛[p]
#makado:lookAway
这样啊……和我家情况一样呢[p]
#riki:worry
诶？[p]
#makado:tweet
我父亲也是长期卧床[r]
两年前中风倒下后　一直在家里照顾着[p]
#makado:tweetLA
刚才还去看过情况呢[r]
从早上开始妈妈就一直在身边守着……[p]
[delay speed="60"]
#riki:tweetLA
……原来是这样[r]
那我今天岂不是超级添麻烦　占用了人手[p]
[resetdelay]
#makado:angry
嗯。[r]
正因如此　今后绝对不能再袭击纱罗纱了[l][r]
#makado:tweetLA
被同班同学差点杀掉　肯定很受打击吧[p]
#riki:normal
……不过志户田那家伙神经还挺大条的—。[r]
说不定意外地没事儿呢？[l][r]
#riki:hate
现在八成正攥着把柄琢磨让我干什么呢！[p]
#sarasa
才……才不会那样做呢，我……[p]
#riki:smileCE
谁知道呢。[r]
你这人平时在想啥根本搞不懂啊！！[p]
[delay speed="50"]
#makado:tweet
喂，登利君。纱罗纱不是那种孩子……[p]
[resetdelay]
[font size="37"]
[quake time="30"]
#riki:shoutG
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[fadeinbgm storage=sicilienne.ogg loop=true time=300 volume="30"]
闭嘴秃子！！[r]
能平安活着真是太好了——才怪啊！[p]
[chara_mod name="riki" face=""]
[chara_mod name="makado" face="wow"]
被你鞭子抽过的地方还留着疤呢！[r]
对初中生下手你还是人吗！[p]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
[resetfont]
#makado:wow
哈……！[p]
[chara_hide_all time="10"]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
;ＳＥ　襖スパン
[chara_show name="hino" top="-100" time="100" wait="false" face="angry"]
#hino
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="50"]
[font size="37"]
贤治郎先生才不是秃子————！！！[r]
只是剃头时太用力了而已————！！！[p]
[resetfont]
[chara_move name="hino" top="-100" anim="false" left="-100" wait="false"]
[wait time=0]
[chara_show name="riki" top="-100" time="100" wait="false" left="360" face="wow"]
[wait time=0]
#riki:wow
日、日野啊！！[p]
#hino:shame
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[wait time=0]
听听你这口气！登利你小子怎么说话呢！！[r]
对中暑晕倒时让我休息的恩人竟然——！[p]
#riki:sad
……中暑？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" face="closeEye" time="100" wait="false" top="-160"]
#sarasa:closeEye
（……当时是这么跟他解释的）[p]
#sarasa:normal
（在登利君睡着的时候，[r]
日野到达了神社……解释起来可费劲了）[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" left="-100" wait="false" face="angry"]
[chara_show name="riki" top="-100" time="100" wait="false" left="360" face="wow"]
#riki:worry
（诶……啊、啊啊。原来是这么回事）[p]
#riki:tweetLA
那你手里拿的那个东西……[p]
#hino:smile
嗯？没错，你发现了吗！！这些堆积如山的资料！！[p]
#hino:happy
[playse  volume="30" buf="0" storage="kansei.ogg"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[wait time=0]
哈哈哈！没错！[r]
在你昏睡的时候 神社里珍藏的文献资料[r]
我可是全都借阅过了啊——！！[p]
#hino:smile
你擅自迟到害得在商店街被丢下不说，[r]
连去神社都被排挤在外确实让我意外……[p]
[chara_mod name="riki" face="sad"]
#hino:happy
[playse  volume="20" buf="1" storage="kakan.ogg" ]
好不容易赶到却晕成烂泥也太不像话了！[r]
噗哈哈哈！！[p]
[delay speed="10"]
#hino:smile
话说贤治郎先生！[r]
这家伙刚才提到鞭子什么的了吧。[r]
登利难道见过[font color="0xf08080"]那件武器[resetfont]吗！？[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" wait="false" face="wow"]
[resetdelay]
#makado:wow
……[p]
[delay speed="10"]
[chara_show name="hino" top="-10" left="-100" wait="false" face="sad"]
[chara_show name="riki" top="-10" time="100" wait="false" left="360" face="sad"]
#hino:sad
真好啊！我也总有一天[r]
想亲眼见识一下的！！[p]
[font size="37"]
#hino:smile
务必！也让我看看吧 求您了！[p]
[resetfont]
[delay speed="60"]
#makado:wow
………………[p]
#hino:smile
……[p]
[resetdelay]
#hino:angry
[font size="37"]
[quake time="30"]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
哎！？贤治郎先生！？！？[p]
[resetfont]
[resetdelay]
#makado:wowCM
……啊。[r]
抱歉，刚才走神了……[p]
[delay speed="50"]
#makado:lookAway
那个……、[r]
你所说的[font color="0xf08080"]武器[resetfont]，就是指这个吧[p]
[chara_hide_all time="10"]
#
[image layer=0 folder="image" name="simenawa" storage="item/simenawa.png" width="460" x="270" y="107" time="800" ]
;アイテムスチル：神厩舎の注連縄
[font size="37"]
[quake time="30"]
#hino
呜哇哇——！！[r]
『神厩舍的注连绳』！！是真货啊啊啊！[p]
[resetfont]
#riki
神厩舍的注连绳？啥东西。很有名吗？[p]
[resetdelay]
#hino
在我心里这可是超火的神器NO.1！超想摸一把！[r]
……是、是马门神社世代相传的真货。[l][r]
没想到今天就能亲眼见到……[p]
#riki
嚯。[r]
老子被这玩意儿揍得死去活来可一点都不感激啊[p]
[quake time="30"]
[font size="37"]
#hino
被揍得死去活来！？你什么来头！？[r]
干了啥才会遭这种报应啊！？[p]
[resetfont]
[free layer=0 name="simenawa" time="800" wait="false"]
[delay speed="50"]
#makado
这是远古时代我家神社的马厩……[l][r]
也就是说，这是神明之马栖息之处的注连绳[p]
[chara_show name="makado" top="-10" wait="false" face="tweetLA"]
[chara_show name="hino" top="-10" left="-100" wait="false" face="normal"]
[chara_show name="riki" top="-10" time="100" wait="false" left="360" face="normal"]
#makado
和普通的不同，连纸垂都很少，[r]
历代白绢祭祭主和神官们拔下的头发绞缠而成……[p]
[resetdelay]
#riki:worry
诶、这是用头发做的？[p]
#makado:normal
没错[p]
#riki:sad
好恶心[p]
#hino:shame
[playse  volume="20" buf="0" storage="kakan.ogg"]
[anim name="hino" top="+=30" time="150"]
[wait time=0]
[anim name="hino" top="-=30" time="150"]
[wait time=0]
才不恶心呢——！[l][r]
[chara_mod name="hino" face="angry"]
多亏这个才完成了对御子的封印[r]
这可是有传说记载的！[p]
#makado:smileMini
不愧是日野，懂得真多啊[p]
#makado:tweetLA
正如日野所说，这个镇上留存的文献中记载着[r]
『[font color="0xf08080"]用马门神社的注连绳束缚 奥罗牟克就无法动弹[resetfont]』[r]
类似的记述屡见不鲜[p]
#hino:happy
呵呵呵。被祭主大人夸奖了[p]
#makado:tweet
正因这个传说，所以特别制作了专用握柄……[r]
改造成了能像鞭子一样挥舞的注连绳[p]
#riki:tweetLA
哼——。[r][delay speed="60"]
嘛反正也无所谓啦……[p]
#riki:normal
说到底，注连绳到底是什么东西？[p]
[chara_hide name="makado" time="100" pos_mode="false" wait="false"]
[chara_move name="riki" top="-100" left="340" anim="true" wait="false"]
[wait time=0]
[chara_move name="hino" top="-100" left="-80" anim="true" wait="false"]
[wait time=0]
[resetdelay]
#hino:smile
呵。登利。你这家伙。居然问这个。[r]
你还杵在那儿啊[p]
#riki:angry
啊别摆那张脸看着火大[p]
#hino:smile
就可怜可怜告诉你吧。[l][r]
[fadeoutbgm time="2000"]
[delay speed="60"]
[chara_mod name="hino" face="tweet"]
所谓注连绳，就是用来划分空间，[r]
就是为了防止污秽不净之物进入这个范围的结界……[p]
#hino:normal
嘛、说白了就像是禁止入内的警戒线一样啦[p]
#riki:tweetLA
禁止入内的警戒线[p]
#hino:smile
没错！[l][r]
#hino:tweet
所以被注连绳守护的内部世界，既洁净又安全。[r]
就是这么个防止外界恶灵和污秽入侵的机制[p]
[delay speed="100"]
#sarasa
…………………………[p]

;〇回想
[mask time="1000"]
[fadeinbgm storage=bigriver.ogg loop=true time=3000 volume="20"]
[chara_hide_all time="10"]
@layopt layer=message0 visible=false
[clearfix]
[filter grayscale="100"]
[bg storage="still/kirie_bridge.jpeg" time="10"]
[wait time="700"]
#
[mask_off]
[wait time="800"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#kirie
纱罗纱。[r]
我有话要转告你和树月
[wait time="1000"][er]

[bg storage="brack.png" time="100" wait="false"]
#
——真正的诅咒，是无法消除的[r]
[wait time="2000"]
别自作多情了[wait time="3000"]
[er]
#
[mask]
;スチル足
[stopbgm]
[playse  volume="30" buf="0" storage="basya2.ogg" ]
;ＳＥ川に飛び込む　暗転
[wait time="700"]
[free_filter]
[bg storage="indoor/makado_ima_m.jpg" time="10"]
[chara_show name="makado" top="-10" wait="false" face="normal"]
[chara_show name="hino" top="-10" left="-100" wait="false" face="normal"]
[chara_show name="riki" top="-10" time="100" wait="false" left="360" face="normal"]
#
[mask_off time="2000"]
………………………………[p]
[playse  volume="40" buf="0" storage="hikidopen2.ogg"]
[resetdelay]
#riki:wow
咦？[wait time="1000"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[er]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
#riki:worry
喂志户田！你小子躲哪去了……[p]
#makado:normal
……[p]
#makado:lookAway
不，抱歉，[r]
登利君他们已经先去真正的资料室那边了。[r]
地点日野应该知道吧[p]
#hino:happy
明白！完全OK！[p]
#makado:smileMini
谢谢。[r]
等下我会带纱罗纱也过去[p]
[mask]
[chara_hide_all time="10"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="800"]
[bg storage="indoor/makado_roka.jpeg" time="10"]
[chara_show name="makado" top="-10" face="normal" time="10" zindex="2" left="100"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=30]
[mask_off]
;〇廊下
#makado
纱罗纱。没事吧？[p]
[delay speed="60"]
#sarasa
……贤治郎先生[p]
#sarasa
………………[p]
[delay speed="50"]
#
贤治郎先生究竟知道多少呢。[p]

她身上到底发生了什么。究竟被什么诅咒了。[r]
然后……[p]
#sarasa
……雾绘小姐，[r]
临终前曾说过这样的话。[l][r]
「真正的诅咒不会消失」[p]
#makado:normal
……[p]
#sarasa
[delay speed="60"]
但是，通过这次事件……我明白了。[r]
那时的雾绘小姐，果然也……[p]
[delay speed="100"]
#sarasa
……[wait time="1000"]
明明用我的方式就能救下来的…………[p]
[chara_face name="kirie" face="ghostC" storage="chara/kirie/ghostC.png"]
[chara_show name="kirie" top="-10" face="normal" time="100" wait="false" zindex="1" left="-10"]
[stopbgm]
#kirie:normal
是这样呢[p]
#sarasa
————呜、[p]
#kirie:ghostC
我家是被你杀掉的[p]
[chara_hide name="kirie" time="1000" wait="false" pos_mode="false"]
#makado:tweetLA
不是[p]
[delay speed="50"]
;（きりえの立ち絵消失る）
#makado:tweet
不是的……雾绘的事，不是你的错[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=30]
[chara_move name="makado" face="normal" time="1000" wait="false" left="-70"]
[chara_show name="sarasa" top="-60" face="sadB" time="2000" wait="false" left="360"]
#makado
正如『不可逆』这个词的含义，[r]
逝去的时光永远无法再度重来[p]
#makado:tweet
珍视回忆并时常回想本身是健康的行为。[r]
但是，为改变回忆而痛苦无疑是不健康的。[p]
#makado:closeEye
——不过，会产生这种想法也情有可原。[l][r]
[chara_mod name="makado" face="tweetLA"]
毕竟我也…如此渴望回到过去。想对从前的自己[p]
#sarasa:worry
……[p]
#
[bg storage="brack.png" time="3000" wait="false"]
[chara_mod name="sarasa" face="closeEye"]
[chara_mod name="makado" face="lookAway"]
[chara_hide_all time="3000"　wait="false"]
;〇暗転
[resetdelay]
#
我们自出生那刻起便已成不可逆的存在。[p]

一旦知晓了，目睹了，[r]
听闻了的话。[l][r]
就再也。[p]
[delay speed="60"]
……就这样，[r]
如今已彻底蜕变的我，[p]
[delay speed="100"]
对直至终末都未能触及的雾绘的回忆――[r]
终是生出了触碰的渴望。[p]

#sarasa
……贤治郎先生[p]

杯子……真是抱歉了[p]
[mask folder="bgimage" graphic="still/part1.png" time="3000"]

;【第一章】『可、孵化』　終

;セーブしますか？
[fadeoutbgm time="2000"]
[wait time="2000"]
[showsave]
@jump storage="chapter_2/day1_vol1.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
