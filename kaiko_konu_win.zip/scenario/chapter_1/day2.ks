;第1章『可、孵化』
;二日目
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '一章二日目　前編'"]

[cm  ]
[mask folder="bgimage" graphic="still/part1.png" time="2000"]
[bg storage="saka_ｍ.jpeg" time="100"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
[mask_off]
;〇坂（昼）
;ＳＥ	蝉の鳴き声
#
――8月12日。下午3点。[p]

[chara_show name="hino" top="-100" wait="false"]
[delay speed="70"]
#hino:normal
………………………………[p]
;紗羅紗傘で
[chara_move name="hino" anim="true" left="-110" wait="false"]
[chara_show name="sarasa" face="normal_k" top="-160" left="350"]
#sarasa:normal_k
………………………………[p]
#hino:normal
……………………[l][r]
[resetdelay]
#hino:tweet
那个，志户田[p]
#sarasa:normal_k
……[p]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=30]
#hino:tweet
要玩神奇香蕉游戏吗？[p]
#sarasa:closeEye_k
…………？[p]
#hino:smile
啊、没听过。[p]
[delay speed="20"]
[font size="20"]
就是那个啊、1990年代在电视节目里诞生的联想游戏啦。[r]
[chara_mod name="sarasa" face="worry_k"]
从播出当时到我们现代都广泛普及扎根这点来看，电视这种[r]
媒体的强大力量真是让人感慨啊。哎呀～果然游戏这种文化就是人与[er]
[resetfont]
[resetdelay]
#hino:happy
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
啊、那接龙怎么样！？[r]
据说原本是贵族玩的文字接龙游戏，和志户田你超配哦！[p]
[delay speed="20"]
嗯！来玩吧！那我开始啦——！[p]
[font size="60"]
#hino:shame
[playse  volume="20" buf="0" storage="kakan.ogg" ]
龙宫大人！[p]
[resetfont]
[delay speed="70"]
#sarasa:normal_k
………………[r]
狒、狒狒[p]
[font size="60"]
#hino:angry
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]マントヒヒ！？[p]
[resetfont]
#hino:smile
希……希、希达尔神！[p]
[delay speed="70"]
#sarasa:worryLA_k
蜜、[r]
蜜柑……………………？[p]
#hino:normal
…………………………………………[l][r]
#hino:shame
[resetdelay]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font size="60"]
（完蛋了————！！）[p]
[resetfont]
#sarasa:closeEye_k
那、那个，对不起[p]
#hino:smile
不、没事。没关系的。[r]
志户田玩词语接龙这么菜也没什么大不了的。[r]
[font size="20"]
虽然确实闪过「瞧不起我吗？」的念头[p]
[resetfont]
但真正可恶的是……[l][r]
#hino:shame
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[font size="45"]
迟到十分钟都不来赴约的[r]
登利啊——！！！[p]
[resetfont]
#hino:sad
不行了。虽说在树荫下喝着水等着，[r]
但继续待在这种状态下会出大问题的……！[p]
[chara_hide_all]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[delay speed="50"]
#
日野从树荫下冲进了灼热的烈日中。[r]
擦得锃亮的眼镜片反射出耀眼的光芒。[p]
[resetdelay]
[chara_show name="hino" top=-100 face="normal" time="200" wait="false"]
#hino:normal
那志户田。[l][r]
#hino:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
接下来交给我，你先往神社去吧！！[p]
#sarasa
哎……[p]
#hino:angry
没事。那家伙肯定在家睡大觉呢。[r]
看我不像阴摩罗鬼一样把他捶醒！[p]
#hino:tweet
所以你先一个人去马门神社！[p]
#sarasa
（……我该怎么办……？）[p]

;→ついていく
;→一人で神社へ向かう
#
[link target="*tuiteku"]【１】跟上去[endlink][r]
[link target="*hitoride"]【２】独自前往神社[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*hitoride
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;→一人で神社へ向かう
#
我向日野点了点头。[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="hino"]
[bg storage="brack.png" time="3000" cross="false"]
;暗転
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
——之后，独自迈步前行的我。[p]
[delay speed="60"]
为什么呢？　[r]
每走一步，四肢都传来异样的感觉。[p]

而那种感觉——[r]
在通往神社的台阶上每踏一级，就化为更强烈的确信。[p]
[fadeoutbgm time="3000"]
在令人窒息的灼热空气中，[r]
指尖逐渐冰冷失去知觉。[p]
身体虽然仍在持续行动，[r]
大脑却已无法掌控自己的行为。[p]

…………视野如雾……似烟[wait time="500"]　般朦胧笼罩，[r]
我正被改造成………………[wait time="500"]非我的某种存在。[p]

结局二　纱罗纱的变身[p]
[cm  ]
[clearfix]
@jump storage="first.ks"
;-------------------------------------------------------------------------------
*tuiteku
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;→ついていく
#sarasa:normal_k
[fadeoutbgm time="3000"]
[delay speed="70"]
唔……。[r]
我也，要去[p]
[chara_show name="hino" top=-100 face="normal" time="10"]
#hino:normal
呃[p]
#sarasa
因为……[l]　登利君、[r]
明明今天的事情，期待了很久的说……[p]
#hino:tweet
……啊 确实那家伙，一直兴奋得不得了。[r]
虽然我也一样。[p]
#hino:angry
[resetdelay]
结果居然迟到[r]
对这种轻浮的家伙真是受够了！[p]
#sarasa
[delay speed="70"]
那个……、[wait time="500"][r]
真的、要是只是迟到还好说……[p]

;〇回想

[chara_hide_all wait="true" time="500"]
[filter grayscale="100"]
[bg storage="school/rouka_m.jpg" time="100" cross="true"]
[chara_show name="riki" face="smileCE" time="10" top="-100"]
[delay speed="50"]
#riki:smileCE
哇——！！ 这算什么啊！[r]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
我要去我要去！[stop_kanim name=riki]绝对要去——！[p]
[resetdelay]
[chara_hide name="riki" wait="false" pos_mode="false"]
[bg storage="saka_ｍ.jpeg" time="100" cross="true"]
[chara_show name="hino" left="-110" wait="false" face="normal" top="-100"]
[free_filter]
[chara_show name="sarasa" face="worryLA_k" top="-160" left="350" wait="false"]
[delay speed="50"]
#sarasa:worryLA_k
明明那么期待的说……。[r]
或许他是遇到了什么不得不取消的事吧[p]
[delay speed="60"]
#sarasa:worry_k
如果真是那样的话，…………[l][r]
#sarasa:sad_k
…………………………………[p]
#sarasa:closeEye_k
……想好好问清楚……[p]
[delay speed="50"]
#hino:tweet
……………………[p]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
噢。……噢噢！[p]
[stopbgm]
#hino:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
什么啊。志户田，[r]
原来你一直都有关注着我们嘛！[p]
#sarasa:wow_k
诶？[p]
;ＳＥ風
[chara_hide_all wait="true" time="500"]
#
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
——为我们遮挡烈日的巨树迎风摇曳，[r]
在头顶沙沙作响。[p]
[chara_show name="hino" face="tweet" top="-100" wait="false"]
#hino:tweet
我……，[p]
[resetdelay]
#hino:normal
不，想必2年1班大部分学生都，[r]
认为志户田根本不会注意到我们的事。[p]
#hino:smile
如果我没有这样和你交谈的机会，肯定也会一直[r]
这么认为的！[p]
#hino:happy
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
但是……不对！[r]
原来你也一直默默关注着我们啊！[p]
这个被所有人远远观望的异乡人[r]
志户田纱罗纱的真实身份是，[p]
[delay speed="60"]
[font size="35"]
#hino:smile
[playse  volume="30" buf="1" storage="kansei.ogg"]
连词语接龙都玩得很烂，要是登利不来就会担心得不行[r]
说到底不过是个普通人罢了！[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" top=-160 time="10" face="wow_k"]
[resetfont]
[resetdelay]
#sarasa:wow_k
……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top=-100 time="10" face="smile"]
#hino:smile
走吧！同班同学志户田！[r]
让我们一起去唤醒那些可悲又愚蠢的伙伴们吧！！[p]
[chara_move name="hino" left="-110" wait="false" time="10"]
[chara_show name="sarasa" top="-160" left="350" wait="false"]
#
[delay speed="60"]
在他所指的方向，沥青路面上蒸腾的热浪[r]
正将景色摇曳得模糊不清。[p]
#sarasa:normal_k
…………………………[l]
#sarasa:closeEye_k
嗯[p]
[mask]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[bg storage="noborike_m.jpeg" time="200"]
[chara_mod name="hino" face="normal" time="10"]
[chara_mod name="sarasa" face="normal_k"]
#
[mask_off]
;〇登利家（昼）
#hino:normal
――登利家可是经营澡堂的哦。[r]
在八种算是少有的温泉胜地呢[p]
#hino:tweet
我以前也常和爷爷两个人[r]
一边把肥皂弄得咔嗒响一边来泡汤……[p]
[resetdelay]
#hino:angry
[playse  volume="30" buf="0" storage="kaminari.ogg"]
……根本没人嘛！？[p]
#sarasa:normal_k
从玄关之类的地方……[r]
是不是没法从连着屋子的地方找人啊[p]
#hino:angry
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
不对，登利家这边没营业的时候[r]
根本哪儿都没开啊！[p]
#hino:tweet
看来是全家人都不在家吧。[l][r]
这么说来……[wait time="400"][er]
#hino:sad
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font size="50"]
[stopbgm]
――啊！[p]
[resetfont]
[delay speed="70"]
#sarasa:normal_k
……？[p]
#
怎么了呢。[r]
日野像是突然想起什么似的，整个人僵住了……[p]
#hino:sad
………………。[l][r]
…………原来如此，那家伙……[p]
[resetdelay]
#sarasa:worry_k
……那个，日野。到底……[p]
#hino:lookAway
我明白了。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
那家伙现在肯定在……花隅商店街[p]
#sarasa:wow_k
诶……？[p]
#hino:lookAway
商店街就在这后面……快走。[r]
再不快点就来不及了[p]
[chara_hide name="hino" time="500" wait="false"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
#
……[r]
我决定追赶逐渐远去的日野——[p]
[mask]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[bg storage="syotengai_n.jpeg" time="10"]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top=-100 time="10" face="tweet"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
[mask_off time="2000"]
;〇商店街（昼）
#hino:tweet
前面就是了。[r]
那家伙现在应该就在这里[p]
#sarasa
（……在商店街？为什么……？）[p]
[chara_show name="suguru" face="wow" wait="false" time="200" top="-100"]
[chara_move name="hino" anim="true" time="200" wait="false"]
[wait time="0"]
#suguru:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
部、部长……！[p]
#hino:normal
嗯？[l][r]
#hino:tweet
[playse  volume="20" buf="0" storage="kakan.ogg" ]
……啊，这不是聪君吗！！[p]
#suguru:sad
……你、你怎么会在这里……在做什么啊[p]
[delay speed="70"]
#suguru:angry
……是和志户田前辈一起……[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top=-130 time="10" face="normal_k"]
[resetdelay]
#sarasa:normal_k
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（……？）[p]
#
总觉得，[r]
刚才一瞬间好像被优狠狠瞪了一眼——[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" left="350" wait="false"]
[chara_show name="suguru" top="-100" left="-70" wait="false"]
#hino:sad
啊、那个……抱歉，先问你件事。[r]
登利今天有来过这边吗？[p]
#suguru:sad
诶……登利前辈吗？[p]
#hino:normal
对。务必告诉我[p]
#suguru:normal
……那个[p]
#hino:tweet
……！[r]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
啊、啊咧，那不是登利吗！？喂，登利！[p]
[chara_hide_all time="300"]
#
[delay speed="70"]
日野探出身子，朝我的背后方向挥手。[l][r]
[fadeoutbgm time="2000"]
于是，我为了看清前方，转过头去———[p]
@layopt layer=message0 visible=false
[clearfix]
[filter saturate="40"]
[chara_show name="riki" face="ghost" top="-100" time="10"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[wse]
#riki:ghost
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
[wait time="3000"]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" face="wow_k" time="10" top="-130"]
[delay speed="70"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa:wow_k
（————啊）[p]
[chara_hide name="sarasa" time="10"]
#
那是。[p]
不。那是。[p]
是登利吧。但是，不对――[r]
那已经，明显是……[p]
[chara_show name="sarasa" face="sadB_k" time="10" top="-130"]
#sarasa:sadB_k
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
（……被诅咒的姿态啊――）[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="suguru" top="-100" wait="false"]
[resetdelay]
#suguru:normal
……今早，[r]
登利家的人一大早就来了。[p]
[chara_hide name="suguru" time="10"]
[chara_show name="hino" face="sad" top="-100" time="10"]
#hino:sad
……话说回来，那家伙样子是不是有点怪？[r]
喂，志户田啊……	[r][er]
#hino:sad
嗯？怎么了？[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" face="sadB_k" time="10" top="-130"]
[delay speed="70"]
#sarasa:sadB_k
………啊、我……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" time="10" face="shame"]
[resetdelay]
#hino:shame
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
！？你、你的脸色怎么比平时还要苍白啊！！[r]
出什么事了！要上厕所吗！？中暑了吗！？[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" face="worryLA_k" time="10" top="-130"]
[delay speed="70"]
#sarasa:worryLA_k
我……[l][r]
#sarasa:sadB_k
……………………………………[p]
[free_filter]
#sarasa:worry_k
必须去神社……！[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" time="10" face="sad"]
#hino:sad
神、神社？[p]
[chara_hide name="hino" wait="false"]
[resetdelay]
#sarasa
——对不起，日野！[p]
[bg storage="brack.png" cross="false" wait="false"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
;〇暗転
;ＳＥ走る
#
身后传来日野担忧的呼喊声。[p]
#sarasa
（对了，要联系……！）[p]
#
;ＳＥ電話
[playse storage="phone.ogg" loop="true" volume="60"]
[wait time="2000"]
[stopse]
#makado
[font color="0xb0c4de"][font size="25"]
……喂。怎么了？[r]
这么晚了，出什么事了……[p]
[resetfont]
#sarasa
——登利君他、被诅咒了！[p]
#makado
[font color="0xb0c4de"][font size="25"]
！[r]
现在在哪里！？[p]
[resetfont]
#sarasa
从花隅商店街那边……[r]
正往四ツ山上坡的方向逃[p]
#makado
[font color="0xb0c4de"][font size="25"]
知道了。我马上赶过去[p]
[resetfont]
#
;〇落書き壁朝
[bg storage="rojiura_m.jpg" cross="false" wait="false"]
#
——我拼命奔跑着。[p]

这辈子从未像现在这样被逼到绝路地奔跑……[p]
;〇町昼
[bg storage="inaka_m.jpeg" cross="false" wait="false" time="400"]
[playse  volume="20" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="30" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
……不对。[r]
不是这样的。[p]
明明有过啊。[r]
就在不久前，也发生过这样的事。[p]
#sarasa
[playse  volume="50" buf="0" storage="book.ogg"]
[delay speed="60"]
[quake time="30"]
……呜……！[p]
[bg storage="brack.png" cross="false" wait="false"]

#
在快要摔倒的瞬间，用伞撑住了身体。[r]
或许是承受了全身重量的缘故，伞骨发出了吱呀的声响。[p]
借着伞柄撑地的反作用力，重新站稳了身形。[p]
[delay speed="70"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
这次一定要由我来祓除才行……[l][r]
否则的话，又会——[p]
[mask time="300"]
[resetdelay]
;〇坂（昼）
[bg storage="saka_ｍ.jpeg" time="10"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[mask_off time="300"]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……！[p]
#
就这样忘我地拼命奔跑着，[r]
目的地已然映入眼帘。[p]

从转角另一侧，[r]
传来有人飞奔下楼的声响——！[p]
[chara_show name="makado" face="angrySH_c" top="-10"　wait="false" time="10"]
#makado:angrySH_c
[quake time="30"]
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
————！[r]
纱罗纱！[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-160" time="10" left="100" zindex="2" face="worry_kt"]
#sarasa:worry_kt
贤治郎——[r]
　　　[er]
[stopbgm]
[chara_show name="riki" time="10" top="-150" zindex="1" left="180" face="smileCE"]
[chara_mod name="sarasa" face="wow_kt"]
#riki:smileCE
啊！贤治郎——！[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
#riki:hate
[delay speed="60"]
快过来啊——[r]
志户田你这家伙超过分啊！[p]
#riki:shame
一看到我就突然跑起来。[r]
稍微有点受伤了呢！[p]
#riki:smileCE
其实我内心超纤细的！？老子！[r]
没想到吧！？很意外对吧！？[p]
[chara_hide_all time="300"]
#
登利的声音，仿佛就是从脑后传来的。[p]
[chara_mod name="sarasa" face="sadB_kt"]
——我，没能转过身去。[r]
僵硬的后背上，冰凉的汗水缓缓滑落。[p]
[chara_show name="makado" face="tweet_c" top="-10"　wait="false"]
#makado:tweet_c
……登利君。看起来精神不错嘛[p]
[resetdelay]
[chara_hide name="makado" time="10"]
[chara_show name="riki" time="10" top="-80" left="130" face="smileCE"]
#riki:smileCE
精神过头了，我这人也就这点长处了！[p]
#riki:worry
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
话说，前两天还有人这么说我来着！[r]　
没这回事吧！？[p]
[chara_show name="makado" time="10" top="-10" left="350" face="normal_c"]
[chara_move name="riki" time="10" top="-50" left="-90"]
[wait time="0"]
#makado:lookAway_c
确实呢……你很有活力。[p]
#makado:normal_c
相比之下，[r]
纱罗纱看起来相当疲惫呢[p]
#riki:lookAway
哎呀 说到底[r]
毕竟是志户田家深闺大小姐嘛。[p]
#riki:smile
这种大热天还在外面乱跑[r]
待会儿就要融化了吧？啊哈哈！[p]
#makado:lookAway_c
…………[p]
#makado:sad_c
嗯。说的也是。[r]
我今天也已经……有点累了呢[p]
#riki:smileCE
啊哈哈！[r]
哎呀呀贤治郎，没想到你这么弱不禁风啊！[p]
#riki:smile
喂喂，[r]
等到了神社台阶那儿，跟我比谁先跑上去吧！[r]
看谁能先冲到顶上！[p]
#makado:smile_c
饶了我吧……[p]
#sarasa
…………[p]
#makado:normal_c
……[l][r]
#makado:lookAway_c
纱罗纱[p]
[chara_hide_all]
#
贤治郎先生将手搭在我的肩上，[r]
轻声说道。[p]
[chara_show name="riki" time="10" top="-50" left="-90" face="normal"]
[chara_show name="makado" time="10" top="-10" left="350" face="normal_c"]
#makado:normal_c
走吧[p]
#sarasa
[delay speed="80"]
……可、可是……[p]
#makado:tweetLA_c
[resetdelay]
没事的。[r]
我都准备妥当了[p]
[chara_mod name="riki" face="smileH"]
#sarasa
[delay speed="80"]
………………………………[p]
[delay speed="60"]
[chara_mod name="riki" face="normal"]
#makado:tweet_c
能帮到你们的东西，[wait time="500"][r]
肯定能在我们家找到的[p]
#riki:smileCE
[font size="45"]
[resetdelay]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
好嘞！[r]
那我们现在就立刻出发吧！[p]
#
[resetfont]
[chara_hide_all]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
#
[delay speed="60"]
……贤治郎先生从我身边离开，[r]
被登利推搡着爬上了斜坡。[p]

于是我也深吸一口气，慢慢平复急促的呼吸――[l][r]
跟上了他们的脚步。[p]
[mask time="3000"]
[fadeoutbgm time="3000"]
[wait time="3000"]
[showsave]
@jump storage="chapter_1/day2_2.ks"


;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
