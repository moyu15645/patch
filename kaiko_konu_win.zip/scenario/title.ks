
[cm]



@clearstack
@bg storage ="title.jpg" time=100
@wait time = 200
*start
[playbgm storage=tukutukulong.ogg loop=true volume=30]
[button x=100 y=420 graphic="title/button_start.png" enterimg="title/button_start2.png" storage="prologue/day1.ks"]
;enterimg="title/button_start2.png"
[button x=100 y=510 graphic="title/button_continue.png" enterimg="title/button_continue2.png" role="load" ]
;enterimg="title/button_load2.png"
;[button x=135 y=410 graphic="title/button_cg.png" enterimg="title/button_cg2.png" storage="cg.ks" ]
;[button x=135 y=500 graphic="title/button_replay.png" enterimg="title/button_replay2.png" storage="replay.ks" ]
[button x=100 y=600 graphic="title/button_config.png" enterimg="title/button_config2.png" role="sleepgame" storage="config.ks" ]
[s]

*gamestart
;一番最初のシナリオファイルへジャンプする
@jump storage="day1.ks"
