;=========================================
; CG モード　画面作成
;=========================================
@layopt layer=message0 visible=false
@layopt layer=message1 visible=false
[hidemenubutton]
[clearfix]
[chara_hide_all  time="10"]
[cm]

[layopt layer="1" visible=true]
[bg storage="../../tyrano/images/system/bg_item.png" time=10]


;*memo
;[if exp="f.item.memo==true"]
;レイヤー１を解放
;[bg storage="../../tyrano/images/system/bg_item.png" time=10]

;[image layer="1" name="memo_select,back" storage="../image/config/c_btn.png" x=0 y=300 width=960 height=300]
;[image layer="1" name="memo_select" zindex=10 storage="../image/item/memo.png" x=70 y=330 width=300]
;[ptext layer="1" name="memo_select,select_text" zindex=10 text="アキにもらった" x=400 y=390 size=32 time=0]
;[anim name="memo_select" opacity=0 time=0]
;[s]
;[endif]


;-------------------------------------------------------------------------------
*common
;-------------------------------------------------------------------------------
[button target="*backgame" graphic="../../tyrano/images/system/menu_button_close.png" enterimg="../../tyrano/images/system/menu_button_close2.png" x=840 y=580 ]
[image layer="1" name="back" storage="../image/config/c_btn.png" x=0 y=300 width=960 height=300]
;アイテムボタン
;所持判定
[if exp="f.item.memo==true"]
;[image storage=""="../../tyrano/images/system/noimage.png" x="60" y="130" width=160 height=140]
;メモボタン
[button name="items_icon,memo_icon" fix="true" target="*memo" graphic="item/memo.png" x="60" y="130" width=160 height=140]
;説明文(カーソルが乗ったら表示する)
[image layer="1" name="memo_select" zindex=10 storage="../image/item/memo.png" x=70 y=300 width=400]
[ptext layer="1" name="memo_select,select_text" zindex=10 text="【町と私】班メモ" x=500 y=320 size=32 time=0]
[ptext layer="1" name="memo_select,select_text" zindex=10 text="アキにもらった" x=500 y=390 size=32 time=0]
;アニメーション(必要なかったら消す)
[anim name="items_icon" opacity=0 time=0]
[anim name="items_icon" opacity=255 time=500]

[endif]
;[button graphic="../../tyrano/images/system/noimage.png" x="60" y="130" width=160 height=140]
[s]

*return
[return]
*memo
[anim name="memo_select" opacity="1" time="10"]
[s]

*backgame
[awakegame]

;ホバー処理
[iscript]
$(".items_icon").on({
  mouseover: function(){
    $(".memo_select").css("opacity","1");
  },
  mouseout: function(){
    $(".memo_select").css("opacity","0");
  },
  mousedown: function(){
    $(".memo_select").css("opacity","1");
  }

});
/*
$(".akane_icon").hover(
  function(e){
    $(".akane_select").css("opacity","1")
  },
  function(e){
    $(".akane_select").css("opacity","0")
  }
);
*/
[endscript]
