;第2章『私は不思議でたまらない』
;一日目中編
;-------------------------------------------------------------------------------
*part3
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '二章一日目　中編'"]
#
[mask folder="bgimage" graphic="still/part2.png" time="10"]
[mask_off]

[playse storage=wara.ogg volume="100" sprite_time="0000-0400"]
[wse]

[mask_off]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="250"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
;〇暗転
#
自从开始奔跑后……我便迷失了前进的方向。[p]
[resetdelay]
就这样向着校舍正面……[r]
也就是说，只要冲到操场那边，就有许多师生。[l][r]
那也意味着可以向他人求助……[p]
#sarasa
（——该怎么办）[p]

;▶運動場の方へ逃げる
;▶人気を避けて裏の林に逃げる
#
[link target="*undojo"]【１】往操场方向逃跑[endlink][r]
[link target="*hayasi"]【２】避开人群，逃往树林深处[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*undojo
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;▶運動場の方へ逃げる

#sarasa
……肯定有人、会来帮我的…………！[p]

#
……怀揣着希望，我朝着人群所在的方向纵身跃去。[p]

就在这时，背后传来了尖叫声——[r]
那些声响全都远远消失在深邃的深处。[p]

地面上只余下阵阵回声。[p]

…………[p]
[fadeoutbgm time="2000"]
当这样的回响重复了五次左右时，[r]
我不由得停下脚步回头望去。[p]
#aki
真是麻烦啊[p]
#
那个本应吞噬了数人的少年，此刻的模样……[r]
与平日并无二致，依旧如常。[p]
结局３「不可思议的少年」[p]
[free_filter]
[resetdelay]
[clearfix]
@jump storage="first.ks"


;▶人気を避けて裏の林に逃げる
;-------------------------------------------------------------------------------
*hayasi
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#sarasa
（要是、要是像黑田君那样，又有人被他[r]
吞噬”的话……绝对会引起大骚动的）[p]
#
况且，就算之后能想办法解除阿奇的诅咒――[p]

必须向目击者解释关于【御黑面怪之咒】的相关情况，[r]
不，就算解释了……[l]这个消息也必定会传遍整个城镇。[p]
消息的扩散，就是诅咒的扩散。[p]
为了避免增加受害者”，[r]
我走向无人问津的校舍后方、更深处――[l]踏入树林之中。[p]
@jump target="*hayasi_oku"
;---------------------------------------------------------
*hayasi_oku
;---------------------------------------------------------
[mask]
;ＳＥ　走る
[fadeoutbgm time="2000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[bg storage=./school/kyukosya_m.jpeg time="1000" wait=true]
[free_filter]
[mask_off]
;〇旧校舎
[delay speed="50"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=30]
#sarasa
……这、这里是……[p]
#
摇摇欲坠的古老建筑，[r]
如同被遗忘的失物般静静矗立。[p]

……校舍后方的树林深处，居然有这样的地方……[p]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥ燃える音
[playse storage="takibi.ogg" volume="40" loop="true"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
……………………………[p]
#sarasa
（……对面传来了声响）[p]
#
当风穿过树梢的间隙时，[r]
从那个声音的方向飘来焦糊的气味。[p]
[delay speed="60"]
……有什么东西，在燃烧吗？[p]
[resetdelay]
#??
…………等等，那里是不是有人？[p]
#sarasa
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
（！[l][r]
糟了，有人往这边来了……！）[p]
[delay speed="50"]
;ＳＥ足音
[stopse]
[playse storage=wara.ogg volume="100" sprite_time="0000-0400"]
[wse]
[playse storage=wara.ogg volume="100" sprite_time="0000-0400"]
[wse]
[chara_show name="suguru" top="-100" wait="false" left="-80" face="wow" time="100"]
#suguru
……你、你是……[p]
[chara_show name="sarasa" wait="false" top="-160" left="360" face="wow_kt"]
#sarasa
……！[r]
优、优……君[p]
#suguru
…………[p]
#suguru:angry
……你这是什么意思？[r]
现在居然连社团活动时间都要闯进来……[p]
#sarasa:worry_kt
诶……？[p]
#suguru
果然……[p]
#suguru:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
志户田前辈，你是想利用御白姬的职务便利[r]
来接近部长对吧。[r]
这种小心思，早就看穿啦[p]
#sarasa
……[p]
#
在她令人费解的言行中，混乱愈发加深。[r]
此时从她背后，又出现一个人影。[p]
@layopt layer=message0 visible=false
[clearfix]
[stopbgm]
[chara_hide_all time="100"]
[chara_show name="hino" top="-100" face="ghost"]
[wait time="2000"]
#hino:ghost
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
——志户田？[p]
[resetdelay]
[quake time="30"]
#sarasa
！？[p]
…………日、日野……[r]
	那张脸——！[p]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
#hino
[playse  volume="30" buf="2" storage="kansei.ogg"]
怎么，居然特意跑到这种地方来……[r]
[kanim name=hino keyframe=up time=300 wait="false"]
太开心啦！[stop_kanim name=hino][p]
#
这么说着的日野，[r]
在熊熊燃烧的火焰深处露出了爽朗的笑容。[p]
#sarasa
（开玩笑吧……现在 我……[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
居然被两个被诅咒的人夹在中间了？）[p]
[chara_hide name="hino" wait="false"]
[delay speed="60"]
#
之前能逐个应付诅咒，[r]
不过是因为运气好罢了……[p]

仔细想想也是理所当然。要是一群人同时袭来，[r]
既然能确实杀死御白姬……[r]
即便我是被诅咒的一方，也会这么做。[p]

但是。在这种状况下……[r]
扮演御白姬的角色，究竟要怎样才能得救？[p]

;ＳＥ　森の足音
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[chara_show name="sarasa" top="-160" wait="false" face="sadB_kt"]
#sarasa
呜、来了……[p]
[chara_hide name="sarasa" pos_mode="false" time="10"]
[chara_show name="suguru" top="-100" face="sad" time="10"]
#suguru
……哈？　你说来了，什么东西……[p]
[chara_hide name="suguru" time="10"]
#
被身后逼近的脚步声所震慑，[r]
我下意识想要向前迈步的身体……[p]
当视野中映入日野站在面前的身影时，我僵在原地。[p]
[chara_show name="hino" top="-100" time="350" wait="false"]
#hino
……志户田，你打算去哪儿？[p]
[chara_hide name="hino" time="10" pos_mode="false"]
[chara_show name="sarasa" top="-160" time="500" face="sadB_kt"]
#sarasa
啊……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" time="500"]
#hino
……咦，器乐堂你也在一起啊？[p]
[chara_move name="hino" time="300" anim="true" left="300"]
[chara_show name="aki" wait="false" top="-100" left="-70"]
#aki
……[p]
#hino
不过真少见呢。没想到你会在学校……[p]
#aki
抓到你了[p]
[chara_hide_all time="500"]
#
[playse  volume="30" buf="2" storage="shimeage.ogg"]
阿奇说着，用力抓住了我的手腕。[p]
[chara_show name="suguru" wait="false" top="-100" face="normal"]
#suguru
……器乐堂前辈，你的状态好像有点……[p]
[chara_hide name="suguru" time="10"]
[chara_show name="hino" top="-100" left="300" wait="false"]
[chara_show name="aki" top="-100" left="-70" wait="false"]
#aki
纱罗纱 你就是 御白姬啊[p]
[chara_hide_all time="10"]
[chara_show name="suguru" time="500" top="-100" face="sad"]
#suguru
……咦？[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="300" time="10"]
[chara_show name="aki" top="-100" left="-70" time="10"]
#aki
为了让你成为 真正的 御白姬……[l][r]
来吧 你也 坠入我的体内吧[p]
#sarasa
[quake time="30"]
阿基…………！！[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeoutbgm time="2000"]
[wait time="2000"]
;ＳＥ火が燃える
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[layermode name="hino" graphic=hino.png time=300]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#aki
……！[free_layermode name="火野" time="300" wait="true"]
[chara_move name="aki" time="200" left="-150" anim="true"]
好烫……！[p]
[chara_hide_all time="300"]
#
[playse  volume="20" buf="2" storage="sariin.ogg" ]
————阿奇在那一瞬间，松开了抓着我的手腕。[p]
[delay speed="80"]
#aki
[font color="0xf08080"]
……太过分了 你要干什么[l][r]
[chara_show name="hino" wait="false" top="-100"]
日野[p]
[resetfont]
#sarasa
……………诶？[l][r]
日、…………日野……！？[p]
[resetdelay]
#hino
……志户田，过来这边[p]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
[chara_hide name="hino" time="300" wait="false"]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥ燃え盛る火のカベ
[playse storage="takibi.ogg" volume="40" loop="true" buf="1"]
[layermode name="hino" time="300" graphic="hino.png"]
[free_layermode time="300"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

[chara_show name="sarasa" wait="false" top="-160" face="wow_kt" time="100"]
#sarasa
呀啊……！[p]
#
突然出现的奇异火焰，[r]
在我和阿奇之间，突然燃起一道如墙壁般巨大的火焰。[p]
[delay speed="50"]
#sarasa:worry_kt
……日、日野，你到底是[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" time="300" wait="false"]
#hino
……器乐堂，简直像是……[font color="0xf08080"][l]被诅咒了[resetfont]一样[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" time="10" wait="false" face="wow_kt" top="-160"]
#sarasa
！[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
……那、那你……[l]没有被诅咒吗？[p]
[resetdelay]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" time="10" wait="false"]
[fadeinbgm storage="faure-op84-5.ogg" loop=true time=3000 volume="50"]
#hino
[playse  volume="30" buf="1" storage="kaminari.ogg"]
[quake time="30"]
[font size="45"]
怎么可能被诅咒啊！[r]
[resetfont]
这到底是怎么回事！？[p]
究竟发生了什么！？[font color="0xf08080"]志户田[resetfont]！[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" wait="false" face="wow_kt" top="-160"]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
（……！果然……[l][r]
虽然样子很奇怪，但日野他还保持着理智……！）[p]
#sarasa
……………………………………[l][r]
#sarasa:lookAway_kt
…………………………[p]
#sarasa:angry_kt
我、我现在必须先从他身边逃开！[p]
[chara_move name="sarasa" anim="true" top="-160" left="360" time="300" wait="false"]
#sarasa:closeEye_kt
所以，如果可以的话……[chara_show name="火野" time="200" top="-100" wait="false" left="-70"]
请把你的力量借给我。日野[p]
#hino
……！[l]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
明、明白了！　[r]
既然是这么回事的话……[p]
[chara_mod name="hino" face="angry" cross="false" time="1000"]
好！跟我来！[p]
[stopse buf="1"]
[chara_hide_all time="10"]
[chara_show name="suguru" top="-100" wait="false" face="wow"]
#suguru
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
等、等等……！[kanim name=suguru keyframe=up time=300 wait="false"]　部长你要去哪……[stop_kanim name=suguru][p]
[chara_hide name="suguru" time="10"]
[chara_show name="hino" time="10" top="-100"]
[font size="45"]
[quake time="30"]
#hino
[playse  volume="20" buf="1" storage="kakan.ogg"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
聪君！[p]
[chara_hide name="hino" time="10"]
[chara_show name="suguru" top="-100" face="shame" time="10"]
[quake time="30"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
#suguru
[anim name="suguru" top="+=30" time="150"]
[anim name="suguru" top="-=30" time="150"]
噫呀！[p][resetfont]
[delay speed="50"]
[chara_hide name="suguru" time="10"]
[chara_show name="hino" top="-100" wait="false"]
#hino
你就在这儿等着！[r]
毕竟现在可是地研的活动时间……[p]
[resetdelay]
不能让部员擅离岗位，[r]
这是绝对不允许的！[p]
[chara_hide name="hino" time="10"]
[chara_show name="suguru" top="-100" face="sad" time="10"]
#suguru
……部长…………[p]
[delay speed="60"]
[chara_hide name="suguru" time="10"]
[chara_show name="hino" top="-100" time="10"]
#hino
作为地研部成员，你就留在那里……等着我。[l][r]
[chara_mod name="hino" face="lookAway"]
——我一定会回来[p]
[resetdelay]
[chara_hide name="hino" time="300" wait="false"]
;ＳＥ走る
[playse storage=wara.ogg volume="60" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="250"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wse]
[chara_show name="suguru" top="-100" face="sad" wait="false" time="500"]
[delay speed="60"]
#suguru
部、部长……！[r]
一定要、一定要平安回来啊……！[p]
[chara_hide name="suguru" time="10"]
[chara_show name="aki" wait="false" top="-100"]
#aki
……[p]
[chara_hide name="aki" time="10"]
[chara_show name="suguru" top="-100" time="10" face="wow"]
#suguru
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
！[r]
[chara_mod name="suguru" face="angry"]……な、なに！[r]
别一直盯着看！[p]
[chara_hide name="suguru" time="10"]
[chara_show name="aki" top="-100" time="10"]
#aki
……哈啊。[r]
真麻烦啊……真是的[p]

[mask]
[fadeoutbgm time="2000"]
[resetdelay]
[chara_hide name="aki" time="10"]
[bg storage=./school/kyukosya_roka.jpeg time="2000" wait="true"]
;〇旧校舎
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
#
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[wait time="3000"]
[mask_off time="7000"]
;ＳＥ古い木を歩く
[delay speed="50"]
#hino
……这里是小谷坂学园的旧校舍。[r]
平时是禁止学生进入的区域哦[p]
[chara_show name="hino" top="-100" wait="false" face="smile"]
[resetdelay]
志户田是优等生，应该没来过吧？[p]
[chara_move name="hino" left="-70" anim="true" time="450" wait="false"]
[chara_show name="sarasa" top="-160" face="closeEye_kt" left="360" wait="false"]
#sarasa
嗯、嗯。居然还有这种地方……[p]
#hino:normal
……嗯。但也不能一直困守在这里。[r]
去二楼的教室躲着，先理清现状吧[p]
[chara_hide name="hino" wait="false"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
#
日野大步流星地穿过破败的走廊。[r]
看这熟练的样子，想必是常来这里吧。[p]
#sarasa:normal_kt
……日野，你刚才在做什么？[p]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
啊。稍微整理了些资料！[p]
把重复的讲义和社团活动多印的材料之类[r]
和聪君一起烧掉了哦[p]
#
说着这话的日野抬起的右手里，[r]
正抱着一本非常厚重的活页夹……[p]
#hino
这里很安静，我挺中意的。[r]
偶尔会过来生个火[p]
#sarasa:wow_kt
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
（对了，那个火……！）[p]
[font size="20"]
#hino
志户田，注意脚下跟紧我啊[p]
[resetfont]
#sarasa:worry_kt
啊、等等……！[chara_move name="sarasa" left="-500" anim="true" time="1000" wait="false"][p]
#
[mask]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[chara_show name="hino" left="-70" top="-100" face="normal" time="10"]
[chara_move name="sarasa" top="-160" face="angry_kt" left="360" time="200"]
[bg storage=./school/kyukosya_kaidan.jpeg time="300" wait=true]
[mask_off]
;〇旧校舎：階段
#sarasa
这到底是怎么回事？[p]
#hino
诶？[p]
[delay speed="50"]
#sarasa
就是那个、火焰啊！[r]
从日野身上冒出来的、火焰――[l][r]
普通人绝对不可能拥有的、不可思议的力量。[p]
[chara_mod name="sarasa" face="angry_kt"]
那是[font color="0xf08080"]被暗御津破诅咒之人[resetfont]才会激发的、[r]
超自然能力对吧……！？[p]
#hino:tweet
？[l]　………………………………[p]
#hino:smile
[playse  volume="20" buf="0" storage="sariin.ogg"]
啊对哦！[r]
你这是第一次目睹[font color="0xf08080"]祝福[resetfont]吧，志户田。[p]
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
[chara_mod name="hino" face="normal"]
我们所有人都被赐予了这份力量。[r]
――从被认定为[font color="0xf08080"]御白姬眷属[resetfont]的那天起[p]
[delay speed="70"]
#sarasa:wow_kt
御白姬的……眷属？[p]
[delay speed="50"]
#hino
……哦呀？你不是吗？[p]
[chara_mod name="hino" face="ghost" cross="false" time="500" wait="false"]
能看见这份力量的，[r]
本应只有同伴才对[p]
#sarasa:worry_kt
…………[l][r]
………………………………[p]
#sarasa:lookAway_kt
……是不是眷属，我不清楚……[l][r]
[chara_mod name="sarasa" face="sad_kt"]
听说因为被选为御白姬的扮演者，[r]
才会像这样被盯上啊[p]
#hino
——嚯！原来如此，原来如此……[r]
也就是说……[p]
[resetdelay]
[chara_mod name="hino" face="smile" cross="true" time="300" wait="false"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[font color="0xf08080"]传说中绢布的烧毁[resetfont]が[r]
果然是你在操控御白姬暴走啊！[p]
#sarasa:wow_kt
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
……哎！[p]
#hino:shame
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
[font size="45"]
哎！？[p]
[resetfont]
#sarasa:wow_kt
……[l]日野，你连封印绢布的事都知道吗？[p]
#hino:tweet
嗯、啊啊……[l][r]
#hino:smile
当然知道。在我们圈子里这可是传得沸沸扬扬啊[p]
#sarasa
（传闻……。[l][chara_mod name="sarasa" face="normal_kt"]不过……如果是这样，[r]
【封印之绢布被烧毁】知道的人难道不是应该[r]
立刻全都被诅咒才对吗……）[p]
[delay speed="70"]
#hino:tweet
……。[r]
话说回来……聊着聊着突然想到[p]
[resetdelay]
#hino:normal
志户田明明就是被御白姬盯上的元凶，[r]
看起来你完全没搞明白现在发生的状况啊？[p]
#sarasa:worry_kt
诶……[p]
[resetdelay]
[playse storage=page.ogg volume="40"]
#
日野在台阶上方突然停住脚步――[l][r][playse storage=page.ogg volume="40"]
开始哗啦哗啦地翻动手中的文件。[p]
#hino:normal
嗯……看来为了你[r]
有必要好好展示下我的知识储备了！[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥ燃える壁、後ろに
[playse storage="takibi.ogg" volume="40" loop="true" buf="2"]
[layermode name="hino" graphic=hino.png time=300 mode="lighten"]
[chara_mod name="sarasa" face="wow_kt"]
[free_layermode]
@layopt layer=message0 visible=true
@plugin name=tip mark=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
呀啊……！[p]
#hino:tweet
啊、突然烧你后背真不好意思！[p]
#hino:normal
为了不让器乐堂上到二楼来，[r]
我设置了火焰防护门之类的障碍……[r]
觉得这样会比较好呢[p]
#hino:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
不过我的火焰[font color="0xf08080"]只会烧毁想要焚烧的东西[resetfont]，[r]
你不用每次都这么害怕的！！[p]
#sarasa:closeEye_kt
原、原来如此……[p]
[chara_hide_all time="300"]
[playse storage=page.ogg volume="40"]
#
日野在跟我说话的同时，[r][playse storage=page.ogg volume="30"]
视线依然盯着不断翻动的文件……[p][playse storage=page.ogg volume="50"]
仿佛在说终于找到了似的，[r]
他的手停在了某一页上。[p]
[chara_show name="hino" top="-100" face="smile" time="200" wait="false"]
#hino
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
好！跟我来志户田！[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" top="-160" face="angry_kt" time="200" wait="false"]
#sarasa
嗯、嗯……[p]
[stopse buf="2"]
[mask]
[fadeoutbgm time="2000"]
[resetdelay]
[chara_hide name="sarasa" time="10"]
[bg storage=./school/kyukosya_heya.jpeg time="1500" wait=false]
[chara_show name="hino" face="smile" top="-100"]
;〇旧校舎
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
#
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]
#
[wait time="300"]
[mask_off]
;〇旧校舎　空き教室

#hino
这间教室的所有入口都被火焰包围了！[p]
也就是说，只要待在这里[r]
你就不会和他碰面啦！哈哈哈！[p]
#sarasa
谢、谢谢……[r]
连累你了，真的很抱歉……[p]
#hino
不不，没关系。[r]
没想到传说中的事件，自己居然能参与其中……[p]
#hino:happy
[playse  volume="30" buf="2" storage="kansei.ogg"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
作为民俗学的爱好者来说，[r]
这可是梦寐以求的经历啊！[p]
#sarasa
[delay speed="100"]
……………………[p]
[resetdelay]
#hino:normal
呼，好了。[p]
[delay speed="60"]
#hino:tweet
[playse  volume="20" buf="0" storage="kakan.ogg" ]
志户田过去也[r]
[font color="0xf08080"]你知道同样的事情正在发生吗？[resetfont][p]
#sarasa
诶……[l]同样的、事件是说……[p]
[delay speed="80"]
……………………………………[l][r]
难道以前、封印的绢布也曾经……燃烧过吗？[p]
[resetdelay]
#hino:smile
没错！关于这件事嘛……确实如此。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
之前　贤治郎先生在马门神社展示过的[font color="0xf08080"]神物名称[resetfont]是[r]
你还记得吗？[p]


;▶『神厩舎ノ注連縄』
;▶『神馬ノ手綱』
;▶『神馬ノ注連縄』
#
[link target="sinbutu_yes"]【１】神厩舍的注连绳[endlink][r]
[link target="*sinbutu_no"]【２】神马的缰绳[endlink][r]
[link target="*sinbutu_no"]【３】神马的注连绳[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*sinbutu_no
;-------------------------------------------------------------------------------
;不正解
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#hino:shame
不不不不对……！正确的叫法是『神厩舍的注连绳』才对[r]
应该这么称呼[p]
@jump target="*sinbun"
;-------------------------------------------------------------------------------
*sinbutu_yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#hino:lookAway
对！『神厩舍的注连绳』……。[p]
@jump target="*sinbun"
;-------------------------------------------------------------------------------
*sinbun
;-------------------------------------------------------------------------------
[chara_hide name="hino" time="800" wait="false"]
#hino
这是，[r]
或许可以说这是与之相关的传说吧[p]
#hino:smile
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
哦！正好还留着焚烧前的复印件！[r]
这个就赠予你吧[p]
#
@layopt layer=message0 visible=false
[clearfix]
[playse storage=page.ogg volume="40"]
;アイテムスチル：【昭和十九年九月の記録『志戸田家の令嬢危機一髪！』】
[image layer=0 folder="image" name="sinbun" storage="item/sinbun.png" width="500" x="225" y="80" time="800" visible="true"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[font color="0xb0c4de"]
[playse  volume="20" buf="0" storage="sariin.ogg"]
获得了〇旧报纸		。[tip key="shinbun"][endtip]
[wse][p]
[resetfont]
#sarasa
……以前的、报纸……？[p]
#hino
似乎是战争时期的故事呢。大约70年前……[l][r]
战火让我们八种町[r]
失去了许多具有历史价值的宝物。[p]
[delay speed="60"]
其中既有曾经生活在镇上的人们，[r]
也有自古绵延传承的文化瑰宝。[p]
而在这牺牲的长列中……[p]
据记载当时与现今相同 保存在马门神社正殿里的[r]
[font bold="true"]其中也包含了封印之绢布啊[resetfont][p]
#hino
报纸上提到，[r]
后来[font color="0xf08080"]知晓了奥六目封印被解开之人[resetfont]又[r]
据说目标是扮演御白姬的志户田家千金小姐的性命……[p]
那人用[font color="0xf08080"]神厩舍的注连绳[resetfont]将其束缚令其恢复神智，[r]
千钧一发之际救下千金小姐的[r]
据说是当时的神官·马门缘四郎先生[p]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
啊……！这和现在的情况简直如出一辙……[p]
[free layer=0 name="sinbun" time="800" wait="false"]
[chara_show name="hino" top="-100" wait="false" left="-70" face="smile"]
[chara_show name="sarasa" top="-160" wait="false" left="360" face="worry_kt"]
[resetdelay]
#hino
嗯嗯。正因为有过这段往事，[r]
贤治郎先生才会将那注连绳时刻不离地带在身上吧。[p]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
#hino:happy
根据历史经验采取防范措施这种作风，[r]
跟咱们考前复习是一个道理嘛！[p]
[delay speed="50"]
#hino:normal
但从你这反应来看……[r]
贤治郎先生没跟你提过这事儿吧？[p]
#hino:smile
这种同行间的常识[r]
我还以为早该互相通过气了呢。[p]
#sarasa:wow_kt
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
…………………[l][r]
#sarasa:lookAway_kt
[fadeoutbgm time="5000"]
……………………………………[p]
[delay speed="60"]
#sarasa:worryLA_kt
……嗯。[p]
#sarasa:lookAway_kt
那个…………[p]
#hino:normal
或者说？[p]
#sarasa
……………[l][r]
#sarasa:worry_kt
……………………[p]
#sarasa:closeEye_kt
…………说实话，最开始我只听那个人说因为绢布烧了所以我有生命危险，[r]
就这么一句话……[p]
[delay speed="70"]
#sarasa
……就觉得、这个人、[l][chara_mod name="sarasa" face="sad_kt"]拼命相信童话故事好奇怪，[r]
这么……怀疑过……[p]
[resetdelay]
#
贤治郎先生对御黑祟的应对知识和理论恐怕是——[r]
基于类似这样的记录案例，[r]
逐步构建出来的吧。[p]
[delay speed="50"]
[chara_mod name="sarasa" face="normal_kt"]
……为什么他，[r]
『自己是根据过去发生的实际案例采取行动』[r]
不能一开始就这样说明清楚呢。[p]
#sarasa
[delay speed="100"]
………………………………………………[p]
[delay speed="70"]
（要是能在一开始就告诉我这篇报道的事……）[p]
[chara_mod name="sarasa" face="closeEye_kt"]
（…………要是我当时没表现出那么明显的怀疑态度的话[r]
事情可能就不会变成这样了吧。）[p]
[chara_hide_all time="10"]
[stopbgm]
[chara_show name="kirie" time="10" top="-100" face="ghost"]
[resetdelay]
#kirie
贤治郎根本就没那么信任你啊[p]
[chara_hide name="kirie" time="10"]
[chara_show name="sarasa" time="10" face="sadB_kt" top="-160"]
[playse  volume="50" buf="2" storage="book.ogg" ]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
#sarasa
——！？[stop_kanim name=sarasa][p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" face="shame" time="10"]
[quake time="30"]
[font size="30" bold="bold"]
#hino
[playse  volume="30" buf="10" storage="kaminari.ogg"]
呜哇！？[r]
怎么了志户田你怎么突然站起来啊！！？[p][resetfont]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" top="-160" time="10" face="sadB_kt"]
#sarasa
啊……[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="sarasa" time="500" wait="false"]
[delay speed="60"]
#
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
——当我再次缓缓环顾这间空教室时……[l][r]
除了我和日野之外，再也看不到其他人影。[p]
[chara_show name="sarasa" time="300" top="-160" face="sadB_kt"]
#sarasa
……[l][r]
我、我……[p]
[chara_hide name="sarasa" time="10" wait="true" pos_mode="false"]
[chara_show name="hino" top="-100" face="sad" time="10"]
#hino
……啊、啊——[p]
[resetdelay]
#hino:smile
[playse  volume="20" buf="1" storage="kakan.ogg" ]
嘛、嘛！我要不是亲身经历的话，[r]
肯定也只会当作是普通怪谈一笑置之[r]
对吧……！！[p]
#hino:sad
[playse  volume="20" buf="0" storage="kakan.ogg" ]
才、才没有轻视你的意思[r]
我觉得贤治郎先生并不是故意沉默的！[p]
[delay speed="60"]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" top="-160" time="400" wait="false" face="worryLA_kt"]
#sarasa
……。[l][r][delay speed="60"]
#sarasa:closeEye_kt
嗯……[p][resetdelay]
[chara_move name="sarasa" left="360" anim="false" time="100" wait="false"]
[chara_show name="hino" top="-100" face="normal" left="-70" wait="false"]
#hino
不过，这下麻烦了……[r]
要驱除诅咒果然还是需要注连绳啊！[p]
#hino:tweet
不如这样，我先把你藏在这里，[r]
我亲自去贤治郎先生那边……[p]
[delay speed="60"]
#sarasa:worry_kt
啊、不是这样的……[l][r]
[chara_mod name="sarasa" face="closeEye_kt"]
只有我才能……驱除诅咒……[p]
#hino:normal
……诶？[p]
#sarasa
……由我来驱除。要看到诅咒的源头……[r]
从回忆中提取意图，是我的职责[p]
但是……在我观测的过程中，[r]
必须有人帮忙拖住被诅咒者的脚步。[r]
[chara_mod name="sarasa" face="worryLA_kt"]
所以，……[p]
#hino:sad
……那好吧[p]
@layopt layer=message0 visible=false
[clearfix]
[stopbgm]
;ＳＥ壁ガラガラ崩れる
[chara_mod name="sarasa" face="wow_kt"]
[chara_mod name="hino" face="shame"]
[quake time="1000" wait="false"]
[playse  volume="30" buf="1" storage="kaminari.ogg"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[wse]
[wait time="1000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……[p]
[font size="45" bold="bold"]
#hino
！！　不……不会吧！？[p][resetfont]
[playbgm storage=fuon.ogg loop=true time=300 volume="50"]
[chara_hide_all time="300"]
[chara_show name="aki" top="-100" face="ghost" wait="false"]
#aki
……啊呀　日野……和　纱罗纱也在呢。[r]
找～到你们啦[p]
#
阿奇出现的位置，是从我们所站的角度看去[r]
对面那堵墙……[p]
[delay speed="80"]
正中被挖开的孔洞之中。[p]
#sarasa
难、难道说……连墙壁，那个洞的……里面也[p]
#aki
因为只能一点点地吞噬过去啊。[r]
从最远的教室开始，一个一个地「塞」进来的[p]
[chara_hide name="aki" time="500"]
#
看向阿奇的背后，[r]
确实有个与阿奇身高相仿的孔洞被整齐地贯穿。[p]

——隔壁教室那荒废的光景……[r]
甚至从我所在的位置都能清晰可见。[p][resetdelay]
[chara_show name="hino" top="-100" face="shame" time="10" wait="false"]
#hino
你、你疯了吗器乐堂！？[r]
这种荒唐事……！[r]
居然连建筑物的墙壁都要一并摧毁！！[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" time="10"]
#aki
…………[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="angry" time="10"]
#hino
就算你[r]
已经被御黑祟的诅咒侵蚀了……[p]
#hino:shame
这里可是眼看就要坍塌的[r]
旧校舍啊？！要是崩塌了你也不可能没事的[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" time="10"]
[delay speed="50"]
#aki
哇！好厉害啊 出现了[r]
你们 对他人 生命的 担忧 到底有几分真心呢？[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="tweet" time="10"]
[fadeoutbgm time="2000"]
#hino
…………………………[l][r]
[chara_mod name="hino" face="sad"]
诶、诶？[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" time="10"]
#aki
还是说　在自己也可能被卷进去的情况下[r]
就得先把怒火发泄到罪魁祸首身上[r]
不然根本没法忍？[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="sad" time="10"]
#hino
…………[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" time="10"]
#aki
话说……　日野你其实也想活下去对吧。[r]
那要是不小心连累到你的话　对不住啦[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="sad" time="10"]
[delay speed="60"]
#hino
器、器乐堂……？[p]
#hino:smile
……明、……明明不擅长粗暴对待他人的[r]
就连你也，为什么要这样，简直像在威胁一样……[p]
#hino:shame
[playse  volume="20" buf="0" storage="kakan.ogg" ]
暗黑印记的诅咒太可怕了！[r]
太可怕了！！[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" wait="false"]
#aki
……哈啊　我说啊……。[p][delay speed="60"]
日野你啊[r]
我现在想抹消的只有纱罗纱一个人[r]
明白了吗？[p]
#aki
——啊啊 你肯定不明白吧。[r]
毕竟你是个迟钝的外乡人 一直[p]
[resetdelay]
#aki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
或者说 你那种 热血？ 应该这么说吧……[r]
一直都让人很烦啊。[l][r]
现在能请你停止吗[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="smile" wait="true"]
#hino
[font size="20"]
诶…………、烦人…………、[p]
[resetfont]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" time="10"]
#aki
要是不肯停手的话[r]
连你也一起吞掉哦[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="shame" time="10"]
[delay speed="60"]
#hino
…………………………[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-100" time="10"]
#aki
……………………………………。[l][r]
呃……那个。[p]
啊哈哈 完全不知道该怎么表达才好。[r]
会痛会害怕的事 谁都不喜欢吧……[p]
#hino
………………[p]
#aki
只要不碍事就不会对你怎样啦[r]
我只是想说这句话而已啊——[l][r]
喂 御白姬[p]
#
[delay speed="70"]
……………………………………[p]
看向日野。[r]
她脸上不见往日的活泼神采，[r]
只是茫然无措地望着眼前怪异的阿奇。[p]
[delay speed="50"]
#sarasa
……………………[l]阿基、你那种力量是……什么？[p]
刚才突然消失的黑田君也，[r]
果然是被你吞噬掉了吗……？[p]
#aki
嗯～如果在意的话　你也[r]
进来看看不就明白了吗[p]
[delay speed="70"]
#sarasa
……[p]
[resetdelay]
让你说出这种话的祸祟……[r]
我这就把它祓除[p]
#aki
啊咧？[l][r]
难道说纱罗纱……　[wait time="200"]现在在生气？[p]
#sarasa
…………[p]
[delay speed="50"]
#aki
是啊……肯定是这样的。[r]
嗯 因为声音听起来很生气[p]
……啊哈哈哈哈！[r]
你现在一定在用超级可怕的眼神瞪着我吧！[r]
以这个形态看东西模糊不清 真是遗憾得要命[p]
唉 真是的……[p]
[delay speed="80"]
我还以为，你和我是同类。[wait time="800"]太失望了[p]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="50"]
[chara_move name="aki" anim="true" width="+=100" top="-=60" wait="false"]
[chara_hide name="aki" wait="false"]
;ＳＥ走り出す
[playse  volume="10" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[resetdelay]
#sarasa
（……！要来了！）[p]
[chara_show name="hino" face="sad" top="-100" wait="false"]
#hino
！[wait time="200"][r]
[chara_mod face="ghost" name="hino" cross="false" wait="false" time="300"]危ない、志戸田さん！[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="hino" time="300"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
;ＳＥ火が燃える
[layermode name="hino" graphic=hino.png time=300 wait="true" mode="lighten"]
[free_layermode time="500"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[playse storage="takibi.ogg" volume="40" loop="true" buf="1"]
[chara_show name="aki" top="-100" time="10"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=aki keyframe=up time=300 wait="false"]
#aki
啊真是的。[r]
不是说过别来碍事吗！[stop_kanim name=aki][p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="ghost" time="100"]
#hino
再、再靠近的话……我就烧了你！[p]
#sarasa
日、日野……[p]
#hino
[delay speed="15"]
同一个小组的，[r]
同伴之间互相伤害……太荒唐了！[p]
[chara_hide name="hino" time="300"]
手足相残才是、[r]
人类文明史上最丑陋的历史啊！[p]
[resetdelay]
#riki
没错没错！支持日野！！[p]
[stopse buf="1"]
[stopbgm]
[mask time="10"]
;ＳＥ鞭
[playse  volume="100" buf="0" storage="punch.ogg" ]
[quake time="30"]
[wait time="500"]
[chara_show name="aki" top="-100" time="300" wait="false"]
[mask_off time="10"]
[quake time="10"]
#aki
[anim name="aki" top="+=30" time="150"]
……[p]
[anim name="aki" top="+=800" time="800"]
[chara_hide name="aki" time="200"]
[delay speed="80"]
#sarasa
啊……！[p]
#
击中阿奇背部的绳索状武器，[r]
正被其使用者迅速收回。[p]
[chara_show name="hino" top="-100" face="sad" wait="false"]
[font size="45"]
[resetdelay]
#hino
贤治郎先生！[font size="20"]顺便连[font size="45"]登利也……！[p][resetfont]
[chara_hide name="hino" time="10"]
[chara_show name="riki" top="-10" face="angry" time="200" left="350" wait="false"]
[chara_show name="makado" top="-10" face="rady_c" time="200" left="-90" wait="false"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
#riki
喂！『顺便』是多余的！『顺便』啊——！[p]
#makado
抱歉，来晚了呢。纱罗纱[p]
[chara_hide_all time="200"]
[chara_show name="sarasa" top="-160" face="wow_kt" time="200" wait="false"]
#sarasa
贤治郎先生……[l][r][delay speed="70"]
[chara_mod name="sarasa" face="lookAway_kt"]
……………[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" time="10" top="-10" face="normal_c"]
#makado
……………？[l][r]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]
#makado:tweet_c
……怎么了？[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-160"  time="500" face="normal_kt"]
#sarasa
……………[l][r]
#sarasa:closeEye_kt
没、没什么……果然还是没事。[l][r][resetdelay]
[chara_mod name="sarasa" face="normal_kt"]
可是，为什么偏偏是这个地点……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" top="-10" face="smileMini_c" time="200" left="-90" wait="false"]
[chara_show name="riki" top="-10" face="normal" time="200" left="350" wait="false"]
#makado
是登利君告诉我的。[r]
还特意跑到我家来通知我……[p]
#riki:smileCE
嘿嘿。虽说用跑的，[r]
来的时候基本都是乘风飘过来的啦！[p]
#riki:tweetLA
阿奇你啊，看到黑田被吞掉的那瞬间……[r]
总感觉像德涅布？扎涅利？[p]
#makado:lookAway_c
……既视感？[p]
#riki:normal
对对！就是那个。我当时就感觉到了——[r]
糟了！这绝对是被诅咒了吧……[p]
#riki:smile
嘿嘿，被我猜中了吧！[p]
#makado:closeEye_c
真的多亏登利君特意来叫我。[l][r]
[chara_mod name="makado" face="normal_c"]
……还有就是，日野[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" face="shame" time="10"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[font size="45"]
#hino:
咿呀！[p][resetfont]
[chara_move name="hino" time="200" left="350" top="-10" wait="false"]
[chara_show name="makado" top="-10" wait="false" face="smileMini_c" left="-90"]
#makado
谢谢你一直陪着纱罗纱。[r]
你真的很温柔呢。谢谢[p]
#hino:sad
…………贤治郎先生[p]
#makado:tweet_c
——来吧，纱罗纱！[p]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=3000 volume="30"]
[chara_hide_all time="500"]
[chara_show name="sarasa" top="-160" face="angry_kt" wait="false"]
#sarasa
好的……[p]
@layopt layer=message0 visible=false
[clearfix]
[playse storage="takibi.ogg" volume="40" loop="true"]
[wait time="2000"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
——日野刚才召唤出的火墙，至今仍在我面前[r]
毫无温度地熊熊燃烧着。[l][r]
[r]
透过那火焰……[r]
我凝视着蜷缩在地的阿奇。[p]
[chara_hide name="sarasa" time="300" wait="false"]
[delay speed="80"]
#aki
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
呜啊……真讨厌啊——……[p]
#sarasa
………………………………[p]
#sarasa:closeEye_kt
[stopse]
（必须在阿基内心深处的黑暗中，找出成为诅咒源头的记忆……[r]
将其揪出来）[p]
[mask time="100"]
#
[bg storage="still/aki_ana.png" time="100"]
[playse  volume="60" buf="0" storage="sariin.ogg" ]
[wse]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[fadeoutbgm time="3000"]
[wait time="3000"]
[clearfix]
[mask_off time="3000"]

;ＳＥリアルな叩く音

#
[playse  volume="50" buf="0" storage="book.ogg"]
[quake time="1000" wait="true" vmax="5"]
好痛。[l][r]
[r]
[playse  volume="50" buf="1" storage="book.ogg"]
[quake time="1000" wait="true" vmax="5"]
好痛。[l][r]
[r]
[playse  volume="50" buf="0" storage="book.ogg"]
[quake time="1000" wait="true" vmax="5"]
好痛。[l][r]
[r]
[playse  volume="50" buf="0" storage="book.ogg"]
[quake time="1000" wait="true" vmax="5"]
好痛。[l][r]
[r]
[playse  volume="50" buf="0" storage="book.ogg"]
[quake time="1000" wait="true" vmax="5"]
好痛。[p]
#
「妈妈，对不起」[l][r]
在能喘息的间隙试着说出这句话。[l][r]
[r]
[r]
[playse  volume="50" buf="0" storage="book.ogg"]
[quake time="1000" wait="true"]
[playse  volume="50" buf="0" storage="book.ogg"]
[quake time="1000" wait="false" vmax="5"]
变得更加疼痛了。[p]
#
[font size="20"]
「……………你啊」[l][r]
[r]
[r]
[delay speed="70"]
「迄今为止我人生的错误[r]
就只有生下你这件事」[l][r]
[r]
[r]
[r]
「所以[l]　[resetdelay]
只要你消失的话[r]
我就自由了」[p]
[resetfont]
[mask time="100"]
[playse  volume="60" buf="0" storage="sariin.ogg"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="./school/kyukosya_heya.jpeg" time="10" cross="false"]
[mask_off time="3000"]
;〇空き教室

#sarasa
……噫……[l]
刚、刚才的……[p]
#
那段回忆正涌入我的脑海。[l][r]
让本该未被任何人殴打的我的身体颤抖不已。[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]
;【选择正确的选项】＿＿＿に＿＿＿＿＿＿と言われて、＿＿＿＿記憶。

;▶兄
;▶母
;▶父
;▶只要你消失，我就能自由
;▶被骂了
;▶遭受虐待

;ＳＥカーン
;-------------------------------------------------------------------------------
@layopt layer="message1" visible="true"
[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
[font size="25"]
【选择正确的选项】选择正确的选项[r]
＿＿＿对＿＿＿＿＿＿说道，＿＿＿＿的记忆。[r]
[glink color="btn_12_black" target="*but" text="兄" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good" text="母" width="20" x="630" y="60" exp="f.flag1=true" clickse="tapSE.ogg"]
[glink color="btn_12_black" target="*but" text="父" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but" text="只要你消失，我就能自由" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but" text="被骂了" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but" text="遭受虐待" width="20" x="430" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*but
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[if exp="f.flag2==true"]
@jump target="good2"
[endif]
[if exp="f.flag1==true"]
@jump target="good"
[endif]
@jump target="loop"

;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
[font size="25"]
【选择正确的选项】选择正确的选项[r]
母亲对我说＿＿＿＿＿＿，＿＿＿＿的记忆。[r]
[glink color="btn_12_black" target="*but" text="兄" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but" text="父" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*good2" text="只要你消失，我就能自由" width="20" x="530" y="60" exp="f.flag2=true" clickse="tapSE.ogg"]
[glink color="btn_12_black" target="*but" text="被骂了" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but" text="遭受虐待" width="20" x="430" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good2
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
[font size="25"]
【选择正确的选项】选择正确的选项[r]
母亲对我说「要是没有你我就自由了」，＿＿＿＿的记忆。[r]
[glink color="btn_12_black" target="*but" text="兄" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but" text="父" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but" text="被骂了" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*good3" text="遭受虐待" width="20" x="430" y="60" clickse="tapSE.ogg"]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good3

@layopt layer=message1 visible=false
[clearfix]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
@layopt layer=message0 visible=true
[current layer="message0"]
[position vertical=false]


[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetfont]
;-------------------------------------------------------------------------------
[mask]
[chara_show name="aki" top="-100" face="ghost"]
[delay speed="50"]
[mask_off]
#aki
……[p]
#
——明明连我的回忆都被窥探了……[r]
阿奇异常安静。[p]
[resetdelay]
[chara_hide name="aki" time="10"]
[chara_show name="riki" top="-100" face="sad" wait="false"]
#riki
……喂、喂。志户田。[r]
你这讨厌的家伙……现在正在做的，[l]不对是已经做了对吧？[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" face="sadB_kt" wait="false"]
#sarasa
…………………………………………[l]嗯[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" face="wow" time="10"]
#riki
……我啊，被那样的时候，恶心得要死啊？[r]
阿奇，完全没事人一样呢[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" time="10" face="sadB_kt"]
[delay speed="70"]
#sarasa
那……那个，……[r]
阿基……他……[p]
[chara_hide name="sarasa" time="10"]
#aki
啊哈哈[r]　
装可爱的做作女[p]
[chara_show name="aki" top="-100" face="ghost" time="10"]
[chara_move name="aki" anim="true" width="+=100" top="-=60" wait="false"]
[chara_hide name="aki" wait="false"]
[resetdelay]
#sarasa
……！[p]
#
阿奇摇摇晃晃地从地上站了起来——！[p]

;ＳＥ　鞭
[playse  volume="100" buf="0" storage="punch.ogg" ]
[quake time="30"]
[wait time="500"]
[mask_off time="10"]
[quake time="10"]
#aki
！[p]
[chara_hide name="aki" time="100" wait="false"]
[chara_show name="makado" face="rady_c" top="-10" time="200" wait="false"]
#makado
还不能让你起来。[r]
直到把你的诅咒完全祛除为止……[wait time="500"][r][er]
[chara_hide name="makado" time="10"]
[chara_show name="aki" top="-100" time="100" wait="false"]
[delay speed="60"]
#aki
从刚才开始就啪啪啪啪。[r]
难道打人就这么开心吗？[p]
[chara_hide name="aki" time="10"]
[chara_show name="makado" face="wow_c" top="-10" time="10" wait="false"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
什……！[p]
[chara_hide name="makado" time="300" wait="false"]
[resetdelay]
#
……阿奇。[l][r]
被『神厩舍的注连绳』击中的效果[r]
根本就像不存在一般……[p]

就这样，径直冲向熊熊燃烧的火焰之中。[r]
一头扎了进去。[p]
@layopt layer=message0 visible=false
[clearfix]
[layermode name="hino" graphic=hino.png time=300]
[playse  volume="10" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
@layopt layer=message0 visible=true
@plugin name=tip mark=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#hino
！？　[chara_show name="hino" left="-600" top="-100" face="sad" time="10"][wait time="500"]
[chara_move name="hino" left=80 time="500" anim="true"]
住手！！[p]
[stopbgm]
[chara_hide name="hino" time="10"]
[free_layermode time="400" wait="false"]
[chara_show name="riki" top="-100" face="wow" wait="false"]
[font size="40"]
#riki
喂、喂日野！！把火灭掉的话——[p][resetfont]
[chara_hide name="riki" time="10"]
[chara_show name="aki" top="-100" face="ghost" time="10"]
#aki
已经来不及了啦[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[chara_hide name="aki" time="10"]
[bg storage="still/aki_ana.png" time="100" wait="false"]
[chara_show name="hino" top="-100" face="sad" time="10"]
[wait time="1000"]
[chara_hide name="hino" time="3000"]
;消える日野
[wait time="1000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage=./school/kyukosya_heya.jpeg time="1500" wait=false]
#
[fadeinbgm storage=severe-reprimande.ogg loop=true time=5000 volume="30"]
………………[p]
[chara_show name="makado" top="-10" wait="false" face="wowCM_c"]
[delay speed="50"]
#makado
……日野他……消失了！？是这孩子干的吗！？[p]
#aki
啊  那边的  和尚  是第一次见面呢[r]
正如你所见[p]
#makado:worryB_c
…………！　[r]
果然、一开始就该把他捆起来的………[p]
[chara_hide name="makado" time="10"]
[chara_show name="riki" top="-100" face="angry" time="100" wait="false"]
[resetdelay]
#riki
所——以——说——、来时我就说过不行吧！[r]
靠近洞穴的东西都会被拖下去的、阿奇！[r]
要动手的话只能从背后轻轻戳两下啦！[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-10" face="wowB_c" time="100"]
#makado
但是、……[wait time="300"][r]
[chara_mod name="makado" face="worryB_c"]
――更重要的是、为什么你还能动，器乐堂……！？[p]
被注连绳击中的人 即便是我也[r]
应该能使其停止30秒左右……[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-160" face="sad_kt" time="200" wait="false"]
#sarasa
并不是完全没效果哦[p]
[chara_hide name="sarasa" time="200"]
[chara_show name="makado" top="-10" face="wow_c" wait="false"]
#makado
……你说什么？[p]
[fadeoutbgm time="3000"]
;ＳＥ走る
#
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[delay speed="50"]
#
……我、从趴着的阿奇身边离开……[r]
我冲向贤治郎和登利所在的墙洞方向。[p]
[chara_show name="riki" top="-10" face="worry" left="-70" wait="false"]
[chara_show name="sarasa" top="-30" face="closeEye_kt" left="360" wait="false"]
#riki
……阿奇、完全不动了[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
没错。正如登利所说……[l][r]
[r]
阿奇以压倒日野的姿态倒下，[r]
将他吞噬之后。[l][r]
[r]
就这样静止在地上一动不动。[p]
#sarasa
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
他……似乎对疼痛非常迟钝。[r]
要是再爬起来的话，肯定又会来追我们[p]
#makado:angry_c
……原来如此。[r]
总之先拉开距离，再决定对策……[p]
#riki:hate
哦、哦哦…！[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[mask]
;ＳＥ走る複数人
[chara_hide_all]
#
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[bg storage=./school/kyukosya_kaidan.jpeg time="10"]
[mask_off time="3000"]
;〇旧校舎階段
[chara_show name="makado" top="-10" face="lookAway_c" wait="false"]
#makado
……如果没法用注连绳捆住他的话……[p]
[resetdelay]
#makado:normal_c
果然还是该先钉住关节限制行动，[r]
然后保持距离周旋比较妥当[p]
[chara_show name="riki" top="-10" face="shame" wait="false"]
#riki
啊～阿奇真可怜啊～那玩意儿可疼了～[p]
#makado:closeEye_c
我、我也是怀着愧疚在行动的……[r]
别再说啦[p]
#riki:lookAway
嘿嘿、开玩笑的啦。[r]
不管怎么想、把活吞了两个同学的阿奇[r]
就这样放着不管的家伙才更可怕吧[p]
#riki:worry
不过话说回来，[r]
按现在这状况我也帮不上什么忙啊。[r]
那种状态的阿奇、体内应该没啥概念可循吧。[p]
#riki:tweetLA
像我这种专攻内在的流派、实在太不利了……[p]
[chara_show name="sarasa" top="-30" left="360" face="worry_kt"]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg"]
…………………………[l][r][delay speed="60"]
那个……登利君，难不成，该不会……[p]
#riki:normal
啊？[p]
#sarasa:worry_kt
…………………………[l][r]
#sarasa:worryLA_kt
……登利君你，[font color="0xf08080"]还能[resetfont]变成烟吗？[p]
[resetdelay]
#riki:normal
哈？这不是当然的吗！[p]
[stopbgm]
#riki:ghost
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
看好了！[p]
[delay speed="60"]
#sarasa:worry_kt
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
………真的变成烟了……[p]
#sarasa:worryLA_kt
[delay speed="60"]
（…………………………………………）[p]
[resetdelay]
[chara_mod name="sarasa" face="closeEye_kt"]
（不对　现在不是纠结[font color="0xf08080"]这个[resetfont]的时候。[r]
总之必须想办法应对阿基……）[p]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
#sarasa:angry_kt
贤治郎先生　登利君他……据说能变成烟，[r]
他一定能帮上忙的[p]
#makado:tweet_c
………………………[p]
#makado:wow_c
[playse  volume="20" buf="0" storage="sariin.ogg" ]
……对哦！[p]
#riki
哈？[p]
[chara_hide name="makado" wait="false" time="200" pos_mode="false"]
[chara_hide name="sarasa" wait="false" time="200" pos_mode="false"]
[chara_move name="riki" left="100" time="300" wait="false" anim="true"]
#makado
登利君。[r]
现在能接近器乐堂的只有你了[p]
[chara_mod name="riki" face="sad" time="200" wait="false"]
#riki
诶、诶——！？为、为什么是我啊！？[l][r]
你刚才明明说我就是个没用的累赘啊！[p]
#sarasa
不……我也觉得非你不可。登利君[p]
#riki:wow
哎！？连志户田都这么说！？[p]
#makado
他身体上不是有洞吗，[r]
[font color="0xf08080"]掉进去的东西[resetfont]都会消失对吧？[p]
也就是说，[r]
雾化状态的存在不会被吞噬[p]
#riki:sad
……[l]
#riki:ghost
哈啊？[p]
[delay speed="50"]
#sarasa
你、你看。如果是能虚体化的登利君的话……[r]
既不会被黑洞吸入又能妨碍阿基行动，[r]
就是这个意思。[p]
比如遮挡视线、干扰声音传播之类的……[p]
[resetdelay]
#riki:smileCE
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
啊————！！！　化成烟雾，[r]
就是让你去遮挡视线干扰听觉什么的啊——！！[p]
#makado
……对、对啊。你能理解真是太好了[p]
#riki:normal
嘿嘿……我说啊。[r]
居然能用这能力帮上忙[r]
从来都没想过啊。[p]
以前这能力啊，只有在觉得没容身之处想消失的时候，[r]
或者想悄无声息人间蒸发时才会用到的啊[p]
[delay speed="50"]
#riki:lookAway
这样一来，黑田和日野……[wait time="300"]嘛、虽然不知道他们是不是还活着？[r]
假设他们还活着的话。[p]
#riki:smileCE
阿奇和志户田也是，[r]
顺便连贤治郎也能救出来的话——嘛，倒也不坏啊[p]
[chara_hide name="riki" time="10" pos_mode="false"]
[chara_show name="makado" top="-10" face="smileMini_c" time="100"]
#makado
…………这样啊……。[l][r]
#makado:lookAway_c
[delay speed="60"]
那么——看来马上就轮到你的出场了。登利君[p]
[chara_hide name="makado" wait="false" pos_mode="false"]
#
顺着贤治郎先生的视线望去，抬头看向……二楼的平台。[r]
那个人影早已伫立在那里。[p]
[resetdelay]
[chara_show name="aki" top="-100" wait="false" left="100"]
#aki
……[p]
[chara_hide name="aki" time="10"]
[chara_show name="riki" top="-100" time="100" wait="false" face="ghost"]
[font size="40"]
#riki
阿奇！你这家伙和我啊，[r]
都惨得让人受不了啊！[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_hide name="riki" time="200"]
[resetfont]
[chara_show name="aki" top="-100" time="100" wait="false"]
@layopt layer=message0 visible=false
[clearfix]
[layermode name="riki" graphic=riki.png time=300]
;ＳＥ渦巻く風
[wait time="400"]
@layopt layer=message0 visible=true
@plugin name=tip mark=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#aki
呜……！够了力！[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="aki" time="100" wait="false"]
[quake time="300"]
[free_layermode time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
阿奇虽然一度畏缩，但依然果敢地朝这边冲来。[r]
全身缠绕着铁锈色的烟雾……[p]
[chara_show name="makado" top="-10" time="100" wait="false" face="angrySH_c"]
#makado
好！先冲到一楼去！[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-160" face="angry_kt" time="100" wait="false"]
#sarasa
是！[p]
#
[chara_hide name="sarasa" wait="false"]
[mask]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[bg storage="./school/kyukosya_kado.jpeg" time="10"]
[chara_show name="aki" top="-100" time="10"]
[layermode name="riki" graphic=riki.png time=300 wait="false"]
[mask_off]
;〇廊下

#aki
真是受够了啊…我讨厌这种状况[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
或许因为视野受阻，[r]
阿奇不断撞上校舍墙面却仍向我们迫近。[l][r]
[r]
凡是他接触过的墙面都诡异地凹陷下去……[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
;ＳＥ鞭
[mask time="10"]
[playse  volume="100" buf="0" storage="punch.ogg" ]
[quake time="30"]
[wait time="500"]
[mask_off time="10"]
[quake time="10"]
[anim name="aki" top="+=30" time="150"]
#aki
……！[anim name="aki" top="+=800" time="800"]
[chara_hide name="aki" time="200"][p][free_layermode time="200" wait="false"]
[chara_show name="makado" face="rady_c" top="-10" wait="false"]
#makado
这一层的话，[r]
就算他倒下也不会导致地板塌陷。[r]
快，纱罗纱。趁现在！[p]
[chara_hide name="makado" time="200" wait="false"]
;-------------------------------------------------------------------------------;-------------------------------------------------------------------------------
;【文章の空白を正しい位置に移動させよ】
;▶おねがいよ＿私の＿可愛い＿息子＿ここから＿出して

@layopt layer="message1" visible="true"
;-------------------------------------------------------------------------------
*kenno
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
;[glink color="btn_12_black" target="*kenno-yes" text="ともきのかわりに<br>あんたがきえればいい" width="200" x="450" y="60" ]
[r][r][r][r][r]
[r][r][r][r][r]
[link target="*kenno-yes"]「私の　可愛い息子[r]ここから　出して」[endlink][r]
[call target="*q_hover"]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*kenno-yes
;-------------------------------------------------------------------------------
[cm]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]

;ＳＥカーン

;回想スチル
[mask time="100"]
#
[bg storage="still/mabusi_2.jpeg" time="100"]
[playse  volume="60" buf="2" storage="sariin.ogg" ]
[wse]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[fadeoutbgm time="3000"]
[wait time="3000"]
[clearfix]
[mask_off time="3000"]

;ＳＥ　ギャグマンガの喧嘩音
#
[font color="0xf08080"]
[font size="55"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
「就是你——！　就是你——！」[l][r]
[r]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="100"]
「要是没有你的话——！　△〇×◇△〇×◇！！」[l][r]
[resetfont]
[font size="22"]
[delay speed="60"]
最近　在家里情绪激动的时候[r]
常常会语无伦次[l]
[r]
但两个人一起祈祷的时间总是很安静[r]
我也很喜欢哦　妈妈[l][r]
[r]
「……求求您　御白姬大人啊　八种的土地啊」[l][r]
妈妈的　心愿　永远只有一个[p]
「让阿奇　从未出生过吧[wait time="500"][r]　
让我　变回怀上阿奇之前的那个我」[l][r]
[r][delay speed="18"]
「让阿奇　从未出生过吧[r]
让我[wait time="500"]　变回怀上阿奇之前的那个我」[l][r]
[r]
[r]
[delay speed="60"]
妈妈每次祈祷时　从嘴边漏出的心愿[l][r]
只有那一天　爸爸突然提早回家[r]
被爸爸听到了呢[r][l]
妈妈当时被爸爸这样说了[l][r]
[r]
[delay speed="80"]
「你说什么？」[p]
[font color="0xf08080"]
[font size="50"]
[resetdelay]
[quake time="30"]
果然女人就是不行啊 生了个孩子[r]
就得意忘形装起悲剧女主角[r]
来了是吧？[r]
[r]
就算现在恢复单身[r]
你以为还能拥有[r]
和年轻时同等的价值吗？[p]
[resetfont]
[font size="22"]
[delay speed="60"]
#
爸爸怒吼道[r]
妈妈总是一动不动地僵在原地[r]
自从爸爸离开后[r]
她把家里的东西吃进去又吐出来 接着就是[l][r]
[r]
轮到我来承受呕吐[l][r]
[delay speed="70"]
[r]
当她把东西都吐完之后[r]
自己体内变得空无一物[l][r]
制造这片空白的不是别人 正是母亲[l][r]
那么填补它的也应该是母亲才对[r]　
某天我这样想着[p]
就在那天之后约一个月[l]　电视上报道了一则新闻[l][r]
[r]
附近山间的巨大天坑发生了登山大学生坠崖事件[r]
坠崖青年的父亲和母亲　面容憔悴地[r]
在搜寻被深山吞噬的儿子[l][r]
[r]
「我相信儿子还活着」「那孩子怎么可能就这样消失[r]
我绝对无法相信」[r]
屏幕上显示着　始终未能找到的他生前的照片[r]
无论多少人失踪都依然巍然不动的群山[r]
父母用黏土般看不出情绪的脸色　凝视着这一切[l]
[r]
直到看见这一幕[r]
我才第一次为自己感到悲哀[r]
我的父母就算看到我坠崖也绝不会惊讶吧[p]
可是……………………………………………………[l][r]
[r]
[r]
……………………………………………………………[l][r]
[r]
……………………………………………………………[r]
[r]
……………………………………………………………[r]
[r]
……………………………………………………………[r]
[r]
[r]
[delay speed="80"]
[font color="0xf08080"]
我一定[wait time="500"]　　如果妈妈掉下去的话[wait time="500"]　会感到悲伤吧[p]
[resetfont]
[font color="0xf08080"]
从那天起[r]
从我身体空洞的深处　不断传来的话语！[l][r]
[r]
[r]
[r]
「求求你 我可爱的儿子[wait time="500"]　放我出去」[p]
;〇旧校舎
;【选择正确的选项】器楽堂アキは＿の作った＿＿を＿に＿＿て欲しいと願った

;▶母親
;▶空白
;▶埋
;▶父親
;▶进来
;▶吐
;▶自己
[mask time="3000"]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="./school/kyukosya_kado.jpeg" time="10" cross="false"]
@layopt layer="message1" visible="true"
[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]

;-------------------------------------------------------------------------------
*loop2
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
【选择正确的选项】[r]
器乐堂阿奇希望将＿制作的＿＿＿在＿里＿＿[r]
[glink color="btn_12_black" target="*but2" text="父親" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but2" text="进来" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good4" text="母親" width="20" x="580" y="60" exp="f.flag1=true"]
[glink color="btn_12_black" target="*but2" text="空白" width="20" x="530" y="60" ]
[glink color="btn_12_black" target="*but2" text="自己" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but2" text="埋" width="20" x="430" y="60"]
[glink color="btn_12_black" target="*but2" text="吐" width="20" x="380" y="60" ]
[mask_off time="3000"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[if exp="f.flag2==true"]
@jump target="*good5"
[endif]
[if exp="f.flag1==true"]
@jump target="*good4"
[endif]
@jump target="*loop2"
;-------------------------------------------------------------------------------
*good4
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
【选择正确的选项】[r]
器乐堂阿奇希望能将母亲制作的＿＿交还给母亲[r]
[glink color="btn_12_black" target="*but2" text="父親" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but2" text="进来" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good5" text="空白" width="20" x="530" y="60" exp="f.flag2=true"]
[glink color="btn_12_black" target="*but2" text="自己" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*but2" text="埋" width="20" x="430" y="60"]
[glink color="btn_12_black" target="*but2" text="吐" width="20" x="380" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good5
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
【选择正确的选项】[r]
器乐堂阿奇希望能将母亲制作的空缺填补回母亲[r]
[glink color="btn_12_black" target="*good5" text="父親" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good5" text="进来" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good5" text="自己" width="20" x="480" y="60" ]
[glink color="btn_12_black" target="*good6" text="埋" width="20" x="430" y="60"]
[glink color="btn_12_black" target="*good5" text="吐" width="20" x="380" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good6
;-------------------------------------------------------------------------------
[mask time="10"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
;ＳＥカーン
[delay speed="80"]
[mask_off time="3000"]
#sarasa
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……………………………………………………[p]
[delay speed="50"]
#aki
真奇怪 明明是你先做了讨厌的事情[r]
纱罗纱看起来反而更难受的样子[p]
#sarasa
但、但是……这种事情，……[p]
[delay speed="70"]
……如果刚才我看到的回忆是真的……[r]
阿基的、妈妈、一直……[l][r]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=5000 volume="30"]
……………………在那之中……[p]
[resetdelay]
#aki
哈哈 所以说啊[p]
[layermode name="riki" graphic=riki.png time=300 wait="false"]
[chara_show name="aki" top="-100" wait="false" left="100"]
在意的话 直接去看不就好了[r]
你看起来相当感兴趣嘛 对别人家的事这么上心[p]
#riki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……阿奇！别说了 这种说话方式！！[p]
#aki
啊对对对[r]
这件事明明只有登利君一个人知道的！[r]
纱罗纱你也太直白了 就这么揭人伤疤啊[p]
[delay speed="60"]
#makado
……妈妈…………[l][r][resetdelay]
什么意思？难道现在有谁在他那个所谓的洞里？[p]
[delay speed="60"]
#aki
……咦？哥哥[r]
该不会从一开始就看不见我现在这个样子？[p]
[resetdelay]
搞什么啊[r]
那你早点说 我就能解释清楚了[p]
我的身体上　开着一个大洞呢[r]
只要把人拖进那里[r]
东西就会掉进名为'我'的器皿里[p]
[chara_hide name="aki" time="200" wait="false"]
[free_layermode name="riki"]
[delay speed="70"]
那个器皿里面[r]
只进去过妈妈一个人　去年冬天终于实现了呢[p]
[chara_show name="makado" top="-10" time="100" face="wowB_c"]
#makado
…………[p]
[chara_hide name="makado" time="10"]
[delay speed="50"]
#aki
如果你也有　想消失的人[r]
我可以帮你　永远藏起来哦[p]
[chara_show name="aki" top="-100" wait="false" time="300" face="ghost"]
不过　如果继续妨碍我的话[r]
也会让你　一起进来的哦……[p]
[chara_show name="riki" top="-100" face="ghost" time="300" wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="10"]
#riki
……阿奇　你给我适可而止啊[p]
[delay speed="60"]
#aki
其实对力　也做过同样的提案呢[r]　
但总是会被拒绝[p]
[delay speed="70"]
如果是我的话[r]
力的妈妈和哥哥　都能一次性……[wait time="400"][p]
[stopbgm]
[chara_hide_all time="10"]
[bg storage="still/aki_battle1.png" time="10"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="300"]
[font size="40"]
#sarasa
阿基！！！！[p][resetfont]
[bg storage="still/aki_battle2.png" time="10"]
#aki
…………[p]
#riki
……志、志……志户田[p]
#aki
……什么意思 志户田 你还要让我更加幻灭吗？[p]
#sarasa
…………[p]
#
被登利的烟雾笼罩着的阿奇虚空中，[r]
还能听见我刚才声音的回响。[p]
#riki
…………志、志户田，算了……[r]
我，早就听惯了这种话[p]
#sarasa
…………………………………………[p]
[bg storage="still/aki_1.png" time="10"]
#aki
……呵呵[r]
我早就知道了啊[r]
你和我一样 都是内心空洞的人[p]

可最近 你却抢先一步[r]
开始填满自己的内心……[p]
[bg storage="still/aki_battle2.png" time="500" wait="false"]
说实话…… 看到这个 我很失望[r]
我们本该永远保持纯白[r]
明明就该永远保持空壳般活着才对……[p]
[bg storage="still/aki_1.png" time="500" wait="false"]
…………可你凭什么生气啊[r]
为了那些、至今都与你毫无瓜葛的陌生人[l][r]
少在那里自以为是地发火 别装作为别人生气的样子[p]
[bg storage="still/aki_battle1.png" time="10"]
#sarasa
我可不是你[p]
#
[bg storage="still/aki_1.png" time="1000" wait="false"]
#aki
…………[p]
#
[bg storage="still/aki_battle2.png" time="1000" wait="true"]
#sarasa
阿基[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/aki_1.png" time="100"]
[wait time="800"]
[bg storage="still/aki_2.png" time="10"]
[playse  volume="30" buf="2" storage="garasu.ogg" ]
@layopt layer=message0 visible=true
@plugin name=tip mark=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#aki
[font size="40"]
……叛徒！！[p]
[bg storage="./school/kyukosya_kado.jpeg" time="100"]
[chara_show name="sarasa" top="-160" face="angry_kt" time="100" wait="false"]
#sarasa
[playse  volume="20" buf="1" storage="sariin.ogg" ]
！[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[chara_hide name="sarasa" wait="false"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[resetdelay]
[resetfont]
#
喊出这句话的瞬间——[r]
阿奇猛地朝我所在的位置扑了过来。[p]
#riki
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[font size="40"]
啊……！志户田！快躲开！[p]
[resetfont]
[chara_show name="makado" top="-10" face="angrySH_c" time="300"]
#makado
！纱罗纱！！[p]
#
[chara_hide name="makado" time="10"]
;ＳＥ紐が結ばれる
[mask time="10"]
[playse  volume="100" buf="0" storage="punch.ogg" ]
[quake time="30"]
[wait time="500"]
@layopt layer=message0 visible=false
[clearfix]
[mask_off time="10"]
[quake time="10"]
[bg storage="still/aki_ana.png" time="100" wait="false"]
;消える日野
[wait time="3000"]
@layopt layer=message0 visible=true
@plugin name=tip mark=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="80"]
#
……………………[p]
[bg storage="brack.png" time="100"]
#aki
可……为什么……[wait time="600"][p]
[font size="40"]
[bg storage="./school/kyukosya_kado.jpeg" time="100" wait="false"]
[chara_show name="aki" top="-100" time="100"]
[quake time="30"]
[playse  volume="30" buf="1" storage="garasu.ogg" ]
为什么就是咽不下这口气？！[p][resetfont]
@layopt layer=message0 visible=false
[clearfix]
[resetdelay]
[chara_hide name="aki" wait="false" time="3000"]
[bg storage="still/aki_ana.png" time="3000" wait="true"]
[wait time="1000"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible=true
阿奇那深邃幽暗的虚空……正在眼前无限延展。[l][r]
但那份永恒，[r]
却拒绝继续容纳我的存在。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="./school/kyukosya_kado.jpeg" time="4000" wait="false"]
[chara_show name="makado" top="-10" face="rady_c" wait="false" time="500"]
#makado
果然这根注连绳接触过的东西[r]
都会产生同等结界效果啊……[p]
[chara_hide name="makado" time="10"]
[chara_show name="aki" top="-100" time="100"]
#aki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="aki" left="-=10" time=50 ]
[anim name="aki" left="+=10" time=50 ]
[anim name="aki" left="-=10" time=50 ]
[anim name="aki" left="+=10" time=50 ]
唔……[p]
#
因无法吞噬我而僵在原地的阿奇，[r]
视线越过我肩膀望向贤治郎先生。[p]
[chara_hide name="aki" time="10"]
[chara_show name="makado" top="-10" face="rady_c" wait="false"]
#makado
不仅能祛除诅咒，[r]
[font color="0xf08080"]也是为了庇护那些即将被诅咒吞噬的人[resetfont][r]
还能发挥力量哦。[p]
[delay speed="50"]
[chara_hide name="makado" wait="false"]
#
贤治郎先生方才击出的注连绳前端，[r]
正缠绕在我左脚踝上盘绕了一圈——[p]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（原来如此……[font color="0xf08080"]多亏这个[resetfont]，[r]
现在才没掉进洞里……！）[p]
[resetdelay]
#
我用尽全力抓住，[r]
眼前空洞少年的双臂。[p]
[delay speed="60"]
[playse  volume="20" buf="0" storage="shimeage.ogg" ]
#sarasa
阿基妈妈留下的那个空洞……[r]
光靠妈妈一个人是填不满的啊[p]
[chara_show name="sarasa" top="-160" face="angry_kt" time="300"]
所以……没用的　无论往里面塞多少人[r]
你都不会改变的　还是放弃吧[p]
[resetdelay]
#aki
[chara_show name="aki" top="-100" face="ghost" time="300"]
吵死了[r]
我今后也　注定要[r]
以一无所有的状态活下去[p]
既然这都不会改变[r]
既然已经无法改变这一点　我才像这样[r]
故意表演给你看的啊[p]
#sarasa
即便如此…………[l][r]
#sarasa:worry_kt
[delay speed="60"]
…………………………………………[p]
#sarasa:closeEye_kt
……………………[l][r]
[resetdelay]
#sarasa:angry_kt
但果然还是不行啊 阿基[r]
虽然我自己也……不太明白…………[p]
[delay speed="60"]
如果连伤害他人的部分都要模仿那些痛苦的记忆……[r]
连珍惜你的人，都会消失不见吧[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="50" buf="1" storage="sariin.ogg" ]
[resetdelay]
[mask time="100"]
[chara_hide_all wait="true" time="100"]
[mask_off]
;【回顧から　器楽堂アキの　呪いの意図を取り出せ】

;器楽堂アキは＿＿からの＿＿という言葉や＿＿に苦しんだ末に＿＿による心の穴を
;＿＿によって＿＿たいと願った

;▶母
;▶虐待
;▶埋
;▶只要你消失，我就能自由
;▶消除
;▶開け
;▶父
;▶自己
@layopt layer="message1" visible="true"
[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]
[eval exp="f.flag3=false"]
[eval exp="f.position=570"]
;-------------------------------------------------------------------------------
*loop-kaiko
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[font size="25"]
[r]
【从回忆中　提取器乐堂阿奇的[r]
　诅咒意图】[r]
器乐堂阿奇从＿＿的[r]
＿＿的话语和＿＿中痛苦挣扎后[r]
渴望用＿＿来＿＿由＿＿造成的心灵空洞[r]

[glink color="btn_12_black" target="*loop-kaiko" text="埋" width="20" x="570" y="60" ]
[glink color="btn_12_black" target="*loop-kaiko" text="父" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-true1" text="母" width="20" x="450" y="60" exp="f.flag1=true"]
[glink color="btn_12_black" target="*loop-kaiko" text="消除" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*loop-kaiko" text="只要你消失，我就能自由" width="20" x="330" y="60" ]
[glink color="btn_12_black" target="*loop-kaiko" text="自己" width="20" x="270" y="60"]
[glink color="btn_12_black" target="*loop-kaiko" text="虐待" width="20" x="210" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*kaiko-false
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[if exp="f.flag3==true"]
@jump target="*kaiko-true3"
[endif]
[if exp="f.flag2==true"]
@jump target="*kaiko-true2"
[endif]
[if exp="f.flag1==true"]
@jump target="*kaiko-true1"
[endif]
;-------------------------------------------------------------------------------
*kaiko-true1
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[font size="25"]
[r]
【从回忆中　提取器乐堂阿奇的[r]
　诅咒意图】[r]
器乐堂阿奇从母亲那里的[r]
＿＿的话语和＿＿中痛苦挣扎后[r]
渴望用＿＿来填补由母亲造成的心灵空洞[r]

[glink color="btn_12_black" target="*kaiko-false" text="埋" width="20" x="570" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="父" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="消除" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-true2" text="只要你消失，我就能自由" width="20" x="330" y="60" exp="f.flag2=true"]
[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="270" y="60"]
[glink color="btn_12_black" target="*kaiko-false" text="虐待" width="20" x="210" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*kaiko-true2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[font size="25"]
[r]
【从回忆中　提取器乐堂阿奇的[r]
　诅咒意图】[r]
器乐堂阿奇从母亲那里的[r]
「没有你我就自由了」之类的话语和＿＿中痛苦挣扎后[r]
渴望用＿＿来填补由母亲造成的心灵空洞[r]

[glink color="btn_12_black" target="*kaiko-false" text="埋" width="20" x="570" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="父" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="消除" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="270" y="60"]
[glink color="btn_12_black" target="*kaiko-true3" text="虐待" width="20" x="210" y="60" exp="f.flag3=true"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*kaiko-true3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[font size="25"]
[r]
【从回忆中　提取器乐堂阿奇的[r]
　诅咒意图】[r]
器乐堂阿奇从母亲那里的[r]
「没有你我就自由了」之类的话语和虐待中痛苦挣扎后[r]
渴望用＿＿来填补由母亲造成的心灵空洞[r]

[glink color="btn_12_black" target="*kaiko-true4" text="埋" width="20" x="570" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="父" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="消除" width="20" x="390" y="60" ]
[glink color="btn_12_black" target="*kaiko-false" text="自己" width="20" x="270" y="60"]

[resetfont]
[s]
;ＳＥカーン
;-------------------------------------------------------------------------------
*kaiko-true4
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer="message1" visible="false"
[current layer="message0"]
[position vertical=false]
[bg storage="still/ganmon.png" time="5000" wait="false"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="30"]
[wse]
;くはぬ　とばぬ　みず　なれば
;ねがひたてまつる　ひめあそばせ　ひめあそばせ
[wait time="2000"]
[mask time="3000"]
[fadeoutbgm time="3000"]
[wait time="4000"]
[bg storage="./school/kyukosya_kado.jpeg" time="10" cross="false"]
[chara_show name="aki" top="-160" face="ghost" time="100"]
[mask_off time="3000"]
;〇旧校舎

#aki
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="80"]
……………………[p]
[filter blur="4"]
@layopt layer=message0 visible=false
[clearfix]
[anim name="aki" top="+=30" time="150"]
[anim name="aki" top="+=800" time="800"]
[chara_hide name="aki" time="200"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
[wait time="1000"]
;ＳＥバタ
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
肉体的空洞闭合、恢复原状的阿奇――――――[r]
就这样直直沉落，双膝跪在了地板上。[p]
[mask folder="bgimage" graphic="still/part2.png" time="3000"]
[wait time="2000"]
[showsave]
;【第二章】1日目後編『私は不思議でたまらない』
;セーブしますか？
@jump storage="chapter_2/day1_vol3.ks"
;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;---------------------------------------------------------
*q_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#f08080");
},
function() {
  $(this).css("color", "#000000");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
