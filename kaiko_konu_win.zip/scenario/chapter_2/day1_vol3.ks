;第2章『私は不思議でたまらない』
;一日目後編
;-------------------------------------------------------------------------------
*part3
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '二章一日目　後編'"]

[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=20]
[bg storage="brack.png" time="100"]
[mask_off time="3000"]
;〇旧校舎（夕）

;ＳＥひぐらし
#mokke
呜……嗯～……[p]
[free_filter]
[bg storage="school/kyukosya_a.jpeg" time="100"]
[chara_show name="mokke" top="100" left="100" time="10" face="kuroda" wait="false"]
[chara_show name="riki" top="-100" face="smile" left="360" time="10"]
[resetdelay]
[font size="40"]
[stopbgm]
#mokke
……啊！！[p][resetfont]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
#riki
哦——。早啊——[p]
#mokke
啊……咦？登利？你怎么会在这儿……[p]
#riki:normal
没什么好没什么的啦。[r]
你要晕倒的话就记得勤喝水啊——[p]
[delay speed="50"]
#mokke
诶？啊、我……该不会是中暑了吧？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" face="closeEye_kt" top="-160" wait="false"]
#sarasa
真的，累坏了，[r]
连累你了真对不起……[p]
[resetdelay]
[chara_hide name="sarasa" time="10"]
[chara_show name="mokke" top="100" left="100" time="100" face="kuroda" wait="false"]
[chara_show name="riki" top="-100" face="lookAway" left="360" time="100" wait="false"]
#mokke
啊！志、志户田！[r]
不是的完全是我自己没管理好！[r]
别在意……[p]
[font size="40"]
话说现在几点了！？[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="10" face="normal_c" time="100"]
[resetfont]
[resetdelay]
#makado
大概六点半吧[p]
[chara_hide name="makado" time="10"]
[chara_show name="mokke" top="100" left="100" time="100" face="kuroda" wait="false"]
[chara_show name="riki" top="-100" face="sad" left="360" time="100" wait="false"]
[quake time="30"]
[font size="40"]
#mokke
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
完蛋啊啊！！[r]
整整翘掉了社团活动啊——！！[p]
[quake time="30"]
#riki:wow
[playse  volume="30" buf="2" storage="kaminari.ogg"]
[anim name="riki" left="-=10" time=50]
[anim name="riki" left="+=10" time=50]
[anim name="riki" left="-=10" time=50]
[anim name="riki" left="+=10" time=50]
啊——！！我也完蛋了啊——！！[p]
[resetfont]
#mokke
啊啊怎么办。怎么办啊——！[r]
下次练习赛绝对要让我光脚上场了——！！[p]
#riki:sad
呵、放心吧黒田。估计我也一样[p]
#mokke
啊，你也被说了？[p]
#riki:smileH
说了。顺便，[r]
还说要动用顾问老师的权力确保我的右脚小拇指[r]
彻底报废[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="closeEye_c" time="100" wait="false"]
#makado
……你们社团的指导老师，[r]
真的适合待在教育岗位上吗？[p]
[chara_hide name="makado" time="10"]
[chara_show name="mokke" top="100" left="100" time="10" face="kuroda" wait="false"]
[chara_show name="riki" top="-100" face="tweetLA" left="360" time="10" wait="false"]
#mokke
不能这样下去了，[r]
我现在就去职员室看看能不能道歉！[l][r]
[chara_move name="mokke" left=-520 anim="true" time=700 wait="false"]
[chara_hide name="mokke" pos_mode="true" time="10" wait="false"]
那下次见！登利！志户田！[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" face="smile_kt" time="100" wait="false"]
#sarasa
嗯，黒田君……今天谢谢你了[p]
#mokke
还有那个不知道干嘛的和尚！[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" top="-10" face="tweet_c" time="100" wait="false"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
才不是和尚……[wait time="400"][er]
[chara_show name="riki" top="-10" face="angry" time="10" wait="false"]
[chara_mod name="makado" face="closeEye_c" wait="false"]
#riki
黒田——！[r]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
连我的份也一起道歉啊——[p]
#makado
…………。[p]
#makado:normal_c
好了。[l][r]
#makado:tweet_c
意识清醒了吗？日野[p]
[chara_hide_all time="10"]
[chara_show name="hino" time="400" wait="false" face="sad" top="-100"]
#hino
……清、清醒了……[p]
[chara_hide name="hino" time="10"]
[chara_show name="aki" wait="false" face="hate" top="-100" zindex="2"]
#aki
……[p]
[chara_move name="aki" left="-70" anim="true" wait="false"]
[chara_show name="hino" wait="false" top="-100" left="360" zindex="2"]
[delay speed="70"]
#hino
器乐堂，你……[p]
#aki:normal
…………啥？[r]
要是恨的话  大可以  揍我  烧我  随你便……[p]
[resetdelay]
[font size="40"]
[chara_mod name="aki" face="wow"]
[quake time="30"]
#hino:shame
[playse  volume="30" buf="0" storage="kansei.ogg"]
……呃、[wait time="500"][r]
诅咒总算解除了啊啊啊啊啊！！[p]
[font size="20"]
[delay speed="10"]
#hino:smile
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
哎呀太好了太好了。毕竟同班同学里，而且还是小组内！[r]
要是存在个杀意爆棚的家伙和他的目标对象，待着也太难受了啊。[r]
总不能像七人御前那样直接换成员吧！！[p]
#hino:happy
[resetdelay]
[resetfont]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
这下放心了，事件，解决！ 噗哈哈哈！[p]
[delay speed="50"]
#aki
……[l][r][chara_mod name="aki" face="sad"]
你啊…果然是个怪人呢[p]
[resetdelay]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
嗯！经常被这么说！！[p]
[chara_show name="riki" top="-100" face="smile" time="100" wait="false" left="70" zindex="1"]
[chara_move name="hino" left="390" wait="false" anim="true"]
[chara_move name="aki" left="-100" wait="false" anim="true"]
#riki
哎哎～掉进洞里的感觉如何？[r]
有遇到扔锤子的乌龟啊硬币之类的东西吗？[p]
#hino:normal
唔？要说的话…除了持续坠落的感觉以外………[r]
就只记得比暑假补习班的教室还要凉快这点吧[p]
#hino:smile
嘛，要是真掉到底的话说不定会有针山血池什么的！[p]
[delay speed="80"]
……………………………………………………[p]
[quake time="30"]
[font size="37"]
#hino:shame
[delay speed="18"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
诶！仔细想想超可怕！！[r]
你干了什么啊器乐堂——！！[p]
[resetdelay]
[resetfont]
#riki:smileCE
哈哈！反应也太慢了吧[p]
#aki:tweetLA
与其像这样生气的话[r]
当时要是没让火熄灭的话 就不用掉下来了吧[p]
#hino:angry
说什么蠢话！[r]
怎么可能把朋友点燃啊！[p]
#aki:worry
你居然能面不改色说出这种话[r]
你还真是个得天独厚的家伙啊[p]
#hino:smile
哦！这是在夸我吗！[r]
这种善意评价我最爱听了！！[p]
#hino:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
但今天因为你[r]
害得我把工作都推给重要的副部长一个人先回去了[r]
待会儿记得和我一起去道歉啊[p]
#riki:smile
话真多啊国雄[p]
[chara_hide_all time="500"]
[chara_show name="makado" top="-10" face="smileMini_c" wait="false"]
#makado
――不过日野的火焰？之力也好，器乐堂也好，[r]
结果谁都没有受伤就顺利解决了[p]
#makado:lookAway_c
通过这次事件，[r]
没有人丧命，真是太好了……[p]
[chara_hide name="makado" time="500" pos_mode="false"]
[chara_show name="riki" top="-100" face="smile" time="300" wait="false" left="70"]
[chara_show name="hino" left="390" wait="false" time="300" face="normal" top="-100"]
[chara_show name="aki" left="-100" wait="false" time="300" face="normal" top="-100"]
#riki
是啊——[r]
我还以为掉进阿奇洞里的人[r]
肯定会全军覆没呢[p]
#aki:tweetLA
看来不会死呢。[r]
实际上　我母亲在这里住了大半年[r]
还活蹦乱跳的呢[p]
#
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" wait="true" time="1000" face="normal_kt"]
[delay speed="50"]
#sarasa
——呐，阿基[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" top="-100" face="normal" time="500" wait="false"]
#aki
……怎么了？纱罗纱[p]
[chara_hide name="aki" time="10" pos_mode="false"]
[chara_show name="sarasa" top="-160" wait="true" time="300" face="worry_kt"]
#sarasa
阿基今后也要[r]
这样继续……活下去吗[p]
[chara_hide name="sarasa" time="10" pos_mode="false"]
[chara_show name="aki" top="-100" face="smileB" time="300" wait="false"]
[resetdelay]
#aki
当然　我就是这么打算的[p]
#aki:normal
毕竟　这就是　我所祈求的　全部了[r]
这样就好[l][r]
本来嘛　血缘这种东西　就是斩不断的呢[p]
[chara_hide name="aki" time="10" pos_mode="false"]
[chara_show name="sarasa" top="-160" wait="false" time="300" face="closeEye_kt"]
[delay speed="60"]
#sarasa
…………………………这样啊……[p]
[chara_hide name="sarasa" time="10" pos_mode="false"]
[chara_show name="aki" top="-100" face="tweet" time="100" wait="false"]
#aki
啊—啊　好丢脸啊　完全搞错了方向[r]
你根本　一点都不　空洞呢[p]
#aki
……虽然平时　总是一声不吭的[r]
脑子里其实　想了很多事情吧[r]
和我不同　很有内涵呢[p]
[chara_hide name="aki" time="10" pos_mode="false"]
[chara_show name="sarasa" top="-160" wait="false" time="500" face="normal_kt"]
#sarasa
…………。[p]
#sarasa:closeEye_kt
可是……我也[r]
只有通过别人说出口的话 才能了解自己啊[l][r]
不像阿基那样……连为自己强烈祈祷都做不到[p]
#sarasa:sad_kt
所以 总是…………[p]
#sarasa:closeEye_kt
…………[wait time="300"][chara_mod name="sarasa" face="normal_kt"]总是 欲言又止 或者错过倾听[r]
净是这样的事[p]
[chara_hide name="sarasa" time="10" pos_mode="false"]
[chara_show name="aki" top="-100" face="smile" time="100" wait="false"]
[resetdelay]
#aki
啊哈哈 那这么说 你多少有点羡慕我？[r]
我啊 为了维持表面形象 总是会立刻对别人指手画脚呢[p]
[chara_face name="aki" face="back" storage="chara/aki/back.png"]
#aki:back
[fadeoutbgm time="2000"]
[delay speed="60"]
——不过 是啊 从今以后 或许该[r]
不仅为了外在 也要为了内心 做些什么[r]
这样会比较好呢[p]
至少 不要变成 像爸爸和妈妈那样的[r]
那种大人 我绝对不想成为那样的人[r]
绝对要………………………[p]
[chara_hide name="aki" time="300"]
[chara_show name="riki" top="-100" face="normal" wait="false"]
#riki
………………[p]
[resetdelay]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=30]
#riki:think
啊、对了。[r]
喂喂志户田[p]
#riki:normal
你小子啊、特意跑到黒田那边的后巷水龙头处[r]
到底有啥事啊？[p]
#riki:smileCE
难不成、是在找我？[p]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
啊……！[p]
[chara_mod name="riki" face="normal"]
对、对啊……。[r]
我、我有事情想问你[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-10" time="100" wait="false" face="normal_c"]
#makado
……！[p]
#
贤治郎先生像是察觉到我的意图般使了个眼色。[p]
[delay speed="50"]
[chara_hide name="makado" wait="false"]
我对此微微点头……[r]
决定就在这里推进那件事”。[p]
[chara_show name="sarasa" face="closeEye_kt" top="-160" wait="false"]
#sarasa
这个问题，肯定……[r]
和日野还有阿基都有关联。[p]
#sarasa:angry_kt
所以……如果可以的话，希望你们俩也能回答[p]
[resetdelay]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" face="normal"  wait="false" left="70"]
[chara_show name="hino" left="390" wait="false" face="normal" top="-100"]
[chara_show name="aki" left="-100" wait="false" face="normal" top="-100"]
#aki
看内容而定　没问题？[p]
#hino:smile
啊！我也同意！[r]
在能回答的范围内尽量回答吧！[p]
[chara_hide_all time="10"]
[chara_show name="makado" face="normal_c" top="-10" time="100" wait="false"]
#makado
……那就好[p]
[chara_hide name="makado" time="100"]
[delay speed="60"]
[fadeoutbgm time="4000"]
#
紧握的掌心渗出汗来，[r]
我知道这不是因为闷热，而是出于紧张。[p]

根据他们提供的名字，[r]
或许就能查明那天可疑人物的真身。[p]
@layopt layer=message0 visible=false
[clearfix]
;回想スチル：不審者
[filter grayscale="100"]
[bg storage="still/first_contact.png" cross="false" wait="true" time="800"]
[wait time="1000"]
[free_filter]
[bg storage="school/kyukosya_a.jpeg" time="2000" wait="true" cross="false"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……那个……[p]
[font color="0xf08080"]关于封印之绢布的烧毁……[resetfont][l][r]
你们到底是从谁那里听来的？	[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="riki" top="-100" face="smileH" time="100" left="70" wait="false"]
[chara_show name="hino" left="390" face="normal" top="-100" time="100" wait="false"]
[chara_show name="aki" left="-100" face="hate" top="-100" time="100" wait="false"]
[wait time="2000"]
#aki
@layopt layer=message0 visible=true
@plugin name=tip mark=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……………………[p]
#hino
……………………[p]
#riki
…………。[p]
[delay speed="60"]
#sarasa
……诶？[p]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume="40"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
――本该被八月暑气笼罩的树林，[r]
骤然变得阴冷起来。[l][r]
[r]
[r]
直到刚才还像是普通同学的少年们[r]
如同人偶般　紧闭双唇[r]
玻璃珠般的眼眸　死死钉穿了我。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
……怎、怎么了？[p]
#aki
…………………………[p]
#hino
…………………………[p]
#sarasa
大……大家、怎么了……？[p]
[stopbgm]
#riki:normal
是树月啊[p]
#sarasa
诶……[p]
#
[chara_hide_all time="100" wait="false"]
[bg storage="brack.png" time="2000" wait="true"]
[delay speed="100"]
[wait time="1000"]
[font color="0xf08080"]宗方树[resetfont][p]
[clearfix]
[bg storage="school/kyukosya_a.jpeg" wait="true" time="3000"]
#sarasa
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……………………………………[l][r]
[fadeinbgm storage=higurasi2.ogg loop=true time=6000 volume="40"]
怎、[wait time="500"]怎么会…………[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
这句话所代表的含义。[r]
也就是说。[l][r]
[r]
[delay speed="60"]
[font bold=" true"]封印の絹布の焼失[resetfont]を、彼らに広めた張本人は――[l][r]
既不是最初袭击我的[font color="0xf08080"]神秘可疑人物[resetfont]，[r]
也不是诅咒的牺牲者·[font color="0xf08080"]宗方雾绘[resetfont]。[p]
#sarasa
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……是一树在、[wait time="500"]说话吗？[p]
[delay speed="50"]
[chara_show name="aki" top="-100" face="normal" time="300" left="-80"]
[fadeoutbgm time="6000"]
#aki
自从雾绘小姐　去世之后[r]
在最初的『眠之日』那天就听说过了[p]
[chara_show name="hino" top="-100" face="tweet" time="500" wait="true" left="370"]
#hino
树月为了即将到来的『蔟之日』，[r]
站在众人面前宣告道[p]
[chara_show name="riki" top="-100" time="600" left="70"]
#riki
由于封印绢布的烧毁，为讨伐御黑目[r]
御白姬将再度降临人世[resetfont]什么的[p]
[chara_hide_all time="10"]
[chara_show name="makado" face="wowB_c" top="-10" time="100" wait="false"]
[delay speed="80"]
#makado
――――――！！[wait time="600"][er]
[font size="40"]
[resetdelay]
[quake time="30"]
#makado:worryB_c
难道说你们[r]
全都是狮心教的孩子吗！？[p][resetfont]
[chara_hide name="makado" time="10"]
[chara_show name="aki" top="-100" time="100" wait="false"]
#aki:normal
……[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" time="100" wait="false"]
#hino:normal
……[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" wait="false" top="-160" face="worry_kt"]
#sarasa
……[l][r]
[delay speed="70"]
诶、什、什么？那个……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" wait="false" face=""]
#riki:tweetLA
……[l][r]
[chara_mod name="riki" face="normal"]
[delay speed="50"]
嗯，对啊。[p]
二年一班，我们被编成的「城镇与我」小组的成员，[r]
全都是"[font color="0xf08080"]狮心教[resetfont]"的孩子。[p]
[chara_hide name="riki" time="100" wait="false" pos_mode="false"]
[chara_show name="sarasa" top="-160" wait="false" face="worry_kt" left="120"]
不过[wait time="500"]这家伙除外哦[p]
#sarasa
………………除了、我？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" top="-100" time="100" wait="false"]
#aki
难道说[r]连名字都不知道？[r]
怎么可能！[r]
像你这样和一树关系这么好的人[p]绝对不可能！[p]
[delay speed="80"]
#sarasa
…………不、不知道[r][wait time="500"]
[chara_hide name="aki" wait="false"]
不明白……………………[p]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=40]
[resetdelay]
#
……对我来说[r]连对话中词语的意图都
一切都无法理解。[p]

为什么、会提到树月的名字？[p]
[delay speed="60"]
除了我以外的、小组成员都……[r]
是通过某种我所不知道的方式、维系在一起的吗？[p]
[chara_show name="hino" face="tweet" wait="false" top="-100"]
[resetdelay]
#hino
如果你不知道这件事的话、现在知道不就好了[p]
[delay speed="50"]
#hino:lookAway
所谓狮心教、是八种町自古流传的创唱宗教。[l][r]
信奉产土神[font bold="true"]御白姬[resetfont]，为了获得祝福而进行[font bold="true"]祈祷[resetfont]。[r]
而这个教派的、创始家系是……[p]
[chara_hide name="hino" time="10"]
[bg storage="brack.png" time="100" wait="true"]
[chara_show name="kirie" top="-10" time="100" face="normal" left="130" wait="false"]
[chara_show name="suguru" left="-100" time="100" wait="false" top="-10" face="normal" wait="false"]
[chara_show name="ituki" left="360" top="-10" face="normal" time="100" wait="false"]
宗方雾绘、宗方树、宗方优三姐妹诞生的家族。[r]
[font color="0xf08080"]是宗方家的人啊[resetfont][p]
[chara_hide_all time="100" wait="false"]
[delay speed="70"]
#sarasa
……以一树的家为发源地创立的宗教……[p]
#makado
…………原来如此。果然……[l][r]
想必是为了不让你们知晓，才刻意保护起来的吧[p]
雾绘她们在狮心教内部被冠以某个称谓……[r]
承担着重要职责。[p]
其名为――[wait time="600"]三人官女[p]
[fadeoutbgm time="7000"]
#
[cm]
;【第二章】『私は不思議でたまらない』終
[mask folder="bgimage" graphic="still/part2.png" time="6000"]
[wait time="3000"]
[showsave]
@jump storage="chapter_3/day1_vol1.ks"






;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;---------------------------------------------------------
*q_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#f08080");
},
function() {
  $(this).css("color", "#000000");
　}
);
[endscript]
[return]
;--------------------------------------------------------
[s]
;tipプラグイン
*tiplist
[tip_list]

[s]
