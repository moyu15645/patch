;第2章『私は不思議でたまらない』
;一日目前編
*part3
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '二章一日目　前編'"]

@layopt layer=message0 visible=false
[clearfix]
[playse storage=page.ogg volume="50"]
[mask folder="bgimage" graphic="still/part2.png" time="3000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=30]
[wait time="3000"]
[bg storage="hataneM.jpg" time="3000" wait="true"]
[delay speed="50"]
[mask_off time="2000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
养蚕业啊，[r]
听说很多地方都把八月当作休养季节。[r]
跟我们暑假差不多嘛。[p]

然后根据卵孵化的时期　会有不同的叫法。[r]
春天叫春蚕、夏天叫夏蚕……这样。[p]

不过　不管哪个季节……[r]
产完卵的雌蚕　很快就会死掉。[p]

……话说回来　产卵和死亡　哪个更痛苦呢？[p]
[stopbgm]
[resetdelay]
;教室
[bg storage=./school/croom_m.jpg time="1500" wait=true]
[chara_show name="riki" top=-100 wait="false"]
#riki:smileCE
——嘛，大概就是这样！[r]
养蚕业可是个收取生命的厉害职业，[r]
这个行当在昭和年代前可是在八种延续着的呢！[p]
#
[chara_show name="ituki" left=-60 top=-160 time="10" face="tweet"]
[chara_show name="aki" left=390 top=-100 time="10" face="wow"]
哦——！[p]
[chara_hide_all time=100]
[playbgm storage="gymnopedies2.ogg" loop="true" volume="70"]
#
……8月18日。[r]
窗外的蓝天被巨大的积雨云占据着，[r]
正是盛夏的酷暑天。[p]
[chara_show name="ituki" top=-160 time="10" face="smileCE"]
#ituki
太厉害了！[r]
居然一周内就准备了这么多情报！[p]
[chara_hide name="ituki" wait="true" time="10"]
[chara_show name="aki" top=-100 time="10" face="wow"]
#aki
真是、让人刮目相看了呢！[r]
本来以为你绝对什么都做不成的……[p]
[chara_hide name="aki" wait="true" time="10"]
[chara_show name="riki" wait="false" top="-100" time="10" face="angry"]
#riki
恶魔始祖[p]
#aki
对、对不起。但真的出乎意料……[p]
#ituki
那是当然的呀。[r]
因为登利君可是从不遵守截稿日的王国之王呢[p]
#riki:think
喂、我可没建立过这种国家啊[p]
[chara_hide name="riki" wait="false"]
#
登利一边收拾着摊开在桌上的汇报资料[r]
嘴上还在抱怨着。[l][r]
但语气里却带着几分得意。[p]
[chara_hide name="riki" time="10"]
[chara_show  name="aki" left=250 top=-100 wait="false"]
[chara_show  name="riki" face="normal" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="smile" left=-230 top=-100 wait="false"]
[chara_show  name="ituki" face="smile" left=490 top=-160 wait="true"]
#hino:smile
多亏马门神社还留着资料才捡回条命啊。[r]
下次记得带盒点心去答谢啊，登利！[p]
#riki:angry
哈——？[r]
这种人情世故等上了中学再学也不迟啦。[l][r]
#riki:smile
对吧，志户田[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="wow"]
#sarasa
呃……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-1" face="shame" top="-100" time="10"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
喂！[r]
别因为我是个老好人就硬拉我入伙啊！！[p]
[chara_hide name="hino"]
[chara_show name="sarasa" top="-100" top="-160" face="closeEye"]
#sarasa
（原来在他们眼里我就是个老好人啊……）[p]
#
从登利解除诅咒”那天起直到今天――[l][r]
我身上，并没发生什么特别重大的事情。[p]
[chara_hide name="sarasa" time="100" wait="true"]
[bg storage="brack.png" cross="false" wait="false"]
[fadeoutbgm time="200"]
[delay speed="60"]
但是――[r]
眼下这个场合，有件事必须引起重视。[p]
[resetdelay]

;〇四ツ山階段（夕）
[mask]
[bg storage="saka_a.jpeg" time="100"]
[mask_off]
;ＳＥ蝉
[fadeinbgm storage=higurasi2.ogg loop=true time="5000" volume="30"]
[chara_show name="hino" top="-100" wait="false" face="smile"]
#hino
――那贤治郎先生，[r]
今天真是太感谢您啦！[p]
[chara_move name="hino" time="100" left="300" wait="false"]
[chara_show name="makado" top="-60" wait="false" left="-100" face="smileMini_c"]
#makado
嗯，下次有什么事尽管来找我[p]
#hino:sad
诶……真、真的可以吗……！？[r]
现在正是忙的时候，会不会打扰到您……[l][r]
[chara_mod name="hino" face="angry"]
而且光是今天的事，我都觉得已经给您添麻烦了……[p]
#makado
说什么呢。对于珍惜神明的人[r]
任何时候都欢迎来访啊[p]
#hino:happy
哇啊啊！！[r]
真的吗啊啊啊！太好啦啊啊啊！[p]
[chara_hide_all time="10"]
[chara_show name="riki" top="-100" face="tweetLA" wait="false"]
#riki
哈。平等是吧？[p]
[chara_hide name="riki" wait="false" pos_mode="false"]
[chara_show name="hino" left="300" top="-100" time="10" face="angry" wait="false"]
[chara_show name="makado" top="-60" time="10" left="-100" face="normal_c" wait="false"]
#hino
喂你这家伙登利你那张脸……[r]
你对贤治郎先生有什么意见吗！？[p]
#riki
没～有？完全没～有。[r]
日野～，走啦～～[p]
#hino:shame
喂、喂别自顾自先走啊！[l][r]
[chara_mod name="hino" face="smile"]
贤治郎先生，今天承蒙您关照了！[r]
志户田也下次返校日见！[p]
[chara_hide_all time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="800"]
[delay speed="50"]
#riki
啊……对了，[r]
贤次郎[p]
#
登利像是突然想起什么似的回过头。[p]
[chara_show name="riki" time="10" top="-100" face="tweetLA"]
#riki
贤治郎啊。[l][r]
[chara_mod name="riki" face="worry"]
永远无法再醒来的家人的脸，[r]
你能一直盯着看吗？[p]
#
……我因为在意贤治郎先生的回答，[r]
抬头看向他的脸。[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-10" time="10" face="normal_c"]
#makado
……[p]
#makado:tweet_c
明明还留在那里，[r]
哪有不能看的道理？[p]
[chara_hide name="makado" time="10"]
[chara_show name="riki" top="-100" time="10" face="worry"]
#riki
……[l][r]
[chara_mod name="riki" face="lookAway"]
嘿嘿。果然我和你啊，完全不一样呢——[p]
#riki:smileCE
啊——对了志户田！[r]
要是和贤治郎走得太近，树月可是会吃醋的哦。[r]
那家伙超——可怕的，差不多得了——[p]
[resetdelay]
[chara_hide name="riki" wait="false"]
#riki
那我下次还要来喝你家的梅子汁！[r]
回头见啦贤治郎——！[p]
;ＳＥ歩いて行くｆｏ
#
……[p]
#makado
那家伙……[l][r]
明明刚才吐了整整一杯的量，现在还想继续挑战吗。[p]
#makado
——来吧。我送你一程[p]
[mask]
[stopbgm]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[bg storage="ton_m.jpeg" time="100" wait="true"]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=50]
[mask_off]
;〇トンネル（夕）
#makado
……虽然很抱歉[l][r]
[delay speed="50"]
[chara_show name="makado" face="normal_c" top="-10" wait="false"]
现在要跟你说些[r]
你可能不愿再被提起的事[p]
#makado:closeEye_c
那天，在这地方倒下时……[p]
#makado:tweet_c
[stopbgm]
你看到袭击者的脸了吗？[r]
还、还记得吗？[p]
[chara_mod name="makado" face="normal_c"]
#sarasa
——呃……[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=50]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
后背倏地窜过一阵寒意。[p]
那一定是因为[r]
被强行挖出了刻意回避的记忆吧。[p]

#sarasa
…………抱歉[l]　当时太暗了　我太慌张。[r]
实在……[p]
#makado
…………[p]
[fadeoutbgm time="2000"]
[delay speed="60"]
#makado:closeEye_c
不……你说得对。[r]
[chara_mod name="makado" face="tweetLA_c"]
我的错，别放在心上[p]
#sarasa
……。[l][r]
贤治郎先生，您是不是……有什么在意的事？[p]
#makado:wowCM_c
！[p]
[resetdelay]
[fadeinbgm storage=sicilienne.ogg loop=true volume="50" time="4000"]
#makado:tweet_c
是啊。[r]
我在想今后能不能利用[font color="0xf08080"]诅咒的法则[resetfont]，[r]
提前防范怪物来袭……[p]
#sarasa
法则……吗？[p]

#makado:normal_c
[playse  volume="20" buf="0" storage="sariin.ogg"]
嗯。无论多灵异的事件，[r]
只要认真分析大多都能找出规律――[r]
应该能总结出规律来的[p]
#makado:tweetLA_c
比如说……[p]
#makado:tweet_c
你看，像丑时参拜”之类的，不是都有严格的操作步骤吗？[p]
[delay speed="60"]
#sarasa
……？丑时参拜…………？[p]
[resetdelay]
#makado:sad_c
那个……总之就是说诅咒”这种法术，[r]
大多都是基于[font color="0xf08080"]严格规则才能生效[resetfont]的[p]
#makado:tweet_c
要么必须完美念出固定咒语，[r]
要么仪式对时间和天气有特定要求[p]
#makado:lookAway_c
所以黑魆魆的诅咒也肯定不例外[r]
必定存在某种规则——[p]
#makado:tweet_c
如果能反过来利用这点，[r]
应该就能降低纱罗纱今后被袭击的可能性[p]
[chara_hide name="makado" wait="false"]
目前我们关于黑魆魆的诅咒[r]
能确认的情报整理如下——[p]

[playse storage=page.ogg volume="50"]
[image layer=0 folder="image" name="makado_memo_b" storage="item/makado_memo_b.png" width="500" x="250" y="52" visible="true" time="800" ]
;持ち物スチル：呪いについてのメモ
;	・呪われた者は志戸田紗羅紗を『オシラヒメ』と呼び、狙う
;	・呪いは志戸田紗羅紗が回顧に触れることで祓える
;	・呪われた者は『神厩舎の注連縄』によって一定時間動きを止められる
;	・視覚による呪われた者の判別は志戸田紗羅紗が可能
;	・呪われた者を放置すると、自死する可能性がある？
#makado
……大概是这种感觉。[p]

#makado
——最后这点我认为至关重要，[r]
说到底……[font color="0xf08080"]被诅咒之人的规则[resetfont]你还记得吗？[p]

;▶呪われるのは、『御黑祟を知っている者』
;▶呪われるのは、『御黑祟と、封印の絹布の焼失についても知っている者』
;▶呪われるのは、『絹布の焼失について知っている者」
[font size="25"]
#
[link target="*noroi1_hazure"]【１】被诅咒的对象是“知晓御黑祟存在的人”[endlink][r]
[link target="*noroi1_atari"]【２】被诅咒的是“知晓御黑祟与绢布烧毁之事的人”[endlink][r]
[link target="*noroi1_hazure"]【３】被诅咒的是“知晓绢布烧毁之事的人”[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*noroi1_hazure
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;不正解
[image layer=0 folder="image" name="makado_memo_b" storage="item/makado_memo_b.png" width="500" x="250" y="52" visible="false" time="100"]
[image layer=0 folder="image" name="makado_memo" storage="item/makado_memo.png" width="500" x="250" y="52" time="800" visible="true" ]
真可惜啊。[r]
[font color="0xf08080"]是知晓『御黑祟[resetfont]与[font color="0xf08080"]封印之绢布烧毁的人[resetfont]』[p]
@jump target="*noroi1"
;-------------------------------------------------------------------------------
*noroi1_atari
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;正解　＋白い繭
[image layer=0 folder="image" name="makado_memo_b" storage="item/makado_memo_b.png" width="500" x="250" y="52" visible="false" time="100"]
[image layer=0 folder="image" name="makado_memo" storage="item/makado_memo.png" width="500" x="250" y="52" time="800" visible="true" ]
#makado
正是如此！[r]
要遭受黑魆魆的诅咒，除了了解黑魆魆的知识之外[r]
[font color="0xf08080"]也必须打听关于『封印之绢布烧毁』的事情。[resetfont][p]
@jump target="*noroi1"
;-------------------------------------------------------------------------------
*noroi1
;-------------------------------------------------------------------------------
#sarasa
啊……！那、今天的登利君也……[p]
#makado
没错。他肯定在某个地方听到过相关传闻[p]
关于那个散布传言的人，[r]
希望你能从纱罗纱的立场也帮忙调查一下[p]
#
关于绢布烧毁事件，知情人士――[p]

目前可以确定的是，[r]
【已故的宗方雾绘】和【8月4日的可疑人物】吧……[p]

#makado
如果找到了散播传言的人――[r]
纵火烧毁绢布的真凶也能揪出来。[p]
[image layer=0 folder="image" name="makado_memo" storage="item/makado_memo.png" width="500" x="250" y="52" visible="false"  wait="false"]
[free layer=0 name="makado_memo_b" time="10"]
[free layer=0 name="makado_memo" time="800" wait="false"]
#makado
可以试着根据模糊的肖像特征、或是听到的声音来推测。[r]
[bg storage="brack.png" cross="false" wait="false"]
要把所有不安因素逐个排除[p]
为了让白绢祭平安落幕[p]
[font color="0xb0c4de"]
;〇【呪いについてのメモ】を手に入れた
[playse  volume="20" buf="0" storage="sariin.ogg"]
获得了〇关于诅咒的笔记。[tip key="noroi_memo"][endtip]
[wse][p]
[bg storage="./school/croom_m.jpg" cross="false" wait="false"]
[resetfont]
;〇教室

#sarasa
（……等登利君落单的时候……[r]
找机会套话吧）[p]
[chara_show name="ituki" top="-100" face="smileCE" time="10"]
[stopbgm]
#ituki
纱良酱！[p]
#ituki:tweet
从早上开始就一直心不在焉呢……[r]
是有什么在意的事情吗？[p]
#ituki:normal
不过这种发呆的状态[r]
才是你的日常”吧……呵呵[p]
#
自从那天一起放学后，[r]
或许是因为再没找到和她认真交谈的机会……[p]
[fadeoutbgm time="2000"]
现在的我，[r]
对树月也堆积了太多想问的事。[p]

[chara_hide name="ituki" wait="true"]
;回想スチル：頼まれた伝言
[filter grayscale="100"]
[bg storage="still/kirie_bridge.jpeg" time="500" wait="true"]
[bg storage=./school/croom_m.jpg time="100" wait="true"]
[free_filter]
[chara_show name="ituki" top="-100" face="normal"]
#ituki
……[l][r]
[chara_mod name="ituki" face="tweet"]
纱罗纱还是什么都不知道的样子更迷人呢[p]
#
——？[r]
刚才那句话……究竟是什么意思……[p]
[chara_hide name="ituki" time="10"]
[chara_show name="aki" time="10" top="-100" face="wow"]
#aki
……啊 纱罗纱[l][r]
[chara_mod name="aki" face="normal"]
你手臂下面那张纸 是什么？[p]
[chara_hide name="aki" time="10"]
#
……登利对阿奇的话作出反应，[r]
立刻从我手里夺走了「那个」。[p]
;ＳＥ紙を盗る。ここなんかで代用できない？
[quake time="30"]
#sarasa
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
啊……！[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_show name="riki" top="-100" face="angry" wait="false"]
[delay speed="40"]
#riki
呜哇——！你这家伙、志户田——！！[r]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
老子在发表的时候、你居然在下面乱涂乱画啊————！！[stop_kanim name=riki][p]
[chara_move  name="riki" face="sad" anim="true" left=-70 top=-100 wait="false"]
[chara_show  name="aki" left=250 top=-100 face="wow" wait="false"]
[chara_show  name="hino" left=-230 top=-100 wait="false"]
[chara_show  name="ituki" left=490 top=-160 wait="false"]
[resetdelay]
#aki
诶！[r]　
啊啦　原来是涂鸦的纸吗！？那个　抱歉……[p]
#sarasa
呜……。[l][r]
对、对不起……[p]
#hino:angry
你说什么！？志户田，[r]
在小组成员发表的时候你竟然在专注涂鸦吗！？[p]
[delay speed="70"]
#ituki:normal
哎呀国雄君，是有什么高见吗？[p]
[delay speed="10"]
#hino:smile
没有！我觉得能一心多用非常了不起！[p]
[resetdelay]
#aki:smile
啊哈哈……纱罗纱居然会开小差真是少见呢。[r]
你、你画了什么？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="lookAway" wait="false"]
#sarasa
……[p]
#sarasa:sad
……在、在练习画肖像……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" face="angry" time="10"]
#riki
靠！火大！竟敢把我的发言当背景广播！[r]
喂志户田，[r]
你忘带文具盒那天我绝对什么都不借你！[p]
[chara_move name="riki" anim="true" top="-100" left="300" time="100" wait="false"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
[chara_show name="mokke" left=100 top="100" wait="false"]
#mokke:kuroda
诶！志户田在练习画肖像！？[r]
我！让我来画你！！[p]
#riki:sad
喂黒田。你给我回自己座位去啊[p]
#mokke
可、可是！[p]

;ＳＥ描く
#
……………。[p]
[playse storage=page.ogg volume="50"]
#sarasa
……还、还行吧[p]
#riki
真画了啊喂[p]
#mokke
哇……！让我看看……[p]
[mask]
[chara_hide_all time="10"]
;スチル：ドヘタグロ似顔絵
[bg storage="still/nengo_1.jpg" time="30"]
@layopt layer=message0 visible=false
[clearfix]
[mask_off]
[playse  volume="30" buf="1" storage="garasu.ogg" ]
;ＳＥ叫び声
[wait time="1300"]
[bg storage="still/nengo_2.png" time="1000" cross="true" wait="false"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#mokke
…………………[p]
#aki
…………………[p]
#hino
…………………[p]
#riki
这啥啊？噩梦里的东西吗？[p]
#ituki
纱罗纱很擅长立体主义画风呢[p]
#aki
被你这么一说 虽然不太懂[r]
说不定挺有艺术感[p]
#hino
不……这根本就是……单纯的画技差吧……[p]
#riki
这家伙绝对是个饭桶吧[p]
#ituki
[delay speed="10"]
给我闭嘴！！！！[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="500"]
[bg storage="still/nengo_3.png" time="1000" cross="false" wait="true"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#ituki
[font size="50"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
…………！[p]
[font size="32"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
纱罗纱！！[r]
别在意登利和日野说的话！！[r]
他们终究只是什么都不懂的门外汉！！[p]
[resetfont]
[resetdelay]
#aki
纱罗纱　[r]
太过分了　你们俩这样欺负人　真可怜[p]
[font size="45" bold="bold"]
#日野・登利
诶！？[p]
[resetfont]
#riki
啊、啊可恶　非要夸你才行吗　夸就夸。[l][r]
确实要是晚上在路上遇到这种家伙[r]
感觉会被拐走呢　还挺让人期待的[p]
#hino
原来如此、是类似隐藏神灵的存在啊。[p]
啊、不对志户田对不起！　[r]
仔细看看觉得其实不差！　很有韵味！[p]
[mask]
[bg storage=./school/croom_m.jpg time="10"]
[chara_show name="sarasa" left=390 top=-160 time=200 face="closeEye"]
[chara_show name="mokke" top="100" left=100 wait="false"]
[mask_off]
#sarasa
……没、没关系……。[r]
我……画画果然还是不行啊[p]
#sarasa:normal
比起这个，黑田君……对不起[p]
#mokke
诶……！？　不、不是的！完全没那回事！！[r]
我觉得这幅画很棒……[p]
[chara_hide_all time="10"]
[chara_show name="riki" top="-100" face="smileCE" wait="false"]
#riki
……嘿嘿嘿，喂黑田。[p]
#riki:smile
全盘肯定的男人可没女人缘啊，[r]
部室小黄书里写的这么快就忘了？[p]
[chara_move name="riki" top="-100" left="300" time="10" wait="false"]
[chara_show name="mokke" top="100" left=100 time="10"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=mokke keyframe=up time=300 wait="false"]
#mokke
！？　喂、喂！！　笨蛋！！！！[stop_kanim name=mokke][p]
#riki:smileCE
嘎哈哈哈！你这家伙慌得不行——！[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="300" face="shame" wait="false"]
[chara_show name="aki" top="-100" left="-40" wait="false" face="normal"]
#hino
肮、肮脏！[r]
又肮脏又愚蠢到极点！大庭广众之下喊登利！！[p]
#aki
是吗？普通初中男生不都这样嘛[r]
平常我们都装得太文雅了[p]
#hino:sad
不对！！器乐堂。[r]
我只是，[r]
要批评的不光是讲荤段子这件事……[p]
[chara_hide_all time="10"]
[chara_show name="ituki" top="-160" face="tweetB" wait="false"]
[playbgm storage=fuon.ogg loop=true time=3000 volume="30"]
#ituki
…………[p]
[chara_hide name="ituki" time="10"]
[chara_show name="hino" top="-100" left="300" time="10" face="shame"]
[chara_show name="aki" top="-100" left="-40" time="10" face="wow"]
#hino
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
嘻！就是这个！[r]
我担心的就是这个啊！！救命！[p]
[delay speed="70"]
#ituki
——登利君。你在、想什么呀？[r]
在我们面前，	黄书、什么的……[p]
[resetdelay]
#riki
…………那个。树、树月……？[p]
[chara_mod name="aki" face="sad"]
[chara_mod name="hino" face="angry"]
[delay speed="70"]
#ituki
你。居然在纱罗纱和我面前讲荤段子。[r]
胆子不小嘛。[r]
简直像是把洗手水一饮而尽的客人呢[p]
[chara_mod name="aki" face="worry"]
[chara_mod name="hino" face="normal"]
不过，像野史里那样附和你的伙伴，[r]
虽然您身边似乎没有这样的人呢……[p]
#aki
……[p]
#hino
……南无三……[p]
[chara_hide_all time="10"]
[chara_show name="riki" face="sad" top="-100" time="10"]
[resetdelay]
#riki
不、不用把气氛搞得这么冷冰冰的吧！？[p]
[chara_hide name="riki" time="10"]
[chara_show name="ituki" top="-160" face="tweetB" time="10"]
#ituki
……[l][r]
[stopbgm]
[chara_mod name="ituki" face="smileCE"]
——就是啊，纱罗纱！[p]
[chara_move name="ituki" time="100" anim="false" left="-60" top="-160" wait="false"]
[chara_show name="sarasa" time="100" top="-160" wait="false" face="wow" left="390"]
#sarasa
是、是[p]
[fadeinbgm storage="faure-op84-5.ogg" loop=true time=3000 volume="50"]
#ituki
我呀，可中意这幅画了呢。[r]
如果你不介意的话，可以收下它吗？[p]
#sarasa:worry
诶……这、这种涂鸦……[p]
#ituki:normal
哎呀，毕加索画的线条也是有价值的哦？[p]
[chara_mod name="ituki" face="smileCE"]
那么你画的这幅画，[r]
可是不输任何名作的珍宝呢！[p]
#mokke
我、我的肖像画[p]
#ituki:choise
[playse  volume="20" buf="0" storage="sariin.ogg" ]
来吧纱罗纱。[p]
若要把这个送给我，就用右手小指。[r]
若你不肯给的话，虽然很遗憾……但就用左手小指吧[p]

;▶絵をいつきにあげる
;▶絵をいつきにあげない
#
[link target="*e_ageru"]【１】把画送给一树[endlink][r]
[link target="*e_agenai" exp="f.white+=1"]【２】不把画送给一树[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*e_ageru
;-------------------------------------------------------------------------------
;▶絵をいつきにあげる
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#
我决定握住她的右手小指。[p]
#sarasa:smile
虽然画得不太好……请收下吧[p]
#ituki:smileCE
哇！我成功啦！[p]
#riki
岂止是不太好，根本画得很烂啊[p]
#hino
登利！别再往罪行上叠加罪行了！！[p]
#mokke
……我、我果然还是赢不了宗方啊……[p]
[fadeoutbgm time="2000"]
@jump target="*e_ato"
;-------------------------------------------------------------------------------
*e_agenai
;-------------------------------------------------------------------------------
;▶絵をいつきにあげない　－紫の繭
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
#
我决定握住她的左手小指。[p]
#ituki:cry
怎么这样……呜呜呜[p]
[chara_hide_all time="10"]
[chara_show name="mokke" top="100" time="10"]
#mokke
啊、那！　这个我可以拿走吗……[p]
[chara_hide name="mokke" time="10"]
[chara_show name="ituki" top="-160" time="10" face="normal"]
#ituki
不行哦。[r]
纱罗纱，请你自己好好处理掉吧[p]
[chara_hide name="ituki" time="10"]
[chara_show name="mokke" top="100" time="10"]
#mokke
为什么！？[p]
[fadeoutbgm time="2000"]
@jump target="*e_ato"
;-------------------------------------------------------------------------------
*e_ato
;-------------------------------------------------------------------------------
#
[chara_hide_all time="100"]
[playse storage=bell.ogg sprite_time="0000-6000" volume="5"]
[wse]
;ＳＥチャイム
[chara_show name="aki" face="wow" top="-100"]
#aki
……啊[p]
[chara_hide name="aki" time="10"]
[chara_show name="kuma" top="-160" face="smile"]
#kuma
好！　那么今天的班会时间到此结束。[r]
不要一直闲聊，大家早点回家吧—！[p]
#kuma:normal
还有，除了『城镇与我』之外的其他作业，[r]
别忘了要全部做完哦！[p]
[chara_hide name="kuma" time="10" wait="false"]
[chara_show name="riki" top="-100" left="300" wait="false" face="hate"]
[chara_show name="mokke" top="100" left=100 wait="false"]
[playbgm storage="gymnopedies2.ogg" loop="true" volume=70]
#riki
呜哇——想起来了——。[r]
得赶紧把数学和理科作业也推进一下不然要完蛋——[p]
#mokke
喂喂今年夏天咱们也是命运共同体吧……。[r]
千万别拖到最后一天啊[p]
#riki:shame
不过要是没完成的话[r]
又会像去年那样被川神罚跑操场三圈啊[p]
#mokke
要是没像跟屁虫一样紧跟着我的话[r]
处罚也不会这么重就是了……[p]
#女子生徒
——喂。黑田[p]
[chara_hide name="riki" wait="false" pos_mode="true"]
#mokke
啊？[p]
[chara_face name="mokke" face="womenBlack" storage="chara/mokke/womenBlack.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke:womenBlack
你打算在那边待到什么时候？[r]
该轮到我们组值日了[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
#mokke:kuroda
呃……抱歉。别这么凶嘛[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke:womenBlack
……真是的，登利那边还好说……[r]
别总和那边的人”说话啊？[p]
#
……[p]
#mokke
……[l][r]
[fadeoutbgm time="4000"]
干嘛？志户田。别死盯着这边看[p]
[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" time="10" face="wow" top="-160"]
#sarasa
呃……[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=30]
[chara_show name="mokke" wait="false" top="100" left="100" face="womenBlack" time="10"]
[chara_move name="sarasa" left="390" top="-160" anim="true" wait="false"]
#mokke
被你像估价似的狠狠瞪着，[r]
我也很不爽啊[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
#mokke:kuroda
喂、喂班长。别这样，别用那种态度……[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke:womenBlack
怎么了？黑田。[r]
你也对志户田特殊对待吗？[p]
[delay speed="60"]
还是说……就是那个吧。[r]
反正因为是喜欢的女生才这样护着她对吧[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
#mokke:kuroda
[delay speed="10"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……才、才不是……！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke:womenBlack
[resetdelay]
先说清楚，志户田……[r]
我无法原谅你这种人[p]
总是什么都不说，[r]
能不能别总指望别人察言观色？[r]
说到底，什么御白姬之类的角色——[p]
#
;ＳＥドアガラガラ
[playse  volume="100" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_hide_all time="10"]
;入道
[chara_new  name="nyudo" storage="chara/nyudo/normal.png" color="0xffd700" jname="入道永海" ]
[iscript]
TYRANO.kag.stat.charas['nyudo'].jname = '入道 永海'
[endscript]
;表情
[chara_face name="nyudo" face="normal" storage="chara/nyudo/normal.png"]
[chara_face name="nyudo" face="angry" storage="chara/nyudo/angry.png"]
[chara_face name="nyudo" face="angryB" storage="chara/nyudo/angryB.png"]
[chara_face name="nyudo" face="closeEye" storage="chara/nyudo/closeEye.png"]
[chara_face name="nyudo" face="ghost" storage="chara/nyudo/ghost.png"]
[chara_face name="nyudo" face="sad" storage="chara/nyudo/sad.png"]
[chara_face name="nyudo" face="shame" storage="chara/nyudo/shame.png"]
[chara_face name="nyudo" face="smile" storage="chara/nyudo/smile.png"]
;コピペせい！
[wse]
[playbgm storage=fuon.ogg loop=true time=300 volume="30"]
[chara_show name="nyudo" top="-100" face="angryB"]
[delay speed="70"]
#nyudo:
……你、你突然这么大声……吵什么啊[p]
[resetdelay]
[quake time="30"]
#mokke
噫！[l][r]
……入道、老师……[p]
[delay speed="70"]
#nyudo
[chara_move name="nyudo" anim="true" left=110 top="-110" width="+=50" time=1000 wait="false"]
…………发生什么……争执了吗……？[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
[resetdelay]
#mokke
没……没有！[r]
只是这家伙自己在瞎激动罢了……[p]
[delay speed="70"]
#nyudo:normal
是……这样啊。[r]
精神这么好……是好事……[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke
……[p]
[chara_hide name="nyudo" time="10"]
[resetdelay]
[chara_show name="kuma" top="-160" face="wow" time="10"　wait="false"]
#kuma
哎呀，这不是入道老师吗？怎么了？[p]
[chara_hide name="kuma" time="10"]
[chara_show name="nyudo" top="-100" face="closeEye"]
#nyudo
熊老师……能稍微、占用您一点时间吗……[p]
[chara_hide name="nyudo" wait="false"]
;ＳＥドアガラガラ
[playse  volume="100" buf="0" storage="hikidopen2.ogg"]
[wse]
[stopbgm]
#クラスメイト
[font size="18"]
……糟了……那家伙来我们班干嘛？[r]
[resetfont]
恶心死了。连返校日都不让人清净……[r]
[font size="18"]
整天阴阴沉沉的真受不了……[p]
[resetfont]
[playbgm storage="gymnopedies2.ogg" loop="true" volume=70]
[chara_show name="riki" top="-100" left="300" wait="false" face="smileCE"]
[chara_show name="mokke" top="100" left=100 wait="false" face="womenBlack"]
#riki
……啊哈哈哈！！喂班长——[r]
光是永海来了就吓成这样至于吗！[p]
你是有多讨厌她啊——！！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '委員長'
[endscript]
#mokke
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
什……什么啊，登利！？[r]
你别掺和进来行不行！[p]
#riki:hate
嘿嘿，气坏身子可是会短命的哦——[p]
#mokke
哈！？胡说什么呢！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
#mokke:kuroda
啊、哈哈哈，确实、说得对呢……[l][r]
那，登利。待会儿部室见啦[p]
#riki:normal
哦。别忘了带水壶啊[p]
[chara_hide name="mokke" wait="false" pos_mode="true"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
;ＳＥ　歩いて行く
#riki:smile
……喂喂喂志户田——！[r]
你小子被班长骂惨了吧[p]
#
登利无论何时都努力保持着开朗。[p]
#riki:lookAway
嘛，一个班将近四十号人[r]
有一两个合不来的家伙也很正常啊。[r]
只能想办法好好相处了[p]
[chara_move name="riki" time="10" anim="false" left="300"]
[chara_show name="hino" face="smile" top="-100" wait="false" left="-70"]
#hino
哦，难得登利和我的意见一致啊。[p]
#hino:normal
国家之间都会争斗，规模更小的村庄怎么可能不争斗……[r]
历史已经证明了这一点[p]
#riki:worry
国雄啊——，[r]
别特么什么都硬扯到你的兴趣上去行不行[p]
#
……但即便是那样无忧无虑的登利，[r]
在平常表现的背后，也有烦恼……和痛苦的过去。[p]
[chara_show name="aki" top="-100" face="normal"]
#aki
力。[l][r]
你放学后要去社团的话，我今天就先走啦[p]
#riki:normal
啊、知道了。[r]
其他人待会儿要干嘛？[p]
#hino:smile
我要去社团。[r]
就算是暑假期间地域科学研究部也在活力满满地活动着呢！[p]
#hino:happy
[playse  volume="20" buf="0" storage="kakan.ogg" ]
想参观的话随时欢迎，[r]
特别是器乐堂你哦！[p]
#aki:normal
啊哈哈　不了　今天我还有急事……[p]
#
登利要去社团活动，日野也是社团活动，[r]
没参加社团的我和阿奇就直接回家……[p]
——同样没参加社团的树月会怎样呢？[p]
[chara_hide_all wait="true"]
[delay speed="50"]
#
……[p]

………咦？[p]
[resetdelay]
[chara_show name="aki" top="-100" time="10"]
#aki
啊 一树的话 已经 回去了哦[p]
[delay speed="50"]
#
……[l]今天又错过和她说话的机会了。[p]
#aki:tweet
……纱罗纱[p]
#aki:smile
如果有什么想告诉一树的话[r]
要由我来替你转达吗？[p]
#sarasa
诶……[p]
#aki:normal
因为今天之后说不定还有见面的机会。[r]
怎么样？有什么要说的我帮你带话[p]

#sarasa
（……………。）[p]
;▶自己で伝える、と言う
#
[link target="*aki_yes"]【１】我要亲自传达[endlink][r]
[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*aki_yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#sarasa
……不用。[l][r]
我……会自己告诉她的……[p]
#aki:wow
……！[r]
好、我知道了[p]
#aki:tweetLA
…………[p]
[chara_mod name="aki" face="normal"]
[chara_move name="aki" top="-100" left="-70" wait="false" anim="true"]
[chara_show name="riki" top="-100" left="300" wait="false" face="normal"]
[resetdelay]
#riki
不过话说回来啊。[p]
#riki:lookAway
刚才志户田被找茬的时候，[r]
幸好一树不在场呢[p]
#sarasa
诶……？[p]
#aki:hurry
啊～确实　如果一树还在教室的话[r]
说不定会闹得很大呢[p]
[chara_mod name="aki" face="tweet"]
#riki:smileCE
那！今天咱们小组就到此解散啦——！[r]
[chara_move name="riki" left=-520 anim="true" time=700 wait="false"]
[chara_hide name="riki" pos_mode="true" time="10" wait="false"]
下周见——！[playse  volume="100" buf="0" storage="hikidopen2.ogg"][p]

;ＳＥ	扉ガラガラ
#sarasa
啊……！[p]
#
不行！要是就这样让他走了，[r]
和贤治郎先生约定的事，就没法问他了……！[p]
#sarasa
等…登利君，我……！[p]
;ＳＥ	扉ガラガラ
[mask]
#
[playse  volume="100" buf="0" storage="hikidopen2.ogg"]
[fadeoutbgm time="2000"]
[chara_hide name="aki" time="100" wait="true"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[bg storage=./school/step_m.jpg time="1500" wait=true]
[mask_off]
;〇階段
#
……[l][quake time="30"]不、不见了！　[p]

他一定是，[r]
以全速冲过走廊了吧……[p]
#sarasa
（因为被提醒了也不改正，[r]
所以被川铃木老师盯上了啊……）[p]
#
没办法。[r]
我也赶紧朝他跑的方向追去……[p]
[chara_show name="aki" face="tweet" top="-100"]
#aki
等等 纱罗纱[p]
[chara_show name="sarasa" top="-160" left="300" face="normal" wait="false"]
[chara_move name="aki" top=-100 left="-70" time="1000" anim="true" wait="false"]
#sarasa
……阿基？[p]
#aki:normal
……那个啊。[r]
有件事想问你一下……可以吗？[p]
#
……究竟是什么事呢。[r]
『小镇与我』的学习？还是说，白绢祭……[p]
#aki:smile
——你最近好像变了个人似的[p]
#sarasa:normal
……[l][r]
变了……[p]
#aki:tweet
嗯……[r]
之前你明明从不和班上同学……[p]
[chara_mod name="aki" face="tweetLA"]
不、应该说除了小树之外[r]
主动去接触任何人[r]
这样的场景我从未见过——[p]
#aki:normal
今天的你却和阿力、日野，还有黑田君……[r]
	和好多人都在交谈呢[l][r]
这让我觉得不可思议极了[p]
#aki:normal
……是心境有什么变化吗[r]
 有过吗？[p]
#sarasa:worry
……诶……[p]
#aki:sad
不 我是说雾绘同学的事[r]
这个夏天 你经历了很多艰难的事[r]
我自认为也是充分理解的[p]
#aki:normal
如果你要改变……[l][r]
#aki:smile
不 如果有不得不改变的理由的话[r]
希望也能告诉我[p]
#
……理由什么的——[p]

;〇回想
[chara_hide_all wait="true"]
;回想スチル：頼まれた伝言
[filter grayscale="100"]
[bg storage="still/first_contact.png" cross="false" wait="true" time="100"]
[bg storage="still/kirie_bridge.jpeg" cross="false" wait="true" time="100"]
[bg storage="still/battle_riki.png" cross="false" wait="true" time="500"]
[bg storage=./school/step_m.jpg time="100" wait=true]
[free_filter]
[chara_show name="sarasa" top="-160" left="300" face="sad" wait="false"]
[chara_show name="aki" top=-100 left="-70" wait="false"]
#sarasa
…………[p]
[delay speed="60"]
……我不明白　最近　发生了太多事情……。[r]
但是……[p]
#sarasa:closeEye
……现在的、我……[l][r]
只要能让身边的人都得救，[r]
这么做会更好……我只是这么想着……[p]
#aki:normal
……[p]
#aki:hate
嗯。[p]
[resetdelay]
#aki:normal
抱歉啊纱罗纱　突然拦住你。[r]
那下次上学日再见吧[p]
#sarasa:normal
……嗯。下次再聊[p]
[chara_hide name="aki" wait="false"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
#
只有在超越我的那个瞬间　露出开心的笑容之后，[r]
阿奇安静地走下了楼梯。[p]
#
——直到完全目送他的背影消失后，我才走向玄关。[p]
[mask]
[chara_hide name="sarasa" wait="true"]
[bg storage=./school/entrance_m.jpg time="100" wait=true]
[mask_off]
;〇玄関
#
登利的鞋子已经不在鞋柜里了。[p]
#sarasa
（那只能去教学楼外面找了……）[p]
[delay speed="50"]
#
他刚才还和黒田说『在社团教室汇合』……[r]
也就是说，他应该去了足球部的活动室。[p]

运动类社团的活动楼，位于教学楼对面隔着操场的方向。[r]
只要去那里，自然能堵到他。[p]
[resetdelay]
[mask]
[bg storage=./school/kotei_m.jpeg time="100" wait=true]
[mask_off]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=50]
;〇運動場
;ＳＥ運動部
#
…………[p]
#sarasa
（……今天这么热，户外社团真辛苦啊……）[p]
#
小谷坂学园的运动类社团特别多。[l][r]
就在这样的环境中，最先从操场前方横穿而过的——[r]
是「搬运部」……[p]

各年级部员分别扛着大型家具，[r]
列队奔跑着。[p]
[chara_face name="mokke" face="longYellow" storage="chara/mokke/longYellow.png"]
[chara_face name="mokke" face="tibiYellow" storage="chara/mokke/tibiYellow.png"]
[chara_face name="mokke" face="motiWhite" storage="chara/mokke/motiWhite.png"]
[chara_face name="mokke" face="pink" storage="chara/mokke/pink.png"]

[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '二年'
[endscript]

[font size="35" bold="bold"]
[chara_show name="mokke" top="100" wait="false"]
#mokke:longYellow
[playse  volume="30" buf="0" storage="kaminari.ogg"]
一年级——！！[r]
今年一定要夺得东海大赛冠军啊——！！！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '一年'
[endscript]
#mokke:tibiYellow
是前辈！！[p]
[chara_hide name="mokke" wait="true" time="10"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wait time="200"]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[mask time="100"]
[playse  volume="100" buf="0" storage="book.ogg"]
[wse]
[mask_off]
[quake time="30"]
;ＳＥドスン
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '二年'
[endscript]
[chara_show name="mokke" top="100" wait="false"]
#mokke:longYellow
[playse  volume="30" buf="1" storage="garasu.ogg" ]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=mokke keyframe=up time=300 wait="false"]
啊啊啊啊——！！！！[r]
我的脚趾啊啊啊啊啊！！！[stop_kanim name=mokke][p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '一年'
[endscript]
#mokke:tibiYellow
前辈————！！[p]
[resetfont]
[font size="24"]
[delay speed="50"]
您没事吧？对不起，我手滑了……[r]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
不小心、把冰箱……砸到前辈身上了！！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '二年'
[endscript]
#mokke:longYellow
不……[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=mokke keyframe=up time=300 wait="false"]
咳呕、[stop_kanim name=mokke]没关系……[r]
你们一年级生还是没上过场的雏鸟、所以我[r]
这种失误就笑着原谅吧……[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '一年'
[endscript]
[resetfont]
#mokke:tibiYellow
前辈……！[r]
为什么……为什么变得这么器宇轩昂了啊……！！[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'マネージャー'
[endscript]
#mokke:motiWhite
当然是因为一直认真努力的缘故啊[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '二年'
[endscript]
#mokke:longYellow
――经理……[l]　[resetdelay]不对，是德式经理[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'ジャーマネ'
[endscript]
#mokke:motiWhite
德式经理[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '二年'
[endscript]
[font size="35" bold="bold"]
#mokke:longYellow
啊哈哈哈哈哈哈哈——！！！！！[p]
[resetfont]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '一年'
[endscript]
#mokke:tibiYellow
……切[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '顧問'
[endscript]
#mokke:pink
搬运部最棒！[p]
[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_k" wait="false"]
#sarasa
……[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '黒田'
[endscript]
[chara_move name="sarasa" top="-160" time="100" left="350" wait="false"]
[chara_show name="mokke" face="kuroda" top="100" left="100" wait="true"]
#mokke
咦？这不是志户田嘛！[r]
　你在这地方干嘛呢！？[p]
#sarasa:normal_k
啊……黑田君[p]
#sarasa:closeEye_k
……我想见登利君……[p]
#mokke
诶、登利？那家伙现在不在这儿啊[p]
#sarasa:normal_k
诶……？[p]
#mokke
嗯——他刚才去饮水处了。[p]
而且那家伙好像有什么奇怪的执念啊[r]
每次都特意不去操场那边，非要绕到教学楼后面去[l][r]
说什么那边的水更甜更冰！[p]
#sarasa:lookAway_k
（教学楼后侧……）[p]
#mokke
哈，听不懂吧。说什么萤火虫之类的……[p]
#sarasa:worry_k
（又得去追了……这么热的天）[p]
#mokke
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
啊！？对、对不起。我净说些无聊的话[p]
#sarasa:wow_k
咦？[l][r]
[chara_mod name="sarasa" face="angry_k"]
啊、不是那样的……[p]
[delay speed="20"]
#mokke
没、没事啦！不用这么拘谨！[r]
我经常被人说讲话很无聊的[p]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
啊——但是连志户田都[r]
把我当成冷场王也太惨了吧！[p]
[chara_mod name="sarasa" face="worry_k"]
#
……[p]
[delay speed="50"]
#mokke
…………………………………………[p]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
对、对了！要不要我带你过去？[r]
就带你去教学楼后面的饮水处吧！[p]
[resetdelay]
#sarasa:normal_k
诶……？[p]
#mokke
因为、你看。志户田肯定不知道吧？[r]
另一个饮水处的位置！[p]
而且那边平时也只有运动社团的家伙会去……[p]
#
——确实，黒田说得没错。[p]
虽说从教学楼后面”这个字面意思来找的话应该很快能找到，[r]
但实际上我对那个地方一无所知。[p]
#mokke
所以说啊。我带你去吧！[r]
啊、如果你不介意的话！？[p]
不愿意的话要告诉我啊！？[r]
我这人对这种事比较迟钝……[p]
#sarasa:normal_k
……。[l][r]
嗯……能麻烦你带路吗[p]
#mokke
诶！[p]
#sarasa:smile_k
刚才一直错过碰面，正发愁呢……[r]
那就拜托你了！[p]
#mokke
……嗯、嗯！[p]
[chara_hide name="sarasa" time="10" pos_mode="false"]
[chara_show name="kawa" top="-10" wait="false" face="smile" left="370"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
#kawa
喂——黒田——[r]
其他队员都在搬轮胎的时候还敢享受青春，胆子不小啊—[p]
#mokke
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
呜哇啊啊啊啊啊！！[p]
[chara_move name="kawa" anim="true" top="-10" left="350" wait="false"]
#kawa
别给少年回忆添油加醋啊—。黒田—。[r]
你小子可是足球部里过灰色夏天的人—[p]
#mokke
我、我才不要—！！[r]
我才不要回去练那种中世纪奴隶般的训练项目啊——！[p]
再说了你作为挂名顾问，[r]
请不要说足球部是灰色青春这种话！[p]
#kawa
哼—在这说什么天真话呢—[r]
从你们加入我社团的那一刻起就注定了[r]
你们必将度过一个青春早衰的十来岁啊—[p]
#mokke
太过分了！[r]
我们居然要进军这种充斥垃圾大人的社会[r]
不行吗！？[p]

;ＳＥ笛
#kawa:whistle
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
哔哔哔哔哔！哔——————！！！！！[p]
#mokke
呜哇啊啊啊啊！！！[l][r]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
志户田、快！快逃！！！[p]
#sarasa
呃、嗯……[p]
[chara_move name="mokke" left=-520 anim="true" time=700 wait="false"]
[chara_hide name="mokke" pos_mode="true" time="10" wait="true"]
#kawa:normal
哈哈哈，黒田你这家伙。给我记住啊—[p]
#
[fadeoutbgm time="3000"]
[mask]
[chara_hide name="kawa" time="10"]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0300" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0200" buf="0" storage="walk_rouka.ogg" ]
[wse]
[bg storage=./school/kosyaura.jpeg time="100" wait=true]
[chara_show name="sarasa" top="-160" time="10" left="330" time="10" face="worry_kt"]
[chara_show name="mokke" face="kuroda" top="100" left="100" time="10"]
[mask_off time="2000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=30]

;〇校舎裏
[delay speed="60"]
#mokke
[anim name="mokke" top="+=30" time="200"]
[anim name="mokke" top="-=30" time="200"]
[anim name="mokke" top="+=30" time="200"]
[anim name="mokke" top="-=30" time="500"]
哈啊哈啊……到、到这儿总该安全了吧……[p]
[resetdelay]
#mokke
啊、抱歉志户田，我身上现在臭烘烘的别靠太近！[r]
你要是能保持一定距离跟着我会很感激……的[p]
[chara_mod name="sarasa" face="normal_kt"]
[chara_move name="sarasa" anim="true" time="300" left="350" top="-160" wait="false"]
#
我点点头，稍微和黒田拉开些距离。[p]
#mokke
（啊、果然是因为我臭吗！？到底臭不臭啊！？）[p]
#sarasa:worry_kt
……咦？[p]
#mokke
啊、不是！没什么……[p]
[delay speed="70"]
#mokke
……。[p]
那个啊、志户田。[l][r]
刚才在教室被班长怼的时候，你难受吗？[p]
#sarasa:normal_kt
哎……[p]
[delay speed="50"]
#mokke
啊、就是。班长……我们班那个、饭岛。[l][r]
那家伙老是动不动就发火……[p]
#sarasa
……那个……[l][r]
[chara_mod name="sarasa" face="closeEye_kt"]
毕竟……很少被女生当面呵斥过……[r]
稍微有点惊讶吧[p]
[resetdelay]
#mokke
哈哈，没想到你还挺沉得住气嘛！志户田。[r]
被那样说了也完全不在意的样子[p]
#sarasa:lookAway_kt
（才、才没有放在心上……呢……）[p]
#mokke
哈哈……。不，那家伙啊。[r]
肯定是嫉妒志户田你吧。[p]
因为一直、好像很向往御白姬这个角色……[p]
#sarasa:normal_kt
——向往演御白姬？[p]
[fadeoutbgm time="2000"]
#mokke
对。志户田你可能不知道，[r]
我们镇上的女孩子基本都想演这个角色呢？[p]
穿着漂亮的和服在镇上到处走，[r]
作为御白姬被赞颂、被众人瞩目……[p]
[delay speed="50"]
#mokke
饭岛那种人……尤其喜欢出风头吧？[p]
幼儿园时在寺子屋教室看到展示的和服那会儿[r]
「我要穿！」这样撒泼打滚来着。[p]
[delay speed="60"]
啊哈哈……所以那家伙才把志户田你当眼中钉啊。[r]
我一提这事就立刻炸毛……[p]
毕竟同龄女生得到了她梦寐以求的角色嘛[p]
[resetdelay]
#mokke
不过最近都没正经说过话，[r]
虽然我也不清楚真实情况啦[p]
喂、我可不是在闲聊啊。[r][delay speed="60"]
这里的通称是……后院饮水处”[p]
;〇スチル；水のみ登利
[mask]
[bg storage=./still/rikimizu.png time="100" wait=true]
[chara_hide_all time="10"]
[mask_off]
;ＳＥ水道
[delay speed="50"]
#
被带到的教学楼后墙边，[r]
确实安装着一个饮水台。[p]

在那里，[r]
登利正濡湿着嘴角休息。[r]
终于找到了……！[p]
[mask]
;〇校舎裏
[bg storage=./school/kosyaura.jpeg time="200" wait=true]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=1000 volume=50]
[chara_show name="mokke" face="kuroda" top="100" left="100" time="10"]
#sarasa
[chara_show name="sarasa" top="-160" time="10" left="350" face="smile_kt"]
[mask_off]
谢谢，黒田君[p]
#mokke
没、没什么大不了的！别在意[p]
……啊！话说我[r]
一直想这样和志户田说说话呢！[p]
超开心啊——又完成了一个小目标[p]
#sarasa:normal_kt
诶……？[p]
#mokke
不是。该怎么说呢。[r]
志户田你总是和大家保持距离对吧？[l][r]
说难听点，就是有点不合群吧……[p]
#sarasa:wow_kt
呃……[p]
#mokke
啊！糟、可能说得太过分了。[p]
不过啊，我正因为志户田是这样的性格才会在意。[r]
一直在想你到底怀着怎样的心思活着[p]
但要是在教室里搭话的话[r]
立刻就会起哄对吧？[r]
『你是不是喜欢人家啊』之类的。[l][er]
只是远远看着就会被说闲话……[p]
#sarasa:normal_kt
……[l][r]
[chara_mod name="sarasa" face="smile_kt"]
呵呵，确实是这样呢[p]
[resetdelay]
#mokke
啊、你懂我！？对对就是这样的！[r]
超莫名其妙的，上了中学后男女就自动分成两派！[p]
[fadeoutbgm time="300"]
[delay speed="60"]
而且啊。我们班还不止这样，[r]
[chara_hide_all time="100"]
宗方家的信徒和非信徒之间也……[r][er]
[chara_show name="riki" top="-100" time="10" wait="false" face="wow"]
[font size="45"]
#riki
喂！阿奇！！[p]
[resetfont]
#
——？[p]
[delay speed="60"]
被这突如其来的喊声惊得回头，[r]
看见饮水处的登利正僵在原地望向这边。[p]
[chara_hide name="riki" wait="false" time="100"]
但为什么现在要喊阿奇的名字[r][er]
[chara_show name="aki" face="ghost" top="-100" time="10" wait="false"]
[quake time="40"]
[resetdelay]
[filter saturate="70"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="50"]
#aki:ghost
啊——[r]
别突然蹲下啊。[p]
[delay speed="60"]
嘴角”都要扭曲了好吗[p]
[delay speed="80"]
#
————这声音，在他身体上撕开了一个[r]
在深邃的洞穴中回荡着，轻轻摇曳。[p]
我一边听着这奇异的声音，[r]
一边拼命思索—————[p]

……突然意识到。[p]
[chara_hide name="aki" wait="false"]
[delay speed="140"]
[filter saturate="50"]
#sarasa
…………………………………………[l][r]
………………咦…………？[p]
#
……说起来，不见了。[p]
[delay speed="80"]
刚才还在聊天的，[r]
黒田的身影已无处可寻。[p]
[delay speed="60"]
#aki
他啊　早就　进来了哦[p]
[delay speed="80"]
#sarasa
…………咦？[p]
[chara_show name="aki" top="-100" time="10"]
#aki
刚才　已经　被我　吸收进来了[r]
你也　快点　进来吧。[l][p]
#sarasa
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
……！[p]
[chara_hide name="aki" wait="true" time="100"]
[bg storage="brack.png" time="100" wait="false" cross="true"]
[playse storage=wara.ogg volume="60" sprite_time="0000-0300"]
[wse]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="250"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
;ＳＥ　走る
;〇暗転
[wait time="500"]
[resetdelay]
#
——我拼命逃离了那个地方。[p]

那个、阿奇的……绝非人类应有的姿态。[r]
还有，那个称呼我为御白姬的言行。[p]
[delay speed="60"]
不会有错。[l][r]
接下来被诅咒的……似乎是器乐堂的阿奇。[p]


;【第二章】『私は不思議でたまらない』

;セーブしますか？
[mask folder="bgimage" graphic="still/part2.png" time="3000"]
[wait time="2000"]
[showsave]
@jump storage="chapter_2/day1_vol2.ks"






;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------
[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
