;第3章『彼が五齢に着替えたら』
;ニ日目前編
;-------------------------------------------------------------------------------
*part3
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '三章二日目　前編'"]
[bg storage="brack.png" time="100"]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=30]
;-------------------------------------------------------------------------------
;ituki
[chara_new name="marigan" storage="chara/marigan/normal.png" color="0xffd700" jname="紀伊 マリガン"]
[iscript]
TYRANO.kag.stat.charas['marigan'].jname = '紀伊 マリガン'
[endscript]
;表情
[chara_face name="marigan" face="normal" storage="chara/marigan/normal.png"]
[chara_face name="marigan" face="angry" storage="chara/marigan/angry.png"]
[chara_face name="marigan" face="hate" storage="chara/marigan/hate.png"]
[chara_face name="marigan" face="sad" storage="chara/marigan/sad.png"]
[chara_face name="marigan" face="hurry" storage="chara/marigan/hurry.png"]
[chara_face name="marigan" face="smile" storage="chara/marigan/smile.png"]
[chara_face name="marigan" face="smileCE" storage="chara/marigan/smileCE.png"]
[chara_face name="marigan" face="smileB" storage="chara/marigan/smileB.png"]
[chara_face name="marigan" face="tweet" storage="chara/marigan/tweet.png"]
[chara_face name="marigan" face="tweetLA" storage="chara/marigan/tweetLA.png"]
[chara_face name="marigan" face="worry" storage="chara/marigan/worry.png"]
[chara_face name="marigan" face="wow" storage="chara/marigan/wow.png"]
;-------------------------------------------------------------------------------

#
[mask_off time="2000"]
;彼が五齢に着替えたら
[delay speed="70"]
――8月20日，上午7时。[p]

沿着当年上学的路线前行，当目的地逐渐映入眼帘时……[r]
仿佛时光倒流般的错觉涌上心头。[p]

但，这不过是错觉罢了。[r]
逝去的时代，终究无法重现。[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage=./school/kotei_m.jpeg wait=true cross="false" time="5000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
(……那孩子到底在想些什么……)[p]
[font size="40"]
[resetdelay]
[stopbgm]
#？？
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[quake time="30"]
哇————！！[p][resetfont]
[quake time="30"]
#makado
呜哇！？[p]
#
猛然推了我后背一把的那个人，[r]
我转身确认。[p]

#makado
啊……你是……莫非[l][r]
纪伊玛莉甘小姐……！？[p]
[chara_show name="marigan" top="-10" face="smileB" wait="false"]
[playbgm storage=hitoriboti.ogg loop=true volume=20]
#marigan
哟～深山里的饿鬼小和尚。[r]
全名太长就叫小和尚行吧？[p]

#makado
……请不要用小和尚称呼，可以叫我的名字吗。[r]
马门或者贤治郎哪个都行[p]
[delay speed="50"]
(话说回来，为什么非要故意吓我一跳啊……？)[p]

#marigan:normal
不过话说回来你，在这种地方……小谷坂学园的[r]
在偷看哪儿啊。对JK有兴趣？还是JC？[p]
[resetdelay]
#marigan:hate
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
靠——这个国家的萝莉控难道是国民病吗！[r]
简直泛滥成灾，泛滥成灾啊！[p]
[delay speed="50"]
#makado
不是这样的…。[r]
今天也是好好联系了恩师，来查阅藏书的。[l][r]
只是对校内的状况，有些在意的事情……[p]
[resetdelay]
#marigan:tweetLA
哈、在意的事……[p]
#marigan:smileB
[playse  volume="20" buf="0" storage="sariin.ogg" ]
不过不是关于你，[r]
而是志户田纺织家的大小姐……对吧？[p]
#makado
！[p]
……是这样啊，[r]
您是知道内情才来到这里的吧[p]
#marigan:smile
因为日野发来的情书咯。[r]
说是担心单独行动的你呢[p]
#marigan:tweet
……那，你的恩师是哪位来着？[p]
[delay speed="70"]
#makado
诶……[l]是熊老师……[p]
[resetdelay]
#marigan:normal
哼。[l]
但那个女人，今天不在学校吧[p]
#makado
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
…………！[p]

#marigan
你今天啊，纱罗纱托你办什么事了？[p]
[delay speed="70"]
#makado
…………………………………………[l][r]
她让我…去和某人见个面。[p]
[resetdelay]
#marigan
那个人，是谁[p]

#makado
……那个……[l][r]
啊！来了[p]
[chara_hide name="marigan" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
;s E走ってく
#makado
不好意思！能打扰一下吗！？[p]
[chara_show name="nyudo" top="-100" wait="false" face="normal" width="+=150" zindex="2"]
#nyudo:normal
哈………？[p]

#makado:
我……是这里的毕业生。[p]
#makado:
今天本来申请了校内藏书阅览，[r]
但负责联络的老师不在……[r]
所以想请您帮忙开具临时入校许可证[p]
[delay speed="60"]
#nyudo:normal
…………从那边进去的话，[r]
有个接待处……在那里可以领取……[p]
[resetdelay]
#makado:smile_c
那个……希望能请您带我去接待处。[r]
毕业已经四年了，[r]
想着学校可能也有不少变化……[p]
#makado:smileMini_c
而且……也想向在校的老师打听下　现在的小谷坂学园[r]
是什么样氛围的地方[p]
#makado:normal_c
所以，[p]
[delay speed="25"]
#makado:tweet_c
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
[playbgm storage=fuon.ogg loop=true time=300 volume="30"]
[font color="0xf08080"]
占用您时间实在抱歉[r]
能否拨冗让我详细请教几个问题？[r]　
您无需陪同我到校外也没关系的[p][resetfont]
[delay speed="60"]
#nyudo:angryB
(诶……问话……？)[p]
[font size="20"]
#nyudo:closeEye
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
……我、我没有……！[p]
[resetfont]
#makado:worry_c
啊！？[p]
[chara_show name="marigan" top="-10" time="100" wait="true" width="-=100" left="100" face="wow" zindex="2"]
#marigan
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[anim name="marigan" top="+=30" time="150"]
[anim name="marigan" top="-=30" time="150"]
[anim name="marigan" top="+=30" time="150"]
[anim name="marigan" top="-=30" time="150"]
[font size="40"]
好厉害！[p][resetfont]
[chara_move name="nyudo" left="-160" anim="true" wait="false"]
#makado:wow_c
…！？　马利根小姐，突然怎么了？[p]
[delay speed="10"]
#marigan
太快了啦！各方面都！冲得太过了！[r]
而且语气好凶！[p]
[delay speed="60"]
#makado:worry_c
突、突然这么说……[p]
[fadeoutbgm time="2000"]
[delay speed="10"]
#marigan:hate
笨拙的辩解不需要不需要！[r]
换人！[p]
[chara_move name="marigan" left="340" anim="true" wait="true"]
[delay speed="50"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
#marigan:smileCE
不好意思～这孩子是我的助手～[l][r]
气场太强吓到了吧！[p]
[font size="20"]
#nyudo
呃……啊……那个[p]
[resetfont]
#marigan:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
我是民俗学者纪伊玛莉甘。[r]
今天承蒙熊明子女士牵线搭桥，[r]
特来拜阅图书馆内的藏书。[p]
#marigan:smileB
所以……如果方便的话，[r]
想请您带我们参观校园。[r]
啊、不过、您要是忙的话就不必麻烦了……[p]
[delay speed="60"]
#nyudo:normal
[anim name="nyudo" top="+=30" time="150"]
[anim name="nyudo" top="-=30" time="150"]
啊……原、原来是这件事啊……
请让我来为您带路……[p]
[resetdelay]
#marigan:smileCE
哇——太感谢您抽空帮忙了！[l][r]
[chara_mod name="marigan" face="smile"]
……可以请教您的名字吗？[p]
[font size="20"]
#nyudo:sad
啊、那个……我叫入道。[p]
[resetfont]
#marigan:smileB
[playse  volume="10" buf="0" storage="sariin.ogg" ]
入道先生。真是独特的姓氏呢。
听过一次就忘不掉了[p]
#nyudo:shame
诶……真、真的吗……？[p]
[delay speed="50"]

#
玛莉甘散发的气场，[r]
似乎连教师入道永海也被牵连其中……[p]
#makado
………………………………[p]
(……又借用了别人的力量啊……)[p]
[mask]
[bg storage=./school/rouka_m.jpg time="100" wait=true]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[chara_mod name="nyudo" face="normal"]
[chara_mod name="marigan" face="tweetLA"]
#nyudo
[mask_off]
[resetdelay]
啊……您和日野认识呀。[r]
那孩子交际真广呢……[p]

#marigan:normal
入道老师当过日野的班主任吗？[p]
[delay speed="60"]
#nyudo:sad
啊…那个…我是社团指导老师……地研社的……[p]
#nyudo:closeEye
那孩子挺顽皮的……我实在不敢带他那个班……[p]
[resetdelay]

#marigan:smileCE
啊～，外号叫「小谷坂的弗兰肯」对吧。[r]
这方面比起国雄还是熊楠更合适呢[p]
[delay speed="100"]
#makado
……………………………………[p]

#marigan
……………………………………[l][r]
[resetdelay]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=marigan keyframe=up time=300 wait="false"]
[chara_mod name="marigan" face="hate"]
………………喂[p][stop_kanim name=marigan]

#marigan
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="marigan" top="+=30" time="150"]
[anim name="marigan" top="-=30" time="150"]
[font size="25"]
（发什么呆啊笨蛋[r]
我们可还不知道你的目的呢[r]
接触这家伙你到底想干什么啊）[p]

#makado
（我才没在发呆啊！是在找人啦！）[p]
[delay speed="60"]

（因为还有另一个人……委托人让我务必找到对方谈话……）[p]

#marigan:worry
（哈？还有个？除了那个叫入道的家伙之外？）[p]
#nyudo
（……玛丽冈小姐真是位出色的人呢……）[p]

#makado
（虽然我也不是很清楚，但据纱罗纱说那两个人[r]
和其他老师们不同，似乎有什么[font color="0xf08080"]特别[resetfont][font size="25"]？之处……）[p]
[resetdelay]
#marigan
（特别啊……纱罗纱这家伙又语焉不详地糊弄人……）[p]
#marigan:smileB
（不过嘛，毕竟你这家伙一直把我当客人对待。[r]
（那孩子也确实从不会毫无保留地说出真心话呢）[p]

#makado
（……）[p]

#nyudo
（会不会有恋人什么的呢……）[p]
[chara_show name="kawa" zindex="3" left="130" top="-10" time="100" wait="true" width="-=130" face="whistle"]
[playse  volume="30" buf="1" storage="kaminari.ogg"]
[quake time="30"]
[font size="40"]
[stopbgm]
#kawa
哔——————！！[p]
[chara_move name="marigan" left="400" anim="true" wait="false"]
[chara_move name="nyudo" left="-210" anim="true" wait="false"]
#
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[chara_mod name="nyudo" face="angryB"]
[chara_mod name="marigan" face="wow"]
呜哇————！！[p][resetfont]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
#makado
啊……另一个人就、就是这位，就是这位！　
川铃木 仁老师！[p]

#marigan
诶！？这个超级危险的恶魔小子！？[p]

#nyudo:sad
啊……因为笛子的缘故……[p]

#kawa:smileW
才～不是什么艾洛伊姆·艾萨姆呢～[p]

#makado
诶……那是什么啊？[p]
[font size="40"]
[quake time="30"]
#三人
[playse  volume="30" buf="2" storage="garasu.ogg" ]
[chara_mod name="marigan" face="wow"]
[chara_mod name="nyudo" face="angryB"]
[chara_mod name="kawa" face="sad"]
呜哇————！！[p]
[resetfont]
#
在眼前，[r]
入道、玛莉甘和川铃木三人痛苦地扭动着身体——[p]
[delay speed="60"]
#nyudo
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
这样啊……现在的孩子不知道呢……现在的孩子不知道呢……！[p]

#kawa:think
喂……这种玩笑真的别开了行不行？[r]
怎么感觉我像个大叔一样了……[p]

#marigan:hate
现在肚子超痛的……[p]
[resetdelay]
#makado
……我、我刚才做了什么吗！？[p]
#kawa:normal
——话说，你之前不是那个和尚吗。[p]
#kawa:smileW
怎么又跑回学校来了啊。[r]
这里可不是你这种处在青春期延迟阶段的[r]
家伙该回来的地方啊[p]

#makado
呜……[l][r]
[delay speed="60"]
那个、我、有件事想问问你们……[p]

#nyudo:sad
（诶？刚才不是说毕业后[r]
时隔很久才回来的语气吗……[r]
难道是骗人的？好可怕……）[p]

#marigan:normal
……[p]
[resetdelay]
#kawa:think
总觉得你很可疑啊—[p]
#kawa:smile
要是有事的话，就老老实实说出来啊—[r]
不过听不听还得看内容就是了—[r]
十有八九会被赶出去吧—[p]

#makado
（糟了……）[p]
[delay speed="50"]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
再这样下去，什么都还没查清楚就要被赶出校舍了。[r]
得想个表面理由才行——[p]
[delay speed="100"]
#marigan:normal
[fadeoutbgm time="2000"]
……………………[p]
#marigan:tweetLA
…………………………………………[l][r]
[resetdelay]
……这孩子 听说立志当老师呢[p]

#kawa:think
诶？[p]

#marigan:smile
对吧？[wait time="800"]　贤治郎[p]

#makado
…………[p]
[delay speed="100"]

#makado
……………………………………[wait time="500"][r]
啊……那个、呃……[p]
[delay speed="60"]
#makado
………………[l][r]
……………………………………………………[r]
确实、曾经是有过这样的志向……[p]
[resetdelay]
#marigan:smileCE
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
你看。所以，[r]
其实这孩子，好像是想要观摩各位老师的工作状态呢。[p]
#marigan:smile
他 入学时选的是神道科[r]
听说只要想考的话也能拿到教师资格证[r]
说不定过段时间教育实习时就会一起共事呢……[p]
#marigan:smileB
趁现在先[r]
杂务什么的都行 能让他观摩下吗？[l]对吧！[p]

#kawa:smileW
[anim name="kawa" top="+=70" time="300"]
[anim name="kawa" top="-=70" time="300"]
嚯——！你小子想当老师啊——[p]
#
川铃木，简直就像对待挚友般[r]
将手搭在了他的肩上。[p]
[delay speed="50"]
#makado
是、是啊……[p]

#kawa:shame
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
[anim name="kawa" top="+=30" time="150"]
[anim name="kawa" top="-=30" time="150"]
当老师啊——超棒的对吧。[l][r]
能合法参与别人家孩子的人格塑造过程这事儿啊[r]
才是精髓懂不懂啊——[p]

#makado
等……别敲我头啊[p]
[delay speed="60"]
#nyudo
…………[l][r]
[chara_mod name="nyudo" face="sad"]
那个，没记错的话你的名字……是叫马门贤治郎对吧。[p]

#nyudo:normal
说到神道科的学生，马门同学……[r]
你这剃发的造型，果然……是为了白绢祭准备的吧？[p]
[resetdelay]
#makado
！　啊、是的。没错。[l][r]
我，是今年的祭主……[p]
[delay speed="60"]
#nyudo
啊……果然。[r]
这么说来，你将来是要当社会课老师吗……[p]
#nyudo:sad
虽然社会课老师准备教材好像很辛苦，[r]
但大家都工作得很开心的样子。[p]
和其他科目一样，[r]
都是为学生长大成人后非常重要的学问呢……[p]

#makado
……[l]入道老师是负责什么科目的呢？[r]
既然是地研社团的顾问，我还以为是教社会课的老师……[p]
[resetdelay]
[delay speed="60"]
#nyudo:normal
我教理科。[r]
高中范围的课程也能教哦[p]

#nyudo:sad
去年之前，[r]
确实是由社会课老师担任地研社团顾问的……[p]
#nyudo:closeEye
有次……因为发展方向上的分歧，和日野大吵了一架。[r]
所以从今年开始就由我来担任顾问……就是这么回事[p]
[resetdelay]

#kawa:normal
人类居然会因为思想差异这种小事[r]
就能变得那么凶暴啊——我这么想着[r]
我呢——[p]

#marigan:hurry
发生什么了？[p]
[delay speed="60"]
#nyudo:sad
涉及个人隐私保护……[r]
关于学生的部分就不便透露了……[p]
#nyudo:normal
如果是其他方面的话，倒是可以稍微透露一点……[r]
要介绍一下教职工的暑假安排吗？[p]

#makado
诶……啊，非常感谢！[p]

#nyudo:smile
哪里哪里……虽然我也帮不上什么大忙……[p]
#nyudo:normal
那么，[r]
等入校许可证准备好后，请来二楼的理科教室……[p]
[resetdelay]
#kawa:smile
我这边也正好有需要人手的活儿呢。[r]
等会来运动部的社团大楼找我一趟[p]

#makado
好……好的[p]

;ＳＥ去る
[chara_hide name="kawa" wait="false" pos_mode="false"]
[chara_hide name="nyudo" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]

#makado
…………………………[l][r]
（总算暂时摆脱困境了……）[p]

#
看来能顺利获得直接询问他们两人的机会了。[p]

#marigan:tweet
哈～总会有办法的吧—[p]
#marigan:normal
那我去图书馆打发时间，[r]
等事情都搞定了记得告诉我呀—[p]

#makado
请等一下[p]
[delay speed="50"]
	——我想当老师这件事，你是从哪里听说的？[p]

这件事……[l][r]
[fadeoutbgm time="5000"]
除了雾绘以外，我从没告诉过别人[p]
可你为什么会……[l][r]
你到底知道多少？[p]

#marigan
………………[p]

#marigan:tweet
述而不作　信而好古[p]
#marigan:tweet
知道吗？孔子说的[p]

#marigan:tweetLA
……都很可怕啊。[r]
通过抛弃过去 连现状也会改变[p]
;ＳＥ去っていく
[chara_hide name="marigan" wait="false"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="1000"]
[delay speed="70"]
#kirie
人的心情怎么可能懂嘛[p]
#kirie
所以无所谓啦 就算不明白什么意思也没关系[p]

[mask time="3000"]
[bg storage="brack.png" time="10"]
[wait time="1000"]
;○分かれ道
#
[mask_off]
――学校里……[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
只有三位，特别的老师。[p]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=50]
[bg storage="ton_m.jpeg" wait="false" cross="false"]

#
这三位分别是，熊明子老师、
川铃木仁老师、入道永海老师……[p]
[chara_show name="sarasa" face="normal_c" wait="false" top="-160"]
#sarasa
在这几位当中，贤治郎先生除了入道老师以外[r]
应该都见过面的[p]
[resetdelay]
#makado
啊，熊老师的话，我初中时也当过我的班主任……[r]
川铃木老师是？[p]
#sarasa
大家都管他叫川神……[l][r]
#sarasa:worryLA_c
[delay speed="60"]
那个……就是……特别喜欢吹笛子的那位老师……[p]
#makado
啊……那个……[p]
[resetdelay]
#makado
然后，我去见了这几位老师，[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]我只要去打听他们各自的信仰就行了吧？[p][resetfont]

#sarasa:normal_c
嗯[p]
[delay speed="50"]

#sarasa
不过……[l]
[chara_mod name="sarasa" face="closeEye_c"]
恐怕当天，[r]
熊老师应该不会在学校里[p]

#makado
诶？为什么？[p]

#sarasa
因为熊老师据说是狮心教的眷属[p]
[font size="40"]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
居…居然是这样！？[p]
[resetfont]
#sarasa
是的……刚才从优那里听说……他告诉我的。[r]
据说魔伏日的集会，他从未缺席过[p]

#makado
居…居然不知道。[r]
原来如此，所以才会担任你们班级的班主任吧……[p]

#sarasa
…………[p]

#sarasa:normal_c
[fadeoutbgm time="3000"]
贤治郎先生。[p]
[delay speed="60"]
#
少女停下脚步时过于安静，[r]
以至于自己毫无察觉地多走了几步。[p]

转身看向发出呼唤的来处。[p]

#sarasa
我……很不甘心。[r]
当知道贤治郎先生有事瞒着不告诉我时……[r]
[p]
#sarasa:closeEye_c
最近净是些让人不甘心的事。[r]
无论是雾绘的事，狮心教的事，[r]
白绢祭的事，还是我的事，[p]
[delay speed="70"]
#sarasa:worryLA_c
——连一树的事也总是让我耿耿于怀……[p]
#sarasa:closeEye_c
…………[p]
……大概，就算最初看到那篇新闻的时候，[r]
我对贤治郎先生是个怪人的看法[r]
应该也不会改变吧……[p]
[delay speed="50"]
#sarasa:normal_c
[fadeinbgm storage=gymnopedies2.ogg loop=true time=3000 volume=50]
	……但正因如此[r]
我不希望再让你感到不甘心了[p]
#sarasa
我作为御白姬有义务让白绢祭顺利落幕[r]
为此就算你抗拒 我也要问个明白[r]
为了把你从祭主之位拉下来[p]
#
………………[p]

#makado
啊哈哈……果然那时候你觉得我是个怪人啊[p]

#sarasa:normal_c
……现在也、稍微有一点[p]

#makado
啊、现在也……[p]

#makado
……[p]
[delay speed="100"]
#makado
父亲他……[l]倒下的那年冬天，我正读高二。[l][r]

就在我像平常一样放学回家的时间点――[p]
[bg storage="brack.png" wait="false" cross="false" time="3000"]
[chara_hide name="sarasa" wait="false" time="3000"]
[delay speed="50"]
神社里反常地聚集了很多人，我正想着发生了什么，[r]
人群中央是脸朝下趴着的父亲[p]

之前也说过了吧……[wait time="800"]病因是脑中风。[r]
毕竟他也上了年纪，这也是没办法的事[p]
[bg storage="still/makado_me.png" wait="false" cross="false"]
之后的两年间 我一边继续看护[r]
为了继承神社[r]
在翻阅父亲留下的资料时 我突然意识到[p]

我们神社代代相传着……[p]
然而至今没有传承给我的[r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]这表明曾存在过某种仪式[resetfont][p]

#sarasa
那是……作为祭主的仪式吗？[r]
还是说，作为马门神社的神主大人，要进行的仪式……吗？[p]

#makado
甚至连这点如今也无从知晓[l][r]
莫说是文献　就连口述传承　亲属中也无人知晓……[p]

不过，父亲在从祖父那里继承了[r]
某种仪式之后[font color="0xf08080"]每日清晨从不间断[resetfont][r]
只知道他一直在供奉着那块绢布的小祠堂里进行着仪式[p]

关于御黑御荫的存在以及……[r]
关于神厩舍注连绳的事，父亲在身体还硬朗时就告诉过我了[r]
我想他本打算在适当时候把【仪式】也传授给我的[p]
[delay speed="70"]
但没等到那天　父亲就再也没能恢复意识[p]

就在我为此辗转反侧的时候……[r]
我也刚好发现了那则报纸新闻[p]

读到它时……不知为何产生了某种预感[p]

『啊、[wait time="500"]或许这次在我和父亲之间失传的仪式，[r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font color="0xf08080"]大概是和御黑祟的封印有关的东西吧。[resetfont]
就是……[p]




;○トンネル前
[bg storage="ton_m.jpeg" wait="false" cross="false" time="3000"]
[chara_show name="sarasa" face="normal_c" wait="false" top="-160" time="3000"]


#sarasa
……[p]

#makado
正因如此　我才祈祷这次白绢祭能平安无事……[l][r]
祈祷不要发生与御黑目封印相关的灾祸[r]
可是……[p]

封印被解开　造成了实际伤害[r]
而自己却因为能力不足　什么都做不到[r]　
这个事实暴露在光天化日之下……[p]
[fadeoutbgm time="2000"]

…………[p]
[delay speed="100"]
………………………………………………[p]
#sarasa
[delay speed="50"]
……您怎么了？贤治郎先生[p]
[delay speed="60"]
#makado
……………………………………………………[l][r]
父亲他……要是治疗再晚一点可能真的就去世了[r]
也说不定、[p]
但、他确实是位认真尽责的、优秀的神官。[r]
四十年来一直都是[p]
所以我觉得绝对是我的错、[r]
一定是我这边有问题[p]
[delay speed="50"]
#sarasa
我并没有觉得您父亲有什么不好。[r]
当然，对贤治郎先生也是。[p]
#sarasa:closeEye_c
想要把自己现在的处境怪罪到别人头上什么的，[r]
我连想都没想过[p]
[fadeinbgm storage=higurasi2.ogg loop=true time=10000 volume=50]

#makado
…………[l][r]
不　……………………抱歉[p]

#sarasa
不是道歉就能解决的……[p]
[delay speed="70"]
#makado
说、说的也是啊。[r]
现在道歉也于事无补了……[p]

#sarasa
不是道歉就能解决的……[p]

#makado
……？[l]　[resetdelay]纱罗纱？[p]

#sarasa
…………[p]
[delay speed="70"]
#sarasa:normal_c
贤治郎先生之前对我……[l][r]
[delay speed="50"]
说过雾绘的事不是我的错对吧。[p]
#sarasa
我当时……[l][r]
原来我一直在等着……[r]从别人那里听到这句话……[p]
直到贤治郎先生对我说了才意识到[p]

#sarasa:closeEye_c
所以现在我也要这样告诉你[p]
#sarasa:normal_c
无论是没能从父亲那里继承的封印[r]还是雾绘小姐的事[p]
这些全都不是贤治郎先生的错[p]

而且……[p]
[chara_mod name="sarasa" face="smile_c"]
[chara_hide name="sarasa" wait="false"]
[bg storage="brack.png" wait="false" cross="false"]
[wait time="1000"]
如果非要说是谁的错的话[p]也可以算在我头上[p]
[mask]
#
[bg storage=./school/rouka_m.jpg time="10"]
[fadeoutbgm time="3000"]
[wait time="3000"]
;○学校　階段
[mask_off]
[delay speed="100"]
——我们决定前往入道等候着的二楼实验室。[p]
;セーブしますか？
[mask folder="bgimage" graphic="still/part3.png" time="3000"]
[bg storage="still\den_29.png" time="10"]
@layopt layer=message0 visible=false
[clearfix]
[showsave]
@jump storage="chapter_4/day1_vol1.ks"






;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
