;第1章『可、孵化』
;一日目
[eval exp="f.save_title = '三章一日目　前編'"]
[bg storage="brack.png" time="100"]
[playbgm storage="faure-op84-5.ogg" loop=true volume="30"]

[mask_off time="1000"]
[delay speed="50"]
#
纱罗纱[l][r]
我说啊——要不要定个秘密暗号？[p]

我看加贺丸那家伙总这么玩 所以我也想着[r]
和朋友一起编暗号玩游戏应该很有趣吧——[p]

啊 加贺丸？[p]
[delay speed="60"]
加贺丸是……朋友。不是纱罗纱你的那种……[p]

嗯……其实是个大叔啦[r][wait time="1000"]
不过人很好哦。还是个忍者呢[p]
[delay speed="20"]
别别 都说没事了 住手 别把防狼警报按我脸上啊[p]
[delay speed="50"]
……不过就算编了暗号 也没机会用吧[p]

那不如 来编个只有我们懂的手势暗号？[p]

我想想啊……[wait time="1000"]要可爱点的比较好[r]　
就像占卜书里写的那种 让人心跳加速的手势[p]
[fadeoutbgm time="3000"]
[delay speed="80"]
把右手小指和左手小指 像这样伸到你面前[p]

然后你从中选一边[r]
我心里总是希望你能选右边[p]
[delay speed="50"]
但纱罗纱肯定……偶尔也会选左边吧[p]
朋友之间不就是这样的吗？[p]
[mask]
[wait time="1500"]
[bg storage="hataneA.jpg" cross="false" wait="false"]
[fadeinbgm storage=bigriver.ogg loop=true time=300 volume="8"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'アキラさん'
[endscript]
[resetdelay]
@layopt layer=message0 visible=false
[clearfix]
[mask_off time="3000"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#mokke
……还是老样子身体不适吗？纱罗纱[p]
[delay speed="60"]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
最近回程的车厢为何如此令人窒息。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetdelay]
#mokke
确实亲眼目睹陌生人跳轨这种事[r]
可能冲击性还是有点大啊……[p]
人终有一死嘛！[r]
在意的话就没完没了啦没完！[p]
[delay speed="60"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
最近，我体内似乎有什么活物般的存在[l][r]
[r]
总是翻涌到咽喉处，[r]
又悄然退去究竟为何。[p]
[resetdelay]
#mokke
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
真是给人添麻烦啊，宗方先生家那位也是[p]
居然对前途无量的志户田家大小姐做出临别放屁般的举动[r]
简直让人无语呢[p]
[delay speed="60"]
#sarasa
……唔[p]
#mokke
？ 咦，怎么了，出什么事了纱罗纱小姐[p]
#sarasa
……好难受……[p]
[resetdelay]
#mokke
哎呀糟糕！先暂停一下！[p]
[mask]
#
[stopbgm]
[bg storage="fork_a.jpg" time="10"]
[wait time="1500"]
[mask_off]
;ＳＥ車のドア
;〇分かれ道（夕）
[delay speed="100"]
…………[p]

#sarasa
（……对了，就是这里……）[p]
;回想スチル：いつき
[mask]
[filter grayscale="100"]
[bg storage="still/ituki_smile.png" time="100"]
[resetdelay]
[mask_off]
#sarasa
（……从那天和一树一起放学走到这里开始……[r]
	我的暑假就开始变得不一样了……）[p]
[delay speed="70"]
#
……不对[l][r]
这个暑假，打从一开始就应该是特别的才对。[p]
[delay speed="60"]
[mask]
[bg storage="hataneA.jpg" time="100"]
[free_filter]
@layopt layer=message0 visible=false
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[clearfix]
[mask_off]
[wait time="1000"]
[clearfix]
@layopt layer=message0 visible=true
我，作为志户田家的女儿。[l][r]
二十年一度的白绢祭典中，御白姬的职责……[r]
毫无特别意识地理所当然地接受了。[l][r]
[r]
[fadeinbgm storage=higurasi2.ogg loop=true time=5000 volume=30]
[bg storage="fork_a.jpg" time="2000" wait="true" cross="false"]
从未想象过会有人渴望承担这个职责。[l][r]
这个职责背后，经历过怎样的历史――[r]
我也从未试图去了解。[l][r]
[r]
正如周围人所评价的那样……[l][r]
我从未努力正视过自己所生存的世界。[p]
@layopt layer=message0 visible=false
[clearfix]
[delay speed="50"]
[chara_show name="kirie" top="-100" wait="true" time="1000" face="normal"]
[wait time="1000"]
@layopt layer=message0 visible="true"
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#kirie:smile
所以，就连树月生活的世界是何种模样[r]
你也根本一无所知吧。[p]
#sarasa
……[p]
[chara_hide name="kirie" time="100" wait="false"]
[font size="25"]
[resetdelay]
#mokke
纱罗纱——！没事了就快点上车啦——[p]
[resetfont]
[delay speed="60"]
[bg storage="brack.png" time="2000" wait="false"]
#
…………[l][r]
回到车内后　果然还是让我觉得窒息。[p]
[resetdelay]
[mask folder="bgimage" graphic="still/part3.png" time="3000"]
;第三章『彼が五齢に着替えたら』
[fadeoutbgm time="3000"]
[wait time="2000"]
[bg storage="indoor/kinuyoRoom_n.jpeg" time="2000" wait="true"]
[chara_show name="kinuyo" top="-160" time="10" face="back"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[mask_off time="1000" wait="false"]
[wse]
[playse storage="nail.ogg" loop="true" volume="70"]
;〇絹世部屋（夜）
;ＳＥ障子空く
;ＢＧＭパチパチ
#kinuyo
……真讨厌。居然醒着熬到这种时辰[p]
#sarasa
……妈妈[p]
[delay speed="50"]
#kinuyo
已经晚上8点了哦？　[r]
你该不会忘记明天的课程了吧。[r]
别因为假期就得意忘形。快去睡觉[p]
#sarasa
唔……才没有、忘记。[r]
只是，[p]
[stopse]
#kinuyo:normal
怎么？[p]
#sarasa
明天……课程结束后的、15点开始。[l][r]
[delay speed="70"]
为了暑假作业……有个想去的地方[p]
#kinuyo
……[p]
[delay speed="50"]
[chara_mod name="kinuyo" face="angry"]
哈啊……真是麻烦呢，居然布置必须参加课外活动的作业。[r]
校方到底在想什么才会安排这种事情啊[p]
[delay speed="60"]
#kinuyo:back
——不过可以哦。阿基拉明天有空的时间段，[r]
应该是到16点为止……[p]
[resetdelay]
#sarasa
不用了，不需要麻烦阿基拉过来啦[p]
[delay speed="100"]
#kinuyo
…………………………………………[l][r]
[fadeinbgm storage=fuon.ogg loop=true time=5000 volume="50"]
你这是什么意思呢[p]
[resetdelay]
#sarasa
……明天……[l][r]
贤治郎先生会陪我去的[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="2000"]
#kinuyo
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[chara_mod name="kinuyo" face="smileSP" time="100" cross="false"]
——呵呵呵　可不是！[r]
最近你们好像相处得特别亲密呢？[p]
#sarasa
……[p]
[delay speed="50"]
#kinuyo
他明明也是即将参加白绢祭的人。[r]
居然还有闲情陪你们玩耍[r]
真是让人想不通呢……不过算了。[p]
#kinuyo:normal
可别忘了你作为御白姬的职责呀。[r]
好了、今天就睡吧[p]
#sarasa
……嗯。[l][r]
晚安、妈妈[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="sarasa" time="1000" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
[chara_mod name="kinuyo" face="back"]
[fadeoutbgm time="2000"]
[playse  volume="30" buf="0" storage="hikidopen2.ogg"]
[wse]
[mask time="1000"]
[chara_hide name="kinuyo"]
[bg storage="indoor/sitodrouka.jpg" time="10"]
[chara_face name="mokke" face="nitibu" storage="chara/mokke/sankakuBlue.png"]
[chara_show name="mokke" top="100" time="10" face="nitibu"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '日本舞踊の先生'
[endscript]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=10]
[mask_off]
;〇志戸田家
#
――8月19日、下午3点。[p]

;ＳＥつづみポポン
[delay speed="50"]
#sarasa
今天也多谢关照了[p]
[resetdelay]
#mokke
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="mokke" top="-=80" time="200"]
[anim name="mokke" top="+=80" time="200"]
我说啊。八种町的白绢祭总觉得有点浪费呢[p]
[chara_move name="mokke" left="100" anim="true" wait="false"]
[chara_show name="sarasa" left="360" face="normal" top="-160" wait="false"]
#sarasa
……？[p]
#mokke
难得纱罗纱要担当大任，[r]
这个祭典居然没有神乐舞和盂兰盆舞之类的活动对吧？[p]
明明准备了那么华丽的服装……[r]
却只是像新娘游行一样走个过场。[r]
太敷衍了有点扫兴呢[p]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
需要跳舞的话就叫我！我来帮你编舞！[p]

#sarasa:smile
……务必……[p]
[delay speed="60"]
#mokke
……不过话说回来，你今天怎么了？[p]
#sarasa:normal
诶？[p]
[delay speed="50"]
#mokke
居然穿着校服就来上舞蹈课。[r]
虽然没细问……[p]
该不会等下马上要去暑期补习班之类的？[p]
#sarasa
啊……是的。今天……[p]
#sarasa:closeEye
因为课后马上有熟人会来接我，[r]
觉得不能让人家久等……[p]
#mokke
哎呀？是大学生年纪的男孩子吗？[r]
要真是那样的话，他十分钟前就该到了呀[p]
#sarasa:wow
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
咦？[p]
#mokke
正和绢世小姐聊着天，[r]
是个腰杆笔挺的帅气青年呢！[p]
[resetdelay]
#sarasa:worry
……请、请问他被带到哪个房间了？[p]

#mokke
嗯——最里头那间阳光房吧？[p]
#sarasa:closeEye
……失、失礼了！[p]
#
[chara_move name="sarasa" left=-520 anim="true" time=700 wait="false"]
;ＳＥ引き戸
[chara_hide name="sarasa" pos_mode="true" time="10" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]
[delay speed="100"]
#mokke
…………[p]
[delay speed="60"]
#mokke
……总觉得今天的纱罗纱，特别好说话呢[p]
[mask]
[stopbgm]
[chara_hide name="mokke"]
[bg storage="indoor/shitoda_shoji.jpg" time="10"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=10]
#
[mask_off]
;〇障子
……[l][r]
正如老师所说，[r]
阳光房的纸门另一侧能看到两个人影。[p]
[delay speed="80"]
[chara_show name="sarasa" top="-160" face="worry" wait="false"]
#sarasa
（果然两个人都在这儿——）[p]
[resetdelay]
#kinuyo
……这么说来果然，[r]
你今年夏天就要从大学退学了对吧[p]

#makado
是的[p]
#sarasa:wow
…………[p]
[delay speed="50"]
#kinuyo
是啊。贤治郎先生，真是个顾家的孩子呢……。[r]
从东京回来的事，[r]
令堂一定也很高兴吧[p]
[chara_mod name="sarasa" face="worryLA"]
[chara_move name="sarasa" left="300" time="1500" wait="false" anim="true"]
#makado
虽然被说过「好不容易考进去太可惜了」……[l][r]
我想现在应该能让他过得轻松些了[p]
[chara_hide name="sarasa" wait="false" time="2000"]
[bg storage="brack.png" time="2000" wait="false"]
#kinuyo
是呀。[wait time="1000"]而且，你还能继承家业。[l][r]
既然生来就有这般福分，可得好好报答享四郎先生呢[p]

#makado
——确实如此[p]
[cancelskip]
#kinuyo
……好了[p]
[mask time="10"]
[stopbgm]
[bg storage="indoor/sunroom_m.jpg" time="10"]
[chara_hide name="sarasa" time="10"]
[chara_show name="kinuyo" top="-10" time="10" face="normal" left="370"]
[chara_show name="makado" top="-10" time="10" face="tweet" left="-90"]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
#
[playbgm storage=tukutukulong.ogg loop=true  volume=40]
@layopt layer=message0 visible=false
[clearfix]
[mask_off time="10" effect="flipInX"]
;ＳＥスパーンと障子
[wait time="1500"]
;〇サンルーム（夕）
[chara_hide_all time="10"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

[chara_show name="sarasa" top="-160" time="100" wait="true" face="wow"]
#sarasa
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
……！[p]
[delay speed="60"]
[chara_hide name="sarasa" time="10"]
[chara_show name="kinuyo" top="-100" time="100" wait="false"]
#kinuyo
——真是的，这孩子……[r]
偷听可不是什么好习惯……[p]
[chara_hide name="kinuyo" time="10"]
[chara_show name="makado" top="-10" face="tweet" wait="false" time="100"]
[resetdelay]
#makado
纱罗纱。[r]
已经练习完了吗？[p]
[chara_move name="makado" left="-200" top="-60" anim="false" wait="false" time="200"]
[chara_show name="kinuyo" left="-20" top="-100" wait="false" face="normal"]
[chara_show name="sarasa" top="-100" face="sadB" left="360" wait="false"]
[delay speed="100"]
#sarasa
啊……那、那个，我……[p]
#kinuyo:normal
纱罗纱 你最近到底想干什么？[p]
[fadeoutbgm time="2000"]
[resetdelay]
#makado:normal
……………？　[wait time="600"]绢世姐？[p]
[chara_move name="kinuyo" left="10" anim="true" wait="false"]
[fadeinbgm storage=fuon.ogg loop=true time="2000" volume="50"]
#kinuyo
[delay speed="50"]
自从这个暑假开始 你就变得有些不堪了[r]
尤其让我不快的是[r]
你开始热衷于干涉他人的人生这一点[p]
[chara_mod name="makado" face="worry"]
这个世界上有些人[r]
注定要以[font color="0xf08080"]维持现状[resetfont]的方式[r]
走完自己的人生[p]
你也是其中之一啊，纱罗纱[p]
[chara_move name="kinuyo" left="20" anim="true" wait="false"]
[delay speed="100"]
[chara_mod name="kinuyo" face="closeEye"]
你只需要作为[font color="0xf08080"]志户田纱罗纱[resetfont]而存在[r]
[font color="0xf08080"]在作为继承御白姬血脉的女儿茁壮成长之后[resetfont][r]
[font color="0xf08080"]只会在这片土地上渐渐老去罢了[resetfont][p]
[chara_mod name="kinuyo" face="normal"]
别忘了。[r]
世人期待的从不是你去接触世界――[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
而是作为『志户田纱罗纱』这个符号活着[r]
直到死去的人生 仅此而已[p][resetfont]
#
…………[p]
[delay speed="60"]
#makado:bike
…………[p]
#makado:worryB
啊、绢、绢世小姐。[r]
那我和纱罗纱就先告辞了……[p]
#kinuyo
……[p]
#kinuyo:smileSP
呵呵[r]
给您添麻烦了 贤治郎先生[p]
[resetdelay]
#makado:wow
啊、好的……我们才是打扰了。[r]
18点前会送她回来的……[l][r]
[chara_mod name="makado" face="tweetLA"]
……走吧，纱罗纱[p]
[mask]
[chara_hide_all time="10"]
[stopbgm]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
#
[bg storage="shitodaEnt_m.jpeg" time="10"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_show name="sarasa" top="-100" left="360" time="10" face="closeEye"]
[chara_show name="makado" top="-60" left="-70" time="10" face="lookAway_c"]
[mask_off]
;〇玄関
;ＳＥガラガラ
[delay speed="100"]
#sarasa
………………[p]
#makado
………………[p]
[delay speed="50"]
#makado:closeEye_c
……那个……[r]
绢世小姐生起气来 还挺有威慑力的啊[p]
#sarasa
……是啊。[r]
我也尽量不想给大家添太多麻烦的[p]
#
;-------------------------------------------------------------------------------
;アキ私服
[chara_face name="aki" face="normal_s" storage="chara/aki/normal_s.png"]
[chara_face name="aki" face="hate_s" storage="chara/aki/hate_s.png"]
[chara_face name="aki" face="hurry_s" storage="chara/aki/hurry_s.png"]
[chara_face name="aki" face="sad_s" storage="chara/aki/sad_s.png"]
[chara_face name="aki" face="smile_s" storage="chara/aki/smile_s.png"]
[chara_face name="aki" face="smileB_s" storage="chara/aki/smileB_s.png"]
[chara_face name="aki" face="tweet_s" storage="chara/aki/tweet_s.png"]
[chara_face name="aki" face="tweetLA_s" storage="chara/aki/tweetLA_s.png"]
[chara_face name="aki" face="worry_s" storage="chara/aki/worry_s.png"]
[chara_face name="aki" face="wow_s" storage="chara/aki/wow_s.png"]
[chara_face name="aki" face="ghost_s" storage="chara/aki/ghost_s.png"]
;-------------------------------------------------------------------------------
[chara_hide_all time="500" wait="false"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[chara_show name="aki" top="-100" face="normal_s" wait="false"]
#aki
你好呀 纱罗纱。来得可真够晚呢[p]
[resetdelay]
[chara_hide name="aki" time="10"]
[chara_show name="sarasa" face="wow" top="-160" wait="false"]
#sarasa
……！啊、阿基[p]
[chara_move name="sarasa" top="-100" left="360" wait="false" anim="false"]
[chara_show name="makado" top="-80" left="-200" wait="false" face="normal_c"]
[chara_show name="aki" top="-100" wait="false" face="normal_s" left="-10"]
#aki
等太久我就直接过来了。[r]
大家已经在神社等着了哦[p]

#sarasa:closeEye
说得对呢……对不起[p]

#aki:normal_s
就是啊。[r]
光道个歉可不够补偿呢[p]
#aki:tweet_s
应该说[l][r]
[chara_mod name="aki" face="hate_s"]
…………。[p]
[delay speed="60"]
#sarasa:worry
……？怎、怎么了……？[p]
#aki
我说 你现在去换衣服怎么样？[p]
[delay speed="50"]
#aki:tweet_s
大家都是穿便服来的 今天。[r]
就是啊 贤治郎先生[p]
[resetdelay]
#makado:worry_c
诶？啊、啊啊。是这么回事啊[p]
#aki:tweetLA_s
就你一个人穿校服站在那里。[r]
搞得我们都有些不自在了[r]
说是不认真也好 说是排挤也好[p]
#aki:smile_s
所以呢 再等你几分钟好了。[r]
现在立刻去换衣服吧[p]
#sarasa:worry
……[l][r]
[chara_mod name="sarasa" face="worryLA"]
……啊、阿基[p]
#aki:normal_s
干嘛？[p]
[delay speed="80"]
#sarasa
没、没什么……[l][r]
[chara_mod name="sarasa" face="closeEye"]
那个、你性格是不是……变差了……？[p]
#aki
……[l][r]
[chara_mod name="aki" face="sad_s"]
[fadeoutbgm time="2000"]
果然还是算了吧[p]
#sarasa:worry
诶……[p]
[fadeinbgm storage="faure-op84-5.ogg" loop=true time=3000 volume="50"]
[delay speed="50"]
[chara_mod name="makado" face="normal_c"]
#aki
昨天 那之后 我想过了 关于让我不再空虚的方法[p]
#aki:tweetLA_s
所以 更多地把所思所感[r]
试着表现出来[r]
虽然只是我个人的想法——[p]
[chara_mod name="aki" face="smile_s"]
[resetdelay]
……啊哈哈。如果纱罗纱觉得讨厌的话 那就算了吧[r]
毕竟也给你添了麻烦 我心里过意不去——[p]
[font size="45"]
#sarasa:angry
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
啊、……等、等等！[p][resetfont]
#aki:wow_s
……[p]
[delay speed="60"]
#sarasa
不、不讨厌！我觉得…这样很棒。[p]
#sarasa:smile
因为……这才是阿基真正的样子……对吧？[r]
如果是这样的话……我一点都不讨厌哦[p]
[delay speed="100"]
[chara_mod name="makado" face="smileMini_c"]
#aki:smile_s
纱罗纱……[p]
[resetdelay]
[stopbgm]
#aki:normal_s
那还等什么 快去换衣服啦[r]
还是说 你还想继续浪费我们的时间？[p]
[chara_mod name="sarasa" face="worry"]
[chara_mod name="makado" face="closeEye_c"]
[mask time="2000"]
[wait time="2000"]
[chara_hide_all time="10"]
[bg storage="porch_m.jpeg" time="10"]
#
;-------------------------------------------------------------------------------
;登利
[chara_face name="riki" face="normal_s" storage="chara/riki/normal_s.png"]
[chara_face name="riki" face="angry_s" storage="chara/riki/angry_s.png"]
[chara_face name="riki" face="wow_s" storage="chara/riki/wow_s.png"]
[chara_face name="riki" face="smile_s" storage="chara/riki/smile_s.png"]
[chara_face name="riki" face="smileCE_s" storage="chara/riki/smileCE_s.png"]
[chara_face name="riki" face="smileH_s" storage="chara/riki/smileH_s.png"]
[chara_face name="riki" face="sad_s" storage="chara/riki/sad_s.png"]
[chara_face name="riki" face="hate_s" storage="chara/riki/hate_s.png"]
[chara_face name="riki" face="lookAway_s" storage="chara/riki/lookAway_s.png"]
[chara_face name="riki" face="think_s" storage="chara/riki/think_s.png"]
[chara_face name="riki" face="worry_s" storage="chara/riki/worry_s.png"]
[chara_face name="riki" face="shame_s" storage="chara/riki/shame_s.png"]
[chara_face name="riki" face="tweetLA_s" storage="chara/riki/tweetLA_s.png"]
[chara_face name="riki" face="smileB_s" storage="chara/riki/smileB_s.png"]
[chara_face name="riki" face="shoutG_s" storage="chara/riki/shoutG_s.png"]
;紗羅紗
[chara_face name="sarasa" face="normal_s" storage="chara/sarasa/sihuku/normal_s.png"]
[chara_face name="sarasa" face="normal_c" storage="chara/sarasa/sihuku/normal_c.png"]
[chara_face name="sarasa" face="angry_s" storage="chara/sarasa/sihuku/angry_s.png"]
[chara_face name="sarasa" face="wow_s" storage="chara/sarasa/sihuku/wow_s.png"]
[chara_face name="sarasa" face="smile_s" storage="chara/sarasa/sihuku/smile_s.png"]
[chara_face name="sarasa" face="smile_c" storage="chara/sarasa/sihuku/smile_c.png"]
[chara_face name="sarasa" face="sad_s" storage="chara/sarasa/sihuku/sad_s.png"]
[chara_face name="sarasa" face="sadB_s" storage="chara/sarasa/sihuku/sadB_s.png"]
[chara_face name="sarasa" face="closeEye_s" storage="chara/sarasa/sihuku/closeEye_s.png"]
[chara_face name="sarasa" face="closeEye_c" storage="chara/sarasa/sihuku/closeEye_c.png"]
[chara_face name="sarasa" face="worry_s" storage="chara/sarasa/sihuku/worry_s.png"]
[chara_face name="sarasa" face="worry_c" storage="chara/sarasa/sihuku/worry_c.png"]
[chara_face name="sarasa" face="worryLA_s" storage="chara/sarasa/sihuku/worryLA_s.png"]
[chara_face name="sarasa" face="worryLA_c" storage="chara/sarasa/sihuku/worryLA_c.png"]
[chara_face name="sarasa" face="lookAway_s" storage="chara/sarasa/sihuku/lookAway_s.png"]
;日野
[chara_face name="hino" face="normal_s" storage="chara/hino/normal_s.png"]
[chara_face name="hino" face="angry_s" storage="chara/hino/angry_s.png"]
[chara_face name="hino" face="happy_s" storage="chara/hino/happy_s.png"]
[chara_face name="hino" face="sad_s" storage="chara/hino/sad_s.png"]
[chara_face name="hino" face="shame_s" storage="chara/hino/shame_s.png"]
[chara_face name="hino" face="smile_s" storage="chara/hino/smile_s.png"]
[chara_face name="hino" face="lookAway_s" storage="chara/hino/lookAway_s.png"]
[chara_face name="hino" face="tweet_s" storage="chara/hino/tweet_s.png"]
[chara_face name="hino" face="ghost_s" storage="chara/hino/ghost_s.png"]
;-------------------------------------------------------------------------------
[mask_off]

;〇縁側
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_show name="sarasa" top="-160" face="closeEye_c" wait="false"]
[delay speed="70"]
#sarasa
……让你久等，真的很抱歉……[p]
[resetdelay]
[chara_hide name="sarasa" time="10"]
[chara_show name="riki" top="-100" face="angry_s" time="100" wait="false"]
#riki
太慢啦——！！[r]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
差点就要把贤治郎家的麦茶全喝光了啊！[p]
[chara_hide name="riki" time="10"]
[chara_show name="hino" top="-100" face="shame_s" time="100" wait="false"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[font size="40"]
#hino
你这家伙懂不懂什么叫客气！？[r][font size="23"]
擅自开别人家冰箱的时候我差点想和你绝交啊！！[p][resetfont]
[chara_hide name="hino" time="10"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '叔父'
[endscript]
[chara_show name="mokke" face="oji" left="600" top="100" wait="false"]
[chara_show name="makado" top="-10" left="-70" wait="false" face="worry_c"]
#mokke
哈哈哈。大家还挺精神嘛。[p]
#makado:closeEye_c
叔叔，真是不好意思。还让您陪孩子们闹……[p]
#mokke
没啥。在我看来贤治郎君也还是个孩子呀？[r]
遇到困难时要记得依靠大人啊[p]
[delay speed="60"]
#makado:tweetLA_c
好的……实在不好意思[p]
[resetdelay]
[chara_hide_all time="10"]
[chara_show name="riki" top="-100" face="smileCE_s" time="100" wait="false"]
#riki
[playse  volume="30" buf="0" storage="kansei.ogg"]
喂喂！贤治郎！这位大叔真的超厉害啊！[r]
他可是「Pazumisha」天梯950级的大佬诶——！？[r]
我还是第一次见到这么硬核的玩家！！[p]
[chara_move name="riki" left="360" anim="true" wait="false"]
[chara_show name="mokke" wait="false" face="oji" left="100" top="100"]
#mokke
没有啦～也就是个重氪玩家而已……[r]
叔叔这种程度和真正的高玩比根本不算[r]
什么啦[p]
#riki:smile_s
少在那儿装模作样了！[r]
光靠氪金可到不了这水平啊！[r]
下次见面时再给我表演个十连击啊！！[p]
#mokke
真拿你没办法。[p]
那下次就，[r]
顺便把我珍藏的联名阵容也展示给你看吧[p]
[font size="40"]
#riki:smileCE_s
[playse  volume="30" buf="1" storage="kansei.ogg"]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
呜哇啊啊！！太猛了！！！[p][resetfont]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="worry_c" time="100" wait="false" left="-70"]
[chara_show name="hino" top="-10" face="angry_s" time="100" wait="false" left="360"]
#makado
……虽然早知道叔叔沉迷手游……[r]
解谜……什么来着？[p]

#hino
解谜×御社宫司……简称解谜社。[p]
虽然冠以民间信仰神祇之名，却毫无民俗学要素[r]
根本就是个讨人厌的解谜游戏！！[p]
[chara_hide_all time="10"]
[chara_show name="mokke" wait="false" face="oji" time="100"]
#mokke
那我先回去工作啦♪ 回头见，小鬼们[p]
[chara_hide name="mokke" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="angry_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="sad_s"]
#riki
大叔——！[r]
我可要叫你师父的啊啊啊！！[p]
[delay speed="50"]
#
贤治郎先生的叔父对着登利竖起大拇指，[r]
身影渐渐消失在神社深处……[p]

#riki:worry_s
[playse  volume="20" buf="0" storage="sariin.ogg" ]
师父……要是你肯绑架我的话，我说不定真能改变……[p]

#aki:tweetLA_s
能改变力君的大人啊[r]
是绝对不会绑架你的啦[p]
#aki:tweet_s
……好了。[l][r]
[fadeoutbgm time="2000"]
[chara_mod name="aki" face="normal_s"]
纱罗纱 真的要好好感谢我哦。[r]
今天可是专门为你……[p]
[chara_mod name="riki" face="smileH_s"]
[chara_mod name="hino" face="normal_s"]
#aki:smileB_s
[font color="0xf08080"]毕竟从狮心教借调了足足三人呢[resetfont][p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false"]
#sarasa
……嗯[p]
#
每次了解到大家的新一面时……[r]
有时会觉得大家好像都在渐渐变成不同的人，这让我感到害怕。[p]
[chara_mod name="sarasa" face="closeEye_c"]
……不过，这总比一无所知要好得多。[p]
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" top="-10" face="tweet_c" wait="false" time="100"]
#makado
你们……是和家人一起加入狮心教的吗？[p]
[chara_hide name="makado" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_s"]
[delay speed="60"]
#aki
是啊 我们家 以前是妈妈……[wait time="1000"][r]
现在 和爸爸 一起 参加 集会[p]
[resetdelay]
#hino:smile_s
日野家的话，现在只有我祖父是信徒！[r]
现在全家参加集会的就剩我一个人了[p]
#riki:smile_s
我家可是全家信教？懂吗？就是这种！[r]
我所有亲戚全都是狮心教的！知贵当然也是！[p]

[delay speed="70"]
#sarasa
大家都是因为家庭关系，[r]
那个，[font color="0xf08080"]狮心教[resetfont]……才入教的吧[p]
[resetdelay]
#hino:tweet_s
当然是这样。[r]
但不仅如此哦[p]
[delay speed="100"]
#sarasa
诶……[p]
[delay speed="50"]
#aki
我们　所有人　都和家庭　无关[r]
是真心实意　信仰着　[font color="0xf08080"]御白姬[resetfont]的[p]

#sarasa
……在八种町，御白姬已经是特别的存在了……[l][r]
比那还要、更加特别——是这个意思吗？[p]

#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
没错！之前也说过了，[r]
狮心教正是所谓的[font color="0xf08080"]创唱宗教[resetfont]！！[p]

#sarasa
创唱……[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="tweetLA_c" time="100" wait="false"]
#makado
所谓创唱宗教，[r]
[font color="0xf08080"]是指由某人提倡并创立的宗教。[resetfont][p]
#makado:lookAway_c
比如佛教也是创唱宗教……就是遵循释迦牟尼的教诲对吧？[r]
具有这种结构的宗教，我们就这样称呼哦[p]
[resetdelay]
[chara_hide name="makado" time="10"]
[chara_show name="riki" top="-100" face="smileCE_s" wait="false" time="100"]
#riki
嘎哈哈，贤治郎你对佛教还挺熟嘛。[r]
不如干脆去当和尚算啦？[r]
连发型都不用换多方便啊[p]
[chara_hide name="riki" time="10"]
[chara_show name="makado" top="-10" face="closeEye_c" time="100" wait="false"]
#makado
不是剃个光头就能当和尚的好吗[p]
[chara_hide name="makado" time="10"]
[delay speed="50"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="tweet_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="smileCE_s"]
#aki
真是的[r]
有力在场的话　五分钟能说完的事　怕是要拖上一个小时呢。[r]
总之……[p]
#aki:smile_s
我们狮心教　向御白姬　献上祈祷。[p]
原本或许只是民间信仰的神明吧[r]　
但对狮心教而言　她就是[r]
毋庸置疑的至高女神本身……[p]
#aki:normal_s
[playse  volume="20" buf="0" storage="sariin.ogg" ]
所以信徒们不以[r]
[font color="0xf08080"]信徒[resetfont]自称　而称[font color="0xf08080"]眷属[resetfont][r]
为了证明自己愿成为女神之手足　耳目　喉舌[p]
[resetdelay]
[chara_hide_all wait="false"]
#
[font color="0xf08080"]崇拜御白姬的眷属们的集会[resetfont]。[r]
这就是狮心教……[p]
[chara_show name="makado" wait="false" face="sad_c" top="-10"]
#makado
而提倡并创立这个狮心教的人――[l][r]
[chara_mod name="makado" face="tweet_c"]
你早已熟知的雾绘·树月·优三姐妹的本家『[font color="0xf08080"]宗方家[resetfont]』[p]
[chara_hide name="makado" time="10"]
[fadeinbgm storage=onedari.ogg loop=true time="1000" volume=40 sprite_time="0200-21000"]
@layopt layer=message0 visible=false
[clearfix]
;スチル：宗方三女神
[bg storage="still/sanninkanjo.png" time="500" wait="false" cross="false"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="60"]
#makado
……狮心教的信徒们[r]
【从御白姬那里获得的祝福，会解决自身的烦恼】[r]
遵循着这样的教义而生活。[p]

而将这些信徒的祈愿[r]
传达给御白姬的职责，正是由[r]
宗方血统选出的三位女儿――[font color="0xf08080"]三位巫女[resetfont]所承担[p]
[resetdelay]
#hino
[font size="40"]
[quake time="30"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
正是如此！！[resetfont][p]
她们从一百多年前就肩负着本组织的核心职能[r]
可是大·大·开祖大人的直系血统啊！[p]
所以在花隅商业街沿线居住的居民中[r]
狮心教相关人士特别多　[font size="20"] 冷知识[p][resetfont]
[delay speed="70"]
那里有着眷族聚集的宗方家宅邸……[r]
[font color="0xf08080"]因为那里有“茧之家”啊！[resetfont][p]
#
茧的……家……[p]
[mask]
[fadeoutbgm time="2000"]
[bg storage="porch_m.jpeg" time="10"]
[chara_show name="sarasa" top="-160" face="normal_c" time="10"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[mask_off]
[delay speed="50"]
#sarasa
眷属的人……会在什么情况下去茧的家？[r]
有什么规矩吗……？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="tweetLA_s"]
#riki
——嗯，这个嘛……[r]
硬要说的话，就是'发生状况的时候'吧[p]
[resetdelay]
#riki:shame_s
最近啊——[r]
知贵的自律呼吸？不是经常突然停止什么的嘛——[r]
搞得我们经常要临时集体去祷告呢。我们家。[p]
#riki:sad_s
然后让树月「请治好知贵！」这样[r]
帮忙做了祈祷来着——？[p]
结果，[r]
都两周没收到[font color="0xf08080"]祝福[resetfont]了啦！[p]
#aki:tweet_s
……御白姬她[r]
[font color="0xf08080"]并非每次必定会赐予我们祝福[resetfont]。[p]
[chara_mod name="aki" face="smile_s"]
只要像个孩子般 一心一意地 作为眷属 存在下去的话[r]
总有一天肯定 也能实现 对知贵君的祈愿哦[p]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
#riki:smileCE_s
噢、说得对呢——！[r]
我也得更努力当个称职眷属才行啊！　[stop_kanim name=riki]嘿嘿！[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false"]
#sarasa
…………[p]
[delay speed="60"]
#sarasa:closeEye_c
――我说。那个，祝福”什么的……[p]
#眷属の少年たち
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_s"]
？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false"]
#sarasa
…………大家难道已经、哪怕一次……[r]
得到过祝福吗？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_s"]
#aki
…………。[l][r]
[chara_mod name="aki" face="smileB_s"]
啊——　说的也是呢[p]
[layermode name="riki" graphic=riki.png time=300 wait="false" opacity="190"]
[stopbgm]
#眷属の少年たち
[chara_mod name="hino" face="ghost_s"]
[chara_mod name="aki" face="ghost_s"]
[chara_hide name="riki" time="10" pos_mode="false"]
就像这样[p]
[free_layermode name="riki" time="10"]
[chara_hide_all time="100" wait="true"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false" time="100" face="worry_c"]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
！[p][stop_kanim name=sarasa]
[delay speed="70"]
#sarasa:worryLA_c
……。[r][fadeinbgm storage=lost-happy.ogg loop=true time=3000 volume="30"]
果然是这样……呢……[p]
[chara_move name="sarasa" top="-100" left="360" anim="false" wait="false"]
[chara_show name="makado" top="-60" left="-70" face="tweet_c" wait="false"]
#makado
？ 纱罗纱。[r][resetdelay]
你说的「果然」……是什么意思？[p]
#
——对了，说起来他，[r]
是无法看到登利他们[font color="0xf08080"]这副模样[resetfont]的。[p]
[delay speed="50"]
#sarasa:worry_c
……贤治郎先生，他对我……[font color="0xf08080"][l][r]
能够分辨诅咒的存在[resetfont]
曾经这么说过对吧[p]

#makado:normal_c
啊啊……在你的眼里，被诅咒的人会显现出扭曲的姿态对吧？[p]
[delay speed="60"]
#sarasa:closeEye_c
……是的。我至今都认为……自己看到的……[p]
[resetdelay]
#sarasa:normal_c
眼前所见正是[p]
奥鲁莫克带来的[font color="0xf08080"]诅咒导致的异形化[resetfont][r]
现象……[p]
[resetdelay]
[mask]
[chara_hide_all time="10"]
[bg storage="brack.png" time="100"]
#
[chara_show name="kirie" top="-100" face="ghostC" time="10"]
[layermode name="kirie" graphic=kirie.png time=300 wait="false" mode="lighten"]
[mask_off]
那时——就像雾绘用双手扼住脖子那般。[p]
[mask]
[free_layermode name="kirie" time="10"]
#
[chara_hide name="kirie" time="10"]
[chara_show name="riki" top="-100" face="ghost" time="10"]
[layermode name="riki" graphic=riki.png time="10" wait="false" mode="lighten"]
[mask_off]
登利也仿佛[p]
要从体内撕裂人类躯体。[p]
[mask]
#
[chara_hide name="riki" time="10"]
[free_layermode name="riki" time="10"]
[chara_show name="aki" top="-100" time="10" face="ghost"]
[bg storage="still/aki_ana.png" time="10"]
[mask_off]
阿奇他，[r]
仿佛要将存在本身都彻底抹消在深渊之中。[p]
[mask]
[chara_hide name="aki" time="10"]
[bg storage="brack.png" time="10"]
[mask_off]
#sarasa
奥鲁莫克通过赋予人类超常能力的方式，[r]
企图抹杀身为御白姬的我……[p]
为此，[r]
[font color="0xf08080"]原以为被诅咒的人都会变成异形的样貌……[resetfont][p]
[delay speed="100"]
[bg storage="porch_m.jpeg" time="2000" wait="false"]
[chara_show name="sarasa" top="-100" left="360" wait="false" time="2000" face="worryLA_c"]
[chara_show name="makado" top="-60" left="-70" face="normal_c" wait="false" time="2000"]

但是……[wait time="1000"]那个…………………………[p]
[delay speed="50"]
#makado:tweet_c
……纱罗纱现在[r]
似乎察觉到人们形貌异变另有隐情――[r]
是这样吗？[p]
[resetdelay]
[font size="50"]
#sarasa:worry_c
！　[resetfont]……是的[p]
#makado:closeEye_c
明白了。[r]
我当然会尊重你的想法[p]
#makado:tweet_c
请务必告诉我，[r]
你看到的[font color="0xf08080"]被诅咒的人们[resetfont]以及你现在所想的[font color="0xf08080"]异变原因[resetfont][p]

#sarasa:normal_c
——好的[p]

#sarasa:closeEye_c
（至今为止接触过的，[r]
被诅咒之人『异形的缘由』恐怕……[r]
[font color="0xf08080"]与御黑祟无关[resetfont]。）[p]
#
真正的理由、一定藏在这边——[p]
;-------------------------------------------------------------------------------
*igyo
;-------------------------------------------------------------------------------
[chara_mod name="sarasa" face="normal_c"]
[chara_mod name="makado" face="normal_c"]
;▶オシラヒメから眷属たちに授けられた”祝福”
;▶馬門神社
;▶白絹祭
[font size="27"]
#
[link target="*igyo_no"]【１】白絹祭[endlink][r]
[link target="*igyo_no"]【２】馬門神社[endlink][r]
[link target="*igyo_yes"]【３】御白姬的祝福[endlink][r]
[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*igyo_no
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#makado:worry_c
……？这真的、是相关线索吗？[p]

#sarasa:worry_c
（啊…不、不对。必须好好回答才行！）[p]

@jump target="*igyo"
;-------------------------------------------------------------------------------
*igyo_yes
;-------------------------------------------------------------------------------
;▶オシラヒメから眷属たちに授けられた”祝福”
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
[delay speed="50"]
[fadeoutbgm time="2000"]
#sarasa
……长久以来被诅咒者的异形化与超能力全部——[r]
或许都是御白姬赐予的[font color="0xf08080"]祝福[resetfont]吧？[p]
[delay speed="100"]
#makado
…………[p]

#makado:wow_c
[quake time="30"]
……[wait time="1000"]诶？[p]

#sarasa
每当触及大家的回忆时……[r]
我都以为自己追寻的是诅咒的源头[p]
就这样，登利君怀抱着『[font color="0xf08080"]想要消失[resetfont]』……[l][r]
而阿基则怀着『[font color="0xf08080"]想让别人填补心中空洞[resetfont]』的祈愿[r]
这些我都已然知晓……[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" face="hate_s" wait="false" time="100"]
#aki
……[p]
[resetdelay]
[chara_hide name="aki" time="10"]
[chara_show name="riki" top="-100" face="angry_s" top="-100" time="100" wait="false"]
#riki
喂——这种丢人事就别总挂嘴边啊[p]
[chara_hide name="riki" time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_c" time="100" wait="false"]
#sarasa
对、对不起。可是……[p]
[delay speed="60"]
[chara_mod name="sarasa" face="normal_c"]
贤治郎先生。[r]
那些全都是与他们所拥有的[font color="0xf08080"]超常能力相连的愿望[resetfont]啊[p]
[resetdelay]
[chara_hide name="sarasa" wait="false" pos_mode="false"]
[chara_show name="makado" face="wow_c" wait="false" top="-10" left="100"]
我所目睹的异常形态，[r]
全都像是那种'祈愿'具现化后的产物――[p]
[font size="40"]
#makado
――！！[p]
[quake time="30"]
#makado:wowB_c
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font size="33"]
也就是说，你认为……狮心教的眷属们，[r]
真的从御白姬那里获得了[font color="0xf08080"]祝福[resetfont][font size="33"]，[r]
是这个意思吗！？[p]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[chara_hide name="makado" time="10"]
[chara_show name="hino" top="-100" wait="true" time="100" face="angry_s"]
[resetdelay]
#hino
[anim name="hino" top="+=60" time="150"]
[anim name="hino" top="-=60" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
喂喂喂喂！！！[r]
这话我可不能当没听见啊贤治郎阁下——！！[r]
[resetfont]
御白姬是真实存在的！！[p]
[chara_hide name="hino" time="10"]
[chara_show name="makado" top="-10" face="worry_c" wait="false"]
#makado
啊、不……抱歉。[r]
我并不是要否定你们的信仰对象[p]
[delay speed="60"]
#makado:worryB_c
但是，………………如果御白姬赐予的祝福[r]
确实存在于现实的话，那我——[p]
[resetdelay]
[chara_hide name="makado" time="10"]
#riki
[chara_show name="hino" top="-100" left="100" wait="false" face="smile_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="smile_s" time="100"]
[chara_show name="riki" top="-100" left="400" wait="true" face="smileCE_s" time="100"]
[anim name="riki" top="+=60" time="150"]
[anim name="riki" top="-=60" time="150"]
啊！难道说，你要改信狮心教不成！？[r]
我们可是超级温馨的宗教团体啊——！[r]
既没有强制捐款，也没有拉人指标！！[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="worry_c" wait="false"]
#makado
…………[l][r]
[chara_mod name="makado" face="sad_c"]
不……倒也不是因为这个[p]
[chara_hide name="makado" time="10"]
#aki
[chara_show name="hino" top="-100" left="100" wait="false" face="sad_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="sad_s" time="100"]
[chara_show name="riki" top="-100" left="400" wait="true" face="sad_s" time="100"]
那您究竟是？[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="worry_c" wait="false" time="100" face="tweetLA_c"]
#makado
……好吧[p]
[delay speed="50"]
#makado:angry_c
既然都到这份上了。[r]
我就直说了……请在场的狮心教诸位给我个明确答复。[l][r]
正如她所说，你们——[p]
#makado:tweet_c
能将愿望具现化的，超能力……[r]
[font color="0xf08080"]这是作为祝福，从御白姬那里得到的吧？[resetfont][p]
[chara_hide name="makado" time="10"]
#眷属の少年たち
[chara_show name="hino" top="-100" left="100" wait="false" face="ghost_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="ghost_s" time="100"]
[layermode name="riki" graphic=riki.png time="100" wait="true" opacity="190"]
[chara_hide name="riki" time="10" pos_mode="false"]
是的[p]
#makado
[free_layermode name="riki" time="10"]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" face="normal_c" wait="false"]
[chara_show name="makado" top="-60" left="-70" face="lookAway_c" wait="false"]
……[p]
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
[resetdelay]
#sarasa
现在也……贤治郎先生您还是看不见对吧。[r]
他们形态发生变化的样子[p]
#makado:closeEye_c
是啊。……甚至连气息都感觉不到[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="smileCE_s" time="100"]
哈哈！那不是理所当然嘛。[r]
贤治郎又不是狮心教的人[p]
#
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" time="100" face="worry_c" wait="false"]
[chara_show name="makado" top="-60" left="-70" time="100" face="worry_c" wait="false"]
诶？[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="smileCE_s" time="100"]
[delay speed="50"]
我说啊？　咱们这个祝福，本质上就是[r][font color="0xf08080"]
只有在狮心教里同样获得过祝福”的人[resetfont]之间[r]
才能互相识别的啊[p][resetdelay]
#riki:smileB_s
所以啊——真要较真的话[r]
志户田能看见这形态才更离谱好吧！[r]
你脑子到底哪根筋搭错了？哈哈哈！[p]
[delay speed="60"]
[font color="0xf08080"]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
祝福这种力量，[r]
只有狮心教内获得过『祝福”的人才能互相识别……？[resetfont][p]
#sarasa
（怎么会……明明直到昨天为止……[r]
我连狮心教这个名字都未曾听闻……）[p]
[resetdelay]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" time="100" face="worryLA_c" wait="false"]
[chara_show name="makado" top="-60" left="-70" time="100" face="tweet_c" wait="false"]
#makado
像她这样[r]
与狮心教无关却能看见祝福的人，[r]
之前也出现过吗？[p]
#aki
唔～不过　其实我们　也　[r]
关于这件事[r]
详细情况我们也不太清楚呢[p]
就连眷属中有谁获得了祝福 都没完全掌握[r]
更别说自己的祝福了 怎么可能到处宣扬！[r]
这种念头压根没想过啊[p]
所以在我们确认的范围内[r]
没被祝福却能看见祝福的人 目前[r]
大概只有纱罗纱了吧[p]
[delay speed="50"]
#makado:lookAway_c
……在狮心教内部　这件事也[r]
是不该摆在台面上讨论的话题呢[p]

#aki
因为　基本上[r]
这和成为眷属的缘由本身　都涉及个人隐私啊[p]

啊　千万　别到处乱说哦[r]
纱罗纱[p]

#sarasa:closeEye_c
才、才不会说呢……[p]
[resetdelay]
#riki
就是就是啊。[r]
既能窥探个人隐私、又能查看祝福状态。[l][r]
你这家伙到底想把我们怎么样啊—[p]

#sarasa:worryLA_c
呜、呜呜……[p]

#makado:sad_c
……因为她快要遭殃了，我们很困扰啊[p]
#makado:normal_c
…………………………除此之外，[r]
关于祝福还有什么能告诉我们的吗？[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="tweet_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="smile_s"]
#hino
唔——嗯………………[p]
#hino:smile_s
啊！　[r]
说不定那双[font color="0xf08080"]能窥见他人回忆的眼睛[resetfont]也…………[p]
可怜被盯上的志户田[r]
这可能是被赐予对抗御黑冥的能力哦[p]

#aki
诶—给纱罗纱？谁给的啊[p]
#hino:happy_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
那当然是！御白姬啊[p]

#riki:angry_s
什么鬼！！[r]
志户田又不是眷属！[p]
[quake time="30"]
#hino:shame_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
胡说什么！她可是八种的土地神大人啊！！[p]
以宽宏大量的胸怀，[r]
去拯救作为自己倒影的少女[r]
也没什么奇怪的对吧！？[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="lookAway_c" time="100"]
#makado
啊，原来如此。[r]
或许她真有可能获得了祝福呢……[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_s" time="100"]
#hino
――总之我希望你明白的是，[r]
这种力量绝非与御黑冥有关的现象[r]
而是属于善性之物[p]
[delay speed="50"]
#hino:smile_s
……事实上，[font color="0xf08080"]只要想着‘燃烧吧！’就能点燃物体的能力[resetfont]，[r]
我在三年前就从御白姬那里获得了呢。[p]
[delay speed="10"]
#hino:happy_s
[playse  volume="30" buf="0" storage="kansei.ogg"]
如果这能帮助贤治郎先生加深对狮心教的理解，[r]
我很乐意将这份[r]
获得祝福的经过娓娓道来！[p]
[resetdelay]
#aki:tweetLA_s
……还是算了吧？不管怎么说[r]
把向御白姬　许下的心愿　到处炫耀这种事[r]
总觉得有点　轻浮呢[p]
#hino:normal_s
唔。这么说也有道理[p]
[chara_hide_all wait="false"]
[chara_show name="makado" top="-10" face="closeEye_c" wait="false" left="100"]
#makado
……那么，纱罗纱[p]
[delay speed="50"]
#makado:tweet_c
根据目前为止[r]
你和狮心教众人阐述的观点来看――[p]
我们此前认定为[font color="0xf08080"]受诅咒者的形态[resetfont]的存在，[r]
严格来说[font color="0xf08080"]并非受诅咒者的形态[resetfont]，是这样吧[p]

#makado:lookAway_c
糟了……。[r]
也就是说，我们发现的法则中有一条是错的吗[p]
[chara_hide name="makado" wait="true" time="200"]
;アイテムスチル：馬門のメモ
[playse storage=page.ogg volume="50"]
[image layer=0 folder="image" name="makado_memo_c" storage="item/makado_memo_c.png" width="500" x="230" y="52" time="800" visible="true" ]

#hino
哎呀。看来你遇到麻烦了嘛[p]

#makado
啊。怎么说呢……[p]
关于这一连串的事件，[r]
我原本希望能在不掺杂狮心教概念的情况下解决。[r]
至少最初是这么想的[p]

#aki
为什么？[p]

#makado
虽然我也是因为对狮心教一窍不通才……[l][r]
但最主要还是不想让白绢祭给狮心教添麻烦啊[p]

#makado
可是……[r]
毕竟两者都是供奉御白姬的文化啊……[p]
为了彻底封印污秽灾厄，[r]
关于狮心教祝福的存在，[r]
看来需要进一步请教才行[p]
[mask]
[free layer=0 name="makado_memo_c" time="800" wait="true"]
[chara_show name="makado" top="-10" face="normal_c" time="10"]
[mask_off]
#makado
所以想和大家商量下，[r]
现在还能继续麻烦各位眷属协助我们吗？[p]
#
——贤治郎先生这么说着，望向廊下的少年们。[p]

说到那些少年们，[r]
以这句话为契机，[r]
各自用各自的方式开始确认起当前时间。[p]

#sarasa
……？大家……之后有什么事吗？[p]
[chara_hide name="makado" time="10"]
[resetdelay]
[chara_show name="hino" top="-100" left="100" wait="false" face="sad_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="angry_s" time="100"]
喂喂你在说什么啊——！[r]
之前日野不是那样大喊大叫过了嘛——！！[r]
果然你这家伙就是某个排他性经济水域吧——[p]

#aki:worry_s
光是排他性的话[r]
想说的话　恐怕　是对的吧……[p]
[fadeoutbgm time="2000"]

#hino
……[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" face="worry_c" wait="false"]
[chara_show name="makado" top="-60" left="-70" face="normal_c" wait="false"]
[delay speed="50"]
#sarasa
（啊……那个　好像……有什么事来着……）[p]

#makado
听说有签名会。[r]
是一位叫纪伊玛莉甘的……本镇出身的民俗学者的[p]

#sarasa:normal_c
………………………………[p]

#sarasa:worryLA_c
啊………………！[p]
[mask]
[chara_hide_all time="10"]
#
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=40]
[bg storage="inaka_m.jpeg" time="100"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[mask_off]
;田舎道
[wait time="1000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
――――稍远处，狮心教的少年们正走着。[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
;夏のＢＧＭ
#makado
受打击了？[p]

#sarasa
……诶？[p]
[chara_show name="makado" top="-10" wait="false" face="normal_c"]
#makado
狮心教的事……你之前不知道吧。[r]
虽然隐约觉得可能是这样……[p]
#makado:sad_c
一树——[wait time="500"]一定也有什么难言之隐[r]
才没跟你坦白。[r]
正因为关系亲密反而有些事说不出口[p]
[delay speed="60"]
#makado:tweetLA_c
特别是家庭隐情之类的 更会让人慎之又慎[p]
[chara_mod name="makado" face="normal_c"]
#sarasa
……[p]

#sarasa
……嗯　说的也是[p]
[delay speed="50"]
我也……最近经常想起来。[r]
「不问就不会明白的事情　不问就永远不会明白」[p]
[delay speed="60"]
保持沉默的话……就永远无法知晓。[r]
永远都……[p]
……………………[p]
[chara_hide name="makado" wait="false"]
;〇八種町風景立ち絵なし
[bg storage="hataneM.jpg" cross="false" wait="false"]

――一树她　绝对不会做让我讨厌的事[r]
从小学部第一次见面的那天起　直到今天一直都是这样[p]
所以肯定……她只是为我着想才没有说出来吧[r]
所以我一点都不觉得受打击[p]
#sarasa
[mask]
[bg storage="inaka_m.jpeg" time="10"]
[chara_show name="makado" top="-10" time="10" face="normal_c"]
[mask_off]
;立ち絵戻す
一树她一点都没变[p]

#makado
…………纱罗纱…………[p]
[resetdelay]
#makado:smileMini_c
嗯　是啊。你说得对。[r]
只是看到了新的一面而已　挚友关系不会改变啊[p]
[delay speed="50"]
#makado:smile_c
不过……你倒是有点变了呢！[p]

#sarasa
诶？[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
#
我不由得停下了脚步。[p]

#makado:lookAway_c
最近总觉得……你越来越像、[r]
我记忆中那个爱说话的纱罗纱了。[p]
#makado:smileMini_c
你还是活泼点比较好。要是看到你沉默不语地发呆，[r]
我都不知道该怎么办才好[p]

#
…………[p]

那个……前几天[r]
阿奇好像也说过类似的话。[p]
[chara_hide name="makado" time="10"]
[resetdelay]
[chara_show name="hino" top="-100" left="100" wait="false" face="sad_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="angry_s" time="100"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
啊！你干嘛突然停下来啊！[r]
志户田你这家伙～果然又打算自己开溜是吧！？[p]

#hino:angry_s
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[font size="37"]
过分！！太过分了志户田！！[r][resetfont]
对我期待的行程一点兴趣都没有！！[p]

#aki:normal_s
就没有一点愧疚吗？陪我去办点小事[r]
爽快答应不就好了 大度点嘛[p]

#sarasa
啊……对、对不起[p]

#riki
你们两个鬼鬼祟祟的——在聊什么呢？该不会在说阿奇坏话吧[p]

#aki:normal_s
我可不会逆来顺受啊[p]
[quake time="30"]
#sarasa
才…才不是呢！[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-60" left="-130" wait="false" face="smileMini_c"]
[chara_show name="aki" face="normal_s" top="-60" wait="false" left="500"]
[chara_show name="riki" face="normal_s" top="-60" wait="false" left="300"]

#makado
那你们俩刚才又在聊什么？[r]
不是聊得挺起劲的嘛[p]
[delay speed="50"]
[stopbgm]
#riki
在说贤治郎的坏话[p]
[chara_mod name="makado" face="worry_c"]
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
#aki
仗着身份优势 连小孩都不放过[r]
又是打又是绑的[r]
一言一行都麻烦得要死 活像个男性歌手的矫情歌词[p]

#riki
秃子[l][r]
容易跟和尚搞混[p]
[chara_mod name="makado" face="closeEye_c"]
#aki
端出来的茶点 清一色都是最中饼[p]
#riki
帽子颜色土得掉渣[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=3000 volume=40]
[resetdelay]
[quake time="50"]
#makado:angrySH_c
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
……帽子就放过它吧！！[p]
#
哇啊生气了 快溜啊
[chara_move name="riki" left=-520 anim="true" time=700 wait="false"]
[chara_hide name="riki" pos_mode="true" time="10" wait="false" pos_mode="false"]
[chara_move name="aki" left=-520 anim="true" time=700 wait="false"]
[chara_hide name="aki" pos_mode="true" time="10" wait="true" pos_mode="false"]
[p]
[chara_show name="hino" top="-60" face="angry_s" left="800" time="10"]
[chara_move name="hino" left="300" time="400" wait="false" anim="true"]
#hino
贤治郎先生　我可完全没有参与啊！！[r]
每次说的话都帅炸天啊！[p]
[delay speed="70"]
#makado:sad_c
谢谢……抱歉日野[r]
我会好好跟着你的放心吧[p]
[resetdelay]
[font size="36"]
#hino:shame_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
我可是很相信你的！？[r]
信任你、完全相信你说的这句话！！[p][stop_kanim name=火野]
[resetfont]
[filter grayscale="100" time="1000"]
#
――日野虽然这么说着，[r]
到达商店街前每隔两米就要[r]
回头确认一次。[p]

[fadeoutbgm time="2000"]
[mask folder="bgimage" graphic="still/part3.png" time="3000"]
[wait time="2000"]
[showsave]
;:セーブしますか？
;（休憩セーブポイント）
;（はなしがむずかしいから）
@jump storage="chapter_3/day1_vol2.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
