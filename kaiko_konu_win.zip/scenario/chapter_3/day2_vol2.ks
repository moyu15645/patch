;第3章『彼が五齢に着替えたら』
;ニ日目前編
;-------------------------------------------------------------------------------
*part3
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '三章二日目　後編'"]
#
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]

[mask_off]
……追寻入道的踪迹，最终抵达的地方是。[p]
[delay speed="80"]
;ＳＥ走る
#makado
……[l][r]
为什么、会回到……这里来呢。[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeoutbgm time="3000"]

[bg storage="school/kotei_n.jpeg" wait="true" cross="false" time="5000"]

;学校
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
入道老师……[p]

[mask time="2000"]
[delay speed="50"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[bg storage="brack.png" time="100"]
[mask_off time="1000"]
小时候[l][r]
大人们　总是最喜欢[r]
看着孩子们玩耍的地方[l][r]
[r]
大家　都特别爱看我坐在旋转木马上的样子[r]
一副开心得不得了的样子……[l][r]
大人们总是用无比幸福的目光[r]
望着旋转木马上的我[p]
[delay speed="80"]
[r]
所以我觉得自己说过[l][r]
[r]
对那些想看我开心的大人们[l][r]
[r]
[r]
[wait time="700"]
「我要让你们看看我坐旋转木马的样子」[wait time="700"][r]
这样的话[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask time="3000"]
[bg storage="indoor/sisin_holl.jpeg" time="10"]
[chara_show name="kinuyo" time="10" top="-160" face="normal"]
[delay speed="50"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[mask_off]
;○繭の家

#kinuyo
——志户田家和宗方家之间世代存在着[font color="0xf08080"]心照不宣的约定[resetfont][p]
#kinuyo:angry
[delay speed="60"]
那是，[r][font color="0xf08080"][playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
双方在这座城市里互相回避着生活[resetfont]……这样的约定[p]
[chara_hide name="kinuyo" time="10"]
[chara_show  name="aki" left=150 top=-100 wait="false" top="-100" face="tweet_s"]
[chara_show  name="riki" face="normal_s" left=-230 top=-100 wait="false"]
[chara_show  name="suguru" face="normal_s" left=430 top=-100 wait="false"]
[resetdelay]
#aki
但是 纱罗纱和一树[r]
在小谷坂小学部 分到同一个班级时[r]
却发展成了挚友关系呢[p]
这件事 您应该也是知道的[p]

#kinuyo
嗯。我当时很焦虑。[r][wait time="500"]
最担心的情况还是发生了[p]

#riki:think_s
最担心的情况——？那是什么啊[p]
[delay speed="60"]
#kinuyo
……对我而言，[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]【眷属无法介入的】[resetfont]三人女官和……[r]
女儿产生羁绊这件事啊[p]
[chara_hide_all time="10"]
[chara_show name="kinuyo" top="-160" face="closeEye" wait="false"]
纱罗纱 你大概不知道吧……[l][er]
#kinuyo:sad
在八种地区势力庞大的狮心教 虽然对普通信徒的生活教义[r]
相对宽松　[font color="0xf08080"]但对背离团体者或信仰淡薄的眷属[r]
就会突然变得严厉起来[resetfont][p]
[resetdelay]
#kinuyo:angry
更何况……[wait time="500"]茧的家族在教内拥有巨大影响力[r]
[font color="0xf08080"]禁止三位女官与自身家族交往，简直岂有此理[p][resetfont]
#kinuyo:normal
身为御白姬的左膀右臂却展现如此不诚实的姿态的话[r]
在镇上可是会遭到迫害的[p]
[chara_hide name="kinuyo" time="10"]
[chara_show name="riki" top="-100" wait="false" time="300" face="hate_s"]
#riki
就是这样啊—[r][wait time="500"]
[resetdelay]
#riki:smileB_s
我们啊、对外人虽然啥都不会说、[r]
但对自家人和亲近的家伙可是超级严格的[p]
[chara_hide name="riki" time="10"]
[chara_show name="kinuyo" top="-160" wait="false" face="closeEye"]
[delay speed="60"]
#kinuyo
就这样打破了志户田家世代相传的潜规则、[r]
将你抚养至今……[wait time="500"]纱罗纱[p]
#sarasa
……妈妈[p]
[chara_show name="suguru" top="-100" face="normal_s" wait="false"]
#suguru
那个。可以稍微打扰一下吗[p]
#kinuyo
……有什么事吗[p]
[resetdelay]
#suguru
为什么说得好像只有纱罗纱你和我姐姐交好这件事[r]
才是问题根源一样？[p]
#suguru:angry_s
[delay speed="100"]
说到底最初、引发这一切的罪魁祸首……[r]
不就是绢世小姐你吗[p]

#kinuyo
……[p]

#suguru
因为……[r]
[resetdelay]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=suguru keyframe=up time=300 wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#suguru:angry_s
那你为什么、身为志户田家的你要[r]
打破「默认的规则」成为眷属啊？！[p]
[stop_kanim name=suguru]
[delay speed="60"]
#suguru:sad_s
要是你没成为眷属 不和宗方家扯上关系的话……！[r]
姐姐和纱罗纱小姐本可以不用成为朋友的！[l][r]
[resetdelay]
只要母亲说一句「不许和那孩子来往」就……！[p]
#suguru:wow_s
[font size="40"]
[delay speed="23"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
都是因为你来到我们家的缘故[r]
事情才会变得这么复杂不是吗！[r][resetfont]
最先破坏约定的人……别给我摆出受害者嘴脸！[p]
[delay speed="60"]
#sarasa
优……优君[p]
[font size="40"]
#suguru:angry_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=suguru keyframe=up time=300 wait="false"]
什么事！？？[r][resetfont][resetdelay]
就是因为志户田前辈不生气 我才会这么愤怒啊！[r]
就连姐姐也是……！[p]
[stop_kanim name=suguru]
#kinuyo:normal
就算背叛家族 她也有想要实现的祈愿[p]
[delay speed="100"]
#suguru:sad_s
……………………哈？[p]
[delay speed="60"]
#kinuyo
作为女性  [wait time="500"]也想要证明自己能够继承家业[p]
#kinuyo:sad
因为性别的缘故 [r]
仅仅因为这种理由……连名字都无法留下……[r][wait time="500"]
实在无法忍受[p]

#suguru
…………[p]
[chara_hide name="suguru" wait="false"]
[resetdelay]
#kinuyo:closeEye
我的祝福最终传达到了吗，还是没能传达到呢。[r]
就这样暧昧不明地度过了几十年。[l][r][font size="23"]
[delay speed="60"]
#kinuyo:angry
……即便只是名义上继承了公司 这个世界也根本不会改变[p][resetfont]
#kinuyo:back
——真是愚蠢。真的。[r]
为了如此渺小的愿望，却让女儿受苦……[p]
[delay speed="70"]
#kinuyo
………………………………………………………………[p]
…………………………………[wait time="1000"]对不起。[r]
纱罗纱[p]
#
[chara_hide_all time="1000" wait="true"]
#sarasa
……[p]
#sarasa
……没关系的。妈妈[p]

#sarasa
抬起头来吧…………妈妈[p]
#
我在这一刻才首次意识到，[wait time="800"][r]
自己的母亲也不过是个普通人。[p]

#kinuyo
……我也要向你道歉。[r][wait time="1000"]
对不起　树月先生[p]
[chara_show name="ituki" top="-160" face="tweet_gs" wait="false"]
#ituki
……[p]
[resetdelay]
#kinuyo
在你们狮心教的高层看来，[r]
志户田家想必是极其碍眼的存在吧……[wait time="800"][r]
毫无责任感又自私自利的家族呢[p]
不过啊，[r]
正因如此才能在镇上积累起最庞大的财富[r][wait time="500"]
能够毫无犹豫地统辖并舍弃纯洁无垢之人[p]

#kinuyo
关于我族的事，[r]
就按您这位三柱女官所期望的处置便好――[r][wait time="500"]
我本就没有阻止的权利[p]
[delay speed="100"]
#ituki
………………[p]
#ituki:normal_gs
哈哈……我怎么可能会知道。什么家族不家族的……[p]
#ituki:hate_gs
………………[p]
#ituki
………[wait time="800"]
#ituki:smileW_gs
[resetdelay]
哈——完蛋了！　在下我[l][r]
………………[p]
[delay speed="100"]
#ituki:angry_gs
给我滚出去啊　[wait time="800"][resetdelay]求你了……快走吧[p]

#kinuyo
…………[p]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[playbgm storage=hitoriboti.ogg loop=true  volume=30]
[chara_hide time="10" name="ituki"]
[chara_show name="hino" top="-100" wait="false" face="shame_s" time="100"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="40"]
#hino
喂喂喂喂喂！！！！[r]
大家啊！！！[p][resetfont]
[chara_show  name="suguru" face="sad_s" left=490 top=-100 wait="false"]
[chara_show  name="aki" left=250 top=-100 wait="false" top="-100" face="wow_s"]
[chara_show  name="riki" face="normal_s" left=-70 top=-100 wait="false"]
[chara_move  name="hino" left=-230 anim="true" wait="false"]
[chara_mod name="hino" face="sad_s"]
#aki
[chara_show  name="aki" left=250 top=-100 wait="false" top="-100" face="wow_s"]
怎么了啊　日野[p]

#hino
那个……刚才我又进了前面的[font color="0xf08080"]资料室[resetfont]里[r]
在那里……[p]
[chara_show name="ituki" left="120" face="shout_gs" top="-160" time="100" wait="true"]
[font size="40"]
#ituki
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[chara_mod name="riki" face="worry_s"]
哈啊！？　！？[r][resetfont]
#ituki:angryB_gs
[chara_move name="ituki" left="-500" anim="true" wait="false"]
[chara_move name="hino" left="-700" anim="true" wait="false" ]
你他妈在搞什么鬼——！？[p]
[font size="38"]
#hino
咿呀呜、咿呜哇啊！　呀咩咯喂！[p]
#suguru:sadB_s
[anim name="suguru" top="+=30" time="150"]
[anim name="suguru" top="-=30" time="150"]
[anim name="suguru" top="+=30" time="150"]
[anim name="suguru" top="-=30" time="150"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
姐姐！[r]
别跟日野前辈那么要好！[p]
[chara_move name="ituki" left="-230" anim="true" wait="false"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_mod name="riki" face="shame_s"]
优！[r]
为什么随便让人自由进出啊！？[r]
那里可是三宫女的秘密房间啊！？[p]

#suguru:wow_s
[quake time="30"]
[playse  volume="20" buf="0" storage="garasu.ogg" ]
把那个秘密房间当成牢房来用了[r]
你可是姐姐啊！！[p]
[delay speed="50"]
[resetfont]
#suguru:angry_s
从那里出来之前的时间，[r]
大家也一直都在拼命翻阅资料。[r]
现在说什么都晚了，而且轮不到你来说，懂吗[p]

#ituki:angry_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
…………！！[p][stop_kanim name=树]
[font size="20"]
#hino
呃、咳咳。[p][resetfont]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" face="tweet_s" wait="false"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
没错，就在那时，我『看穿了茧之典』的真面目[p]
[resetdelay]
#aki
啊哈哈　难道还是干花吗？[p]
[delay speed="60"]
#hino:smile_s
器乐堂。枯尾花严格来说并非花朵，而是芒草……[r][wait time="500"]
[resetdelay]
#hino:sad_s
等等，不对不对。不是这样的……[p]
[delay speed="60"]
#hino:normal_s
恐怕玛莉甘小姐所说的[r]
[font color="0xf08080"]所谓秘密教典的《茧之典》是...[l][r][resetfont]
#hino:tweet_s
[playse  volume="20" buf="0" storage="sariin.ogg" ]
准确来说——[wait time="500"][font color="0xf08080"]并非具有教典功能的书籍[resetfont]啊！？[p]

#sarasa
诶……？[p]

#hino:normal_s
是啊，要说的话……[p]
#hino:smile_s
[font size="40"][font color="0xf08080"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
为了管理信徒而编撰的、名册！[resetfont]　是花名册啊！[p]
[chara_show  name="aki" left=140 top=-100 wait="false" top="-100" face="normal_s"]
[chara_move  name="hino" left=-100 anim="true" wait="false"]
#riki
[chara_show  name="riki" face="normal_s" left=360 top=-100 wait="false"]
名册啊。[r]
就是老师点名时拿的那个东西吧[p]

#hino
没错。虽然资料室里堆着海量的书籍……[l][r]
[delay speed="50"]
#hino:tweet_s
但每本书的[font color="0xf08080"]人名[resetfont]、以及翻开后第一页的"封底"上[r]
　[font color="0xf08080"]上面记载着针对三位女官的规约[resetfont][p]

#hino
也就是说那个房间里的书[r]
全都是相同制式与用途的『茧之典』，[p]
#hino:shame_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
实质上记载的并非阐述狮心教教义的"经文"……[r][wait time="500"]
记录着[font color="0xf08080"]各个时期哪些人作为眷属入教[resetfont]、[r]
的总登记簿！[p][stop_kanim name=火野]
[resetdelay]
#hino:normal_s
每个时代的[r]
被选为最高阶三官女的成员，为了管理眷属们而――[p]
#hino:smile_s
同时也是为了遵守狮心教在镇上制定的规矩[r]
所陆续记录下的笔记，[r]
就以『茧之典』之名被长久保管在那里[p]
[delay speed="60"]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（用来管理眷属姓名的登记簿……）[p]
[resetdelay]
#aki
不过话说回来　那么大量的资料[r]
居然能在这么短时间内　全部确认完毕啊[p]
[font size="40"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
人类没有不可能的事！！！！！[p][resetfont]

#sarasa
（……啊！　对了……！）[p]
#
从包里掏出手机。[p]

看向屏幕时，贤治郎先生已经发来了消息。[r]
看来　我想知道的事情　已经查明了……[p]
[font color="0xb0c4de"]
[delay speed="100"]
――[wait time="500"]
『川铃木老师和入道老师，都是狮心教的眷属』[p][resetfont]

#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
（……！果然——！）[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" wait="false" face="angry_s"]
[delay speed="50"]
#sarasa
呐，日野。看到那本『茧之典』的时候……，[l][r]
川铃木老师和入道老师的名字，都写在上面对吧……！？[p]
[chara_hide name="sarasa" time="10"]
[chara_show  name="aki" left=140 top=-100 wait="false" top="-100" face="normal_s"]
[chara_show  name="riki" face="normal_s" left=360 top=-100 wait="false"]
#hino
[chara_show  name="hino" left=-100 top="-100" wait="true" face="shame_s" time="100"]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
咦？你怎么会知道！？[p]
#hino:normal_s
确实写着。我也吓了一跳……[r]
集会上从没见过他们，平时也完全没有[r]
任何可疑的言行[p]
[resetdelay]
#aki:tweetLA_s
嘛　典型的脱教眷属大概就是这样的吧[p]
#hino:sad_s
真见外啊，特别是入道老师！[r]
明明是顾问和部长的关系　坦白告诉我们也[r]
没什么问题的啊[p]

#riki:sad_s
就算告诉我　我也只会觉得恶心而已[r]
没说出口说不定反而是好事[p]
[delay speed="60"]
[chara_hide_all time="10"]
[chara_show name="suguru" top="-100" face="normal_s" wait="false" time="300" left="360"]
[chara_show name="ituki" top="-160" face="tweet_gs" wait="false" time="300" left="-70"]
#suguru
说起来……今天一直来的熊老师[r]
没有出现呢[p]

#ituki
啊……今早收到联络了。[r]
「说是「有要等的人所以来不了」[p]
[chara_hide_all time="1000"]
[font size="20"]
#hino
然后啊……[r][wait time="500"]
在查看这么多资料的过程中，发现有个令人在意的页面[wait time="500"][er]
[resetfont]
#
[delay speed="100"]
……找到了。 终究还是发现了……[p]
[font size="20"][resetdelay]
#ituki
在意的页面？[wait time="500"][er]
[resetfont]
#
[delay speed="100"]
我的眼睛所「视见」的、人类姿态的法则。[p]
[resetdelay]
[font size="20"]
#hino
嗯。就是这个页面……有点奇怪[wait time="500"][er]
[resetfont]
[delay speed="100"]
#
……那时突然想起了曾经听过的话。[p]

『无论多么超自然的怪事，[r]
只要好好分析大多都能找出规律性——也就是规则』[p]
[font size="20"]
[resetdelay]
#hino
就像要掩盖谁的名字似的，[r]
上面被双重纸张覆盖着啊[wait time="500"][er]
[delay speed="100"][resetfont]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（——咦？）[p]
[bg storage="brack.png" time="100" cross="false"]
[stopbgm]
#
那为什么贤治郎先生会[p]
[mask time="1000"]
[bg storage="school/rokaN.png" time="10"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
;ＳＥ走る
[mask_off time="1000"]
[resetfont]
#makado
……入道老师！ 入道老师，您在哪儿！？[p]
[delay speed="50"]
#
在夜晚的校舍内四处奔跑。[l][r]
低年级学生拼命绘制的[r]
「走廊禁止奔跑！」的海报从余光掠过。[p]

#makado
（不行，哪个教室都没有……[wait time="500"]　没办法，接下来去三楼）[p]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥバッシャ―ン
[playse  volume="30" buf="0" storage="basya2.ogg"]
[quake time="60"]
[wse]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[font size="40"]
#makado
！！[p]
[delay speed="60"][resetfont]
#
――就在那一瞬间　从外面传来的声音，简直像是……[r][wait time="500"]
[delay speed="100"]
鲸鱼在海面全力扭转身体时的声响。[p]
[resetdelay]
#？？
[font size="40"]
怎么样——，是不是觉得神清气爽啊！[p]
[resetfont]
#makado
诶？[p]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
[chara_show name="kawa" top="-160" face="smileW" wait="false" top="-10"]
#kawa
超——痛快啊！！[r]
为什么男人就是会莫名[r]
向往那些又大又强的东西呢！[p]

;ＳＥ蝉
#
……转身望去，川铃木站在那里。[p]
[delay speed="60"]
手里抓着罐装啤酒，胳膊肘撑在打开的窗边[r]
用半梦半醒的眼神眺望着外面。[p]

#makado
（在校内喝酒……难以置信）[p]
……玛丽甘小姐没和你一起吗？[p]
[resetdelay]
#kawa:normal
啊——那位大姐啊。[l][r]
#kawa:smile
我跟她说明情况后她就不知去哪了[p]

#makado
情况？什么情况？[p]
[delay speed="50"]
#kawa:shame
[anim name="kawa" top="-=50" time="100"]
[anim name="kawa" top="+=50" time="100"]
比起这个，你也来看看。瞧那副德性—[r]
那种就叫倒错对吧？以前听熊老师说过—[p]

#makado
啊……那个！[r][wait time="500"]
比起这些，我要找入道老师……[p]

#kawa:normal
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
[anim name="kawa" top="-=60" time="200"]
[anim name="kawa" top="+=60" time="200"]
能看到这么棒的场面，跑回来真是值了！[p]
[delay speed="60"]
#makado
（对了……这人根本不会听我说话）[p]
[resetdelay]
#kawa
你也这么觉得吧？东京佬[p]
#makado
我是八种人。实在对不住[l][r]
……等等，诶？！[p]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="100"]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[delay speed="100"]
#makado
咦……在游泳池里的，[wait time="500"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
那不是入道老师吗！？[p]
[resetdelay]
#kawa
就是啊！所以我刚才不是一直说嘛！[p]

#makado
……呜哇、[quake time="30"]
你不说清楚我怎么会明白啊！[p]

#kawa:think
哈——？[p]

#makado
请好好用语言表达完整啊！[p]
#
;ＳＥ走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]

#kawa
为什么那家伙一直在那儿装潮男啊——[p]
[mask]
[bg storage="school/pool.png" time="100" cross="false"]
[chara_hide name="kawa"]
;プール
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
#makado
[mask_off time="3000"]
[font size="40"]
[quake time="30"]
[quake time="30"]
老、老师！[p][resetfont]
[delay speed="50"]
#
翻越栅栏，跳到了泳池边上。[p]
[chara_show name="nyudo" top="-100" face="normal" wait="false"]
#nyudo
啊……马门同学[p]

#makado
你在那种地方做什么啊……！[p]
[delay speed="60"]
#
入道永海正，[r]
穿着日常的衣物，从泳池中央探出上半身。[p]
这难以理解的景象……[r]
与之前理性克制的他判若两人。[p]
#nyudo
…………………………[p]
[font size="20"]
#nyudo:closeEye
该怎么说呢……让人很平静。[l][r]
这里就像是……我本该存在的地方。[p]
[resetfont]
#makado
……啊……[p]

#
或许正如入道老师所说。[r][wait time="500"]
这个念头一闪而过。[p]
[delay speed="50"]
他总是以浑身湿透的形象出现，[r]
此刻安静伫立在水中的模样……[r]
竟显得毫无违和感。[p]

他的身影，[r][wait time="500"]
比起在教室里时，[wait time="500"]比起站在路边人行道时，[r][wait time="500"]
此刻的他才是最自然”的。[p]
——明明此刻采取的行动，[r]
应该是最背离社会常理规范的。[p]
[delay speed="60"]
#nyudo:smile
[anim name="nyudo" top="+=30" time="150"]
[anim name="nyudo" top="-=30" time="150"]
呵……嘿嘿……[p]

#nyudo
果然你也觉得现在，[r]
你更适合待在水里吧？[p]
[resetdelay]
#makado
[playse  volume="10" buf="0" storage="kaminari.ogg"]
诶？[r][wait time="500"]
不、那个[p]
[delay speed="60"]
[font size="20"]
#nyudo:sad
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
没、没关系的……请不用在意[p]
#nyudo:closeEye
我会变成现在这样的体质
[playse  volume="20" buf="0" storage="sariin.ogg" ]
　也都是因为自己许下的祈愿[p]
[resetfont]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
（……原来如此 祝福——！）[p]
[delay speed="50"]
#makado
……能请您告诉我吗？[r]
只要在不造成困扰的范围内，稍微说些就好。[l][r]
[delay speed="60"]
入道老师，您祈求祝福的理由[p]
#nyudo:normal
……你们果然，[r]
看来你对狮心教的相关人员有所顾虑[r]
所以才会来到这里……[p]
#nyudo:smile
但相处一天后我明白了 马门君是个诚实的年轻人[r]
玛莉甘小姐也是 非常优秀的人——[r][wait time="800"]
想必背后有比海更深的隐情吧……[p]
[fadeoutbgm time="2000"]
[delay speed="100"]
#nyudo:normal
是啊…………你[wait time="500"][r]
正是像你这样耿直的人[p]

#makado
诶？[p]
#nyudo
你可曾想过……当英雄挺身而出拯救他人时，[l][r]
那些被救之人……[wait time="500"]将如何度过余生？[r]
你有想象过吗？[p]

#makado
英雄……挺身而出？[p]
[resetdelay]
[font size="20"]
#nyudo:closeEye
挺身而出。舍弃性命。牺牲自我。[p]
[delay speed="80"]
#nyudo:sad
在电视新闻里，偶尔会看到吧。[r]
在盛夏时节，这种故事总是会被反复传颂……[p]
[resetfont]
#nyudo:closeEye
八种也不例外。[r]
为了拯救在河中溺水、被水流冲走的孩子……而，[r]
本应拥有未来的勇敢者，纵身跃入，消逝…………[p]
[delay speed="60"]
#nyudo:normal
而我，却是在海里遭遇了这样的结局。[p]

#makado
…………[p]
#
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[quake time="30"]
[wait time="1000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
背后，传来某人落地的声响。[p]
[chara_hide name="nyudo" time="10"]
[chara_show name="kawa" top="-10" face="smile" wait="false"]
[resetdelay]
#kawa
哟～。哈哈哈，这可真是够夸张的[p]
[chara_hide name="kawa" time="10"]
[chara_show name="nyudo" top="-100" face="closeEye" wait="false"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[delay speed="60"]
#nyudo
我始终觉得……自己比不上那位为我牺牲之人的生命价值，[r]
永远都无法认为自己更为出色[p]
#nyudo:normal
但是……只有‘那样”的话，是不行的。[r]
毕竟我已经夺走过一条性命了[p]
[chara_hide name="nyudo" time="10"]
[chara_show name="kawa" top="-10" face="smile" wait="false" time="300"]
[resetdelay]
#kawa
还是这么阴沉呢～。[r]
就当是捡了个大便宜不就好了嘛—。[p]

#makado
说到海……就不是在八种发生的事了吧？[p]
[delay speed="60"]
[chara_hide name="kawa" time="10"]
[chara_show name="nyudo" top="-100" face="normal" wait="false" time="300"]
#nyudo
嗯。我的家乡是在岩手那边……[l][r]
[delay speed="100"]
#nyudo:closeEye
可是呢……已经无法留在故乡了。[r]
无论看向何处看见什么，都只剩他的残影………[p]
[font color="0xf08080"]
#
身体变得僵硬。[p][resetfont]
[resetdelay]
#makado
说什么遗迹，请别开玩笑了[p]
[delay speed="100"]
[font size="20"]
#nyudo:normal
……？ 嗯，是不是不太好啊……[p][resetfont]
#nyudo:sad
……对我这个开始闭门不出的人，[r]
是外婆她，给我介绍了……狮心教。[r]
就这样　我，开始，祈祷――[p]
[resetfont]
#nyudo:closeEye
『如果自己[wait time="500"]　能化为大海』[wait time="500"]这般[p]
[resetdelay]
#kawa
真是可笑啊—。[r]
你说的事情，规模上相当于魔王级别啊——[p]

#makado
……于是你就这样，变成大海了吗？[p]
[delay speed="100"]
#nyudo
正在逐年变得接近海洋般的存在……[p]
[delay speed="60"]
#nyudo:normal
但我发现啊，所谓被赐予的祝福，[r]
随着使用时间的累积[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]事态逐渐恶化。[resetfont][p]
[delay speed="60"]
#nyudo:sad
原本正常的肌肤逐年变得湿润，[r]
身体也越发庞大起来…………[p]
#nyudo:smile
最近，[r]
每当情绪极度低落时……甚至能召唤出雨云。[r][wait time="500"]
说不定……我能创造出一片海洋呢。[p]
#
——雨云？[p]
[resetdelay]
#makado
您能……让天下雨吗？[p]
[delay speed="100"]
#nyudo:normal
嗯……[r]
虽然我觉得……必须小心控制才行呢……[p]

#makado
（…………）[p]
[chara_move name="nyudo" left="-100" wait="false"]
[chara_show name="kawa" left="380" top="-10" face="smileW" wait="false" width="-=100"]
[resetdelay]
#kawa
这不是挺厉害的嘛—。[r]
把整个镇子淹了的话——连班都不用上了呢—[p]
[delay speed="60"]
#nyudo
川铃木老师……[r]
永远都活得那么逍遥自在……真是令人钦佩呢[p]
[resetdelay]
#kawa:smile
那当然啦—。『不受任何人影响地生活』这件事啊[r]
就是俺的人生目标嘛—[p]
[delay speed="60"]
#nyudo:smile
呵、呵呵……[r]
明明说着不想受任何人影响……[r]
可每次值日锁门的工作都主动接下呢……[p]
#nyudo:smile
马门君……他啊，意外的是个好老师呢……[p]

#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……每次都主动负责锁门？[p]
[resetdelay]
#makado
诶？等一下、[r]
那今天川铃木老师也负责了校园的锁门工作吗？[p]

#kawa:normal
哦—[p]

#makado
结果傍晚就去烤肉店喝酒、[r]
还顺便把罐装啤酒带进教学楼里闲逛是吧？！[p]

#kawa:shame
要当老师的话—，去私立学校比较好哦—。[r]
毕竟私立学校比较自由嘛—[p]
[font size="40"]
#makado
[playse  volume="30" buf="0" storage="kaminari.ogg"]
你这自由过头了啊！！！[p][resetfont]

#kawa:sad
好啦好啦。总之现在先安慰一下被玛丽甘女士甩了的[r]
可怜的入道老师吧—[p]
[font size="20"]
#nyudo:closeEye
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
…………！！被甩……！[p][resetfont]
[mask time="10"]
[chara_hide_all time="100"]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥバッシャ―ン
[playse  volume="40" buf="0" storage="basya2.ogg"]
[wse]
[mask_off time="1000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[font size="40"]
;ＳＥざっぱーん
#makado
[quake time="100"]
呜哇……！[p][resetfont]
#
[delay speed="50"]
从头到脚被浇了个透心凉。[p]

和刚才听到的一样，如同鲸鱼跃起般的浪花声。[r]
而这次，浪花就在身旁突然掀起。[p]
[delay speed="100"]
#makado
（这是……原来如此，虽然看不见，但这是入道老师搞的鬼吗……）[p]
[delay speed="50"]
[font size="20"]
#nyudo
呜……呜呜……玛、玛丽甘小姐……我……[p][resetfont]
[resetdelay]
#kawa
入道老师——我们赶紧切换下个话题吧——。[l][r]
恋爱说到底只能和相配的人维持下去啊——[p]
#nyudo
[delay speed="50"]
[font size="20"]
别……还是安慰我一下吧……[r]
现在这句话比什么都扎心啊…………[p]
[resetfont]
[delay speed="50"]

#
——依旧浑身湿透地，[r]
我呆呆地望着这两个成年人之间的互动。[p]

川铃木她……[r]
还在对抽抽搭搭哭着的入道不停地挥手。[r]
说不定他们意外地很合拍呢。[p]
内向又不善言辞的入道，[r]
应该也会被川铃木那种直来直去不拘小节的性格所拯救吧。[p]

#makado
……………………[p]

#makado
……总觉得，这样也挺好的[p]
[chara_show name="kawa" top="-10" face="think" wait="false"]
#kawa
喂喂，说什么呢。对入道老师太失礼了吧。[r]
『我也想尝尝失恋的滋味呢(笑)』这种话都说得出口啊[r]
这个神佛合一的家伙[p]
[delay speed="60"]
#makado
不、不是这样的……[l][r]
只是觉得，果然同龄的朋友真好啊……[p]
#
……在那一瞬间，我是真心这么想的。[p]

[mask time="100"]
[stopbgm]
[chara_hide name="kawa" time="10"]
[bg storage="indoor/sisin_holl.jpeg" time="10"]
[chara_show name="hino" top="-100" face="shame_s" time="10"]
[wait time="3000"]
[playbgm storage=gymnopedies2.ogg loop=true volume=50]
[mask_off time="100"]
#hino
[font size="40"]
志户田，你听到了吗！？[p]
[chara_hide name="hino" time="10"]
[chara_show name="sarasa" top="-160" wait="true" time="100" face="wow_s"]
#sarasa
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
诶[p][resetfont]
[stop_kanim name=sarasa]
[chara_hide name="sarasa" time="10"]
[chara_show  name="aki" left=140 top=-100 wait="false" top="-100" face="normal_s"]
[chara_show  name="riki" face="normal_s" left=360 top=-100 wait="false"]
#hino
[chara_show  name="hino" left=-100 top="-100" wait="true" face="angry_s" time="100"]
这个、[r]
[resetdelay]
『茧之典』里被从上贴纸遮盖住的部分。[r]
你难道不好奇上面写了什么吗！？[p]
[delay speed="60"]
#sarasa
那个……嗯，是挺在意的，不过……[p]
[resetdelay]

#hino:tweet_s
所以，由我来把这个[playse  volume="20" buf="0" storage="kakan.ogg" ]
【只点燃贴在上面的纸】[r]
这样，你觉得如何？[p]
[chara_hide_all time="10"]
[chara_show name="suguru" top="-100" face="normal_s" wait="false" time="300" left="360"]
[chara_show name="ituki" top="-160" face="hate_gs" wait="false" time="300" left="-70"]
#ituki
这种把戏，你以为会被允许吗？[p]
[delay speed="60"]
#suguru:wow_s
这可能是关乎人命的秘密啊。[r]
志户田前辈有知情权。[wait time="500"]当然我们三宫女也一样[p]

#ituki:angry_gs
……[p]

#suguru
我不会让你抱怨的。姐姐[p]
#
[mask folder="bgimage" graphic="still/mayuten1.png" time="10"]
[stopbgm]
[chara_hide_all time="10"]
[wait time="2000"]
[bg storage="school/pool.png" time="100"]
[mask_off time="10"]
[playbgm storage=gymnopedies2.ogg loop=true volume=50 sprite_time="40000"]

[delay speed="50"]

#makado
……啊[p]
#
低头时，映入眼帘的是滴着水珠的【神厩舍注连绳】。[p]
[delay speed="70"]
#makado
（糟了，纸垂都……！得先晾起来才行……）[p]
[delay speed="50"]
#
把注连绳挂在围栏上，脱下夹克。[p]
T恤比想象中湿得更厉害，[r]
索性脱下来拧干。[p]
#
[mask folder="bgimage" graphic="still/mayuten1.png" time="10"]
[stopbgm]
[wait time="1000"]
[bg storage="indoor/sisin_holl.jpeg" time="10"]
[chara_show name="ituki" top="-160" face="angry_gs" time="10"]
[mask_off time="10"]
[playbgm storage=gymnopedies2.ogg loop=true volume=50 sprite_time="60000"]
#ituki
那页纸上，那个机关……[r]
当我继承茧的典籍时　它就已经存在”了[p]

#ituki:hate_gs
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
所以我家……根本不知道啊。无论出现什么真相[p]

#sarasa
没关系。任何真相都行[p]

#sarasa
这难道是……[r]
如果这是封印阿黑冥加所必需的情报，[r]
我、不能视而不见[p]

#ituki
………………………………………………[r][wait time="500"]
#ituki:angry_gs
……随你、便吧[p]
[chara_hide name="ituki"]
[chara_show name="hino" time="100" top="-100" face="angry_s" wait="false" ]
#hino
好、那就、烧掉吧…………！[p]
#
日野汗湿的手，悬停在『茧之典』上方。[p]
[chara_hide name="hino" time="10"]
[mask folder="bgimage" graphic="still/mayuten1.png" time="10"]
[stopbgm]
[wait time="2000"]
[bg storage="school/pool.png" time="10"]
[chara_show name="kawa" top="-10" face="normal" time="10"]
[mask_off time="10"]
[playbgm storage=gymnopedies2.ogg loop=true volume=50]

#kawa
……咦、喂？[p]

#kawa
贤治郎——
你背上——沾着脏东西哦——[p]
[delay speed="100"]
#makado
诶……？垃圾？[p]
#
[mask folder="bgimage" graphic="still/senaka1.png" time="10"]
[stopbgm]
[bg storage="still/senaka1.png" time="10" cross="false"]
@layopt layer=message0 visible=false
[clearfix]
[wait time="3000"]
[chara_hide name="kawa" time="10"]
[mask_off time="6000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
……………………………………………………[p]
[delay speed="50"]
#makado
不好意思。我看不见……在哪里？[p]

#kawa
哈～真拿你没办法～[p]

嘛～反正就是看着碍眼，我帮你拿掉吧～[p]
[bg storage="brack.png" cross="false" wait="true"]
#kawa
喏[p]
[fadeinbgm storage=bigriver.ogg loop=true time=5000 volume="10"]
#
@layopt layer=message0 visible=false
[clearfix]
;スチル：黄色の目
[bg storage="still/senaka2.png" time="10" cross="false"]
[wait time="4000"]
[bg storage="still/senaka3.png" time="2000" cross="false" wait="true"]
[wait time="5000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
…………………………………………[p]
[delay speed="100"]
#makado
——哎？[p]
#
——在眼前。[p]

眼前展开的景象是……[r][wait time="700"]
过于超脱尘世的、[wait time="700"]神乎其神的、[wait time="700"]现实。[p]
@layopt layer=message0 visible=false
[clearfix]
;スチル；繭の典　#makado#makadoの名
[bg storage="still/mayuten2.png" time="10"]
[wait time="4000"]
;スチル：灰色の目　顔に被る影
[bg storage="still/senaka3.png" time="10" wait="true" time="2000" cross="false"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

宛如怪兽电影里的怪物。[r]
巨大无比的「入道永海」的身影，就矗立在那里。[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/mayuten2.png" time="3000" cross="false" wait="true"]
#riki
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="indoor/sisin_holl.jpeg" time="2000" wait="false" cross="false"]
呜……诶？这是啥？[p]

#aki
…………[p]

#hino
等、等一下，让我捋捋……[p]

#sarasa
……嘘、[p]
[resetdelay]
#
不是骗人的。[p]
[delay speed="100"]
[bg storage="school/pool.png" time="300"]
#makado
……这个，[wait time="700"]是……[p]

#makado
入道老师，这就是，你的…………[p]
[resetdelay]
#nyudo
……啊，马门君[p]
[chara_show name="nyudo"  top="-500" wait="false" face="ghost"]
#nyudo
终于，对上视线了呢[p]

#makado
…………[p]

#makado
骗人的[p]
[chara_hide name="nyudo" wait="false"]
[resetdelay]
#
不是谎言。[p]

[bg storage="brack.png" cross="false" wait="true"]
#
时间不会说谎。[r]
事件不会说谎。[p]
[delay speed="70"]
土地也[wait time="700"]不会说谎。[p]

会撒谎的[wait time="700"]永远只有人类。[p]

[mask]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
;ＳＥ走る
[mask_off]

#sarasa
哈啊……哈啊……[wait time="700"][quake time="30"]贤治郎先生！！[p]
[bg storage="fork_n.jpg" cross="false" wait="true"]
[resetfont]
#makado
…………[p]
[resetdelay]
[chara_show name="sarasa" top="-160" face="angry_s" wait="false"]
#sarasa
贤治郎先生……请听我说。[r]
我从小学六年级的冬天开始，就一直有两种辨认他人的方式。[p]
#sarasa:worry_s
第一种是，不像此世之物的异形姿态……[r]
另一种则是与我相同的人类”容貌[p]
#sarasa:closeEye_s
其中以人类容貌呈现的存在[r]
逐渐扭曲蜕变为异形的过程[r]
就是我目睹『祝福』时的感受……[p]
#sarasa:angry_s
——但是！今天从贤治郎先生那里听闻的故事，[r]
以及造访『茧之家』的经历[r]
这个认知差异的谜题，终于解开了……！[p]
#sarasa:worryLA_s
我只有对狮心教的眷属之人，[r]
才能正确视作人类…………[wait time="700"]而且……！[p]
[delay speed="60"]
#sarasa:worry_s
贤治郎先生………[r]
难道也是狮心教的眷属吗！？[p]
;-------------------------------------------------------------------------------

[chara_face name="makado" face="hurryLA_ce" storage="chara/makado/trueEye_Cap/hurryLA_ce.png"]
[chara_face name="makado" face="bike_ce" storage="chara/makado/trueEye_Cap/bike_ce.png"]
;-------------------------------------------------------------------------------

#
[chara_move name="sarasa" left="360" anim="true" wait="false" time="500"]
[chara_show name="makado" top="-80" left="-70" wait="false" time="500" face="bike_ce"]
[delay speed="100"]
#makado
………………………………………………[p]

#makado:hurryLA_ce
………………………………我、[p]
#
人类无论何时，[r]
我只会看见自己希望看见的事物。[p]
[chara_hide_all time="10"]
[bg storage="still/mayuten2.png" time="10"]
@layopt layer=message0 visible=false
[clearfix]
[wait time="2000"]
[bg storage="brack.png" cross="false" wait="true"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
快来寻找我吧……[l][r]
然后　[wait time="700"]来见我[p]
[resetdelay]
[mask folder="bgimage" graphic="still/part3.png" time="100"]
[wait time="2000"]
[stopbgm]
[playse  volume="40" buf="0" storage="basya2.ogg"]
[wse]
[wait time="1000"]
[showsave]

@jump storage="chapter_4/day2.ks"






;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------
[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
