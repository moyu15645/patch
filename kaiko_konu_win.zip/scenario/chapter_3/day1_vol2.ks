;第3章『彼が五齢に着替えたら』
;一日目後編
;-------------------------------------------------------------------------------
*part3
;-------------------------------------------------------------------------------
[eval exp="f.save_title = '三章一日目　後編'"]
[free_filter]
[chara_hide_all time="10"]
[bg storage="still/mokke_1.png" time="100"]
[fadeinbgm storage=onedari.ogg loop=true time="1000" volume=50 sprite_time="0200-21000"]
[mask_off time="1000"]
#
【至此的剧情梗概！】[p]
[delay speed="50"]
被城里作恶的妖怪「黑雾怪」盯上了[r]
扮演御白姬的纱罗纱。[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/mokke_2.png" time="100"]
直到能从御白姬的角色脱身为止……也就是说[r]
在白绢祭结束之前[r]
要和祭主的贤治郎君一起努力战斗！[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/mokke_3.png" time="100"]
被黑雾怪诅咒的人[r]
对纱罗纱而言[r]
看起来超级～可怕的样子···[p]
没想到啊！那个可怕～的模样，[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/mokke_4.png" time="100"]
竟然是城里宗教团体「狮心教」的信徒[r]
从御白姬那里获得的「祝福」呢！[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/mokke_5.png" time="100"]
那黑雾怪的诅咒又是啥？[r]
而且狮心教里头[r]
好像还牵扯到我重要的闺蜜树月酱···[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/mokke_6.png" time="100"]
我的暑假到底会变成怎样啦～！？[p]

[mask time="1000"]
[fadeoutbgm time="4000"]
[wait time="4000"]
[bg storage="indoor/miyage.jpeg" time="100"]
[chara_face name="mokke" face="marigan"  storage="chara/mokke/longRed.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '紀伊 マリガン'
[endscript]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_show name="mokke" top="100" time="10" face="marigan"]
[mask_off]

#mokke
嗨你好～非常感谢啦[p]
[chara_hide name="mokke" time="10"]
[chara_show name="hino" face="smile_s" time="100" wait="true" top="-100"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[font size="40"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
马利甘小姐！！[p][resetfont]
[chara_hide name="hino" time="10"]
[chara_show name="mokke" face="marigan" time="100" wait="false" top="100"]
#mokke
哦！这不是日野嘛！辛苦啦！[r]
你居然来了啊[p]
[chara_hide name="mokke" time="10"]
[chara_show name="aki" top="-60" left="400" wait="false" face="normal_s"]
[chara_show name="makado" top="-60" left="-150" wait="false" face="normal"]
[chara_show name="riki" top="-60" left="100" wait="false" face="worry_s"]
#riki
哇……简直像大明星一样[p][resetdelay]
#makado:tweet
确实很有都市丽人的感觉呢……[p]
#aki:tweetLA_s
不过八种当地的雾绘小姐也是同等程度的美人啊[p]
[chara_hide_all time="10"]
[chara_show name="mokke" wait="false" face="marigan" top="100"]
[delay speed="100"]
#mokke
那边那个黑皮小鬼　你刚才说啥？[p]
[chara_hide name="mokke" time="10"]
[chara_show name="aki" top="-60" left="400" wait="false" face="normal_s"]
[chara_show name="makado" top="-60" left="-150" wait="false" face="normal"]
[chara_show name="riki" top="-60" left="100" wait="false" face="wow_s"]
#riki:
呃……？[l][r][resetdelay]
[chara_mod name="riki" face="sad_s"]
没、没有啦，就是觉得像女明星一样……[p]
[delay speed="100"]
[chara_hide_all time="10"]
[chara_show name="mokke" wait="false" face="marigan" top="100"]
[fadeoutbgm time="2000"]
#mokke
………………………[l][r]
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
臭小鬼……敢小瞧人就宰了你……[p]
[chara_hide name="mokke" time="10"]
[playbgm storage=fuon.ogg loop=true time=300 volume="50"]
[font size="40"]
#
[chara_show name="aki" top="-60" left="400" wait="false" face="wow_s"]
[chara_show name="makado" top="-60" left="-150" wait="false" face="wow"]
[chara_show name="riki" top="-60" left="100" wait="false" face="wow_s"]
[playse  volume="30" buf="1" storage="kaminari.ogg" ]
[quake time="30"]
——！？[p][resetfont]
[delay speed="50"]
[chara_hide_all time="10"]
[chara_show name="mokke" wait="false" face="marigan" top="100"]
#mokke
老娘我啊……[r]
现在虽然勉强接受当个不入流的艺人[r]
本质上可是高贵优雅的民俗学者好吗[p]
[resetdelay]
;ＳＥ机バン
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
#mokke
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=mokke keyframe=up time=300 wait="false"]
这一切的一切都是……！[r]
都怪老娘我获得了这稀世美貌！[r]
执着的投资才造就了现在这个畸形的处境！！[p][stop_kanim name=mokke]
[delay speed="10"]
[font size="37"]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
啊啊！！何等悲剧！[r]
谁来帮我全身按摩祛除污秽啊！[r]
因为是夏天嘛！开玩笑的！[p]
[stopbgm][resetfont][resetdelay]
[playse  volume="20" buf="2" storage="kakan.ogg" ]
八种才媛 纪伊玛莉甘是也[r]
多指教啦山里的饿鬼们[p]
[chara_hide name="mokke" time="10"]
[chara_show name="hino" top="-100" face="happy_s" time="100" wait="true"]
[anim name="hino" top="+=70" time="150"]
[anim name="hino" top="-=70" time="150"]
[font size="37"]
#hino
[playse  volume="30" buf="0" storage="kansei.ogg"]
玛莉甘小姐！今天也超有型！！[p][resetfont]
[chara_hide name="hino" time="10"]
[chara_show name="aki" top="-60" left="400" wait="false" face="sad_s" time="100"]
[chara_show name="makado" top="-60" left="-150" wait="false" face="worry" time="100"]
[chara_show name="riki" top="-60" left="100" wait="false" face="worry_s" time="100"]
[delay speed="50"]
#aki
嗯……帅呆了[p]

#riki
好可怕[p]

[mask]
[chara_face name="mokke" face="kobayasi"  storage="chara/mokke/motiYellow.png"]
[chara_hide_all time="10"]
[chara_show name="riki" top="-100" time="10" face="worry_s"]
;一回暗転挟む
[mask_off]

#riki
……然后呢[p]

;ＳＥやかんプシュー
#riki:shoutG_s
[font size="37"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
凭什么我们[r]
非得帮忙收拾不可啊——！！[p][resetfont]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_hide name="riki" time="10"]
[chara_show name="aki" top="-100" face="tweetLA_s"]
#aki
喂 力君 有空耍嘴皮子的话[r]
把那边纸箱递过来[p]
[chara_hide name="aki" time="10"]
[chara_show name="mokke" left="100" face="marigan" top="100" wait="false"]
[chara_show name="hino" top="-100" face="smile_s" wait="false" left="360"]
#mokke
哎呀～得救了啊日野～[r]
带了这么多朋友来帮忙[p]
今天活动事务所那边完全没派人手过来啊～[r]
差点就要搞不定了呢！明明都借好场地了[p]

#hino
哪里！[r]
能帮上玛莉甘小姐的忙是我的荣幸！[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="tweet" time="100" wait="false"]
#makado
隔断板全都装上车了[p]
[resetdelay]
[chara_move name="makado" left="-70" wait="false"]
[chara_show name="mokke" face="kobayasi" wait="false" left="500" top="100"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'スタッフ'
[endscript]
#mokke
你小子，带保鲜盒来真是帮大忙了～[r]
怎么样？对地方偶像或者模特之类的工作感兴趣吗？[p]
#makado:sad
呃……[p]
[chara_hide name="makado" time="10" pos_mode="false"]
[chara_mod name="mokke" face="marigan"]
[chara_move name="mokke" left="300" time="100" wait="true"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '紀伊  マリガン'
[endscript]
#mokke
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
喂小林！不要对圈外人出手啊！[p]　
[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_c" wait="false"]
[delay speed="60"]
#sarasa
……那个[p]
[chara_move name="sarasa" left="360" wait="false"]
[chara_show name="mokke" left="100" top="100" face="marigan" wait="false" time="100"]
#mokke
嗯？[p]
#sarasa
[playse  volume="50" buf="0" storage="book.ogg" ]
这个……请给我一本[p]
[resetdelay]
#mokke
哇、平等院的王牌。[l][r]
你是第一次见的孩子呢。是日野的同班同学之类的吗？[p]
#sarasa:normal_c
是的……我叫志户田纱罗纱[p]
#mokke
啊……今年志户田纺织的御白姬扮演者啊。[r]
难怪这么生涩[p]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
挺上心嘛。想在祭典前先了解小镇历史？[r]
不过我这个新手写的书可能有点难懂哦？[p]

#sarasa:closeEye_c
没关系的……。[r]
即便如此，我也必须查清楚……[p]

#mokke
…………[wait time="700"][r]
——嘿 这样啊[p]
[delay speed="60"]
[playse storage=page.ogg volume="50"]
#mokke
今年的白绢祭是……呃。27号来着？[p]
[resetdelay]
拿去吧。不用给钱。箱子里随便挑。[r]
反正屯着在这小镇也卖不完啦[p]
#sarasa:worry_c
诶……可是……[p]

#mokke
别客气。[r]
[anim name="mokke" left="-=80" time=50 ]
[anim name="mokke" left="+=80" time=50 ]
[chara_mod name="sarasa" face="worryLA_c"]
快点 收下啦！那个平等院！[p]
[chara_mod name="sarasa" face="worry_c"]
#mokke
作为交换来帮我收拾摊子吧。[r]
其他孩子抢先一步不让你干活儿的手段[r]
早就被我看穿啦[p]
#
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="500"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="500"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="500"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="800"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[playse  volume="50" buf="0" storage="book.ogg" ]

#sarasa:closeEye_c
[anim name="sarasa" top="-=60" time="150"]
[anim name="sarasa" top="+=60" time="150"]
呜……[p]
#
纪伊玛莉甘径直走到我面前，[r]
二话不说就把纸箱塞进我怀里。[p]
#mokke
被人宠着可不行呢。[r]
想知道什么就得自己跑腿。这是调查的基本准则[p]

#sarasa:normal_c
——！[l][r]
[chara_mod name="sarasa" face="smile_c"]
……好的，玛莉甘小姐[p]
[mask]
[chara_hide_all time="10"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="900"]
[bg storage="brack.png" time="10"]
#
[mask_off]
[delay speed="60"]
;商店街
抱着双层叠放的纸箱，沿着店铺外的小巷前进。[p]

#sarasa
（虽然看不见前面……[l][r]
往这边走的话，车应该就停在那里……）[p]
#
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
就在这时。[l][r]
脚下突然绊了一下，货物的平衡瞬间被打破————！[p]
[font size="40"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="100"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
#sarasa
哇……！[p][resetfont]
[stopbgm]
[playse  volume="70" buf="0" storage="book.ogg" ]
@layopt layer=message0 visible=false
[clearfix]
[quake time="70"]
;暗転
[wait time="1000"]
;ＳＥドサ
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
………………[l][r]
………………………………？[p]
[delay speed="80"]
纸箱仍稳稳地被我抱在怀中。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
似乎有人从对面帮忙扶住了……[p]

#sarasa
那个……非常感谢，呃……[p]

#？？
……[p]

#sarasa
对不起……我现在看不见前面……[p]

#？？
…………[p]

;ＳＥ走っていく
[playse storage=run.ogg volume="60" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]

#sarasa
……？[p]
#
…………[r][delay speed="100"]
刚才那个人……究竟是谁呢。[p]
[resetdelay]
[mask]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[bg storage="indoor/miyage.jpeg" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="smileCE_s" time="100"]
;商店街
[mask_off]
[font size="40"]
#riki
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
呼——总算搞定了！！[p][resetfont]
[chara_hide_all time="10"]
[chara_show name="mokke" wait="false" face="marigan" top="100"]
#mokke
辛苦啦小鬼们！干得漂亮哟～[p]
[chara_hide name="mokke" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
[chara_show name="riki" top="-100" left="400" wait="false" face="smileCE_s" time="100"]
#aki
[chara_show name="aki" top="-100" left="-150" wait="false" face="worry_s" time="100"]
居然对初次见面的[r]
小孩子强行塞工作过来[p]

#riki:sad_s
就是说啊——。虽然日野可能还挺开心的——[r]
我们被卷进来可真是倒大霉了！[p]
[chara_hide_all time="10"]
[chara_show name="mokke" wait="false" face="marigan" top="100" time="100"]
#mokke
说什么天真的小鬼啊。[l][r][delay speed="80"][fadeoutbgm time="2000"]
你们两个明明是连大人都望尘莫及的[font color="0xf08080"]超常现象化身[resetfont]呢[p]
[chara_hide name="mokke" time="10"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_show name="riki" top="-100" face="smileH_s" wait="false" left="-70"]
[chara_show name="aki" top="-100" face="hate_s" wait="false" left="360"]
………………[p]

#riki:normal_s
国雄……刚刚是你在说话？[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" face="normal_s" time="100" wait="false"]
#hino
不，不是我。我什么都没说[p]
[chara_hide name="hino" time="10"]
[chara_show name="riki" top="-100" face="smileH_s" wait="false" left="-70" time="100"]
[chara_show name="aki" top="-100" face="hate_s" wait="false" left="360" time="100"]
#aki
……阿姨你知道狮心教的”祝福”吗？[p]
[chara_hide_all time="100"]
[resetdelay]
#mokke
这不是当然的吗。[r]
我可是在八种进行田野调查时小有名气的学者哦？[p]
日野会带来的同学嘛[r]
反正肯定是狮心教的孩子吧……[p]
[chara_show name="makado" top="-10" face="wowCM" left="-70" wait="false"]
#mokke
[chara_show name="mokke" top="100" left="600" wait="false" face="marigan"]
应该也接受过祝福吧？[r]
御白姬的祝福是[font color="0xf08080"]授予未成年眷属[resetfont]的[p]
[delay speed="50"]
#makado
……未成年？还有这种规定……？[p]

#mokke
没错。[l]无论多玄乎的事件，[r][delay speed="60"]
只要好好分析基本都能发现规律——或者说规则哦[p]

#makado:tweet
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[anim name="makado" top="+=30" time="150"]
[anim name="makado" top="-=30" time="150"]
[font size="40"]
……！[p]
[delay speed="100"][resetfont]
#makado:tweetLA
……你是……[p]
[resetdelay]
#mokke
从和尚随身带着【神厩舍的注连绳】那一刻起[r]
我就有不祥的预感了……[p]

祭主和御白姬一起行动这件事[r]
【封印の絹布】是出什么意外了吗？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" face="closeEye_c" wait="false" time="100"]
[stopbgm]
#sarasa
是的[p][delay speed="60"]
[chara_mod name="sarasa" face="normal_c"]
绢布在 这个月初被烧毁了[p]
[resetdelay]
[chara_move name="sarasa" left="360" anim="true" wait="false"]
[chara_show name="makado" top="-60" left="-70" time="100" face="wow"]
[quake time="30"]
#makado
！？[p]
[delay speed="100"]
#makado:worryB
诶……[wait time="300"]那个……[p]
[delay speed="50"]
#makado:closeEye
（纱罗纱，这件事还是——）[p]

#sarasa:closeEye_c
没问题的[p][r]
[chara_mod name="sarasa" face="normal_c"]
大概……因为马利根先生是[wait time="300"][font color="0xf08080"]不受诅咒之人[resetfont]吧[p]

#makado:worry
诶……！？[p]
#
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
我转身正对贤治郎先生。[r]
为了传达自己的话语。[p]

#sarasa:closeEye_c
…………但还没有十足把握……[r]
或许会因此被诅咒也说不定[p]
#sarasa:normal_c
但是比起那些……现在[r]
我觉得先听取这位先生的讲述更重要[l][r]
不行吗？[p]

#makado:wow
…………[p]
[chara_hide name="makado" wait="false"]
#sarasa:closeEye_c
…………马利根先生……[r]
我们正在调查「暗暗凭」诅咒的规则[l][r]
[chara_mod name="sarasa" face="normal_c"]
所以如果可以的话……请借给我们你的力量[p]
[chara_hide name="sarasa" time="1000" wait="false"]
#
马利根听完我的话后……[l][r]
从鼻子里发出短促的嗤笑。[p]
[chara_show name="mokke" face="marigan" top="100" wait="false" time="100"]
[delay speed="20"]
#mokke
不错。我喜欢！[r]
果然公主殿下就是要任性才够味儿啊[p]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
小林——！[r]
去告诉老板把休息区借给我们用！[r]
要是被拒绝就把我的写真集送他！[p]
[delay speed="60"]
[font size="20"]
#小林
诶～？这也能当谈判筹码吗～[p]
[quake time="30"]
#mokke
[font size="40"]
闭嘴！[p][resetfont]
[chara_hide name="mokke" wait="false"]
[bg storage="brack.png" wait="false" cross="false"]
[resetdelay]
#
她[r]
走向店内角落摆放着圆桌和长椅的区域，[l][r]
从中拖出一把椅子……然后招手示意。[p]
[delay speed="50"]
#mokke
来坐下吧，志户田纺织的大小姐。这是你的专座[p]
整座城市的东西都可以是你的。[r]
只要你开口的话[p]
[mask]
[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=30]
[bg storage="indoor/miyage2.jpeg" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="normal_s" time="100"]
[mask_off]
;土産屋（本棚）
[resetdelay]
好久没吃五平饼了啊—[p]

#aki:wow_s
诶？暑假前营养午餐不是才吃过吗[p]

#riki:smile_s
啊咧—有这回事吗—？喂日野你还记得吗—？[p]

#hino
…………[p]

#riki:hate_s
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
喂————日野————[p]
[font size="40"]
#hino:angry_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
吵死了！会分心啊[r]
还有别靠过来 核桃酱会把书弄脏的[p][resetfont]
#riki:worry_s
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
至少大家聚在一起的时候理我一下啊笨蛋！！[p]
[chara_hide_all time="100"]
#
邻桌的狮心教少年们正[r]
正大口吃着玛丽甘买的五平饼。[r]
[font size="20"]（日野だけ早々と食べきったようだが……）[p][resetfont]
[chara_show name="mokke" face="marigan" top="100" wait="false"]

#mokke
……嘿，你们俩居然能单独撑到现在啊[p]
[chara_hide name="mokke" wait="false"]
[playse storage=page.ogg volume="50"]
;持ち物スチル：#makadoのメモ
[image layer=0 folder="image" name="makado_memo_c" storage="item/makado_memo_c.png" width="500" x="230" y="52" time="800" visible="true" ]
#makado
虽然几个小时前有个条目突然消失了……[p]

#mokke
什么东西消失了？[p]
[delay speed="60"]
#sarasa
[font color="0xf08080"]纱罗纱能够通过视觉辨别诅咒[r][resetfont]
的条目[p]
[resetdelay]
#mokke
嗯——是不是因为某些事件让你意识到认知错误？[l][r]
发生了什么？和诅咒有关的事？[p]

#sarasa
（……玛丽甘小姐是在要求我用自己的经历来解释）[p]
;-------------------------------------------------------------------------------
*sugata
;-------------------------------------------------------------------------------

#
[delay speed="50"]
至今为止[font color="0xf08080"]被我认为是受诅咒者形态的东西[resetfont][r]
其实[font color="0xf08080"]并非受诅咒者的真正形态[resetfont]　这个认知转变的原因是[r]
能作为依据的……只有那次经历了[p]

#
[link target="*sugata_yes"]【１】关于前几日看到的日野的样子[endlink][r]
[link target="*sugaa_no"]【２】关于前几天看到的优的态度[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*sugaa_no
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

;▶先日視た日野の姿について
;▶先日見たすぐるの態度について
;▶#suguruの態度について
[font size="40"]
[quake time="30"]
#hino
诶！？[r]
难道是聪君出什么事了吗！？[p][resetfont]

#sarasa
（啊……不对。我……在说什么啊）[p]

@jump target="*sugata"
;-------------------------------------------------------------------------------
*sugata_yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

;▶#hinoの姿について

#sarasa
……前几天，[r]
被受诅咒的阿基追赶时发生的事……[p]
[mask]
[filter grayscale="100"]
[free layer=0 name="makado_memo_c" time="10"]
[bg storage="still/aki_2.png" time="10"]
[mask_off]

#sarasa
他身上有着，[r]
仿佛被撕裂般巨大的空洞……呈现着[font color="0xf08080"]异形的姿态[resetfont][p]
[bg storage="brack.png" wait="false" cross="false"]

;スチル；先日の#aki
#sarasa
而从那副[font color="0xf08080"]受诅咒的模样[resetfont]的阿基身边[r]
拯救了我的却是……[p]
[chara_show name="hino" top="-100" face="ghost" wait="false"]
同样具备[font color="0xf08080"]理应被诅咒的外形[resetfont]——[l][r]
能使用超常能力的日野[p]

#aki
啊——那个啊。[r]
突然被烈火包围的时候我真的超害怕的……[p]
[delay speed="10"]
#hino
我们也被你害得吓个半死好吗！？[p]
[resetdelay]
#sarasa
结合狮心教所谓的「祝福」来看，[r]
现在回想当时的情形……[p]
[delay speed="50"]
#sarasa
能以异形之姿使用超能力这点，绝不意味着那个人[r]
[font color="0xf08080"]这并不能成为她辨别是否被诅咒的理由……[resetfont][p]
反而该从更本质的层面，去辨识今后可能遭遇的受诅咒者[r]
最终我们得出了这样的结论[p]
[mask]
[free_filter]
[chara_hide name="hino" time="10"]
[bg storage="indoor/miyage2.jpeg" time="10"]
[chara_show name="mokke" face="marigan" top="100" time="10"]
[mask_off]

#mokke
嗯嗯　原来如此。[p]
[delay speed="70"]
――不过啊，在察觉这点之前，始终……[l][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
实际上被诅咒的都是[font color="0xf08080"]异形姿态的家伙[resetfont]
对吧？[p]
[stopbgm]
[delay speed="10"]
#sarasa
……是的没错！[p]
[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="wow_s" time="100" wait="false"]
;ＳＥガタッ
[font size="40"]
[quake time="30"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
#sarasa
贤治郎先生！[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" top="-10" face="wow" time="100" wait="false"]
[quake time="30"]
#makado
啊、在！[p][resetfont]
[resetdelay]
[chara_show name="sarasa" top="-100" left="360" wait="false" face="wow_s"]
[chara_move name="makado" top="-60" left="-70" anim="false" wait="false"]
#sarasa
――说不定今后所谓的『其他部分』就是指……[l][r][font size="40"]
[font color="0xf08080"]曾受过御白姬祝福之人[r][resetfont]
可能会变成这样[p]

#makado:wow
其他部分……[l][r]
[chara_mod name="makado" face="wowCM"]
[delay speed="50"]
也就是说，这是我们在寻找诅咒时需要依赖的线索对吧[p]

#sarasa:closeEye_s
是的……！[p]
#sarasa:worry_s
至今我们确认过的[font color="0xf08080"]被诅咒者[resetfont]全都……[r]
都是作为狮心教眷属获得祝福的人。[p]
#sarasa:normal_s
[playse  volume="20" buf="0" storage="sariin.ogg" ]
也就是说，今后只要[r]
[font color="0xf08080"]身为狮心教眷属且受过祝福之人[resetfont][r]
多加留意这些特征……[p]
[resetdelay]
#sarasa:angry_s
就能在一定程度上预测出[r]
可能被御黑祟诅咒的对象！[r]
你不这么认为吗……！？[p]

#makado
……[p]
[delay speed="80"]
#sarasa
…………[p]

#makado
……………………[p]

#sarasa:worry_s
………………[l][chara_mod name="sarasa" face="closeEye_s"]
[delay speed="70"]
我、我。[r]
刚才说话还顺畅吗[p]

#makado:wow
——啊，啊啊！[r]
我完全明白了，而且……[p][resetdelay]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
#makado:smile
没想到你会跟我说这么多话，[r]
完全出乎我的意料。[r]
真是让我吃惊……[p]

#sarasa:normal_s
诶……[p]
[chara_hide_all time="10"]
[chara_show name="hino" top="-100" left="100" face="smile_s" time="100" wait="false"]
[chara_show name="aki" top="-100" left="-150" face="normal_s" time="100" wait="false"]
#riki
[chara_show name="riki" top="-100" left="400" wait="true" face="smileCE_s" time="100"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
噢——！我也超级感动的——！[r]
刚才的志户田简直像什么刑警一样啊——！！[p]

#hino:angry_s
你说得太过头了登利[p]
#hino:happy_s
但这次我也同意你的看法。[r]
志户田居然这么积极地表达自己意见[r]
吓我一跳！[p]

#aki:smileB_s
确实 纱罗纱能这么理直气壮地[r]
还说了这么多话 真是新鲜呢[p]
#
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" time="1000" wait="false" face="worry_s"]
[chara_show name="makado" top="-60" left="-70" time="1000" face="smileMini" wait="true"]
#sarasa
…………………………。[l][r]
[chara_mod name="sarasa" face="sad_s"]
哪……哪有，真的吗[p]

#makado
喂喂，这有什么好害羞的？[p]
#makado:smile
——不过，我真的很开心啊[p]
#makado:smileMini
因为我根本看不见诅咒……[r]
要不是你这样告诉我，[r]
我可能永远都不会知道这个事实吧[p]
#sarasa:normal_s
…………[p]
#sarasa:smile_s
贤治郎先生……[p]
[chara_hide_all time="10"]
[chara_show name="kirie" top="-100" face="ghost" time="100" wait="false"]
[stopbgm]
#kirie
明明自己藏着没说的事实[p]
[chara_hide name="kirie" time="10"]
[chara_show name="hino" top="-100" face="smile_s" wait="false" time="100"]
[delay speed="10"]
#hino
[playse  volume="20" buf="1" storage="kakan.ogg" ]
这必须得鼓掌啊！[r]
这必须来个全场起立鼓掌才对！[r]
好呀！现在就来吧！[p]
[chara_hide name="hino" time="10"]
@layopt layer=message0 visible=false
[clearfix]
[quake time="100"]
[playse  volume="30" buf="0" storage="kansei.ogg" ]
#
[chara_show  name="kirie" face="normal" left=500 top=-60 time="100" wait="false"]
[chara_show  name="aki" left=250 top=-60 time="100" wait="false"]
[chara_show  name="riki" face="smileCE_s" left=-70 top=-60 time="100" wait="false"]
[chara_show  name="hino" face="smile_s" left=-230 top=-60 time="100" wait="false"]
[chara_show  name="makado" face="smile" left=490 top=-60 time="100" wait="false"]
[wse]
;ＳＥ拍手
[chara_hide_all time="500"]
[wait time="500"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[chara_show name="aki" wait="false" top="-100" face="normal_s"]
[delay speed="50"]
#aki
咦 纱罗纱 你怎么了？[r]
怎么慌慌张张的[p]

#sarasa
啊……………………[p]
[delay speed="100"]
……………………[l][r]
没、没什么……[p]
[chara_hide name="aki" time="10"]
[chara_show name="mokke" top="100" face="marigan" wait="false" time="100"]
[resetdelay]
#mokke
你们真是够可以的啊[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_move name="mokke" left="600" anim="true" wait="false"]
[chara_show name="makado" wait="false" left="-110" top="-60" face="normal" wait="false"]
#makado
那么……接下来，就以刚才的想法为基础，再来一次[r]
重新梳理下奥库罗莫科的诅咒吧[p]

#mokke
哦 拜托了……[p]
[chara_hide_all time="100"]
;持ち物スチル：#makadoのメモ
[playse storage=page.ogg volume="50"]
[image layer=0 folder="image" name="makado_memo_d" storage="item/makado_memo_d.png" width="500" x="230" y="52" time="800" visible="true" ]
;アイテム「呪いについてのメモ 改訂版」入手
[font color="0xb0c4de"]
[playse  volume="20" buf="0" storage="sariin.ogg"]
获得了〇关于诅咒的笔记 修订版		。[tip key="noroi_memo_2"][endtip]
[wse][p]
[resetfont]
#makado
加上了刚才纱罗纱的推论。[r]
含糊不清的条目都打上了问号[p]

#mokke
…………[l][r][font size="20"]
演变成棘手的事态了呢……明明谁都没有错[p]
[resetfont]
那么，作为被请教的一方，老师我要提一个问题。[l][r]
;-------------------------------------------------------------------------------
*marigan_1
第一题，[font color="0xf08080"]御黑祟诅咒人类时会产生什么效果？[resetfont][p]
;-------------------------------------------------------------------------------
;▶人を異形に変え、志戸田#sarasaの命を狙う
;▶志戸田#sarasaの命を狙う
#
[link target="*marigan1_no"]【１】将人变为异形，并令其追杀纱罗纱[endlink][r]
[link target="*marigan1_yes"]【２】令其追杀纱罗纱[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*marigan1_no
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;▶人を異形に変え、志戸田#sarasaの命を狙う▶人を異形に変える

#mokke
喂——这和刚才说的不一样啊？给我好好想想[p]
@jump target="marigan_1"
;-------------------------------------------------------------------------------
*marigan1_yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;▶志戸田#sarasaの命を狙う

#mokke
说得对。御黑祟是志户田家的，[r]
[font color="0xf08080"]目标是杀害担任御白姬角色的少女[resetfont][p]
[delay speed="70"]
#makado
呐，登利君和器乐堂。[l][r]
被诅咒的话……会有什么样的感觉？具体是什么感受？[p]
[resetdelay]
#riki
诶——？该怎么说呢……[r]
就像脑袋里一直有声音在回响的感觉。[l][r]
『杀死志户田纱罗纱——快动手啊』这样的[p]

#aki
是啊　我也一直有种被命令的感觉。[r]
完全无法违抗的　非常强制的命令[p]
[delay speed="70"]

#
……命令…………[p]
[free layer=0 name="makado_memo_d" time="800" wait="false"]
#mokke
告诉你们一个有用的知识。[l][r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[chara_show name="mokke" top="100" wait="false" face="marigan"]
[font size="35"]
[font color="0xf08080"]诅咒不会同时多发，仅会施加于一人身上[p][resetfont]

#sarasa
那么，被诅咒的是……[font color="0xf08080"]一次一个人[resetfont]？[p]
[resetdelay]
#mokke
没错。再告诉你们原因吧[p]
因为……御黑祟只有一张嘴。[l][r]
所以诅咒的咏唱对象，每次也只能针对一个人[p]
[chara_move name="mokke" top="100" left="600" wait="false" anim="true"]
#makado
[chara_show name="makado" top="-10" face="tweet" left="-70" wait="false"]
也就是说御黑祟是单一存在对吧？[p]

#mokke
没错。[wait time="500"]仅此一个哦[p]
#
御黑祟……一次只能诅咒一个人……[p]
;-------------------------------------------------------------------------------

[chara_face name="makado" face="tweetB" storage="chara/makado/tweetB.png"]
[chara_face name="makado" face="hurryB" storage="chara/makado/hurryB.png"]

;-------------------------------------------------------------------------------
#mokke
接下来是第二个问题。[p]
[delay speed="60"]
自御黑祟的存在被认知以来，马门家世代[r]
都肩负着封印的职责[p]
但志户田家的大小姐却[r]
[font color="0xf08080"]仅在【封印的绢布】消失的年份、[r]
据说能看见被诅咒者的记忆[resetfont]呢[p]
[resetdelay]
	……这大概是个谜语式的提问吧。[l][r]
来，知道为什么吗？[r]
为什么大小姐看到绢布燃烧时能窥见他人记忆呢？[p]

#makado:tweetLA
……因为被诅咒的对象本身，[r]
只会在绢布焚毁的年份出现吧。[p]
[delay speed="50"]
#makado:tweet
而且只要身为御白姬的令嬢[r]
放弃御黑祟所憎恶的职责，[r]
被诅咒的人们也会消失——眼睛就能恢复原样了[p]

#mokke
这回答真没劲啊。[r]
我告诉你这个事实可不是因为[r]
担心那位大小姐的隐私被看光光啊[p]
你仔细想想。不觉得很奇怪吗？[r]
[font color="0xf08080"]马门家的人掌控本应被封印的御黑祟的方法[r]
偏偏发生在志户田家千金身上的[resetfont]这种能力啊[p]
[delay speed="60"]
#makado:angry
……那果然还是……[l][r]
[chara_mod name="makado" face="tweetB"]
作为自我保护的力量，被施舍的怜悯吧……[p]
[resetdelay]
#mokke
御白姬她？[r]
这里的土地神不可能这么悠哉吧[p]
[delay speed="50"]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_s" wait="false"]
#sarasa
……那么……[l][r]
[chara_mod name="sarasa" face="normal_s"]
果然我能触碰大家的回忆这件事也…………[r]
是有着……正当理由的吧[p]

#
那一定也是[r]
与诅咒相关的——法则之中。[p]
[chara_hide  name="sarasa" time="10"]
[chara_show name="mokke" top="100" face="marigan" time="100" wait="false"]
#mokke
就是这么回事。[l][r]
[stopbgm]
[resetdelay]
嘛～我现在能说的也就这些了吧～[p]
[chara_hide  name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="wow_s" wait="false" time="100"]
#sarasa
诶……[p]
#
玛丽甘从椅子上站起身，飒爽地朝门口迈步走去。[p]
[font size="40"]
#mokke
小林！该走啦！！[p]
;ＳEガタン
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="400"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="400"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
#sarasa
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
等、等等！[p]
[resetfont]
[chara_hide  name="sarasa" wait="true"]
#
………………………………[p]
[chara_show name="mokke" top="100" face="marigan" wait="false"]
#mokke
………………真是的，这么让人恋恋不舍[p]
[chara_hide  name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="wow_s" wait="false"]
#sarasa
……那个，[l][r]
[chara_mod name="sarasa" face="worry_s"]
[delay speed="60"]
[font color="0xf08080"]我能看到回忆的理由……是？[p][resetfont]
不告诉我吗？[p]
[chara_hide  name="sarasa" time="10"]
[chara_show name="mokke" top="100" face="marigan" wait="false" time="100"]
#mokke
不说[p]
[chara_hide  name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="worry_s" wait="false" time="100"]
#sarasa
你说不说………………[l]也就是说……其实你是知道的吧[p]
[chara_hide  name="sarasa" time="10"]
[chara_show name="mokke" top="100" face="marigan" wait="false" time="100"]
#mokke
我知道[p]
[chara_hide  name="mokke" time="10"]
[chara_show name="sarasa" top="-160" face="worry_s" wait="false" time="100"]
#sarasa
………………………………………………[p]
#sarasa:worryLA_s
为什么不告诉我……呢、[r]
既然玛丽甘小姐知道的话……我也想知道。[r]
现在……[p]
[resetdelay]
[chara_show name="riki" top="-100" face="smileCE_s" left="800" time="10"]
[chara_move name="riki" left="300" time="400" wait="false" anim="true"]
[chara_mod face="wow_s" name="sarasa"]
#riki
啊——！
我也——！我也超想知道的啊——！[p]
#sarasa:worryLA_s
诶、登利君……？[p]
[delay speed="60"]
#
登利从桌上探出身子，[r]
缓缓从椅子上站起来……[l][r]
然后转向玛丽甘的方向，笑眯眯地开口。[p]
#riki
因为啊。什么叫「现在只能告诉你这么多」……[p]
[fadeinbgm storage=fuon.ogg loop=true time=3000 volume="30"]
#riki:smileB_s
知道的事情就全部说出来嘛。[r]
别卖关子了[p]
[resetdelay]
[chara_hide_all time="10"]
[chara_show name="mokke" top="100" face="marigan" wait="false" time="100"]
#mokke
……被隐藏的真相只能靠你自己去揭晓哦 小弟弟[p]
[chara_hide  name="mokke" time="10"]
[chara_show name="riki" top="-100" face="smileCE_s" time="100" wait="false"]
[delay speed="60"]
#riki
啊哈哈 这种像道德课一样的说教[r]
根本不是我想听的好吗！[p]
#riki:smileH_s
有人、在死去啊。已经。[r]
我很困扰啊、[r]
再这样因为那些搞不懂的破事害死更多人[p]

#mokke
…………[p]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="hino" top="-100" left="400" wait="false" face="shame_s"]
[delay speed="10"]
#hino
喂、喂登利你丫的登利[r]
对玛利根小姐怎么能用这种口气说话啊[p]
[delay speed="50"]
#aki:tweetLA_s
但是　我也　和力君　想说的　一样。[r]
为什么　现在　知道的事情　不能　全部　告诉我们？[p]
#aki:hate_s
我[r]
听说　雾绘小姐　被诅咒的时候　好难过……[r]
差一点就要失控了　还好最后冷静下来了[p]　
#hino:sad_s
啊……那个啊　连器乐堂都！！[p]
#hino:angry_s
………………………………！！！[p]
[chara_hide_all time="100"]
[font size="36"]
#
就在此时！[p]
日野猛地站起身来，[l][r]
[stopbgm]
[quake time="100"]
对着圆桌[r]
像歌舞伎演员般重重拍下…………！！！[p]
[playse  volume="30" buf="1" storage="kaminari.ogg"]
[quake time="30"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=300 volume="30"]
[chara_show name="hino" time="100" wait="true" face="shame_s" top="-100"]
#hino
[delay speed="10"]
你们这群——！！！！！[r]
求教的人哪有这种态度的[r]
不对不对不对！[p]
#hino:angry_s
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
至少先把玛莉甘的全部著作[r]
通读一遍再来说同样的话！！[p]
[resetdelay]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
#hino
[playse  volume="100" buf="2" storage="punch.ogg" sprite_time="0500-30000"]
你看啊[r][resetfont]
玛莉甘都被你们这些没礼貌的家伙气哭了！[p][stop_kanim name=hino]
[chara_hide name="hino" time="10"]
[chara_show name="mokke" top="100" face="marigan" wait="false" time="100"]
[delay speed="100"]
#mokke
(つд⊂)唔～山民家的饿死鬼们～[p]
[resetdelay]
[chara_hide name="mokke" time="10"]
[chara_show name="aki" time="100" wait="false" face="worry_s" top="-100"]
#aki
没哭啦 日野 那是假哭啦[p]
[chara_hide name="aki" time="10"]
[chara_show name="riki" time="100" wait="false" face="shoutG_s" top="-100"]
#riki
[playse  volume="30" buf="0" storage="kaminari.ogg"]
气死我了 绝对不要被你这种人拐走！[p]
[chara_hide name="riki" time="10"]
[chara_show name="hino" time="100" wait="false" face="shame_s" top="-100"]
#hino
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
住手快住手啊 不要欺负我啊！！[l][r]
[chara_mod name="hino" face="angry_s"]
这样的……弱女子…………居然最喜欢最短路线[r]
现代死小鬼………………………………！！！[p]
[fadeoutbgm time="2000"]
#riki
同世代的你凭什么说这种话啊[p]
#aki
针对特定年龄层的偏见　只会让生活更艰难[r]
最好还是　别抱有这种想法哦[p]
#hino:smile_s
玛莉甘小姐[r]
这次的『山物语２』我也……读得很愉快呢[p]
而、而且……您刚才提到的[font color="0xf08080"]奥露单独说[resetfont]是[r]
我还是第一次听说！[r]
关于这个的故事会收录在下一部作品里吗！？[p]
[chara_move name="hino" left="-70" anim="false" wait="false"]
[chara_show name="mokke" top="100" left="600" wait="false" face="marigan"]
#mokke
诶～原来你不知道吗？[r]
毕竟关于御白姬的文献留存下来的不多呢……[p]
不过，你家的书房里应该[r]
有关于御白姬传说的书籍才对吧？[r]
就这样还不知道吗？[p]
[delay speed="60"]
#hino:sad_s
啊、我、我家的书房……那个。[r]
如你所知，被我烧掉了……[p]

#mokke
——这样啊。[l][r]
你一直遵守爷爷的嘱咐　完全没有打开看过内容呢[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" wait="false" face="worry_s"]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
（……………？）[p]
#sarasa:closeEye_s
（……玛丽甘小姐　和日野的爷爷[r]
原来是旧识吗[wait time="200"][er]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" top="-100" face="tweet_s" wait="false" time="100"]
#aki
现在说日野爷爷的事　根本无关紧要吧[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
阿奇的一声打断了思绪。	[l][r]
话音刚落，[r]
日野和玛丽甘的家人般私密对话戛然而止。[l][r]
……仿佛是被硬生生截断了话音一般，[r]
玛丽甘狠狠剜了阿奇一眼。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#mokke
…………………………[p]
哼[p]
[mask time="10"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="300"]
[chara_hide name="aki" time="10"]
[chara_show name="mokke" top="100" face="marigan" time="10"]
[chara_move name="mokke" left="240" top="-90" width="+=150" time="10"]
[mask_off time="10"]
#mokke
先把你们同伴之间该聊的悄悄话全都说完[r]
再来找我如何？[p]
尤其是……[l][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
[font size="40"][font color="0xf08080"]
喂　马门贤治郎！[p][resetfont]
[chara_hide name="mokke" time="10"]
[chara_show name="makado" top="-10" face="wow" wait="true"]
#makado
…………………………[p]
[chara_move name="makado" left="-70" wait="false" anim="false"]
[chara_show name="mokke" top="100" left="600" wait="false" anim="true"]
#mokke
你……[p]
[font color="0xf08080"]
[delay speed="100"]
在自己这一代[r]
把御黑蒙克封印方法弄丢了这件事[r][wait time="400"][resetfont]
根本没和任何人商量对吧[p]
#makado:wowB
…………啊、[p]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="closeEyeB" storage="chara/makado/closeEyeB.png"]
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=false
[clearfix]
[chara_mod name="makado" face="tweetB"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
………………[p]
御黑蒙克的封印方法……[l][r]
失传了？[p]

#mokke
我就觉得你突然着急得反常啊。[p]
关于封印绢帛的八种现状，[r]
现在根本不是靠即时情报收集能解决的状况[p]

#makado
…………[p]
#makado:closeEyeB
…………………………………………[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="worry_s" time="100" wait="false"]
#sarasa
……！[p]
[resetdelay]
#sarasa:angry_s
若是御黑蒙克的诅咒，我可以破除[r]
无论过去，还是将来……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="mokke" top="100" time="100" face="marigan"]
#mokke
确实纱罗纱能够，[r]
通过回溯记忆来消除所谓的诅咒。[p]

但那终究只是权宜之计，[r]
并非从根本上封印了诅咒本体[l][r]
所以被诅咒的人仍会不断出现[p]

你们啊……[l]大约70年前 战争年代发生的事[r]
[font color="0xf08080"]你读过关于绢布烧毁的新闻报道吗？[p][resetfont]

#sarasa
（啊……）[p]
（前不久、[r]
 在旧校舍从日野那里拿到的剪报上登载的新闻……！）[p]

#mokke
要是连这个时期的事情都不知道的话，那可就无从谈起了呢。[p]

来吧 除了日野之外的你们[r]
知道这份报纸发行的具体时间吗？[p]

;▶昭和十九年九月
;▶昭和十九年八月
;▶昭和二十年九月
#
[link target="*sinbun_yes"]【１】昭和二十年九月[endlink][r]
[link target="*sinbun_no"]【２】昭和十九年九月[endlink][r]
[link target="*sinbun_no"]【３】昭和十九年八月[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------
*sinbun_no
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

;▶▶昭和十九年九月
;▶昭和十九年八月
[chara_hide name="mokke"]
[delay speed="80"]
#
没能查明任何真相的我，[r]
就这样没能迎来下一个夏天……[p]

END4 呼咻一下就消逝的夏天[p]
[resetdelay]
[cm]
[clearfix]

@jump storage="first.ks"
;-------------------------------------------------------------------------------
*sinbun_yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]
;▶昭和二十年九月

#mokke
没错。报纸发行的日期是昭和二十年九月。[l][r]
不过呢……[p]
[delay speed="50"]
在这个八种町，[r]
导致绢布燃烧的大规模空袭发生的时间是[r]
[playse  volume="20" buf="0" storage="sariin.ogg"]
[font color="0xf08080"][font size="40"]
昭和二十年七月[resetfont]啊[p]
#
……也就是说，从绢布燃烧到报纸发行之间……[r]
也就是说，其间足足有两个月的时间间隔。[p]
[resetdelay]
#mokke
这篇报道中记载着[r]
「名为「赤城贝」的人在遭受诅咒之后……[r]
[font color="0xf08080"]对于其他人是否同样被诅咒一事只字未提[p][resetfont]
更准确地说，在诅咒形成原因之前[r]
[font color="0xf08080"]将绢布烧毁的事件作为新闻报道刊发[p][resetfont]

#mokke
为什么这份资料会如此不自然？[p]
[delay speed="50"]
[font color="0xf08080"]
因为那时已经完全没有可能出现新的受害者了。[r][resetfont]
诅咒的源头，在与神主对峙的那一刻[r]
就被当场封印了[p]
[delay speed="80"]
[fadeinbgm storage=rain.ogg loop=true time=5000 volume=20 sprite_time="2000-3000"]
#
………………[p]
………………………………………………………………[r][p]
——或许是现场那段寂静时光格外漫长的缘故。[p]
[delay speed="50"]
我的意识被天花板上[r]
规律作响的摇头电扇攫走了。[p]
#mokke
因为扮演御白姬而被盯上的纱罗纱[r]
只要白绢祭结束就不会再被恶灵纠缠[r]
从这舞台杀青了吧……[p]
和尚大概是这么想的吧。[p]

但这片土地的故事，可没那么简单就能了结啊。[r]
毕竟，这可不是什么童话故事[p]
[chara_hide name="mokke" wait="false"]
[playse sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" volume="30"]
[wait time="500"]
[playse volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wait time="500"]
[playse volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wait time="500"]
[playse volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg"]
[wait time="800"]
[chara_show name="hino" top="-100" face="shame_s" time="100" wait="true"]
#hino
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
等、等一下，马利根小姐！[r]
我……[p]
[resetdelay]
#mokke
抱歉，我这条命还想再留会儿。[r]
后面的事就交给日野处理吧……[p]

——即便这样还是想知道些什么的话……[p]
[delay speed="60"]
去狮心教总坛看看那本[font color="0xf08080"]秘密教典[resetfont]吧。[l][r]
永别了，纱罗纱[p]
[chara_hide name="hino" wait="false"]
#
商业街外，马利根的脚步声渐渐远去……[p]
[resetdelay]
[chara_show name="riki" top="-100" left="300" wait="false" face="hate_s"]
#aki
[chara_show name="aki" top="-100" left="-70" wait="false" face="sad_s"]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=5000 volume=50]
让她给逃掉了呢[p]

#riki
我说啊[r]
刚才那些又长又难的对话真是够呛。[p]
#riki:think_s
但马利根刚才说的话[r]
我完全不明白贤治郎受伤的原因　为啥啊？[p]

#aki
真是的～力这家伙脑子也太不灵光了吧[p]
#aki:tweetLA_s
所以简单来说呢　把刚才发生的事情整理一下……[l][r]
贤治郎先生在马门神社　好像代代传承着某些东西[r]
但他不知道封印黑目子的方法[p]
#aki:normal_s
也就是说黑目子已经没法被封印了　大概是这样吧[p]

#riki:tweetLA_s
诶？那就算白绢祭结束大家也会继续被诅咒？[p]

#aki
就是这么回事[p]

#riki:wow_s
这不完蛋了嘛[p]

#aki
这下彻底完蛋了[p]

#riki:sad_s
志户田也会一直被盯上的啊[p]

#aki:sad_s
至今为止谢谢你了[p]

#riki:worry_s
真的假的～……[r]
真遗憾啊—我还挺喜欢你的！[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_s" wait="false"]
#sarasa
[quake time="30"]
[playse  volume="20" buf="0" storage="kaminari.ogg" ]
等……还没到死的时候……！！[p]
[delay speed="50"]
#sarasa:angry_s
而且……黑目子的封印方法　未必只有一种[r]
还没确定不是吗[p]
#sarasa:worry_s
经过多方考虑，[r]
如果去调查的话……或许还有别的方法。[r]
所以，[l][chara_mod name="sarasa" face="sad_s"]…………[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="mokke" face="kobayasi" wait="false" time="100" top="100"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = ' 小林'
[endscript]
[resetdelay]
#mokke
咦？玛丽甘小姐呢？[p]
[chara_hide name="mokke" time="10"]
[chara_show name="aki" top="-100" face="normal_s" wait="false" time="100"]
#aki
她已经先走了[p]
[chara_hide name="aki" time="10"]
[chara_show name="mokke" face="kobayasi" wait="false" time="100" top="100"]
#mokke
呜哇被丢下了啊……[p]
喂！那边戴棒球帽的小哥！[r]
真要是有兴趣当明星就联系我啊！这是我的名片！[p]
[chara_hide name="mokke" time="10"]
[chara_show name="aki" top="-100" face="normal_s" wait="false" time="100"]
#aki
啊　现在这人根本没空管这个[p]
[chara_hide name="aki" time="10"]
[chara_show name="hino" top="-100" face="shame_s" wait="false" time="100"]
#hino
我、我们也先离开这里吧！[r]
待太久也不太好！嗯！[p]

[mask]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="closeEyeB_c" storage="chara/makado/cap/closeEyeB.png"]
[chara_face name="makado" face="hurryB_c" storage="chara/makado/cap/hurryB.png"]
;-------------------------------------------------------------------------------
[bg storage="shotengai_a.jpeg" time="100"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="800"]
[chara_hide name="hino" time="10"]
[chara_show name="riki" top="-100" left="300" time="10" face="sad_s"]
#aki
[chara_show name="aki" top="-100" left="-70" time="10" face="sad_s"]
[mask_off]
;○商店街
……[p]

#riki
……[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-60" face="closeEyeB_c" left="-70" wait="false"]
#hino
[chara_show name="hino" top="-60" face="sad_s" left="360" wait="true"]
……那个　贤治郎先生[p]
#hino:tweet_s
给志户田看的[r]
关于战时绢布焚毁事件的报纸……是您给的？[r]
是我[p]
[delay speed="60"]
#makado:tweetLA_c
啊、原来是这样啊……[r]
不愧是您、知道得真详细呢[p]
[resetdelay]
#hino:normal_s
志户田觉得很不可思议呢。[r]
为什么要将这么关键的证据一直隐瞒到现在[p]

#makado:closeEyeB_c
……[p]

#hino:tweet_s
我也很能理解志户田的心情。[r]
我天生就讨厌秘密。[r]
对于自己全身心投入的事业、更是如此[p]

#hino:smile_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
就算那是为我着想的举动[r]
但只要是隐瞒的事实、我还是想知道真相啊。[r]　
毕竟无法坦然面对谎言和被隐瞒的事件啊[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" left="-70" time="100" face="normal_s" wait="false"]
#riki
[chara_show name="riki" top="-100" left="300" time="100" face="worry_s" wait="false"]
等志户田从洗手间回来好好谈谈呗？[r]
老子到现在还没搞明白发生啥事了[p]
#aki
力　你真是　个笨蛋啊[p]
[mask]
[bg storage="brack.png" time="100"]
;○雑居ビル内
#sarasa
[fadeoutbgm time="2000"]
[chara_hide_all time="10"]
[mask_off]
……[p]
[delay speed="50"]
#？？
那个啊～不觉得大家对你有点冷淡吗？[p]

#
这样搭话的是雾绘小姐。[p]

仅在镜中，她站在我的身后。[p]
[fadeinbgm storage="faure-op84-5.ogg" loop=true time=3000 volume="30"]

#kirie
树月他啊。[r]
放暑假后不是更懒得理你了吗？[p]

而且怎么说呢？[l][r]
老家好像是什么「狮心教」之类的宗教团体。[r]
第一次听说这货。惨兮兮～[p]

还有还有！连马门君都变得怪怪的！？[r]
绝对藏着什么见不得人的秘密吧！？[r]
太离谱了！！[p]

你身边啊～根本没人会对你说真话呢[r][wait time="500"]
那我也没必要跟你说真话咯[p]
[delay speed="70"]
#sarasa
…………………………[l][r]
………………………………………………[p]
……[wait time="500"]秘密啊…………[l][r]
并不全是坏事　肯定……[p]

但是，探寻秘密和背后的真相，恐怕……[r]
就意味着要破坏些什么。[p]
……………………………………………………[l][r]
即便如此……[l]我还是想知道雾绘姐的秘密[p]
[fadeoutbgm time="5000"]
[wait time="5000"]
[delay speed="100"]
#
…………[p]
………………………………………………[l][r]
雾绘的身影　消失了。[p]
#sarasa
（……狮心教、）[p]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '紀伊 マリガン'
[endscript]

#mokke
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[chara_show name="mokke" face="marigan" wait="false" time="100"]
去狮心教总坛看看那本[font color="0xf08080"]秘密教典[resetfont]吧。[l][r]
再见，纱罗纱[p]
[chara_hide name="mokke" wait="true"]
#sarasa
（……）[p]
[mask]
#
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="800"]
[bg storage="indoor/birunai.jpeg" time="10"]
;-------------------------------------------------------------------------------
[chara_face name="suguru" face="normal_s" storage="chara/suguru/normal_s.png"]
[chara_face name="suguru" face="angry_s" storage="chara/suguru/angry_s.png"]
[chara_face name="suguru" face="sad_s" storage="chara/suguru/sad_s.png"]
[chara_face name="suguru" face="sadB_s" storage="chara/suguru/sadB_s.png"]
[chara_face name="suguru" face="shame_s" storage="chara/suguru/shame_s.png"]
[chara_face name="suguru" face="smile_s" storage="chara/suguru/smile_s.png"]
[chara_face name="suguru" face="smileSP_s" storage="chara/suguru/smileSP_s.png"]
[chara_face name="suguru" face="wow_s" storage="chara/suguru/wow_s.png"]
;-------------------------------------------------------------------------------

;ＳＥ扉ガチャ
[mask_off]
…………………………[er]
[playse  volume="40" buf="0" storage="book.ogg"]
;ＳＥドン
[quake time="100"]
[chara_show name="sarasa" face="wow_s" top="-160" left="360" wait="false"]
#sarasa
我……[p]
[chara_show name="suguru" top="-100" face="wow_s" left="-70" wait="false" time="100"]
#suguru
……！！啊……啊！[p]

#sarasa
……优！[p]
[font size="40"]
#suguru:sadB_s
[anim name="suguru" top="+=60" time="150"]
[anim name="suguru" top="-=60" time="150"]
[anim name="suguru" top="+=60" time="150"]
[anim name="suguru" top="-=60" time="150"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
哇、哇啊————！！　哇啊————！！！[p]
[delay speed="10"]
#sarasa:worry_s
[playse  volume="30" buf="1" storage="kaminari.ogg" ]
！？[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[quake time="30"]
#suguru
求求你、就当我们[r]
现在是偶然遇见的吧！！[p]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
要是被发现我在跟踪的话，我、我……[r]
前辈会……！[p][resetfont]
[delay speed="50"]
#sarasa:normal_s
（诶……　现在不是偶然遇到的吗……）[p]
[chara_mod name="sarasa" face="worry_s"]
#
[playse  volume="15" buf="1" storage="sariin.ogg" ]
……等等，不对？[r]
她刚才说……她现在是在跟踪我们？[p]

也就是说，她一直跟在我们后面吧？[r]
那么……[p]

#sarasa:closeEye_s
啊……那个，难道说，刚刚……[p]
#sarasa:normal_s
我拿着的行李快要掉的时候，[r]
从对面帮忙扶住的……[p]

#suguru
……呜……可是……[l][r]
[chara_mod name="suguru" face="sad_s"]
[delay speed="80"]
那种情况下，看到了的话……身体就会下意识动起来啊。[r]
就算是情敌也……[p]
[delay speed="60"]
#sarasa:smile_s
这样啊……[r]
果然，刚才就是优帮我解围的吧。[p]
我问过贤治郎先生他们，大家都说不是自己，[r]
还在想到底是谁……[p]
[stopbgm]
#sarasa:normal_s
――咦？情敌……？[p]
#suguru:angry_s
[playse  volume="20" buf="0" storage="shimeage.ogg" ]
今天居然穿着私服来约会……[r]
而且还选在花隅商业街。[r]
真是完美的炫耀呢。绝对是故意的吧。[p]
#suguru:shame_s
[delay speed="10"]
[font size="20"]
但我绝对不会输给前辈们的！[r]
才不要做那种偷偷递创可贴、比谁用得多的小动作……[r]
我要在社团活动时堂堂正正展现自己的优点！[p][resetfont]
[resetdelay]
#sarasa
……[l][r]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_mod name="sarasa" face="closeEye_s"]
……………优酱真可爱啊……[p]

#suguru:wow_s
哈！？哈哈哈，哈！？？[p]

#sarasa:normal_s
我和日野之间什么都没有啦，只是他帮了我而已……[p]
[delay speed="10"]
#suguru:angry_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
那、那个说‘帮了我’该不会是什么隐喻吧！？[r]
是在向我宣战吗……！？[p]
[resetdelay]
#sarasa:closeEye_s
……（不是啦……）[p]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="800"]
;ＳEガチャ
[playse  volume="40" buf="0" storage="book.ogg"]
[chara_mod name="sarasa" face="wow_s"]
[anim name="sarasa" top="+=60" time="150"]
[anim name="sarasa" top="-=60" time="150"]
[chara_mod name="suguru" face="wow_s"]
[anim name="suguru" top="+=60" time="150"]
[anim name="suguru" top="-=60" time="150"]
[wait time="500"]
;-------------------------------------------------------------------------------

[chara_face name="mokke" face="ojisan" storage="chara/mokke/sankakuRed.png"]

;-------------------------------------------------------------------------------
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'おじさん'
[endscript]

[chara_show name="mokke" face="ojisan" top="100" wait="true" left="300"]
#mokke
……啊，抱歉啦[p]
[chara_hide name="mokke" wait="true" pos_mode="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="800"]
;ＳE去っていく

#suguru:sad_s
啊……那位大叔要走了……[p]
#
对着从男厕所方向出现的人物，[r]
优这么说道。[p]

#sarasa:normal_s
？　咦，你们认识……？[p]
[delay speed="10"]
#suguru:angry_s
怎么可能认识那种大叔啊！[p]
[delay speed="50"]
#suguru:normal_s
只是，那个人……[r]
在我跟踪日野前辈他们过来之前，就已经在这儿了，[r]
一直在暗中观察会场的情况。[l][chara_mod name="suguru" face="sad_s"]不知为何……躲在不远处偷看[p]

#sarasa:closeEye_s
（……那那边那个，就是不可爱的跟踪狂……）[p]

[mask]
;○商店街
[chara_hide_all time="10"]
[bg storage="shotengai_a.jpeg" time="10"]
[chara_show name="makado" top="-60" left="-70" face="normal_c" time="10"]
[chara_show name="aki" top="-60" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-60" left="400" wait="false" face="normal_s"]
#hino
[chara_show name="hino" top="-60" left="100" wait="false" face="tweet_s"]
[mask_off]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
啊呀，这不是聪君嘛！[p]
[chara_hide_all time="10"]
[chara_show name="suguru" top="-100" face="smile_s" wait="false"]
#suguru
呃……嘿嘿，部长好……[p]
[chara_hide name="suguru" time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_c" wait="false" time="100"]
#sarasa
刚才……偶然遇到的。[r]
小优也是，[r]
说是想来见玛丽甘女士的……[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" left="-70" face="smile_s" wait="false" time="100" top="-100"]
[chara_show name="suguru" left="360" face="smile_s" wait="false" time="100" top="-100"]
#hino
噢！原来是这样啊！[p]

不愧是地研的女主角。[r]
连历史学者相关的活动[r]
都认真关注过了呢！[p]
[delay speed="60"]
#suguru:shame_s
[anim name="suguru" left="-=10" time=50 ]
[anim name="suguru" left="+=10" time=50 ]
[anim name="suguru" left="-=10" time=50 ]
[anim name="suguru" left="+=10" time=50 ]
啊……不、不过，完全，来的时候已经结束了，那个……[r]
而且新著作也还没读完……[p]
[resetdelay]
#hino:normal_s
是这样吗？[p]
#hino:smile_s
如果有什么地方没完全理解[r]
或者有疑惑的部分，我可以为你讲解！[p]
[delay speed="100"]
#suguru:wow_s
[playse  volume="30" buf="1" storage="kansei.ogg"]

……！请、请务必……[p]
[resetdelay]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" left="-70" wait="false" face="normal_s"]
#riki
[chara_show name="riki" top="-100" left="300" wait="false" face="normal_s"]
优——你这家伙怎么跑出来了？[r]
集会准备工作不用帮忙吗？[p]
#aki
啊对哦[p]
[delay speed="50"]
#aki:wow_s
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]虽然“簇日”将近……[r][resetfont]
待在这种地方没问题？不会挨骂吗？[p]
[chara_hide_all time="10"]
[chara_show name="hino" left="-70" face="normal_s" wait="false" time="100" top="-100"]
#suguru
[chara_show name="suguru" left="360" face="sad_s" wait="false" time="100" top="-100"]
啊……嗯。
树月说你出门了……[p]

#sarasa
……簇之日？[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-10" face="tweetLA_c" wait="false"]
#makado
――狮心教的集会周期都有固定称谓的。[r]
那是根据养蚕工序命名的……[p]
#makado:tweet_c
[font color="0xf08080"]只要重复五次名为“眠日”的集会[r][resetfont]
[font color="0xf08080"]便会迎来所谓的“簇日”[p][resetfont]
#makado:lookAway_c
簇之日这天 信徒的孩子都要在头上裹绢布……[r]
[font color="0xf08080"]据说要在“茧之家”等待祝福的降临[p][resetfont]
[chara_hide name="makado" time="10"]
[chara_show name="aki" top="-100" face="smile_s" wait="false" time="100"]
#aki
簇之日 获得特别祝福的可能性 特别高哦。[r]　
我获得祝福 也是在两年前的簇之日[p]
#
用绢布、从头上盖下……[p]
[delay speed="80"]
用绢布、从头上盖下……[p]
[delay speed="100"]
从头顶、[wait time="500"]缓缓复上绢布……[p]
[chara_hide name="aki" time="10"]
[chara_show name="sarasa" top="-160" face="normal_c"]
#sarasa
……………………………………[l][r]
………………………………诶、[wait time="500"]从头上、盖绢布………………[p]
#sarasa:closeEye_c
……………………………………[p]
[delay speed="50"]
#sarasa:normal_c
……那个、绢布要……盖到什么程度？[r]
像温泉毛巾那样？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" top="-100" face="normal_s" wait="false" time="100"]
#aki
啊哈哈　那样的话有点小家子气呢[p]
#aki:tweet_s
绢布可是有相当大面积的哟[r]
看情况　说不定会有点像幽灵呢[p]
[delay speed="60"]
[chara_hide name="aki" time="10"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false" time="100"]
#sarasa
……那[l][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[delay speed="100"]
就会分不清谁是谁了……对吧？[p]
[fadeoutbgm time="5000"]
#riki
……嗯？[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="wow_s"]
[chara_show name="hino" top="-100" left="100" wait="false" face="tweet_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="worry_s"]
喂志户田……[r]
你小子想干什么？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="closeEye_c" wait="false" time="100"]
#sarasa
……………………[p]
#sarasa:normal_c
贤治郎先生[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="makado" top="-10" face="worry_c" wait="false" time="100"]
#makado
……诶[p]
………………………………………[l][r]
不行　不可以的？　绝对……[p]
[resetdelay]
#sarasa
我要去参加狮心教的集会[p]
[chara_hide name="makado" time="10"]
[chara_show name="aki" top="-100" face="wow_s" wait="true" time="100"]
[font size="40"]
[anim name="aki" top="+=60" time="150"]
[anim name="aki" top="-=60" time="150"]
#aki
哈啊？[p][resetfont]
[fadeinbgm storage="faure-op84-5.ogg" loop=true time=3000 volume="50" sprite_time="0000-76400"]
#sarasa
去查探那个总部的、[font color="0xf08080"]秘密教典[resetfont]之类的东西……[p]
[chara_move name="aki" top="-100" left="-150" wait="false" anim="true"]
[chara_show name="riki" top="-100" left="400" wait="false" face="wow_s"]
#hino
[chara_show name="hino" top="-100" left="100" wait="false" face="shame_s"]
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[quake time="30"]
[font size="40"]
你在说什么啊志户田！？[resetfont][r]
刚才和马利甘先生[r]
商量好的事情都忘了吗！？！？[p]
#hino
那些被暗黑咒术诅咒、想要你命的家伙们……[r]
很可能就是狮心教的眷属啊！？[p]
[delay speed="10"]
#hino:angry_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[font size="40"]
敌人的巢穴那种地方……[r]
就像百鬼夜行里不要命地冲进去[r]
别干这种蠢事！！[p][resetfont]
#riki
你只是想这么说而已吧[p]
#hino
[font size="40"]
[playse  volume="20" buf="1" storage="kakan.ogg" ]
才不是呢！！！！[p][resetfont]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" time="100" face="closeEye_c" wait="false"]
[chara_show name="makado" top="-60" left="-70" time="100" face="tweet_c" wait="false"]
[delay speed="24"]
#makado
日野说得对。不管怎么说都太危险了[l][r]
独自一人[r]
前往可能满是诅咒者的地方什么的……[p]
[delay speed="50"]
#sarasa
……才不是一个人呢[p]

#makado:worry_c
诶……？[p]

#sarasa:normal_c
当天　[wait time="700"]小队大家都会在的吧？[p]
[chara_hide_all time="10"]
[chara_show name="riki" top="-100" left="400" wait="false" face="wow_s"]
[chara_show name="hino" top="-100" left="100" wait="false" face="sad_s"]
#aki
[chara_show name="aki" top="-100" left="-150" wait="false" anim="true" face="wow_s"]
[font size="40"]
……哈啊？[p]
[resetfont]
#riki:sad_s
你认真的吗志户田？[r]
你说的[font color="0xf08080"]小队大家[resetfont]是指我们吗？[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false" time="100"]
[delay speed="60"]
#sarasa
除了我们之外……也没别人了吧[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="hino" top="-100" left="100" wait="false" face="sad_s"]
[chara_show name="aki" top="-100" left="-150" wait="false" anim="true" face="wow_s"]
#riki
[chara_show name="riki" top="-100" left="400" wait="false" face="worry_s"]
……[l][r]
[chara_mod name="riki" face="sad_s"]
既、既然如此……有我们在，你还有什么好说的啊[p]
#
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-100" left="360" face="closeEye_c" wait="false" time="1000"]
[chara_show name="makado" top="-60" left="-70" time="1000" face="worryB_c" wait="true"]
#sarasa
登利君和阿基还有日野……都会保护我的。[l][r]
所以就算我去参加集会……也肯定没问题的[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" left="-150" wait="false" anim="true" face="worry_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="worry_s"]
#hino
[delay speed="100"]
[chara_show name="hino" top="-100" left="100" wait="false" face="sad_s"]
…………………………[p]

#aki
…………………………[p]
#riki
……[l]装、装什么国王派头啊[p]
[chara_hide_all time="10"]
[chara_show name="suguru" top="-100" time="100" wait="true" face="wow_s"]
[font size="40"]
[quake time="30"]
[resetdelay]
#suguru
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[anim name="suguru" top="+=60" time="150"]
[anim name="suguru" top="-=60" time="150"]
[anim name="suguru" top="+=60" time="150"]
[anim name="suguru" top="-=60" time="150"]
等……等一下啊……！[p][resetfont]
[delay speed="20"]
#suguru:sad_s
别擅自用能轻松潜入的设定推进剧情啊！？[r]
狮心教的集会……[l][r]
[anim name="suguru" top="+=60" time="150"]
[anim name="suguru" top="-=60" time="150"]
[resetdelay]
尤其是簇日当天，对眷属来说可是特别重要的祈祷时间！！[p]
#suguru:angry_s
……就算是我，虽说是菜鸟但好歹也是三官女之一。[r]
虽然不清楚你究竟有什么目的，[l]……[p]
但让你这种观光心态的人进茧的家，[r]
只要我还有一口气就绝不允许！[p]
[chara_move name="suguru" anim="true" wait="false" left="-70"]
[chara_show name="sarasa" top="-160" face="normal_c" wait="false" left="360"]
#sarasa
……[p]
[delay speed="50"]
#sarasa:closeEye_c
只有这次……求你放过我吧。[r]
求求你……[p]

#suguru:wow_s
等、等等……[p]

#sarasa:worry_c
这关系到人命啊，优。[p]
[delay speed="80"]
#sarasa:closeEye_c
不是我的话，说不定还会有别人……[r]
可能又会有新的牺牲者出现，所以……！！[p]
#suguru:wow_s
[anim name="suguru" left="-=10" time=50 ]
[anim name="suguru" left="+=10" time=50 ]
……………………！！[l][r]
[chara_mod name="suguru" face="sad_s"]
呜……呜呜[p]
#
优紧咬后槽牙，露出了犹豫的神色。[l][r]
……再加把劲……！[p]

#sarasa:worryLA_c
……我、我……[l][r]
[chara_mod name="sarasa" face="closeEye_c"]
……！[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[quake time="30"]
[font size="40"]
[chara_mod name="sarasa" face="worry_c"]
[resetdelay]
希望优的感情之路也能……[r]
平安无事就好了……我是这么想的……！？[p]
#suguru:wow_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……呜、啊……！？[p]
[resetfont]
[delay speed="80"]
#sarasa
希望……一切……都能平安无事……[p]
[resetdelay]
#sarasa:worryLA_c
[playse  volume="30" buf="2" storage="kaminari.ogg"]
偷偷做的亏心事，要是暴露了的话………[r]
希望……不要发生……这种事情啊………我是真心这么想的……！[p]
[delay speed="80"]
#suguru
(这……这个……志户田纱罗纱啊)[p]
[font size="40"]
#suguru:sadB_s
[playse  volume="30" buf="1" storage="kaminari.ogg"]
(居然在威胁我……！！？)[resetfont][p]

#suguru:sad_s
咕……呜……[l][r]
[chara_mod name="suguru" face="angry_s"]
呜呜呜……[wait time="1000"]呜啊——……！[p]
[font size="20"]
[chara_hide_all time="3000" wait="false"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="30"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="20"]
[wse]

[resetdelay]
#suguru
……明白了[p]
[chara_show name="makado" face="wow_c" top="-10" time="100" wait="false"]
[font size="40"]
#makado
[playse  volume="30" buf="0" storage="kaminari.ogg" ]
[quake time="30"]
诶诶！？[p]
[font size="20"]
#suguru
只是开玩笑的啦[p]
[resetfont]
#makado:wowCM_c
……[p]
#makado:worryB_c
那、那我也要一起去，[r]
总不能只让你们两个去面对……[p]
[chara_hide name="makado" time="10"]
[chara_show name="aki" top="-100" face="normal_s" wait="false" time="300"]
#aki
不 这太勉强了[r]
在蔟祭日需要披绢布的成员里 像贤治郎先生这么高的人[r]
果然 找不到啊[p]
[chara_hide name="aki" time="10"]
[chara_show name="sarasa" top="-100" left="360" face="normal_c" wait="false"]
[chara_show name="makado" top="-60" left="-70" face="wow_c" wait="false"]
#makado
唔……[p]

[delay speed="50"]
#sarasa
贤治郎先生 没问题的[p]

#makado:angrySH_c
你说没问题……凭什么这么断定[p]

#sarasa:smile_c
大家绝对不可能背叛我的[r]
所以……不要紧 大家一定会保护好我的[p]
#sarasa:normal_c
作为交换……[l][r]
[fadeoutbgm time="5000"]
[chara_mod name="sarasa" face="closeEye_c"]
当天、在我去茧家的时候，[r]
希望贤治郎先生能去[font color="0xf08080"]那个地方[resetfont][p]

#makado:angry_c
诶……？[p]
#sarasa
这是、我的……[p]
#sarasa:normal_c
在我心里、现在擅自建立的假设，[r]
为了验证这个假设需要证据，所以才拜托你的事[p]

#makado:worry_c
………………………………[p]

#sarasa
贤治郎先生也………………会按我说的去做吧。[p]
[mask folder="bgimage" graphic="still/part3.png" time="3000"]
#
;セーブしますか？
[fadeoutbgm time="2000"]
[chara_hide_all time="1000"]
[showsave]
@jump storage="chapter_3/day2_vol1.ks"






;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
