[eval exp="f.save_title = '五章パート５'"]

@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

[mask]
#
[bg storage="still/mokke_1.png" time="100"]
[fadeinbgm storage=onedari.ogg loop=true time="1000" volume=50 sprite_time="0200-21000"]
[bg storage="still/den_1.png" time="10"]
[mask_off]
很久很久以前　八种村　遭受了诅咒[p]

但那绝非是　恶灵或是[r]
超自然之物降下的　诅咒[p]
[resetdelay]
[bg storage="still/den_16.png" time="500"]
而是人类　统治所带来的　苦难[p]
统治八种的藩府　没收了部分民众信仰的对象[r]
展开了彻底的运动[l][r]
这被称作　废佛毁释[p]
[bg storage="still/den_17.png" time="500"]
终于有个女子　不堪忍受[r]
她决心投水自尽[p]

「今生恐怕连极乐净土都不被允许[r]　至少请在来世拯救我吧」[p]
[bg storage="still/den_18.png" time="500"]
就这样　女子纵身跃入四ツ山的深潭[r]
在她投水的瞬间！[p]
[bg storage="still/den_19.png" time="500"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
一位肌肤雪白得惊人的神秘女子[r]
将可怜的投水女子救起[p]
[bg storage="still/den_20.png" time="500"]
那女子披着与肌肤同色的白纱[r]
投水女子认出她是自己熟知的观音菩萨　不禁泪流满面[p]
[delay speed="60"]
人类总是这样，[r]
只愿看见自己想看的事物。[p]
[resetdelay]
……[p]
[bg storage="still/den_21.jpg" time="500"]
后来　两个女子　亲密无间地生活在一起[l][r]
她们各自为对方　生下了一个孩子[p]
[delay speed="60"]
「为什么你会出现在我面前[r]　现在的我　已经完全明白了」[p]
[resetdelay]
某天　女子对另一个女子说道[p]
[bg storage="still/den_22.png" time="100"]
[delay speed="60"]
「我一直渴望被像你这样[r]　洁白美丽的人拥抱」[p]

……白衣女子被自己救下的[font color="0xf08080"]宗方[resetfont]家的女子[r]
命名为御白姬[wait time="500"]　[p]

……[p]

时光流逝……[p]
[bg storage="still/den_23.png" time="1000"]
[delay speed="60"]
她们的两个女儿中　一个出嫁了[r]
一个招了女婿[p]
[resetdelay]
出嫁的那个女儿的丈夫[wait time="500"]　说道[p]
[bg storage="still/den_24.png" time="500"]
「御白姬[r]
如今八种仍残留着信仰被剥夺后的空洞」[p]
「所以请您作为庇佑养蚕的女神[r]
来拯救这片土地吧」[p]
[playse  volume="30" buf="0" storage="kansei.ogg"]
[bg storage="still/den_28.png" time="1000"]
凭借御白姬的力量　小镇重新凝聚[r]
她娘家的宅邸也随之变得气派起来[p]
[delay speed="60"]
此时创立的宗教[wait time="500"]　以女儿丈夫的姓氏――[p][font color="0xf08080"]
志户田家[resetfont]为名[r][wait time="600"]
取名为『士心教』。[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[fadeoutbgm time="2000"]
[mask time="2000"]
[chara_show name="sarasa" face="sad_gs" top="-160" time="10" left="420"]
[chara_move name="sarasa" width="-=100"]
[chara_show name="mokke" face="normal" top="-160" time="10" left="-80"]
[chara_move name="mokke" width="-=100"]
[bg storage="siro3.png" time="10"]
#sarasa
[mask_off time="2000"]
[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
……[p]

#sarasa:closeEye_gs
……一定　与你结合的女性……都对你……[r]
【想要和你有个孩子】如此祈祷过吧[p]
[chara_mod name="sarasa" face="closeEye_gs"]
#
而那正是――[r]
涉足生死界限的禁断之愿。[p]
[resetdelay]
#mokke:lookAway
哼。得了便宜还卖乖的说辞呢[p]
#mokke:closeEye
那支血脉诞下的后代大多乖巧可人……[r]
偏偏从我腹中诞下的你们这些血脉浓稠者[r]
无论哪个时代都这么桀骜不驯　真让人火大[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
――志户田家与、[wait time="500"]宗方家。[l][r]
两家的子孙都是『女神”与人类的混血儿，[r]
彼此之间血脉相连。[p]
[delay speed="100"]
[chara_mod name="sarasa" face="sadB_gs"]
这些我都知道　已经够了　但是[p]
[delay speed="60"]
#sarasa
…………那个[p]
#
[chara_mod name="mokke" face="normal"]
御白姬一脸不耐烦地抛来视线。[p]
#sarasa
…………刚才说的那件事，[r]
你到底　打的什么主意[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
雾绘小姐，[r][font color="0xf08080"]
将没有自我的存在放入体内　出现在眼前[resetfont]　什么的[p]
[resetdelay]
#mokke
就是字面意思，有问题吗？[p]
[delay speed="60"]
#mokke:closeEye
要侵入肉体，必须要有可乘之隙才行[r]
和搬家是一个道理[p]
#mokke:smileMini
所以你的自我也赶紧从这世上消失吧[p]
[resetdelay]
#sarasa:worry_gs
你能进入我的身体[wait time="500"]　是因为我马上就要死了[p]
#sarasa:lookAway_gs
你说我的自我即将消失？[r]
这我能理解[p]
#sarasa:sad_gs
……[p]
[resetdelay]
#sarasa:closeEye_gs
可是……在绢布燃烧那天，雾绘小姐的躯体[r]
根本不存在任何濒死的迹象[l][r]
#sarasa:worry_gs
那为什么当时会——[p]
[stopbgm]
@layopt layer=message0 visible=false
[clearfix]
;オシラヒメ()
;オシラヒメ()
#mokke:smileMini
[wait time="4000"]
#mokke:smile
[wait time="6000"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[mask time="400" effect="lightSpeedIn"]
[chara_hide_all time="10"]
;ＳEごおおッ
[bg storage="brack.png" time="10"]
[mask_off time="100"]
[delay speed="100"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
——！呃……[p]
#
御白姬身后骤然掀起狂暴的烈风。[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=bigriver.ogg loop=true time=3000 volume="10"]
[wait time="4000"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[wse]
[mask time="300"]
[bg storage="still/hime2.png" time="500"]
;-------------------------------------------------------------------------------
[chara_face name="mokke" face="ito_1" storage="chara/mokke/osira/ito_1.png"]
[chara_face name="mokke" face="ito_2" storage="chara/mokke/osira/ito_2.png"]
[chara_face name="mokke" face="ito_3" storage="chara/mokke/osira/ito_3.png"]
[chara_face name="mokke" face="ito_4" storage="chara/mokke/osira/ito_4.png"]
;-------------------------------------------------------------------------------
#sarasa
[mask_off time="100"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[fadeinbgm storage=onedari.ogg loop=true time="1000" volume=50 sprite_time="0200-21000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
咿…………！！[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
[bg storage="still/hime.png" time="2000" wait="true" cross="false"]
[wse]
[wait time="2000"]
[fadeinse  volume="05" buf="1" storage="walk_rouka.ogg" loop="true" time="3000"]
[resetdelay]
#
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
@layopt layer=message0 visible=true
――――眼球传来仿佛被细长物体深深刺入的剧痛。[l][r]
[r]
由于疼痛与不适，一时未能察觉……[l][r]
从自己的眼中延伸出数根带着触感的丝线，[r]
似乎与御白姬相连着。[l][r]
[r]
混乱攫住了脑神经中枢，[r]
整个身体被拖向御白姬的方向。[p]
#sarasa
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[quake time="30"]
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
住、住手………！[p]
[font size="40"]
#mokke
来吧！与我共舞！！[r][resetfont]
[chara_hide name="mokke" wait="false"]
与我一同跳完那支你曾最爱的舞蹈　直到生命尽头！[p]
#sarasa
不、不要……！！[p]
#
任性妄为。[r]
这般举止与这个词再相称不过。[p]

她仗着彼此被丝线相连的优势[r]
拽着我不断旋转旋转。[p]

丝线越缠越紧。[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
#mokke
每当触及使徒祝福的回溯时[r]
你之所以能　将我的命令当作不存在[p]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
#mokke
是因为对那个使徒而言　你『知晓其所献上的祈愿”　[r]
这样你就会变成和主人同样的存在了呀[l][r]
毕竟无法对主君挥刃相向对吧？[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[delay speed="50"]
[fadeoutbgm time="5000"]
#
你所经历过的他人记忆的往来[r]
正是将我们连结至此的因果[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[delay speed="100"]
#sarasa
怎……会……[l][r]
那么、我…………迄今为止所做的一切…………[p]
[resetdelay]
#mokke
那些眷属本就不必夺人性命。[r]
正因如此最终[r]
你才成为了让我逐渐同化的　食粮。[p]
[clearfix]
@layopt layer=message0 visible="false"
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
[bg storage="still/hime3.png" time="2000" wait="true" cross="false"]
[wse]
[delay speed="100"]
#sarasa
@layopt layer=message0 visible="true"
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
（……………………………………………………）[p]
[delay speed="50"]
#
我傲慢的声音，[r]
在纯白扩散的空间里不断回响。[p]
#mokke
来吧　就这样跟随我。[r]
最后就让我赠你一份礼物吧[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[font size="40"][font color="0xf08080"]
你曾经极度渴望的[r]
『宗方雾绘”的记忆！！[p][resetfont]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[resetdelay]
#sarasa
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
——诶……！？[p]
[fadeinbgm storage=bigriver.ogg loop=true time=3000 volume="10"]
何必惊讶[r]
你不是一直都想看吗？[r][wait time="500"]
你和那个秃驴说过的每句话我都知道得一清二楚[p]

你也好[wait time="500"]　那个叫贤治郎的男人也罢[r][wait time="500"]
雾绘的记忆[r]
始终未能窥见分毫这件事让你懊悔得不得了吧[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[quake time="30"][font color="0xf08080"]
没能阻止她赴死的你[r]
『此事与我毫无干系』这般　不过是为了寻求自我救赎！！[p][resetfont]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[font size="40"]
#sarasa
[quake time="30"]
……………不对御白姬，我们！！！[p]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[clearfix]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[resetfont]
#
无论戏剧还是电影　真正的遗憾总在离场时显得浑浊[l][r]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[r]
就让我为你描绘一幅　足够干脆利落的退场画卷[l][r]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[r][r][font size="20"]
……对御白姬而言　我们的话语毫无意义――[p]
@layopt layer=message0 visible=false
[resetdelay]
[stopbgm]
;ＳEカーン
[mask time="100"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[wait time="2000"]
[bg storage="still/kirie_smile.png" time="10"]
[mask_off time="100"]
[playbgm storage=tukutukulong.ogg loop=true volume=40]
[wait time="2000"]
[bg storage="still/kirie_smile2.png" time="10"]
[wait time="2000"]
[bg storage="still/kirie_smile3.png" time="10"]
[wait time="2000"]
[mask time="300"]
[fadeoutbgm time="300"]
[bg storage="still/kirie_1.jpeg" time="10"]
[wait time="2000"]
[mask_off time="100"]
[wait time="3000"]
@layopt layer=message0 visible=true
;○都会
[r]歩いている。[l][r]
[r]歩いている。[l][r]
[r]歩いている。[l][r]
[r]建物に入る。[p]
@layopt layer=message0 visible=false
[bg storage="still/kirie_4.png" time="3000" wait="true" cross="false"]
[wait time="2000"]
@layopt layer=message0 visible=true
与男人同寝。[l][r]
[r]男と寝る。[l][r]
[r]男と寝る。[l][r]
[r]男と寝る。[l][r]
[r]男と寝る。[l][r]
[r]男と寝る。[l][r]
[r]笑っている。[l][r]
[r]建物から出る。[l][r][r]
[bg storage="still/kirie_1.jpeg" time="1000" wait="false" cross="false"]
[r]
;○都会
行走着。[l][r]
[r]歩いている。[l][r]
[r]歩いている。[l][r]
[r]歩いている。[l][r]
[r]建物に入る。[p]
@layopt layer=message0 visible=false
[bg storage="still/kirie_2.jpeg" time="5000" wait="true" cross="false"]
[wait time="2000"]
@layopt layer=message0 visible=true
正被询问着。[l][r]
[r]話を聞かれている。[l][r]
[r]話を聞かれている。[l][r]
[r]話を聞いている。[l][r]
[r]泣いている。[l][r]
[delay speed="60"]
[r]泣いている、[l][r]
[resetdelay]
[r]泣くのをやめている。[p]
;電車
@layopt layer=message0 visible=false
[bg storage="still/kirie_3.jpeg" time="5000" wait="true" cross="false"]
[wait time="2000"]
@layopt layer=message0 visible=true
相信着。[l][r]
[r]信じていない。[l][r]
[r]信じなければならない。[l][r]
[r]電車に揺られている。[l][r]
[r]死んでいるはずがないと願っている。[l][r]
[r]体全部で、願って、うなだれている。[r]
毫不避讳旁人目光。[l][r]
[r]そんな彼女を、車内で同じく揺られる全員が[r]
巡视着。[p]
;○八種
@layopt layer=message0 visible=false
[bg storage="hataneM.jpg" time="5000" wait="true" cross="false"]
@layopt layer=message0 visible=true
[r]着いてしまう。[l]行かなければいけない。[l]
本不想去的。[l]因恐惧而颤抖。[l][r]
[r]安心して会える人がいない。[l][r]
[r]彼女はいつもあげてばかりだったから。[l][r]
[r][r]しかし。[p]
[delay speed="60"]
[stopbgm]
忽然[r][wait time="600"]
在这座小镇里，唯一让我想起了收到的东西。[l][r]
[r]思い出す。[l][r]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[r][r][r]思い出す。[p]
[resetfont]
双脚开始移动。慢慢地跑了起来。[r]
[r][r]体にさわらないよう走り出す。[l][r]
[r][r]駅前の向日葵が咲いている。[p]
@layopt layer=message0 visible=false
[bg storage="himawari_1.jpeg" time="5000" wait="true" cross="false"]
[wait time="4000"]
@layopt layer=message0 visible=true
;○向日葵
[font size="22"]
很少有人会经过这个地方。[l][r]
[r][r]
[resetfont][resetdelay]
雾绘以为两人正在一起奔跑。[l][r][r]
[font size="23"]
奔跑着。[l][r]
[r]走った。[l][font size="20"]
奔跑着……[l][r]
[r]……[l][r][r]
[r][resetfont]
就这样，[wait time="500"]到达了。[p]
[bg storage="hall_m.jpg" time="5000" wait="false" cross="false"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[delay speed="100"]
;○お堂
鸟儿、蝉儿，鸣叫着。[p]
雾绘轻轻将手搭了上去。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
用自己的祝福之力驱逐”门锁。[p]
[bg storage="brack.png" time="2000" wait="false" cross="false"]
「…………」[p]
「――[wait time="700"][font size="40"]呀！？！！」[wait time="200"][er]
[stopbgm]
[resetdelay]
;ＳEガシャーン
[playse storage="takibi.ogg" volume="50" loop="true" buf="1"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[quake time="100"]
雾绘的手不由自主地，[r]
用从口袋里掏出的打火机[r]
点燃了火焰。[p]
[font size="20"]
「……！！[l]这个…………」[p]
[font size="40"]
[quake time="100"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[font color="0xf08080"]
「从我身体里滚出去！」[p]
[resetfont]
雾绘将祝福”缠绕在自己身上。[p]
[layermode name="kirie" graphic=kirie.png time=300 mode="lighten"]
@layopt layer=message0 visible=false
[stopse buf="1"]
[playse storage=ti.ogg volume="50"]
[wse]
;ＳEべしゃっ
[font size="20"]
[bg storage="still/ti.png" time="10000" wait="false" cross="false"]
[wait time="5000"]
@layopt layer=message0 visible=true
「啊」[p]
[resetfont]
「雾绘。」[p]
「明白了吗？」[p]
[free_layermode name="kirie" time="300"]
[bg storage="still/kirie_5.png" time="100"]
「就是因为抽烟，[wait time="500"]你的孩子才会胎死腹中」[p]
[playse storage="takibi.ogg" volume="50" loop="true" buf="1"]
沉默。[p]
落在床上的那团东西沉默着。[p]
[font size="22"]
胯下蔓延开一片赤红之海。[r]
与每月造访的那件事截然不同的氛围，[r]
某种令人感到无可挽回的、异样的东西。[p]
虽非自主所为，[r]
但被指认为凶手的，恐怕只会是雾绘一个人吧。[p]
[resetfont]
[bg storage="brack.png" time="3000" wait="false" cross="false"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
沉默。[p]
[delay speed="50"]
抬起头。[p]
在燃烧。[p]
只属于我的秘密。[l][r]
只属于我的祈祷。[p]
[delay speed="60"]
[stopse buf="1"]
属于我的东西[wait time="500"]　早已不复存在。[p]
@layopt layer=message0 visible=false
[mask time="100"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[mask_off time="100"]
[playse storage=page.ogg volume="50"]
[bg storage="still/kirie_smile.png" time="100" cross="false"]
[playse storage=page.ogg volume="50"]
[wait time="300"]
[bg storage="still/mayuten1.png" time="100" cross="false"]
[playse storage=page.ogg volume="50"]
[wait time="300"]
[bg storage="still/kirie_4.png" time="100" cross="false"]
[playse storage=page.ogg volume="50"]
[wait time="300"]
[bg storage="still/curtain_s.png" time="100" cross="false"]
[playse storage=page.ogg volume="50"]
[wait time="300"]
[bg storage="still/kirie_bridge.jpeg" time="100" cross="false"]
[playse storage=page.ogg volume="50"]
[wait time="300"]
[bg storage="still/hold_2.png" time="100" cross="false"]
[playse storage=page.ogg volume="50"]
[wse]
[wait time="300"]
[bg storage="still/hold_1.png" time="100" cross="false"]
[mask time="500"]
[wait time="3000"]
[bg storage="siro4.png" time="10"]
#
[chara_show name="mokke" top="-200" face="ito_2" time="10"]
[chara_move width="-=60" name="mokke" time="10" left="-=360"]
[mask_off time="3000"]
;ＳEカーン
[resetdelay]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
宗方雾绘的故事到此结束[p]
来吧　快点停止呼吸　把身体交出来[p]
[delay speed="100"]
…………[p]
……………………[p]
………………………………………………………………[p]
[delay speed="50"]
啊啊啊、[p]
[chara_move name="mokke" left="140" wait="true" time="100" anim="false"]
[font size="40"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
啊哈哈哈哈哈哈！！[r][resetfont]
为什么？为何要悲伤！？[r]
难道你还不接受那家伙的自杀吗！？[p]
[fadeoutbgm time="3000"]
#mokke
说到这个份上你应该明白了吧。[r]
我并没有命令雾绘“跳下去”。[l][r]
那家伙的死　是出于他自己的意愿[p]
#mokke
也就是说他的死是[r]
纱罗纱[wait time="500"]　贤治郎[wait time="500"]　和你们毫无关系[p]
#mokke
明明如此……[p]
[resetdelay]
无法理解。[l][r]
我感受到了。[wait time="500"]透过丝线传来的 你的怜悯与绝望[p]
很寂寞吗？很痛苦吗？[r][wait time="500"]
明明近在眼前却没能拯救 那个蠢女人的存在[p]
[delay speed="60"]
如今 向你袭来的过去 终将化作祈愿[p]
[delay speed="100"]
[chara_hide name="mokke" wait="false" time="10000"]
;（立ち絵消す）
[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
你们人类总是这样。[r]
无从实现的期望　无从实现的祈祷　无从实现的愿望……[p]
你们却妄图通过向神明祈求[wait time="500"]　超越人智　将其实现[p]
[bg storage="syotengai_n.jpeg" wait="false" cross="false" time="8000"]
明明与自己有着相同生存方式的人类　明明存在着远比自己优秀的同类[r]
过去未来都源源不断诞生着――[l][r]
却仍坚信自己的祈祷与众不同[wait time="500"]　必定会得到神明垂听[p]
[bg storage="indoor/sisin.jpeg" wait="false" cross="false" time="8000"]
全部都是[r][wait time="500"]
正因为你们人类个个都有自我意识才如此可悲。[p]
会思考[wait time="500"]　会追忆[wait time="500"][r]
执着于成为独一无二的自己[wait time="500"]实则徒劳。[p]
就连雾绘也因那离家出走的愚蠢自尊――――[p]
[bg storage="indoor/makado_ima_m.jpg" wait="false" cross="false" time="8000"]
若没有那份渴望确立自我的祈祷[r]
本不必落得那般怀孕的下场　你不这么想吗？[p]
#
[font size="20"]
…………。[p]
[font color="0xb0c4de"]
「……纱……罗纱……纱………」[p]
[bg storage="yotuyamabridge_m.jpg" wait="false" cross="false" time="8000"]
[resetfont]
#mokke
――呜[p]
#
[font color="0xb0c4de"]
[font size="20"]
「纱罗纱、纱罗纱、纱罗纱！！！」[p]
[resetfont]
#mokke
[font size="40"]
[playse  volume="30" buf="0" storage="kansei.ogg"]
啊啊，啊啊！！！[wait time="500"][resetfont]　我的肉体正聆听着那回荡的声响！[r]
终于我即将再度[wait time="500"]　显现于世！！[p]
[resetfont]
#
……沿着丝线，传来树月哭喊的声音。[p]
[mask]
#ituki
[bg storage="still/ituki_te1.png" time="10"]
[mask_off]
纱罗纱！　纱罗纱，[p]
求求你，[wait time="500"]祈祷吧……[p]
现在向谁都行，[wait time="500"]向任何神明都行，[r][wait time="500"]
祈求想要活下去啊！！[p]

――啊已经不行了，对不起啊，[r]
对不起啊纱罗纱……[p]

我、根本不知道该怎么救朋友。[r][wait time="500"]
拯救他人的方法，[wait time="500"]我完全不懂啊！！[l][r]
对不起，如果我不是三宫女的话，[p]
只是个普通女孩子的话[wait time="500"]这种时候……[p]
呜、[wait time="500"]呜呜………[r]
…………………………………………………………[p]
………………………………………………[r]
对不起…………[wait time="500"]我只能为你祈祷了[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/ituki_te2.png" time="600" wait="true" cross="false"]
[fadeoutbgm time="5000"]
[wait time="7000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
…………[p]
……纱、[wait time="500"]纱、[wait time="500"]纱罗[p]
[mask]
#mokke
[bg storage="siro4.png" time="10"]
[chara_show name="mokke" top="-160" face="ito_4" time="10"]
[mask_off]
啊…………？什么？[p]
#mokke
搞什么……喂，你这家伙。[l][r]
[resetdelay]
喂，你手上拿的是什么[p]
#
……我的、[p]
[delay speed="60"]
我们的祈祷，[wait time="500"]并非徒劳。[p]
[mask time="100"]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="mokke" time="10"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
;ＳEシャン
[bg storage="still/ganmon.png" time="10"]
[mask_off time="6000"]
[wait time="2000"]
[bg storage="still/white.png" wait="true" cross="false" time="3000"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[wait time="2000"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="1"]
[playse  volume="40" buf="0" storage="basya2.ogg"]
[bg storage="still/metamorphose.png" time="300" wait="true" cross="false"]
[wait time="5000"]
[mask folder="bgmage/still/metamorphose.png" time="100"]
;-------------------------------------------------------------------------------
[chara_face name="sarasa" face="normal_g" storage="chara/sarasa/shirakinu/normal_g.png"]
[chara_face name="sarasa" face="angry_g" storage="chara/sarasa/shirakinu/angry_g.png"]
[chara_face name="sarasa" face="closeEye_g" storage="chara/sarasa/shirakinu/closeEye_g.png"]
[chara_face name="sarasa" face="sad_g" storage="chara/sarasa/shirakinu/sad_g.png"]
[chara_face name="sarasa" face="shout_g" storage="chara/sarasa/shirakinu/shout_g.png"]
[chara_face name="sarasa" face="tweet_g" storage="chara/sarasa/shirakinu/tweet_g.png"]
[chara_face name="sarasa" face="smile_g" storage="chara/sarasa/shirakinu/smile_g.png"]
;-------------------------------------------------------------------------------
[chara_show name="sarasa" top="-160" face="closeEye_g" time="10"]
[bg storage="yama.jpeg" time="10"]
[mask_off time="3000"]
[wait time="1000"]
[chara_move name="sarasa" width="-=300" anim="true" wait="true" top="+=100" time="1000" left="+=150"]
[wait time="2000"]
[chara_mod name="sarasa" face="normal_g"]
[wait time="3000"]
[chara_hide name="sarasa" wait="false" time="3000" pos_mode="false"]
[chara_show name="ituki" top="-160" face="cry4_s"  wait="false" left="140" time="3000"]
#ituki
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……纱、纱……[p]
#ituki
…………[p]
#ituki
纱罗纱……[wait time="500"]你到底是……[p]
#
[iscript]
TYRANO.kag.stat.charas['sarasa'].jname = '？？'
[endscript]
[chara_hide name="ituki" time="100" wait="true" pos_mode="false"]
[chara_show name="sarasa" top="-60" face="normal_g" wait="true" time="300"]
#sarasa
……………[p]
[chara_hide name="sarasa" time="100" wait="true"  pos_mode="false"]
[chara_show name="ituki" top="-160" face="cry4_s" wait="false" time="300"]
#ituki
喂……[l][r]
哪个、到底是哪个？[wait time="500"]　现在的你，是御白姬？还是志户田纱罗纱？[r][wait time="500"]
求求你回应我，[p]
那是我的………………[wait time="500"]我的[wait time="500"]重要孩子的身体啊[p]
[resetdelay]
#ituki
如果那个孩子再也不会来到这里的话――[r]
我、想要忘记一切[p]
[chara_hide name="ituki" time="100" wait="true" pos_mode="false"]
[chara_show name="sarasa" top="-60" face="closeEye_g" wait="false" time="300"]
#sarasa
不要忘记　我们是这样约定的对吧[p]
[chara_hide name="sarasa" time="100" wait="true"  pos_mode="false"]
[chara_show name="ituki" top="-160" face="cry4_s" wait="false" time="300"]
#ituki
…………[p]
[iscript]
TYRANO.kag.stat.charas['sarasa'].jname = '志戸田 紗羅紗'
[endscript]
[chara_hide name="ituki" time="100" wait="true"  pos_mode="false"]
[chara_show name="sarasa" top="-60" face="smile_g" wait="false" time="300"]
[chara_face name="sarasa" face="smileMini_g" storage="chara/sarasa/shirakinu/smileMini_g.png"]
#sarasa
明明还没和一树去成海边[wait time="500"]　[r][wait time="800"]
我还不会死哦[p]
[font size="40"]
[chara_hide name="sarasa" time="10" wait="true"  pos_mode="false"]
[chara_show name="ituki" top="-160" face="cry4_s" wait="false" time="300" zindex="2"]
#ituki
………………………………！！！[p]
[quake time="30"]
#ituki:cry5_s
――――[playbgm storage="gymnopedies2.ogg" loop=true volume=100]
纱罗纱！！！[p]
[resetfont]
[chara_move name="ituki" wait="true" left="-90" anim="true"]
[chara_show name="sarasa" top="-100" face="smileMini_g" left="5" wait="false"]
#sarasa
对不起，我一直都听得到。对不起……[p]
#ituki
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
再多、再多道歉几次！[wait time="500"][r]
这么可怕的经历，我还是第一次！！！[p]
#ituki:cry4_s
[delay speed="100"]
真的，真的好害怕……！[p][stop_kanim name=树]
[delay speed="60"]
#sarasa:smileMini_g
嗯。[r][wait time="500"]
对不起，对不起嘛，……[p]
[resetdelay]
#ituki:cry3_s
已经……[r][wait time="500"]
头发都变不回来了啊，笨蛋，[wait time="500"]笨蛋，[wait time="500"]笨蛋……！！！[p]
#
树月将脸深深埋进志户田纱罗纱的胸膛。[l][r]
压迫感让脸颊和额头都泛起了红晕。[p]
#sarasa
好痛、好痛啦…… 一树你这家伙[p]
#ituki
这点程度就忍着啊！[r]
人家在纱罗纱昏迷的时候，[r]
可是被马门贤治郎狠狠踢飞过啊！[p]
#ituki:cry1_s
——但是，到底发生什么了？[l][r]
这副模样虽然漂亮，但完全搞不明白…………[p]
#sarasa:normal_g
……[l]
#sarasa:closeEye_g
因为一树理解了我的想法[r]
才能像这样回来啊。[p]
#sarasa:tweet_g
我[wait time="500"]　直到刚才[wait time="500"]　还在和御白姬说话——[p]
[mask time="2000"]
[chara_hide_all time="10"]
[bg storage="siro4.png" time="10"]
#
;○白空間
[mask_off]
[font size="40"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[quake time="30"]
嘎啊啊啊啊啊！！！！[p]
[resetfont]
——纯白的空间里，回荡着她的尖叫声。[p]
#mokke
你……[wait time="500"]这家伙，[quake time="30"]竟敢，[wait time="500"]竟敢做什么！！！？[r]
好痛，[wait time="500"]好痛，[wait time="500"]痛死了啊！！！！[p]
[delay speed="60"]
#sarasa
请忍耐一下……[r][wait time="500"]
因为我也…曾经痛彻心扉啊[p]
[resetdelay]
#mokke
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
啊啊，为什么丝线会断裂！？！[r]
你这家伙明明只是个即将消亡的自我意识——[p]
[chara_show name="mokke" face="hate" top="-160" time="300" left="-80" wait="false"]
#mokke
…………[chara_move name="mokke" width="-=100" anim="true" wait="false"]
[p]
[delay speed="100"]
#mokke:shout
……御白姬大人，您这是做什么？[p]
[chara_show name="sarasa" face="closeEye_gs" top="-160" time="300" left="420" wait="false"]
#sarasa
…………[chara_move name="sarasa" width="-=100" anim="true" wait="false"]………………………………[p]
[resetdelay]
#sarasa:normal_gs
是[l][r]
……………………我，正在祈祷[p]
[delay speed="60"]
#sarasa:closeEye_gs
为了让我，[wait time="500"]能成为您的眷属。[r][wait time="500"]
为了获得您的祝福。然后——[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
#sarasa:angry_gs
[font color="0xf08080"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
让我，[wait time="500"]能够成为御白姬[resetfont][p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[font size="40"]
#mokke:hate
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
——你、你说什么！？！[p]
[resetfont]
#mokke
……………………………………………………[p]
[resetdelay]
#mokke:smile
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"][font size="40"]
[anim name="mokke" top="+=60" time="200"]
[anim name="mokke" top="-=60" time="200"]
啊哈哈哈哈哈哈、[r][resetfont][wait time="500"]
你在胡说什么[wait time="500"]　蠢货！！[p]
#mokke:smile
确实啊，刚才树月哼唱的那段[font color="0xf08080"]愿文[resetfont]是[r]
吾施展力量时与人类立约的誓词。[p][resetfont]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
但是啊，是否实现祈愿的权柄在吾手中！！[l][r]
要吾亲自成为你的[font color="0xf08080"]御白姬[resetfont]
此等妄言吾岂会应允[r]
简直荒谬、[p]
[delay speed="120"]
痴心妄想…………[p]
[fadeoutbgm time="2000"]
#mokke:smileMini
……………………………………………………[r]
……………………………………………………[p]
[resetfont]
#sarasa:closeEye_gs
最初如此祈求之人　正是阁下[wait time="500"]　御白姬[p]
[delay speed="60"]
#sarasa:normal_gs
[playse  volume="70" buf="0" storage="sariin.ogg" ]
是你、[wait time="500"]想成为我吧？[p]
#mokke
……………………………………………………[r]
……………………………………………………[p]
#mokke
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
你……[p]
[delay speed="10"]
#mokke:hate
[quake time="30"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
不对！　[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="50" sprite_time="0000-105000"]
我要将我的意识、植入你这具躯体！！[p]
[resetdelay]
#mokke:smile
[playse  volume="20" buf="0" storage="kakan.ogg" ]
哼、[r]
而且能与你缔结实现愿望之约的只有我[r]
你不过是个凡人！[wait time="500"][p]
作为女神的我岂是你能够超越的！！[r]
真是遗憾啊，就算你绞尽脑汁强词夺理，[r]
像你这种程度的自我意识能想到的终究只是、[p]
[delay speed="60"]
#sarasa:closeEye_gs
[playse  volume="20" buf="0" storage="kakan.ogg" ]
是的　您说得对[l][r]
#sarasa:normal_gs
我……无法成为与你[font color="0xf08080"]不同的存在[resetfont][p]
#sarasa:angry_gs
但是呢[wait time="500"]　所以这份祈愿该由我们……[wait time="500"][r]
不对[wait time="500"]　[font color="0xf08080"][playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
必须由我[resetfont]来实现才行[p]
#mokke
…………[l][delay speed="120"]
不、不对　你和我[p]
[resetdelay]
#sarasa:closeEye_gs
呐[wait time="500"]　你已经忘记了吗？[r]
御白姬[p]
#sarasa:angry_gs
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font color="0xf08080"]
就在刚才　还作为"同等的存在"[wait time="500"][r]
与我紧密相连这件事[p]
[chara_face name="sarasa" face="shout_gs" storage="chara/sarasa/shirakinu/shout_gs.png"]
[playse  volume="30" buf="0" storage="garasu.ogg" ][font size="40"]
[quake time="30"]
#sarasa:shout_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
我可是　记得清清楚楚！！[r][wait time="500"][resetfont]
这些都是我珍贵的记忆　一点都没有忘记！！！[p]
[stop_kanim name=sarasa]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#mokke:hate
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
……………………………………………………[p]
#mokke:shout
[delay speed="100"]
呜……呜啊啊，笨蛋、笨蛋啊！[l][r]
[resetdelay]
[chara_hide name="mokke" wait="false"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_mod name="sarasa" face="closeEye_gs"]
抛弃它、立刻抛弃那个自我！！！[r]
御白姬――――[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font size="40"]
[quake time="100"]
#mokke
作为实现愿望的存在，[r]
不准再继续扭曲下去了啊啊啊！！！！[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
#
[playse  volume="20" buf="0" storage="kakan.ogg" ]
#sarasa:angry_gs
来吧。一决胜负吧，[r]
就在此刻――――――[p]
[chara_move name="sarasa" anim="true" width="+=300" wait="false" time="10" left="-=140" top="-=100"]
#sarasa:shout_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
我与您[wait time="1000"][r]
究竟谁才配得上这座城镇的女神之名！[p]
[resetfont]
[stop_kanim name=sarasa]
[mask time="4000"]
[bg storage="yama.jpeg" time="10"]
[chara_hide name="sarasa" time="10"]
[fadeoutbgm time="4000"]
[wait time="4000"]
[chara_show name="sarasa" top="-100" face="smileMini_g" left="5" time="10"]
[chara_show name="ituki" left="-90" time="10" top="-160" face="cry1_s"]
#sarasa
;○森
[mask_off time="3000"]
[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
我　好像赢过那个人了[p]
[delay speed="60"]
#sarasa:smile_g
一定是因为独占了一树的那份……[r]
被当作女神大人仰慕的心情[r]
才能做到的吧[p]
#ituki:cry5_s
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
笨、笨蛋吗……[wait time="500"]这算什么啊！！[r]
说这种话不觉得羞耻吗！？[p]
#sarasa:smileMini_g
是有点羞耻[p]
#ituki:cry3_s
啊哈哈……[l][r]
人家也很害羞啦，真是的！[p]
#ituki:cry2_s
………………………………………………[l][r]
……不过，能再和纱罗纱说话真是太好了。[p]
#ituki:cry3_s
这下就没什么可担心的了。[wait time="500"]来，我们回祭典吧？[p]
#sarasa
……………………………………………………[l][r]
#sarasa:normal_g
……………………………………………………[p]
#sarasa:closeEye_g
唔……还不行哦[p]
#ituki:cry1_s
诶？[p]
#sarasa:angry_g
还没、结束。[l][r]
御白姬已经回到这个小镇了[p]
[delay speed="70"]
#ituki
……[l]纱罗纱她……[r]
已经完全变成御白姬了不是吗？[p]
#sarasa:closeEye_g
嗯……本来确实是这样打算的呢。[p]
[delay speed="60"]
#sarasa:normal_g
虽然御白姬和我已成为同一存在，[r]
但我们之间，唯独……[wait time="500"][font color="0xf08080"]完全
存在着[resetfont]不完全相同的部分[l][r]
唯有这一点，我似乎没能完全掌控”她”[p]
[delay speed="70"]
#ituki
……那是什么？[p]
[resetdelay]
#sarasa:tweet_g
[playse  volume="20" buf="0" storage="sariin.ogg" ]
是自我意识啊[p]
[delay speed="60"]
#sarasa:closeEye_g
虽然知道的事、能做的事都相同，[r][wait time="500"]
那个人和我性格却截然不同。[p]
#sarasa:angry_g
所以那个人……[l][r][delay speed="70"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
此刻[font color="0xf08080"]
仅凭化作灵魂的碎片[resetfont]，就潜入了这座城市的[r]
「某具肉体」之中[p]
#ituki:sadB_s
肉体……[p]
#ituki:tweetG_s
那岂不是说[wait time="500"]　那个女人现在[wait time="500"]　究竟[font color="0xf08080"]
变成了谁[resetfont]！？[p]
#
御白姬可能附身的人物是――[p]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[r]
【选择正确的选项】[r]
御白姬所逃往的肉体名字是？[r]

[glink color="btn_12_black" target="*but" text="志戸田絹世" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good" text="宗方雾绘" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but" text="宗方优" width="20" x="580" y="60"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop"
;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]
#sarasa
是雾绘小姐…………[p]
[resetdelay]
[font size="40"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#ituki:sadB_s
——！[p]
[resetfont]
#ituki:shout_s
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
可那不是马门贤治郎制造的冒牌货吗！？[r]
用那种恶心的白色祝福……！[l]　怎么会……[p]
#sarasa
正因如此。那具肉体没有自我意识。[l][r]
#sarasa:tweet_g
而且……[r]
若是用御白姬的祝福制造的肉体　便等同于御白姬的子嗣[p]
#sarasa:sad_g
[delay speed="60"]
就连我们的先祖也……[r][wait time="500"]
我们最初也是因祝福而诞生的啊[p]
#ituki:sadG_s
……我们？[p]
#sarasa:normal_g
…………………………[l][r]
[resetdelay]
#sarasa:closeEye_g
不，待会儿再慢慢告诉你。[r]
[chara_hide name="sarasa" wait="false"]
现在当务之急是必须赶去――[p]
[fadeoutbgm time="3000"]
[font size="40"]
#ituki:sadB_s
[quake time="30"]
！！[l][r]
#ituki:shout_s
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
等等！[p][resetfont]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
#
……树月突然拽住我的手腕。[p]
[delay speed="100"]
#ituki:tweetG_s
……别去见他。那家伙会……[p]
#ituki
察觉到的啊……[l][r]
你现在是要去见纱罗纱和贤治郎先生对吧[p]
[delay speed="50"]
#sarasa
……嗯[p]
我，[r]
有东西必须还给贤治郎先生。[p]
而且，现在――[r][wait time="500"]
贤治郎先生正因为伤害了我而痛苦着[p]
所以……[l]我想告诉他「没关系的」[p]
#ituki:shout_s
[playse  volume="30" buf="0" storage="garasu.ogg" ]
纱罗纱根本没有任何东西需要还给那家伙！！[l][r]
#ituki:tweetG_s
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
因为那家伙、[r][fadeinbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400" time="10000"]
[wait time="500"]
――那家伙可是伤害了纱罗纱啊！？[p]
[resetdelay]
#ituki:cry4_s
[font size="20"]
刚才也是、[wait time="500"]我明明[r][wait time="500"]
是怀着怎样的心情放他走的……[p]
[resetfont]
#sarasa
不对。[l][r]
我从一树和贤治郎先生那里都得到了很多珍贵的东西啊[p]
[delay speed="50"]
不止是他们两人。[r]
我真的从许多人那里、得到了各种各样的东西[p]
[delay speed="60"]
所以、必须回报才行[p]
#ituki
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
…………………………………………[p]
#ituki:cry2_s
…………………………………………[p]
……………………为什么我总是……[r]
这么无可救药呢。[p]
一直以来都是这样[r]
像我这样的人无论说什么　做什么……[p]
明明自以为已经完全明白了[r][wait time="500"]
纱罗纱不会事事顺我心意这件事[p]
#ituki:cry3_s
所以我才[r][wait time="500"]
喜欢纱罗纱选择小指的那些时光[r][wait time="500"]
只有那时候纱罗纱[wait time="500"]　眼里才会只看着我呢……[p]
[chara_hide name="ituki" time="2000" wait="false" pos_mode="false"]
#
树月、[wait time="500"]……当场瘫坐在地。[p]
[playse  volume="40" buf="0" storage="book.ogg" ]
[wse]
#sarasa
…………………………………………[p]
#sarasa
一树　别哭了[l][r]
我想守护这座小镇　为了让一树不再哭泣[p]
[font size="20"]
#ituki
嗯…………、嗯………。[l][r]
………………………我知道的、对不起………………[p]
我……[l][r]
我比自己想象中要任性得多　真是羞耻啊[p]
[resetfont]
#sarasa
………………………[l]不。[r]
[bg storage="brack.png" wait="false" cross="false"]
我对一树的任性程度　可一点也不输给你呢[p]
我要去了　去救那个人[p]
[mask time="3000"]
[fadeoutbgm time="4000"]
[wait time="6000"]
[bg storage="hanasumiFalls_m.jpg" time="10"]
[fadeinbgm storage=bigriver.ogg loop=true  time="10000" volume="10"]
;○川沿い
#
[mask_off time="7000"]
[delay speed="70"]
……………………………………………………[p]
#makado
（……日头已经升高了）[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font size="22"]
承载着重大责任与漫长历史的我[r][wait time="500"]
仅仅数小时　就将这所有的积淀毁得七零八落。[l][r]
[r]
不[wait time="500"]　是一直都在破坏着。[r]
[delay speed="50"]
从八月初开始。从那个冬天开始。从诞生之时起，从拥有自我意识的瞬间起――[l][r]
这般持续至今的破坏，[wait time="500"]终于也波及到了志户田纱罗纱。[l][r]
我厌恶什么都守护不了、什么都无法如愿以偿的自己，[r]
但此刻却不得不血淋淋地直面这样的自己，[r]
已经不知该如何是好，无处可逃，进退维谷。[l][r]
[r]
再也感受不到那双窥探记忆的目光，想必她已不复存在了吧。[l][r]
明明是个身处令人想逃离的困境却仍能顽强抗争的，[r]
与我自己天差地别的孩子[wait time="500"]　　　却被我杀死了。[p]
[delay speed="70"]
真相与[l][r]
[r][r]
自己之间垂落的[wait time="500"][r]
站在白色幕布被揭开之处的[l][r]
正是我最后所见雾绘的模样[l][r]
[r]
[delay speed="100"]
那不容错辨的、[wait time="500"]正迈向无可逃避之死亡的生命的姿态。[p]
@layopt layer=message0 visible=false
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="800"]
[chara_face name="kirie" face="cut" storage="chara/kirie/cut.png"]
[chara_show name="kirie" top="-60" face="cut" wait="true" time="4000"]
[wait time="3000"]
@layopt layer=message0 visible=true
[stopbgm]
好冷。[l][r]
[delay speed="70"]
这个夏天，[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
冷得让人难以活下去。[l][r]
[chara_move name="kirie" anim="true" left=110 top="-60" width="+=50" time=1000 wait="false"]
若是连这个夏天都熬不过，[r]
更遑论要度过之后的季节了。[l][r]
[r]
[chara_move name="kirie" anim="true" left="90" top="-80" width="+=50" time=1000 wait="false"]
[delay speed="50"]
雾绘一定也一直很冷吧。[wait time="500"][r]
父亲临终时，想必也很冷吧。[l][r]
[chara_move name="kirie" anim="true" left="70" top="-100" width="+=50" time=1000 wait="false"]
我终究无法实现雾绘的嘱托，[l][r]
也没能成为父亲期望的那种人，[wait time="500"][r]
就这样——[p]
[chara_hide name="kirie" time="10" wait="true"]
@layopt layer=message0 visible="false"
[resetfont]
[chara_show name="sarasa" face="closeEye_g" top="-160" time="500" wait="true"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[fadeoutbgm time="2000"]
[chara_move name="sarasa" width="-=300" anim="true" wait="true" top="+=100" time="1000" left="+=150"]
[wait time="2000"]
#sarasa:angry_g
[resetdelay]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
——别用这副模样伤害贤治郎先生！[p]
#オシラヒメ
[quake time="30"]
[font size="40"]
！！[p][resetfont]
;ＳE走り去っていく
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="2000"]
#sarasa:closeEye_g
……[p]
#sarasa:tweet_g
[delay speed="50"]
……………………………………[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
贤治郎先生[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
如白绢织就的少女，[r]
轻轻托起贤治郎的头颅[wait time="500"]　又放回原处。[p]
[playse storage=ti.ogg volume="10" loop="true"]
[delay speed="60"]
以此为契[wait time="500"][r]
那团蠕动着的苍白肉块边收缩边爬行，[r]
这次复上了青年的右半身。[p]
[stopse]
#sarasa:sad_g
……已经看不出原本的形状了呢[p]
#
@layopt layer=message0 visible=false
[clearfix]
[chara_mod name="sarasa" face="closeEye_g"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[mask folder="bgimage"  graphic="still/white.png" time="2000"]
[fadeoutbgm time="3000"]
[wait time="5000"]
[chara_hide name="sarasa" time="10"]
[bg storage="still/makado_1.jpg" time="10"]
[mask_off time="4000"]
[wait time="3000"]
[playbgm storage=umitoyadorino.ogg volume=35 sprite_time="0000-58000" loop=true]
[wait time="1000"]
#sarasa
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
大家一定会原谅你的。[l][r]
伤害我的行为[wait time="500"]　并非出自你的本意[p]
我、知晓你原本的姿态。[wait time="500"]贤治郎先生――[p]
[delay speed="50"]
#sarasa
来吧[wait time="500"]　请回忆起最初的祈愿。[r]
贤治郎先生绝不是[r]
为了玩弄人命才寻求祝福的吧。[p]
[delay speed="60"]
你[wait time="500"]　向我们祈求的是――[p]
#sarasa
想要守护[wait time="500"]重要之人这件事[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="1000"]
[bg storage="still/makado_2.png" wait="true" cross="false" time="4000"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
[delay speed="100"]
————……[l][font size="20"]
还活着[p][resetfont]
[delay speed="50"]
#sarasa
贤治郎先生、记忆力真好呢。[p]
多亏贤治郎先生把和父亲大人的对话都事无巨细地记着，[r]
我[wait time="500"]　才能回到这里[p]
[delay speed="100"]
[font size="20"]
#makado
那是……[l][r]
是老爸的功劳啦[wait time="500"]　跟我没关系[p]
[resetfont]
[delay speed="50"]
#sarasa
才不是这样。[l][r]
[resetdelay]
来，请站起来吧[wait time="500"][r]
再这样下去的话 白绢祭就没法开始了[p]
[mask folder="bgimage"  graphic="still/white.png" time="2000"]
[bg storage="hanasumiFalls_m.jpg" time="10"]
[chara_show name="sarasa" top="-10" face="normal_g" left="5" time="10"]
[chara_show name="makado" top="-10" face="sad" time="10" left="-180"]
[wait time="4000"]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="normal_e" storage="chara/makado/trueEye/normal_e.png"]
[chara_face name="makado" face="hurryB_e" storage="chara/makado/trueEye/hurryB_e.png"]
[chara_face name="makado" face="lookAway_e" storage="chara/makado/trueEye/lookAway_ce.png"]
[chara_face name="makado" face="shout_e" storage="chara/makado/trueEye/shout_e.png"]
[chara_face name="makado" face="smileMini_e" storage="chara/makado/trueEye/smileMini_e.png"]
[chara_face name="makado" face="tweetB_e" storage="chara/makado/trueEye/tweetB_e.png"]
[chara_face name="makado" face="worry_e" storage="chara/makado/trueEye/worry_e.png"]
[chara_face name="makado" face="wowB_e" storage="chara/makado/trueEye/wowB_ce.png"]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="normal_ce" storage="chara/makado/trueEye_Cap/normal_ce.png"]
[chara_face name="makado" face="angry_ce" storage="chara/makado/trueEye_Cap/angry_ce.png"]
[chara_face name="makado" face="bike_ce" storage="chara/makado/trueEye_Cap/bike_ce.png"]
[chara_face name="makado" face="lookAway_ce" storage="chara/makado/trueEye_Cap/lookAway_ce.png"]
[chara_face name="makado" face="shout_ce" storage="chara/makado/trueEye_Cap/shout_ce.png"]
[chara_face name="makado" face="smile_ce" storage="chara/makado/trueEye_Cap/smile_ce.png"]
[chara_face name="makado" face="smileMini_ce" storage="chara/makado/trueEye_Cap/smileMini_ce.png"]
[chara_face name="makado" face="tweetB_ce" storage="chara/makado/trueEye_Cap/tweetB_ce.png"]
[chara_face name="makado" face="tweetLA_ce" storage="chara/makado/trueEye_Cap/tweetLA_ce.png"]
[chara_face name="makado" face="worry_ce" storage="chara/makado/trueEye_Cap/worry_ce.png"]
;あとでけす
;-------------------------------------------------------------------------------

#makado
[mask_off]
;森
;ＳEがさ
…………[p]
#sarasa
很疼吗？右手……[p]
[delay speed="60"]
#makado:lookAway_e
不……[wait time="500"]没事。抱歉……[p]
#makado:worry_e
比起这个，…………你这副模样到底怎么回事。[l][r]
简直就像是[wait time="500"]　真的变成女神了一样……[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[chara_show name="ituki" left="130" face="hate_s" time="300" wait="false" top="-80"]
#ituki
不是像，是真的变成了。真正的御白姬啊[p]
[delay speed="100"]
#makado:wowB_e
！[wait time="500"][r]
[anim name="makado" left="-=10" time=50 ]
[anim name="makado" left="+=10" time=50 ]
一、一树……[p]
[delay speed="50"]
#ituki
先说好，[r]
就算纱罗纱原谅你 我这辈子也绝不会原谅你。[r]
那件事也绝对不会道歉[p]
[delay speed="60"]
#
树月无需再多言语，[r]
眼神已道尽对他的憎恶。[l][r]
贤治郎先生却用怯懦的目光与她对峙着。[p]
#makado:sad
不……[wait time="500"]我从没想过能获得原谅。[p]
#makado:tweetB_e
…………都是我的错。[wait time="500"][r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
为了许愿这种理由[wait time="500"]　就带着能当凶器的工具……[p]
#sarasa:normal_g
那把像雕刻刀一样的利器……[p]
[delay speed="50"]
#sarasa:tweet_g
刚才逃走的[r]
被御白姬带走了呢。[r]
您是从哪里得到那东西的？[p]
[delay speed="100"]
#makado:lookAway_e
…………啊，那是……[p]
#makado:worry_e
[delay speed="70"]
……诶？御白姬？[r]
那明明是因为我而产生的、雾绘的幻影……[p]
[delay speed="50"]
#ituki:tweetLA_s
别转移话题，快回答。[r]
现在的我们总之先按纱罗纱说的做[p]
[delay speed="70"]
#makado
啊、[wait time="500"]……嗯，……是啊。[p]
#makado:normal_e
[delay speed="50"]
那是，[r]
从纪伊玛莉甘那里得到的[font color="0xf08080"]关于封印的道具[resetfont]。[l][r]
#makado:lookAway_e
不过，玛莉甘和我连使用方法都不知道呢……[p]
#sarasa:normal_g
——————封印……[p]
#ituki:tweet_s
下达诅咒指令的是御白姬的话，[r]
被封印在绢布里的[r]
也不是什么妖怪而是御白姬对吧[p]
#sarasa:closeEye_g
说是绢布封印，不如说……[l][r]
#sarasa:tweet_g
把绢布缠绕在木制的神体上……[wait time="500"]
[font color="0xf08080"]看来似乎夺走了嘴和眼睛[resetfont][p]
[font size="40"]
#makado:wowB_e
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——！[l][r][resetfont]
[resetdelay]
#makado:shout_e
[quake time="100"]
纱罗纱，你明白封印方法了！？[p]
#sarasa:normal_g
…………………………………………[l][r]
#sarasa:closeEye_g
不对[p]
[delay speed="60"]
#
那一定是连如今……[wait time="500"][r]
已成为御白姬的我也无法知晓的过往。[p]

[eval exp="f.flag1=false"]
[eval exp="f.flag2=false"]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop2
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]

[r]
[font size="25"]
【选择正确的选项】[r]
在御白姬所能窥见的＿＿之＿＿里
不可能存在知晓封印仪式方法之人[r]

[glink color="btn_12_black" target="*but2" text="回顾" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*good2" text="眷属" width="20" x="450" y="60" ]
[glink color="btn_12_black" target="*but2" text="絹布" width="20" x="390" y="60"]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*but2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop2"
;-------------------------------------------------------------------------------
*good2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]

[r]
【选择正确的选项】[r]
在御白姬所能窥见的眷属之＿＿中
不可能存在知晓封印仪式方法之人[r]

[glink color="btn_12_black" target="*good3" text="回顾" width="20" x="510" y="60" ]
[glink color="btn_12_black" target="*good2" text="絹布" width="20" x="390" y="60" exp="f.flag1=true" clickse="tapSE.ogg"]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*good3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]


*atomawasi_osira8
[chara_hide_all wait="false"]
御白姬曾提及绢布燃烧时的情形……[r]
她当时是这么说的。[p]
[mask]
[chara_show name="mokke" face="smile" top="-160"]
[bg storage="brack.png" time="10"]
[mask_off]
[resetdelay]
#mokke
多亏如此 我才能与[font color="0xf08080"]初代[resetfont]马门家眷属[r]
[font color="0xf08080"]随着绢布的烧毁[resetfont]我获得了行动的自由[p]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
历经数百年光阴[r]
运势 机缘 乃至天下大势 都该轮转一巡了吧！[p]
[fadeoutbgm time="5000"]
[mask]
#sarasa:closeEye
[chara_hide name="mokke" time="10"]
[bg storage="hanasumiFalls_m.jpg" time="10"]
[chara_show name="sarasa" top="-10" face="closeEye_g" left="20" time="10"]
[chara_show name="makado" top="-10" face="lookAway_e" time="10" left="-180"]
[chara_show name="ituki" left="130" face="tweet_s" time="300" wait="false" top="-80" time="10"]
[mask_off]
（……自狮心教创立至今[wait time="500"][r]
马门家出身且成为狮心教眷属的，唯有贤治郎先生一人）[p]
[delay speed="50"]
#
（所以肯定……[wait time="500"]在我能窥见的'回溯'中，[r]
也不存在能获知封印方法之人。[l][r]
连贤治郎先生都不知晓的，[font color="0xf08080"]马门家的秘密[resetfont]什么的……）[p]
@layopt layer=message0 visible=false
[clearfix]
[mask time="100"]
[chara_hide_all time="10"]
;ＳEカーン
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[bg storage="still/huin2.png" time="10"]
[wait time="2000"]
[mask_off time="100"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[wse]
[wait time="4000"]
[mask time="100"]
#
[bg storage="hanasumiFalls_m.jpg" time="10"]
[chara_show name="makado" top="-10" face="lookAway_e" time="10" left="-90"]
[chara_show name="ituki" left="360" face="tweet_s" time="10" wait="false" top="-50" time="10"]
[wait time="3000"]
[mask_off]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
…………………………………………[p]
#makado:normal_e
…………？[l][r]
………………………………[p]
#makado
怎么了？[wait time="500"]　纱罗纱……[p]
[delay speed="100"]
#sarasa
……本人，[wait time="500"][fadeinbgm storage=severe-reprimande.ogg loop=true time=3000 volume="30"]
看见了[p]
#ituki:tweet_s
咦？[p]
#sarasa
当本人，[wait time="500"]被那样对待时，[l][r]

最后，[wait time="500"]看见了[p]
#ituki
……什、什么……？[p]
#sarasa
御白姬。[p]
只有御白姬……[wait time="500"][r]
[font size="40"]
[resetdelay]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"][font color="0xf08080"]
我知道封印御白姬的方法！！[p]
[mask time="300"]
[chara_hide_all time="10"]
[bg storage="mountainRoad_m.jpeg" time="10"]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = 'オシラヒメ'
[endscript]
#kirie
[wait time="1000"]
[mask_off time="300"]
;○お堂
[quake time="30"]
[playse  volume="30" buf="0" storage="kansei.ogg"]
啊哈哈哈哈哈哈！[p]
[font size="40"]
[chara_show name="kirie" face="smile" top="-60" wait="false" time="100"]
#kirie
[playse  volume="20" buf="0" storage="kakan.ogg" ]
太迟了，现在才想起来吗！女神的余晖！！[p]
[resetfont]
#kirie
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
很好很好，就这样好好珍惜最后的离别吧！[r]
等把你封印之后[r]
我要挖出[wait time="500"]　你的眼珠，拔掉你的舌头！！[p]
[mask time="300"]
[chara_hide name="kirie" time="10"]
[bg storage="hanasumiFalls_m.jpg" time="10"]
[chara_show name="makado" top="-10" face="tweetB_e" time="10" left="-90"]
#ituki
[chara_show name="ituki" left="360" face="sadB_s" time="10" wait="false" top="-50" time="10"]
[mask_off]
[delay speed="100"]
…………不要[p]
[resetdelay]
#ituki:tweetG_s
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
不要啊，[r]
纱罗纱她……[wait time="500"]要被那个女人封印了！？[r]
我不要、我绝对不要这样！[p]
[delay speed="60"]
#makado
…………我们早已失传的仪式，[r]
如今只有被封印之物才能操控什么的…………[p]
#sarasa
这种事情…………[p]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……这种事情，[wait time="500"]我绝不允许发生[p]
[mask]
[chara_hide_all time="10"]
[fadeoutbgm time="3000"]
[wait time="3000"]
#
[showsave]
@jump storage="chapter_5/day1_vol7.ks"
;セーブしますか？
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
