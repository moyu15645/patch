[eval exp="f.save_title = '幕間　営繭の朝'"]
[mask folder="bgimage" graphic="still/interval.png" time="3000"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
;-------------------------------------------------------------------------------
[chara_face name="kirie" face="normal_w" storage="chara/kirie/winter/normal_w.png"]
[chara_face name="kirie" face="hate_w" storage="chara/kirie/winter/hate_w.png"]
[chara_face name="kirie" face="angry_w" storage="chara/kirie/winter/angry_w.png"]
[chara_face name="kirie" face="lookAway_w" storage="chara/kirie/winter/lookAway_w.png"]
[chara_face name="kirie" face="sad_w" storage="chara/kirie/winter/sad_w.png"]
[chara_face name="kirie" face="shame_w" storage="chara/kirie/winter/shame_w.png"]
[chara_face name="kirie" face="smile_w" storage="chara/kirie/winter/smile_w.png"]
[chara_face name="kirie" face="smileW_w" storage="chara/kirie/winter/smileW_w.png"]

;-------------------------------------------------------------------------------
[bg storage="koen_n.jpeg" time="10"]
#
[mask_off time="4000"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
――约两年前，冬季。[p]

没有下雪的冬天。[p]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[chara_show name="kirie" top="-10" face="hate_w" wait="false" left="150"]
[font size="40"]
#kirie
[quake time="30"]
――马门君！！[p]
[resetfont]
[delay speed="50"]
#kirie:lookAway_w
果然，你在这里……[p]

#kirie:sad_w
围巾手套都不戴，不冷吗。[r]
我的借给你[p]

#makado
…………………………………………[p]
不用……不需要[p]

#kirie
……是啊[p]

#kirie:lookAway_w
……[p]

#kirie:sad_w
……享四郎先生，一定没问题的[p]
#kirie:smileW_w
我笨得很，也不太懂生病这些事？[r]
但享四郎先生给我的感觉就是…就算被杀也死不了的那种[p]
#
…………[p]
[delay speed="60"]
#kirie:sad_w
……总、总之先回家吧。[r][wait time="500"]
再这样下去……连你也会死的……[p]

#kirie:angry_w
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
呜呜～～～[l][r]
[resetdelay]
#kirie:hate_w
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
——喂！站起来！给我走！！[p]

[mask]
#
[chara_hide name="kirie"]
[bg storage="indoor/makado_ima2.jpeg"]
;○家
[mask_off]
[delay speed="100"]
#
——跨越国际日期变更线的时间，[r]
敲响了本应听惯的时钟报时声。[p]
#makado
(……已经过了这么久吗)[p]
[delay speed="50"]
#kirie
……终于动了[p]

#makado
欸……[p]
[chara_show name="kirie" top="-10" face="smileW_w" wait="false" left="150"]
#kirie
——因为你完全没动静，我就一直默默看着呢。[r]
还在呼吸吗，没事吧[p]
[delay speed="100"]
#makado
我……还好好活着呢[p]

#kirie:sad_w
…………[l][r]
#kirie:lookAway_w
[resetdelay]
智子小姐，还没回来呢。[p]
虽然大点的医院离这不远，[r]
但果然还是要办住院手续之类的吧[p]
#
……………………………………[p]

#kirie:smileW_w
话说……[wait time="500"]像这样聊天本身，都好久没试过了呢。[r]
寒假都在做什么？[wait time="500"]　过年什么的，应该超级忙吧？[p]
[delay speed="60"]
#makado
……说不定就是因为这个[p]

#kirie:sad_w
诶？[p]

#makado
可能是今年过年期间太拼了。[l][r]
要是我再多留心点，老爸说不定就不会病倒了[p]

#kirie:hate_w
……这种事情，又不是神仙怎么可能预料得到啊。[r]
别胡说八道逃避现实了[p]

#makado
…………。[l][r]
说的也是啊[p]

#makado
——要是我也能像雾绘那样，[wait time="500"][r]
被托付家里所有工作就好了[p]

#kirie:lookAway_w
…………。[l]
#kirie:smileW_w
喂[p]

#makado
……干嘛[p]
[delay speed="50"]
#kirie:smile_w
不当老师的梦想了吗？[p]

#makado
……这都哪年的事了[p]

说这种话的时候，不就只有小学那会儿吗。[r][wait time="500"]
而且，[wait time="500"]我都忘了这事，[wait time="500"]被提醒的人反而记得……[p]
…………………………………………[l][r]
……雾绘这家伙，记忆力真好啊[p]

#kirie:normal_w
嗯嗯[p]

#kirie:smile_w
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
你就这样一直聊我家的事来转移注意力吧。[r]
反正，现在宗方雾绘就在眼前嘛[p]
[delay speed="60"]
#
雾绘托着腮，抬眼望了过来。[p]

#makado
雾绘的、故事……？[p]
[resetdelay]
#kirie:sad_w
就算纠结来纠结去，也不是能改变什么的情况啊。[p]
#kirie:smile_w
那不如为了我，讲讲我的故事吧。[r]
这样更有实际意义[p]
[delay speed="60"]
#makado
……我讲雾绘的事，[wait time="500"]对雾绘有好处吗？[p]
[resetdelay]
#kirie:sad_w
嗯。[wait time="500"]一直叫雾绘就好[p]

#makado
…………[p]
#
我和雾绘，[wait time="500"]开始聊了起来。[p]
[fadeinbgm storage=sicilienne.ogg loop=true time=10000 volume="30"]
[delay speed="60"]
#makado
雾绘。[l]……今晚是怎么从家里溜出来的？[r]
对茧的家人是怎么说的？[p]
[resetdelay]
#kirie
他们劝我的。说让我去看看情况。[l][r]
#kirie:lookAway_w
必须和马门神社好好相处才行呢[p]
[delay speed="60"]
#makado
雾绘她……[p]

听说升上高二之后，[r]
就再也没去过小谷坂上学了。[l][r]
发生什么事了吗……？[p]
[resetdelay]
#kirie:smile_w
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
啊哈哈，没什么啦。[r]
和前辈们在一起比较开心，所以才这样的[p]

#makado
你说的前辈们……就是那群像不良少年的人吧。[l][r]
又不是同个学校的，为什么要叫他们前辈啊[p]

#kirie:angry_w
因为是人生前辈嘛，叫前辈有什么不行。[l][r]
#kirie:hate_w
话说这[wait time="500"]是在说我的事？不对吧？[p]
[delay speed="60"]
#makado
…………………………………………[l][r]
……雾绘……。[p]
[delay speed="50"]
前几天，[r]
你前年暑假推荐给我的那部电视剧重播，我看了。[r]
居然是挺久以前的剧了……[p]
[resetdelay]
#kirie:smile_w
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
诶，居然重播了！还不错吧？[r]
看完感觉怎么样？[p]
[delay speed="60"]
#makado
……唔……[p]

#makado
雾绘你……[wait time="500"]真的，[r]
净喜欢些老电视剧啊综艺什么的呢[r]
一边想着这些一边看的[p]

#kirie:sad_w
……………………[p]

#kirie:smileW_w
……不是啦。[r][wait time="500"]
只是我家里的全是些老电视剧啊综艺节目的录像带而已[p]
[resetdelay]
#kirie:angry_w
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
啊～～真是的，[r]
这样简直不像是在聊我家的事，[r]
反倒像是马门君的问答大会了！！[p]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
停停！打住打住！[p]
[delay speed="60"]
#makado
呃……………………[p]
[resetdelay]
#kirie:hate_w
没想到反被你问这么多话，嗓子都干了啊。[r]
马门君，给我拿点喝的来[p]
[delay speed="60"]
#makado
怎么像……大雄似的……[p]
[delay speed="50"]
#
我被雾绘催促着，去厨房拿饮料。[p]
[fadeoutbgm time="3000"]
[chara_hide name="kirie" wait="false" time="3000"]
;ＳＥ電話
[bg storage="brack.png" time="3000" cross="false" wait="false"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="800"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="4000"]
[playse storage="phone.ogg" loop="true" volume="10"]
[font size="40"]
[quake time="30"]
#
――！[p]
[stopse]

#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
电话……！！[p]
[font size="20"]
[resetdelay]
#kirie
啊——，没事——！！！[l][r]
是我的手机在响————！！[p]
[resetfont]
#makado
………………………………[p]
[font size="20"]
#
「……啊　……喂」[p]

「……嗯…………[wait time="500"]　不。没事的」[p]
[resetfont]
[delay speed="50"]
………………………………[p]
……她到底是在接谁的电话呢。[p]
需要用敬语对话的人，居然在这种深夜打来电话。[r]
对方肯定是个不懂常识的家伙。[p]
#makado
（……刚才提到的那个所谓的前辈吗）[p]
[mask time="300"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
[wait time="2000"]
[bg storage="indoor/makado_ima2.jpeg" time="10"]
[mask_off]
#makado
雾绘……只有茶了，将就下吧[p]
[chara_show name="kirie" top="-10" wait="true" time="100" face="hate_w"]
#kirie
马门君[p]
[stopbgm]
[chara_hide name="kirie" time="100" wait="false"]
[bg storage="brack.png" time="100" cross="false" wait="true" time="100"]
[playse  volume="50" buf="0" storage="hikidopen2.ogg"]
[wse]
;ＳＥガラガラ

#makado
——！？[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
雾绘突然抓住我的手腕，冲出了房间。[p]
[playbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400"]
[resetdelay]
;ＳＥ走る
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="1000"]
[free_filter]
#
「喂、雾绘、雾绘！！[l][r]　突然怎么了……出什么事了！？[l][r]
[r]
[r]
雾绘没有回头。[r][wait time="500"]
她径直冲向玄关，硬把我拽出了家门。[l][r]
[r]
[r]
「…………」[p]
[mask]
@layopt layer=message0 visible=false
[bg storage="jinja_n.jpg" time="10"]
#
;○神社（夜）
[mask_off]
[wait time="4000"]
@layopt layer=message0 visible=true

[delay speed="60"]
[font size="22"]
――每次呼吸，都有一缕白雾缓缓升起。[l][r]
[r]
被匆匆催促穿上的运动鞋还没穿好，[r]
我边重新调整鞋子，[wait time="500"]边偷瞄着行为反常的雾绘。[l][r]
[r]
[delay speed="50"]
「……你到底想怎样。[l][r]　一会儿让我回屋里，一会儿又拽我出来……」[l][r]
「……你啊，」[l][r]
[r][wait time="500"]
「如果享四郎先生死了，[wait time="500"]你一定会很绝望吧」[l][r]
「……」[l][r][wait time="500"]
「………………」[p]
[delay speed="70"]
「明明还有……那么多想向你请教的事、[wait time="500"]想和你一起做的事……」[l][r]
[r]
「你啊……满脑子只想着要成为享四郎先生那样的人，[wait time="500"]从来都是这样」[l][r]
[resetdelay]
「……果然刚才那通电话，[wait time="500"]是老爸出什么事了吗」[l][r]
[r]
[r]
[font size="40"][resetdelay]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
「——喂 你听我说！？」[p]
[resetfont]
雾绘抓住我的双手低语道。[l][r]
[r]
[r]
[r]
「马门君…………」[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[chara_show name="kirie" top="-10" left="150" face="shame_w" wait="false" time="100"]
[delay speed="70"]
[stopbgm]
[font color="0xf08080"]
#kirie
如果是我的话……[wait time="500"]可以让一切都没发生过。[p]
[resetfont]
#makado
诶……[p]
[resetdelay]
[font color="0xf08080"]
#kirie
没关系的。放心吧。绝对、绝对不会有事的[p]
[delay speed="70"]
#kirie:smileW_w
我会……[wait time="500"]我会来救你的。救马门君[p]
[resetfont]
#makado
……………………………………………………[l][r]
什……什么意思啊，救我是说……[p]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font color="0xf08080"]
[delay speed="100"]
[font size="40"]
「给你施个魔法」[l][r]
[r]
[resetdelay]
[resetfont]
[font color="0xf08080"]
「就这样握着手闭上眼睛在心里祈祷！[r]　想让生物死去生命消逝的过去都当作没发生过」[l][r]
[r]
[r]
「要把所有不如意的事情都抹消的话[r]　就必须自私地祈祷才行。[r]　放心啦，反正你肯定没法比我更任性」[p]
[r]
[delay speed="80"]
[font size="22"]
…………[l][r]
[r]
——照着雾绘说的闭上眼，[r][wait time="700"]
继续握着她的手，在心中祈祷。[l][r]
[r]
求求您…千万别让爸爸死去。[l][r]
[r]
请救救爸爸的性命。[l][r]
[resetfont]
[r]
[r]
让他能再一次，[l]回到这个家——[p]
[resetdelay]
[mask folder="bgimage" graphic="still/ganmon.png" time="3000"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="40"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="30"]
[wse]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="20"]
[wse]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[chara_hide name="kirie" time="10"]
;くはぬ　とばぬ　みず　なれば
;ねがひたてまつる　しるしあらわせ　しるしあらわせ
[wait time="3000"]
;ＳＥカーン
[bg storage="indoor/makado_ima2.jpeg" time="10"]
[mask_off time="3000"]
[resetfont]
「嗯、这样啊，先住院观察……[wait time="500"]知道了。」[p]

「没事的，等安顿好再联系」[p]
[playse storage="phone.ogg" volume="30" sprite_time="0000-200"]
[wse]
[delay speed="60"]
#kirie
……太好了呢。[wait time="500"]享四郎先生总算保住性命了[p]

#makado
嗯……[l]谢谢你，[wait time="500"]雾绘[p]

#kirie
诶？[p]

#makado
刚才啊……[wait time="500"]你帮我做了咒语对吧。[l][r]
肯定是那个起效了[p]
[delay speed="50"]
等爸爸回来后，[wait time="500"]我会让他好好向你道谢的[p]

#kirie
……[l]不用，[wait time="500"]没关系的。[wait time="500"][l][r]
大概我们家以后不会再有机会见到享四郎先生了吧[p]

#makado
诶？[l][r]
…………[p]
[delay speed="60"]
#makado
话说回来……[p]
那个、[wait time="500"]现在摊开的[wait time="500"]　破旧书本？一样的东西……　是什么？[r]　
刚才好像剪了什么东西贴上去吧？[p]
[delay speed="50"]
#kirie
啊，这是——[wait time="500"]刚才咒语的仪式用纸。[r]
[delay speed="70"]
必须献上名字才行，但如果被树月看到的话，[r]
就麻烦了……[p]

#kirie
…………[p]
[delay speed="50"]
#kirie
马门君。我很快就要离开这个小镇了[p]
#makado
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
——诶？！[p]
#
我不由自主地从椅子上站起身来。[r]
冲到雾绘面前，追问她话中的真意。[p]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[resetdelay]
#makado
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
你在说什么啊，这也……[wait time="500"]太突然了吧。[l][r]
怎么回事啊，离开八种什么的……[p]

三位官女大人……[wait time="500"]不是不能离开这个小镇的吗，[r][wait time="500"]
所以你才一次都没来参加修学旅行不是吗！[p]

#kirie
所以我要逃离三位官女。[r][wait time="500"]
我要放弃这一切，已经受够了[p]
[delay speed="60"]
#kirie
——你也知道的吧？[r][wait time="500"]
我和你可不一样 最讨厌继承家业这种事[p]

#makado
……………………那个，[wait time="500"]是[p]

#kirie
其实呢，刚才给你听的愿文。[l]　那个……[r][wait time="500"]
是三位官女绝对不可施展的诅咒[p]

偷出这本书的事也……[l][r]
要是被发现的话，[wait time="500"][r]
爸爸妈妈们绝对会往死里教训我的。[p]
[resetdelay]
所以现在正是个好机会，我要逃离这个小镇。[r][wait time="500"]
而且再也不打算回来了[p]
[delay speed="60"]
#makado
——等、[l][r]
怎么可以…………[p]
[delay speed="100"]
#makado
……怎么能……冒这种险，[r][wait time="500"]
今天……你是来见我的吗？[p]
[resetdelay]
#kirie
啊哈哈！！[wait time="500"]抱歉啦～。[p]
[delay speed="50"]
我觉得你正好适合当我离家出走的借口，就利用了你！！[p]

#makado
……雾绘[p]
#
[wait time="2000"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
我一把抓住了雾绘的手。[p]
[delay speed="70"]
[fadeinse  volume="05" buf="0" storage="walk_rouka.ogg" loop="true" time="3000"]
#kirie
呃……[p]

#makado
明白了。[wait time="500"]接下来……该轮到我了吧[p]

#kirie
啊、啊…………？[wait time="500"]　骗人[p]
[resetdelay]
#makado
跟我来[p]
[font size="20"]
#kirie
哇、哇啊……等……！[p]

#kirie
……………………………………………………[p]
[resetfont]
[mask time="2000"]
[bg storage="hall_n.jpeg" time="10"]
#
[wait time="4000"]
[delay speed="70"]
;○お堂
[mask_off time="5000"]
――冬天的山林，寂静无声。[p]

在这片无音的世界里，[wait time="500"]两人踩过枯叶的声响[r]
显得格外刺耳。[p]
[chara_show name="kirie" top="-10" left="150" wait="false" face="hate_w"]
#kirie
……这里是？[p]
[resetdelay]
#makado
我家的秘密基地[p]

#kirie:sad_w
我家是……马门神社？[p]
[delay speed="70"]
#makado
——嗯。[p]
[delay speed="50"]
#makado
雾绘[l]　既然你向我坦白了[r]
足以成为你离开八种的理由的秘密……[p]

那我[wait time="500"]也要告诉你一个重要的秘密。[l][r]
因为我一直想和雾绘保持对等的关系[p]

#kirie
……对等？[p]

#makado
…………………………[p]
[delay speed="60"]
#makado
不。根本不对等……[p]

雾绘总是帮助我。[l][r]
既聪明又善解人意……[r]
甚至比我更清楚自己想要什么[p]
今天也…………………………[l][r]
专程来见我了。[r]
优先考虑我而不是自己的职责………[p]
[stopse]
[delay speed="50"]
#makado
……你总是为他人付出，就算离开八种也一定[r]
你总是把一切都奉献给别人……[p]

所以——[wait time="500"]至少我要…………[p]

成为这座城里唯一 能回报你付出的人[r]
想要等着雾绘回来[p]
#makado
让雾绘能安心归来的，[r]
就像是个避风港一样…………[l][r]
[delay speed="100"]
…………………………………那个[p]
#kirie
……………………………………………[l][r]
…………马门君？[p]
#makado
……………………………………………[p]
[delay speed="50"]
#
说完这些话后，能感觉到脸上越来越烫。[r]
不习惯的事还是不要做，也不该说。[p]
#makado
…………………………抱歉。你肯定听不懂吧。[r]
我在说什么啊，我………………[p]
#
不敢直视雾绘那看着孩子般的表情。[r]
用手背冰了冰发烫的脸颊。[p]
#kirie
…………………………[l][r]
……………………呵[p]
[delay speed="100"]
[font size="20"]
#kirie:smileW_w
呵、呵呵………　在……[wait time="500"]说什么呢。[r]
果汁什么的，不是经常请我喝嘛。除此之外，还有很多………[p]
[resetfont]
#kirie:sad_w
――――――――――[wait time="300"][er]
[chara_hide name="kirie" wait="false" time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[mask time="100"]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="50" buf="0" storage="sariin.ogg" ]
[wse]
[bg storage="still/hold_2.png" time="10"]
[wait time="2000"]
;ＳＥばっ
[mask_off time="3000"]
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
[font size="40"]
[delay speed="50"]
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……呜哇！？[p]
[resetfont]
#makado
雾、[wait time="500"]雾绘…………！？[p]
#
[resetdelay]
[playbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400"]
――突然雾绘就扑过来抱住了我……[l][r]
她的手滑进了我的衣襟。[p]

触碰腹部的指尖如寒冰般冷冽。[p]

#makado
等、[wait time="500"][quake time="30"]
好凉……太冰了、[p]

#kirie
……[p]
[delay speed="50"]
#kirie
果然，还是驱逐出去吧[p]

#makado
[playse  volume="20" buf="0" storage="sariin.ogg" ]
诶？[p]

#kirie
今天发生的事。[wait time="500"]　全部，都从你体内驱逐出去哦[p]
因为比起我自己，我更喜欢马门君啊[p]

#makado
……[p]

#kirie
况且[wait time="500"]　无论我多么努力想成为你心中特别的存在……[r]
我们绝对[wait time="500"]　不可能在一起的[p]
[resetdelay]
你将来肯定会继承享四郎先生的衣钵　成为马门神社的神主[r]
而我只要还在八种　就永远是狮心教的相关人员[p]
[delay speed="50"]
#kirie
所以至少……[r][wait time="500"]
绝不能让那些和我同类”的家伙　把你夺走[p]
[delay speed="70"]
#makado
……被夺走什么的[p]
[bg storage="still/hold_1.png" time="10"]
[delay speed="120"]
#kirie
然后　[delay speed="50"]
也绝不会把君交给御白姬那种家伙[p]
#kirie
你给的秘密也好，愿望也罢――[l]都要变成只属于我的东西。[l][r]
对不起，[wait time="500"]马门君[p]
[bg storage="brack.png" time="5000" wait="false" cross="false"]
#
[layermode name="kirie" graphic=kirie.png time=5000 mode="lighten"]
[fadeoutbgm time="6000"]
[delay speed="80"]
#
――呼地意识逐渐远去。[p]

……在逐渐模糊的视野中，[r][wait time="500"]
雾绘身后似乎飘荡着什么……[p]

『前方危险』[r]
警示意味的黄黑配色，在视野中隐约浮现。[wait time="500"][p]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[mask time="100"]
[wse]
[bg storage="koen_s.png" time="10"]
[playse  volume="140" buf="0" storage="book.ogg"]
[wse]
[free_layermode name="kirie" time="10"]
[wait time="5000"]
;ＳＥドサッ
#
[mask_off time="6000"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
——约两年前，冬季。[p]
[delay speed="100"]
初雪飘落的，寒冬。[p]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[chara_show name="kirie" top="-10" face="hate_w" wait="false" left="150"]
[font size="40"]
#kirie
[quake time="30"]
——马门君！！[p]
[resetfont]
[delay speed="50"]
#kirie:lookAway_w
果然……是在这里啊……[p]

#kirie:sad_w
不戴围巾和手套，不冷吗。[r]
我的借你[p]

#makado
…………………………………………[p]
不用……我不需要[p]

#kirie
……这样啊[p]

#kirie:lookAway_w
……[p]

#kirie:smileW_w
……享四郎先生，能早点出院就好了呢[p]

#makado
嗯……真的、我也这么想[p]
[delay speed="60"]
爸爸和妈妈……要是也能早点从医院回来就好了[p]

#kirie:sad_w
……那个啊，贤治郎。[p]

下次见到享四郎先生的时候……[wait time="500"][r]
能帮我带句话吗？[p]

#makado
传话？[p]

#kirie:smile_w
嗯[p]
[delay speed="50"]
『诅咒应该可以被驱散的[r]　我要去证明这一点』[p]
#
——说出这句话时，雾绘的瞳孔[wait time="500"][r]
正凝视着远方，那眼神前所未见。[p]

#makado
……说要证明什么的，[p]

雾绘，你要出门吗？[p]
[resetdelay]
#kirie:smileW_w
其实是这样啦～[r]
因为不小心触犯了超糟糕的禁忌，我准备离家出走。[p]
[anim name="kirie" left="-=100" time=500 ]
[anim name="kirie" left="+=200" time=500 ]
[anim name="kirie" left="-=100" time=500 ]
#kirie:smile_w
这样下去可能会被监禁诶～[r]
再也不回那个家啦！[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#makado
你……[p]
[delay speed="50"]
#kirie:normal_w
从今晚开始，人家就不是三女官，而是女演员了。[wait time="500"][r]
#kirie:smile_w
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
很棒吧，很羡慕吧！可以成为任何角色哦！[p]
#makado
禁、禁忌？！[p]
[font size="40"]
[resetdelay]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
你为什么要做这种事！[wait time="500"][l][r][resetfont]
不管有什么理由，像我们这样的人[r]
不遵守家规什么的，怎么可以做这种事[p]

#kirie:smileW_w
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
没用的马门君别对我家指手画脚啦[p]
[delay speed="60"]
#
——这劈头盖脸的否定话语，[r]
让体内比空气还要冰冷地刺痛。[p]
[delay speed="50"]
#kirie:lookAway_w
一直以来都[r]
明明知道我家因为”狮心教”在受苦[r]
却一次都没来帮过我们[p]
现在我要逃走的时候反倒来阻拦？[p]
#kirie:sad_w
前辈们可是为了让我能在镇外生活[r]
连住处和工作都给我安排好了。[r]
和马门君完全不一样呢[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=8000 volume=50]
[wait time="5000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="80"]
#
……彼此之间[wait time="500"]　沉默与积雪不断加深。[p]

看着触碰雾绘的结晶逐渐融化消失，[r][wait time="500"]
才意识到自己从未为她付出过任何东西。[p]

无法忍受继续沉默下去，[wait time="500"]开始寻找话题。[p]

#makado
……演员……[wait time="500"]是你曾经的梦想吗？[r]
这种事，从来没听你说过啊……[p]
[delay speed="50"]
#kirie:shame_w
[anim name="kirie" top="-=60" time="100"]
[anim name="kirie" top="+=60" time="100"]
马门君怎么可能知道嘛！[r]
你连我最大的梦想都不记得了。[p]
[delay speed="80"]
#
被这样说着感到不甘心，[l][r]
拼命想在记忆里找出相关线索。[p]

可是，我无论如何也——[r]
就是想不起来雾绘曾经想成为什么。[p]
明明感觉应该有个非常坚定明确的答案，[wait time="500"]却怎么都抓不住。[p]

#kirie:lookAway_w
……呐……马门君[p]
#kirie:smile_w
你是不是觉得我……[l][r]
只喜欢看老掉牙的电视剧[wait time="500"]和综艺节目啊？[wait time="500"]
你是这么想的吧？[p]
#
雾绘却对我的事全都了如指掌。[p]

又聪明，又很会为别人着想……[r]
甚至比我自己还要了解我。[p]
[delay speed="60"]
#kirie
所以最近……[wait time="500"]我看了一部老电影。[p]
#kirie:lookAway_w
讲的是一个想当女演员的女主角[r][wait time="500"]
在恋人给的幸福生活和演员生涯之间[r][wait time="500"]
最终还是选择了后者的故事[p]

#kirie:smileW_w
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="-=30" time="150"]
我啊　超喜欢这部电影的！[r]
作为女演员出生的话　就只能活在舞台上了。[l][r]
那种感觉真的太令人心碎了……[p]
[delay speed="80"]
#kirie:sad_w
所以今天啊[wait time="500"]　就像这部电影的最后一幕那样和我告别吧[p]

#makado
…………………………[l][r]
[delay speed="100"]
………………………………………[p]
……我明白了[l][r]
[delay speed="80"]
至少最后……[wait time="500"]让我也能帮上你的忙……[p]
证明给你看……[l][r][delay speed="100"]
…………………………[p]
#
话说到一半，又放弃了。[p]
[delay speed="80"]
#makado
不，已经太迟了啊。[p]

#kirie:lookAway_w
——是啊[p]
#

[bg storage="brack.png" time="5000" wait="false" cross="false"]
[chara_hide name="kirie" time="5000" wait="true"]

——她当着我的面捏起制服裙摆，[r]
行了个舞台剧演员般的礼。[p]

我[wait time="500"]对着那个身影鼓起掌来。[p]
[stopse]
[delay speed="50"]
「……拜托了」[p]

「直到看不见我为止，[wait time="500"]请在那里继续鼓掌」[p]

冰冷的落花纷飞中，[r]
她的身影渐渐远去。[p]

被白色帷幕笼罩的城镇只回荡着我的掌声，[r]
再无其他声响。[p]

八种町存在的一切，[r]
都静静目送着这位离去的女主角。[p]
[mask folder="bgimage" graphic="still/interval.png" time="3000"]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="30" buf="0" storage="kansei.ogg"]
[wse]
[fadeoutbgm time="6000"]
[wait time="6000"]
[showsave]
;セーブしますか？
@jump storage="chapter_5/day1_vol5.ks"

;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
