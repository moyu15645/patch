[eval exp="f.save_title = '五章パート２'"]

;-------------------------------------------------------------------------------
[mask]
[bg storage="brack.png" time="10"]
;-------------------------------------------------------------------------------

[chara_face name="sarasa" face="normal_gs" storage="chara/sarasa/shirakinu/normal_gs.png"]
[chara_face name="sarasa" face="angry_gs" storage="chara/sarasa/shirakinu/angry_gs.png"]
[chara_face name="sarasa" face="lookAway_gs" storage="chara/sarasa/shirakinu/lookAway_gs.png"]
[chara_face name="sarasa" face="pray_gs" storage="chara/sarasa/shirakinu/pray_gs.png"]
[chara_face name="sarasa" face="sad_gs" storage="chara/sarasa/shirakinu/sad_gs.png"]
[chara_face name="sarasa" face="sadB_gs" storage="chara/sarasa/shirakinu/sadB_gs.png"]
[chara_face name="sarasa" face="smile_gs" storage="chara/sarasa/shirakinu/smile_gs.png"]
[chara_face name="sarasa" face="worry_gs" storage="chara/sarasa/shirakinu/worry_gs.png"]
[chara_face name="sarasa" face="worryLA_gs" storage="chara/sarasa/shirakinu/worryLA_gs.png"]
[chara_face name="sarasa" face="wow_gs" storage="chara/sarasa/shirakinu/wow_gs.png"]
[chara_face name="sarasa" face="closeEye_gs" storage="chara/sarasa/shirakinu/closeEye_gs.png"]

;-------------------------------------------------------------------------------


@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
[mask_off]
[delay speed="100"]
――8月27日！[wait time="500"]　今天是[wait time="500"]　白绢祭！[p]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="50" buf="0" storage="kansei.ogg"]
[wse]
[fadeinbgm storage=tukutukulong.ogg loop=true time=5000 volume=30]
[bg storage="hataneM.jpg" wait="true" cross="false" time="3000"]
[playse storage=bell.ogg sprite_time="0000-6000" volume="3"]
[wse]
;○町の写真
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
八种町的各位[wait time="500"]　早上好[p]

今日天公作美[r][wait time="500"]
美丽辽阔的　蔚蓝天空[wait time="500"]　正笼罩在　我们头顶[p]

今晚８点左右起　由御白姬率领的祭礼队伍将[wait time="500"][r]　
从马门神社出发　巡游全镇[p]

同时段由花隅商工会赞助的[r]
烟火大会　也请务必观赏[p]
[playse storage=bell.ogg sprite_time="0000-6000" volume="5"]
[mask time="2000"]
[fadeoutbgm time="2000"]
;○志戸田家　座敷
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
[bg storage="indoor/sitodrouka.jpg" time="10"]
[mask_off]
;ＳＥ鳥

「恭喜您」[p]

「今日真是可喜可贺」[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="sarasa" top="-160"  time="2000" wait="true" face="closeEye_gs"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa:normal_gs
非常感谢[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[resetdelay]
#kinuyo
……简直像新娘一样呢[p]
[chara_move name="sarasa" left="360" anim="true" wait="false" width="-=50"]
[chara_show name="kinuyo" wait="false" left="-70" top="-160" face="normal"]
#sarasa:normal_gs
妈妈[p]

#kinuyo
从前……[wait time="500"]这个祭典刚刚举办的时候。[r]
听说扮演御白姬的女孩穿的是真正的白无垢呢[p]

#kinuyo:closeEye
后来随着时代变迁[r]
后来换成了志户田纺织特制的绢丝服饰……[l][r]
旨在向町内进一步彰显自家企业的技术实力与政治影响力[p]
[delay speed="50"]
#sarasa
……如果是妈妈的话[p]
#sarasa:closeEye_gs
会想怎样操办这个祭典呢？[p]

#kinuyo:sad
你没必要知道这些事。[l][r]
#kinuyo:normal
…………………………………………[r]
不过呢……[p]

#kinuyo
……是啊。[wait time="500"]这种毫无意义的祭祀活动，[r]
若不是为了维护家族荣誉，我早该放弃这祭祀了。[r]
说到底，要保持肌肤白皙实在太费功夫了[p]

#sarasa:normal_gs
其实……[wait time="500"]
#sarasa:smile_gs
我也觉得有点麻烦呢[p]
#kinuyo
…………………………………[l][r]
#kinuyo:smileSP
真是的。我们可真是生在了一个麻烦的家族啊[p]

#sarasa
……呵呵。是啊[p]
[playse  volume="20" buf="0" storage="hikidopen2.ogg"]
[chara_mod name="sarasa" face="normal_gs"]
[chara_mod name="kinuyo" face="normal"]
[font size="20"]
[resetdelay]
#アキラさん
纱罗纱～早餐想吃点什么～？[r]
最好选不会弄脏衣服的餐点对吧？[p]
[resetfont]

#kinuyo:closeEye
我记得有件做祭典服用的围裙来着，阿基拉。[r]
是我年轻时用过的东西……应该放在二楼壁橱里[p]
[font size="20"]
#アキラさん
我知道，但绢世小姐忘记扔的垃圾散落得到处都是[r]
根本找不到啊。[l][r]
想请您帮忙一起找找看可以吗？[p][resetfont]
[delay speed="50"]
#kinuyo:normal
那可是箱体艺术这种艺术品的一种。[r]
不是垃圾[p]
#kinuyo:back
对了……我今天早上做了饭团来着。[r]
等你有空的时候，随时可以吃哦[p]
#kinuyo
真好呢，纱罗纱[p]
[chara_hide name="kinuyo" wait="false" pos_mode="false"]
;ＳＥ歩いて行く
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]

#sarasa:closeEye_gs
…………………………[p]
#sarasa:worryLA_gs
………………………（咦，原来不是垃圾啊）[p]

#？？
[playse  volume="20" buf="0" storage="hikidopen2.ogg"]
打扰啦——！！[p]　
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[resetdelay]
;ＳＥガラガラ
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '叔父'
[endscript]
[chara_show name="mokke" wait="false" time="100" left="40" top="100" face="oji"]
#mokke
恭喜恭喜，纱罗纱。[r]
[anim name="mokke" top="+=60" time="200"]
[anim name="mokke" top="-=60" time="200"]
哎呀，这衣服真不错！[p]
#sarasa:normal_gs
啊……是贤治郎先生的叔叔[p]
#sarasa:closeEye_gs
[anim name="sarasa" top="+=60" time="400"]
[anim name="sarasa" top="-=60" time="400"]
特意前来真是太感谢了……[p]
[delay speed="50"]
#mokke
你父亲和哥哥真是遗憾呢。[r]
听说他们回不来了？[p]

#sarasa:normal_gs
嗯……但这也是没办法的事。[r]
比起我来，父亲他们更觉得不甘心……[p]

#mokke
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
哈哈，这不是当然的嘛。[r]
错过了宝贝女儿这么隆重的盛装时刻，[r]
肯定哭出血泪了啊！[p]
[fadeoutbgm time="5000"]

#mokke
话说……[r][wait time="500"]
虽然问得有点唐突——[p]
纱罗纱。[r][wait time="500"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
贤治郎那边有联系过你吗？[p]

#sarasa:wow_gs
咦…………？[p]
#
摸了摸怀里的手机查看。[l][r]
一如既往，没有任何通知和回复。[p]
#sarasa:worry_gs
…………………………[p]
#sarasa:sad_gs
……其实从几天前开始，他就一直在躲着我……[r][wait time="500"]
就算聚会时碰面，也没法正常说上话……[l][r]
而且消息已读不回[p]
[resetdelay]
#mokke
啊～这样啊～[p]
[font size="20"]
#mokke
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
唔～嗯～怎么说呢～可能是最近太累了吧～[r]
又或者是迟来的叛逆期？[r][wait time="500"]
毕竟初高中青春期时都一直很乖呢……[p][resetfont]
#
眼前的男人正抱着头，发出含糊不清的嘟哝声。[p]

――看到他这副模样，我被一种莫名的焦虑驱使着……[r]
从坐垫上探出了身子。[p]
[chara_move name="sarasa" left="300" anim="true" wait="false"]
#sarasa:angry_gs
那个……贤治郎先生出什么事了吗？[p]

#mokke
啊—唔—呃—。这个嘛……[p]
[delay speed="60"]
#mokke
……………………………………[r]
……呃，这件事还请暂时对其他人保密。[l][r]
从今早就完全找不到人影了～[p]
#sarasa:wow_gs
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[playbgm storage=fuon.ogg loop=true time=300 volume="30"]
[quake time="30"]
[font size="40"]
――诶！？[p][resetfont]
[resetdelay]
#mokke
就是啊！大叔我也很头疼啊！[p]
[delay speed="60"]
到处都找遍了，神社附近和家里都没人影[l][r]
……最坏的情况就是赶在游行前回来就好，[r]
在那之前就……。[font size="20"]
[wait time="500"]細々とした祭事の、繋ぎがぁ……[p][resetfont]

#
贤治郎先生……失踪了？[r]
而且还是……在白绢祭当天的早晨――！？[p]

#mokke
那孩子啊，骨子里就是个优等生。[r]
会做出这种事，肯定有相当严重的隐情……[p]

可悲的是……我完全想象不到会是什么……[p]
[playbgm storage="lost-happy.ogg" loop=true time=3000 volume="30" sprite_time="0000-105000"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[resetdelay]
#sarasa:angry_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
――能不能帮我转告妈妈和阿基拉，[r]
就说我『稍微出去一下”！？[p]
[stop_kanim name=sarasa]

#mokke
哎？[p]
[chara_hide time="300" wait="false" name="sarasa"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
等、等等，纱罗纱！[p]
[font size="40"]
#sarasa
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
妈——我出门一会儿！！[p]
[font size="20"]
#kinuyo
什么情况啊[r][wait time="1000"]
[delay speed="100"]
……咦，刚才的声音是纱罗纱？[p][resetfont]
#sarasa
[quake time="30"]
拜托了！[p]
#
[mask time="100"]
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[resetdelay]
[chara_hide name="mokke" time="0s"]
[bg storage="brack.png" time="10"]
[mask_off time="100"]
#
叔叔说得没错。[r]
他说的肯定没错。[p]

在白绢祭时，[r]
那么认真对待祭典的贤治郎先生，[r]
居然会像这样”突然消失——[p]
一定是发生了什么。[p]
[mask]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[bg storage="still/ton.jpeg" time="10"]
;○トンネル
[mask_off]
#sarasa
（――好、只要穿过这里……[r]
先去找一树吧。）[p]
（然后召集大家……）[p]

#sarasa
（一起寻找贤治郎先生的下落。[r]
这样的话，只要我们齐心协力就一定能找到……！）[p]
[delay speed="50"]
#
御白姬的服装实在不适合奔跑。[p]

如果真如母亲所说原本是白无垢礼服的话，[r]
活动不便的构造也是无可奈何吧。[p]
[delay speed="60"]
――小学时代，[r][wait time="500"]
树月曾口头给我讲述过某部电视剧的剧情，[r]
似乎确实有过这样的场景。[p]

那部剧叫什么名字来着？[wait time="500"][r]
穿着白无垢在街上奔跑的女性……[l][r]
《悠长假期》的故事。[p]
[mask time="3000"]
[chara_face name="kirie" face="back_1" storage="chara/kirie/back1.png"]
[chara_face name="kirie" face="back_2" storage="chara/kirie/back2.png"]
[bg storage="ton_a.jpg" time="10"]
#kirie
[chara_show  name="aki" left=340 top=-10 time="10" face="smile_s"]
[chara_show  name="riki" face="smileCE_s" left=30 top=-10 time="10"]
[chara_show  name="hino" face="smile_s" left=-190 time="10" top="-10"]
[chara_show  name="ituki" face="sad_s" left=580 time="10" top="-60"]

[chara_move  name="aki" width="-=150" time="10"]
[chara_move  name="riki" width="-=150" time="10"]
[chara_move  name="hino" width="-=150" time="10"]
[chara_move  name="ituki" width="-=150" time="10"]
[chara_show name="kirie" top="-100" face="back_1" time="10" left="10"]
;○トンネル向こう
[stopbgm]
[mask_off time="100"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
对了。今天是白绢祭的庙会呢！[p]

#riki
嗯！我要去看看准备卖给知贵的苹果糖摊位！[p]
[font size="40"]
#sarasa
[filter grayscale="60"]
[quake time="30"]
[quake time="30"]
[font color="0xf08080"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
――！！！[p][resetfont]
[playbgm storage=hitoriboti.ogg loop=true volume=30]
[font color="0xf08080"]
#kirie
嗯，去吧。不过别靠近河边哦[p]

#aki
啊 我们就在岸上看看 一小时就回来[p]

#kirie
多玩会儿嘛。有树月在一起就不用担心啦[p]

#sarasa
（怎……怎么会）[p]
#
我再一次怀疑起自己的眼睛。[p]
为什么，[r]
本该死去的雾绘小姐会――[p]
[font size="40"]
和大家、在一起[p]
[resetfont]
#ituki:tweet_s
啊……！[p]

#ituki:sadB_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
纱、纱罗纱！[p][stop_kanim name=树]
#
在雾绘的臂弯里，[r]
只有树月察觉到了我的存在――并呼唤了我的名字。[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="sadB_gs" time="100" wait="false" left="160"]
[chara_move name="sarasa" width="-=60" time="10"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#sarasa
！树、……[p]
[anim name="sarasa" top="+=30" time="60"]
[anim name="sarasa" top="-=30" time="60"]
[font size="40"]
――树！！[p][resetfont]
#hino
……？[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask time="300"]
[chara_hide name="sarasa" time="10"]
[chara_show  name="aki" left=340 top=-10 time="10" face="smile_s"]
[chara_show  name="riki" face="smileCE_s" left=30 top=-10 time="10"]
[chara_show  name="hino" face="smile_s" left=-190 time="10" top="-10"]
[chara_show  name="ituki" face="sadB_s" left=580 time="10" top="-60"]
[chara_move  name="aki" width="-=150" time="10"]
[chara_move  name="riki" width="-=150" time="10"]
[chara_move  name="hino" width="-=150" time="10"]
[chara_move  name="ituki" width="-=150" time="10"]
[chara_show name="kirie" top="-100" face="back_1" time="10" left="10"]
#hino
[mask_off time="300"]
哎呀，在那边的……不是志户田吗！[l][r]
喂——志户田——！[p]

#aki:wow_s
咦？纱罗纱？[p]

#riki:angry_s
什么啊？明明祭典还没开始，[r]
居然跑到这种地方来了！那家伙——[p]
[font size="20"]
#sarasa
……呜、呜……！[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask time="300"]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="sadB_gs" time="100" wait="false" left="160"]
[chara_move name="sarasa" width="-=60" time="10"]
[mask_off time="300"]
[font size="40"]
#sarasa
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
大家、救救我！[r]
过来这边、听我说！求求你们！[p]
[font size="20"]
#riki
……？那家伙在喊什么呢[p]
[mask time="1000"][resetfont]
[chara_hide name="sarasa" time="10"]
[chara_show  name="aki" left=340 top=-10 time="10" face="tweet_s"]
[chara_show  name="riki" face="normal_s" left=30 top=-10 time="10"]
[chara_show  name="hino" face="normal_s" left=-190 time="10" top="-10"]
[chara_show  name="ituki" face="sadB_s" left=580 time="10" top="-60"]
[chara_move  name="aki" width="-=150" time="10"]
[chara_move  name="riki" width="-=150" time="10"]
[chara_move  name="hino" width="-=150" time="10"]
[chara_move  name="ituki" width="-=150" time="10"]
[chara_show name="kirie" top="-100" face="back_1" time="10" left="10"]
#aki
[mask_off time="300"]
纱罗纱她怎么了呀[r]
还穿着演出服[r]
这个时间明明应该待在家里的[p]

#hino
……[l][r]
#hino:tweet_s
她喊的是救命啊[p]
…………[p]
#hino:sad_s
喂、大家、要不要过去志户田那边看看？[r]
她看起来有麻烦了[p]

#
…………[p]
;-------------------------------------------------------------------------------
[chara_face name="ituki" face="angryB_s" storage="chara/ituki/sihuku/angryB_s.png"]
;-------------------------------------------------------------------------------

#ituki:angryB_s
……！[r][wait time="500"]
#ituki:shout_s
[font size="40"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
碍事的雾绘，闪开！[p][resetfont]
[playse  volume="140" buf="0" storage="book.ogg"]
@layopt layer=message0 visible=false
[clearfix]
#kirie:back_2
[quake time="30"]
[wse]
[chara_hide name="ituki" wait="false" pos_mode="false"]
;ＳＥ走る
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[mask time="100"]
[chara_hide_all time="10"]
[mask_off time="2000"]
[chara_show name="sarasa" left="360" top="-160" wait="false" time="2000" face="sadB_gs"]
#ituki
[chara_show name="ituki" left="-70" top="-160" wait="true" time="2000" face="sadB_s"]
[resetdelay]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
纱罗纱……！[p]

#sarasa
……一、一树……[r]
这到底是怎么回事！？[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask time="100"]
[wait time="1000"]
[chara_hide_all time="10"]
[chara_show  name="aki" left=340 top=-10 time="10" face="normal_s"]
[chara_show  name="riki" face="tweetLA_s" left=30 top=-10 time="10"]
[chara_show  name="hino" face="normal_s" left=-190 time="10" top="-10"]
[chara_move  name="aki" width="-=150" time="10"]
[chara_move  name="riki" width="-=150" time="10"]
[chara_move  name="hino" width="-=150" time="10"]
[chara_show name="kirie" top="-100" face="back_1" time="10" left="10"]
#riki
[mask_off time="300"]
………………[p]
[delay speed="50"]
#aki:tweet_s
怎么了？力[p]

#riki:sad_s
嗯？哦——……[p]

#riki:worry_s
我也——去志户田那边……[wait time="500"]稍微看看情况吧。[r]
总觉得有什么隐情[p]

#aki:wow_s
诶？[p]
[resetdelay]
#riki:normal_s
和雾绘之后还能再见吧？[l][r]
#riki:smile_s
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
所以先[r]
去拜见下今天的主角吧[p]
[delay speed="50"]
#aki:normal_s
……啊　确实。[l][r]
#aki:smile_s
等庙会开始后 可能就没机会和纱罗纱[r]
说话了[p]

#hino:smile_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
……嗯！　那我们出发吧！[p]
[resetdelay]
#riki:smileCE_s
回头见啦，雾绘！　待会见啊——！！[p]
@layopt layer=message0 visible=false
[clearfix]

[chara_hide name="aki" wait="false" pos_mode="false"]
[chara_hide name="riki" wait="false" pos_mode="false"]
[chara_hide name="hino" wait="false" pos_mode="false"]

;ＳＥ走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#kirie:back_2
……………………………………[p]
[chara_hide name="kirie" wait="false" time="3000" pos_mode="false"]
[bg storage="brack.png" time="3000" wait="false" cross="false"]
[delay speed="60"]
#sarasa
呐……一树。[r]
如果我……我说了什么不该说的话 要阻止我[p]

#sarasa
雾绘小姐，在这个月暑假刚开始时……[p]
[bg storage="ton_a.jpg" time="10"]
[chara_show name="ituki" left="-70" top="-160" wait="false" face="sadB_s"]
[chara_show name="sarasa" left="360" top="-160" wait="true" face="sadB_gs"]
#sarasa
[font color="0xf08080"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[resetdelay]
8月6日凌晨1点，[r]
明明应该已经从桥上跳下去死掉了才对！？[p][resetfont]
[delay speed="60"]
#sarasa:worryLA_gs
但是呢，其实直到现在偶尔……[r]
还是会感觉到雾绘小姐的身影和声音。[r][wait time="500"]
可她实际上已经不在了，所以这一定是幻觉，[p]
#sarasa:lookAway_gs
是我的眼睛变得愈发不正常造成的，[r]
虽然我一直这样说服自己……[p]
[resetdelay]
[font size="40"]
[font color="0xf08080"]
#sarasa:sadB_gs
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[quake time="30"]
那不是幻觉吗！？[r][wait time="500"]
为什么大家都在和雾绘说话！？[resetfont][r]
雾绘她……明明已经[p]
[font color="0xf08080"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
现在的八种小镇里，[r][wait time="500"]
只存在于我脑海中的虚假雾绘[r]
才是唯一的存在啊！？！[p][resetfont][stop_kanim name=sarasa]

[delay speed="50"]
#ituki:hateG_s
……你没有错[wait time="500"]　纱罗纱你什么都没错啊[p]
[delay speed="70"]
#ituki:tweetG_s
雾绘明明应该已经死了……[r]
虽然、她的身体还没浮上来……[r][resetdelay]
毕竟是从四ツ山的桥上　掉进了花隅川里啊[p]
#ituki:sadG_s
没关系，我可以很肯定地说[r][wait time="500"]
这才是、我真实的记忆！[p]
#ituki:angryN_s
因为我——自从上次约定之后一点都没有、[r][wait time="500"]
忘记纱罗纱说过的话[r]
和关于雾绘的记忆！[p]
[free_filter]
#sarasa:sad_gs
一树……！[p]

#ituki
没事的，纱罗纱[p]
[delay speed="60"]
#ituki:hateG_s
……不 骗你的 其实有事 根本一点都不好[r]
因为死去的人，现在就站在那里啊……[p]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="smileCE_s"]
[chara_show name="hino" top="-100" left="100" wait="false" face="smile_s"]
[resetdelay]
#riki
哟—。今天白绢祭恭喜啦！[r]
这身打扮超厉害啊！[p]
#hino:normal_s
与夫人大人的头饰款式有所不同呢。[p]
#hino:happy_s
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
嗯，[r]
这顶绵帽不是很适合你嘛！志户田！[p]

#aki:smileB_s
啊—啊—刚才的发言[r]
要是优君在场的话肯定会暴跳如雷吧[p]
[delay speed="60"]
#sarasa
……大、大家……[p]
[fadeoutbgm time="3000"]

#sarasa
(……)[p]

#ituki
…………………………[p]

#ituki
（……纱罗纱）[p]
#
就在刚才还和死者理所当然地谈笑风生[r]
面对他们，犹豫着该如何开口的我——[r]
树月凑近耳边低语。[p]

#ituki
（——雾绘今早装作若无其事地出现在茧家里。[r]
仿佛这几周……）[p]

（不，这几年[r][wait time="500"]
一直在这个小镇过着日常生活的样子，[r]
既无人责备……[wait time="500"]又被周围人所接纳的状态）[p]

#ituki
（可即便如此，力也好 阿基也好 国雄也好[r]
谁都没提起雾绘投河的事[r][wait time="500"]
（雾绘自己也绝口不提近况）[p]
[chara_hide_all time="10"]
[chara_show name="ituki" top="-160" face="tweetLA_s" wait="false"]
（说不定……[r][wait time="500"][font color="0xf08080"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
是某人的祝福[resetfont]导致了这种状况）[p]
#ituki:hate_s
（……所以现在，先静观其变）[p]

#sarasa
（……嗯、嗯 明白了……）[p]
[chara_hide name="ituki" wait="false"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
#
从眷属少年们的头顶望去，[r]
偷偷观察雾绘的身影。[p]

她方才被少年们擦肩而过时的[r]
保持着站立姿势，[r]
背对着这边……手臂无力地垂落着。[p]

雾绘一次都没有，转向我这边。[p]
[resetdelay]
#sarasa
……大家，听我说。[p]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_s"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s"]
从今天早上起，贤治郎先生就失踪了[p]
[font size="40"]
#hino:shame_s
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
哎哎！？！？！？！[r]
祭主大人！？！？！？[p]
[resetfont]
#aki:hate_s
日野　吵死了[r]
这种事……多少能预料到的吧[p]

#riki:shame_s
啊——失踪了啊。终于来了啊[p]
[delay speed="50"]
#sarasa
虽然不清楚，但总觉得……[r]
他应该还没有离开这座小镇[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
所以希望大家也……[r]
分头去找找他吧！[r][wait time="500"]
贤治郎先生他……！！[p]

#riki:smileCE_s
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
了解。[r]
啊哈哈，那种光头可不是随随便便就能遇到的啊。[r]
绝对会是我最先找到他！[p]

#aki:normal_s
嗯　我也会　去找的[l][r]
#aki:smileB_s
要是他想逃跑　就算推他掉坑里　我也会把他带回来[p]

#hino:tweet_s
交给我们吧。志户田[p]
#hino:lookAway_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
我们八种町的白绢祭典，[r]
绝不会让奥露茂的阴谋得逞[p][stop_kanim name=hino]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" wait="false" face="worry_gs"]
[delay speed="60"]
#sarasa
谢谢，那就……[r][wait time="500"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
#sarasa:wow_gs
——！[p]
[stop_kanim name=sarasa]
[chara_show name="ituki" top="-160" face="tweet_s" wait="false"]
#ituki
……？怎么了？纱罗纱[p]
#sarasa
……刚才还在那里的雾绘小姐……[l][r]
#sarasa:sadB_gs
………………………………[l]不知不觉就不见了[p]
[resetdelay]
[chara_hide_all time="10"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
[chara_show name="riki" top="-100" left="400" wait="false" face="normal_s" time="100"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal_s" time="100"]
#riki
？啊—，真的诶—。[l][r]
#riki:think_s
嘛—可能是去厕所了吧？[p]
[delay speed="50"]
#aki:tweetLA_s
现在得先找贤治郎先生[r]
雾绘小姐她[r]
他在哪里不用在意也没关系吧？[p]

#ituki
……是啊 纱罗纱[l][r]
[chara_hide_all time="10"]
[chara_show name="ituki" top="-160" face="hate_s" wait="false"]
这种时候那家伙的事，先放一边吧[p]

#sarasa
……说的也是[p]

#sarasa
[delay speed="100"]
………………………………………[l][r]
（是啊……）[p]
#
现在、总之得先找到贤治郎先生――[p]
[chara_hide name="ituki" wait="false"]
[bg storage="brack.png" wait="false" cross="false" time="3000"]
[delay speed="70"]
#
「那这样、我们分两路找吧。」[p]
「要是被诅咒了可就束手无策了，[r]
分成两人和三人小组行动吧……」[p]

「咱和纱罗纱一队，剩下的废物们自己分[r]
不准有异议」[p]

「诶？没问题吗？全是女孩子的话[r][wait time="500"]
　打起来会吃亏吧？」[p]

「你们这群人根本靠不住。[l]再说了，有咱在就是百人之力」[p]

「呵，树月先生说得没错！！」[p]

「有驱魔的志户田加上三位神官少女的话，[r]
就没什么好怕的了！」[p]

「那就这样——」[p]
[stopbgm]
「要是再有什么情况，随时联系」[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="3000"]
[mask time="3000"]
;-------------------------------------------------------------------------------
[chara_face name="makado" face="cut1_g" storage="chara/makado/ghost/cut1.png"]
[chara_face name="makado" face="cut2_g" storage="chara/makado/ghost/cut2.png"]
[chara_face name="makado" face="closeEye_g" storage="chara/makado/ghost/closeEye_g.png"]
[chara_face name="makado" face="ghost_g" storage="chara/makado/ghost/ghost_g.png"]
[chara_face name="makado" face="lookAway_g" storage="chara/makado/ghost/lookAway_g.png"]
[chara_face name="makado" face="tweet_g" storage="chara/makado/ghost/tweet_g.png"]
[chara_face name="makado" face="worry_g" storage="chara/makado/ghost/worry_g.png"]
;-------------------------------------------------------------------------------
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=50]
[bg storage="mountainRoad_m.jpeg" time="10"]
[mask_off time="3000"]
[wait time="2000"]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]

@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
;○森
#
——两人并肩走在四ツ山的森林中。[p]
[chara_show name="sarasa" left="360" top="-160" wait="false" face="worryLA_gs"]
#ituki
[chara_show name="ituki" left="-70" top="-160" wait="false" face="tweet_s"]
没事吧？纱罗纱[p]

#sarasa:closeEye_gs
没事……抱歉，我太慢了[p]
[delay speed="50"]
#ituki:sad_s
纱罗纱慢吞吞的　不是一直都这样嘛[r]
现在才在意也太迟了[p]
[chara_hide name="ituki" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="800"]
[chara_mod name="sarasa" face="normal_gs"]
#
她正配合着我迟缓的脚步调整步幅。[p]
记得暑假刚开始的时候，[r]
也曾这样拨开枝叶向前行进。[p]
[delay speed="70"]
那时候……是和贤治郎先生一起呢。[r][wait time="500"]
穿着校服，被他带着去了深山里的祠堂…………[p]
[chara_mod name="sarasa" face="sad_gs"]
——之后才，[wait time="500"]遇见了"还活着"的雾绘小姐。[p]

#ituki
……为什么雾绘会以那种方式回来呢。[p]

常言道，死人不会开口说话。[r]
却在这里絮絮叨叨着肤浅的日常对话……[p]

#sarasa:sad_gs
……或许并非如此[p]

#ituki
诶？[p]
[delay speed="50"]
#sarasa
不是雾绘小姐回来了，而是想见雾绘小姐的大家，[r][wait time="500"]
#sarasa:closeEye_gs
……不对。[p]
#sarasa:normal_gs
是我们……[r]
或许是我们让雾绘小姐的肉体重新回来了[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="ituki" wait="false" time="300" face="tweet_s" top="-160"]
[delay speed="70"]
#ituki
……我们？[l][r]
难道说纱罗纱也[wait time="500"] 一直想见雾绘[wait time="500"]吗？[p]
#
——对着露出错愕表情的树月，[r]
我轻轻点了点头。[p]
[delay speed="50"]
#sarasa
……一直在后悔着[l][r]
让她保持着被诅咒的状态……就这样跳了下去……[r]
没能阻止她这件事[p]

#sarasa
所以　想再见雾绘小姐一次[r]
想亲眼见证雾绘小姐的回忆[r][wait time="500"]
我一直这样祈祷着　我――[p]
#ituki
………………………………[p]
#ituki:smileLA_s
…………纱罗纱真是……[r]
太温柔了啊[p]
#ituki:tweetB_s
……可是呢……[p]

#sarasa
……？[l]　怎么了？[p]

#ituki
…………………………[l][r]
#ituki:tweetLA_s
雾绘的自杀　真的都是奥露莫克的错吗[p]

#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
诶……[p]

#ituki
……雾绘她，[l][r]
[resetdelay]

#ituki:sad_s
……[p]
#ituki:smileLA_s
如果我的记忆没错　姐姐她[r]
或许早已深陷地狱了吧[p]

#sarasa
——地狱？[p]
[stopbgm]
#
「纱罗纱」[p]
[delay speed="50"]
[chara_hide name="ituki" wait="false"]
！　[l][r]
……从背后传来这个夏天已听得无比熟悉的声音[wait time="500"][r]
凛然的话音响了起来。[p]

所以我[wait time="500"]试图转身。[p]
[resetdelay]
[font size="40"]
[chara_show name="ituki" face="sadB_s" wait="true" time="100" top="-160"]
[font size="40"][font color="0xf08080"]
#ituki
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
！！！！！[wait time="200"][er][stop_kanim name=ituki]
[font size="40"][font color="0xf08080"]
#ituki:shout_s
纱罗纱、快跑！！！[p]
[resetfont]
[chara_hide name="ituki" time="10"]
#sarasa
贤治郎先生[er]
#
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="makado" top="-100" wait="false" time="100" face="cut1_g"]
[playse storage=ti.ogg volume="50"]
[chara_mod name="makado" face="cut2_g" time="200" wait="true" cross="false"]
[wse]
;ＳＥズバッ　赤いフィルター
[chara_hide name="makado" time="5000" wait="false"]
[bg storage="still/ti.png" wait="false" time="8000" cross="false"]
[wait time="3000"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
…………[p]
[delay speed="100"]
[r]
[r]
[r]
[r]
[r]
……沿着脊梁骨的一道灼热，火辣辣地烧了起来。[p]
[r]
[r]
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。
好烫。好烫。好烫。好烫。好痛。[r]
好痛――[p]
[mask time="100"]
[bg storage="mountainRoad_m.jpeg" time="10"]
[playse  volume="140" buf="0" storage="book.ogg"]
[wse]
[wait time="5000"]
;ＳＥドサッ
[mask_off time="4000"]
#
……[r]
……纱罗纱、纱罗纱！[l][r]
[r]
[r]
[r]
纱罗纱[wait time="500"]　纱罗纱！[p]
[quake time="30"]
[quake time="30"]
[delay speed="60"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[playbgm storage="faure-op84-5.ogg" loop=true volume="50" sprite_time="0000-76400"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[font size="40"]
[resetdelay]
喂……！　喂、喂[r][wait time="500"]
纱罗纱、纱罗纱啊――[l][r]
你在干什么啊，快醒醒啊[p]
[resetfont]
#ituki
啊……啊……啊啊……[r]
不要不要不要，不要啊啊啊[r]
停下，停下来啊——[p]
[font size="20"]
#ituki
呜……呜呜……呜呜呜——…………[p]
[resetfont]
[chara_show name="makado" top="-10" wait="false" face="cut2_g"]
#makado
…………[p]
#
——树月趴伏在横卧地面的志户田纱罗纱身上哭泣着。[r]
她的后背正被鲜血渐渐染红，[r]
用小手拼命按压着。[p]
[chara_hide name="makado" time="10"]
[chara_show name="ituki" top="-160" wait="true" time="100" face="shout_s"]
[font size="40"][font color="0xf08080"]
#ituki
[resetdelay]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[quake time="30"]
——你在干什么啊！！！[p][resetfont]
#
[chara_hide name="ituki" wait="false" time="100"]
[bg storage="still/ti.png" wait="true" time="300" cross="false"]
[bg storage="mountainRoad_m.jpeg" time="300" wait="false" cross="false"]
;SEザクッ
[playse storage=ti.ogg volume="50"]
[font color="0xf08080"]
宗方树用从马门贤治郎那里夺来的利刃，[r]
将划破纱罗纱后背的那只手掌，[r]
狠狠钉在了树干上。[p]
[font size="20"]
#makado
——！呜……[p]
[resetfont]
#ituki
纱罗纱、快逃、纱罗纱……[p]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
#
用头发和手臂，缓缓将纱罗纱抱起来。[p]

正要将她带往灌木丛深处时——[p]

#sarasa
Hoc volo[wait time="500"] sic jubeo[wait time="500"] sit pro ratione voluntas[p]

#ituki
……咦？[p]
[fadeoutbgm time="5000"]
#sarasa
Hoc volo[wait time="500"] sic jubeo[wait time="500"] sit pro ratione voluntas[p]
[delay speed="60"]
#ituki
………………………………[l][r]
纱、纱罗纱……？[p]
[font size="20"]
[delay speed="100"]
#makado
……呜、呜呜……嘎啊……[p]
[resetfont]
[resetdelay]
#
听到贤治郎发出呻吟，树月立即转身，[r]
确认状况。[p]
[playse storage=ti.ogg volume="20"]
只见他正自行拔出刺入手掌的刀刃。[r]
干脆利落，毫无犹豫。[p]
#
[chara_show name="makado" top="-10" face="worry_g" wait="true" time="2000"]
#makado
………………[p]
[delay speed="300"]
#ituki
……马门[wait time="500"]贤治郎[p]

#ituki
你　[wait time="500"]你　唯独你绝对不行[p]
[resetdelay]
#sarasa
别来碍事[r]
树月[p]

#ituki
诶？[p]

#
横躺着的志户田纱罗纱继续说着。[p]

#志戸田 紗羅紗？
啊—　啊—啊—[p]

树、树月……是树月啊[wait time="500"]
对吧？你在那里的……[r][wait time="500"]
因为这可是志户[wait time="500"]田纱罗纱啊[wait time="500"]
对吧[p]
[delay speed="60"]
[chara_hide name="makado" wait="false"]
#ituki
…………你，[wait time="500"]是谁？[p]
[fadeinbgm storage=bigriver.ogg loop=true time=8000 volume="17"]
#志戸田 紗羅紗？
你、你才是那个[wait time="500"]我最[wait time="500"]
最想见到的人啊[p]

#ituki
…………不明白[r][r]
完全没有印象[p]

#志戸田 紗羅紗？
御白姬[p]
[delay speed="70"]
#makado
……………[p]

#ituki
………………………………………………[l][r]
………………………………啊？[p]

#志戸田 紗羅紗？
我是真的御白姬哦[p]

不是你临时准备的那个冒牌货呢[r]
三人官女 宗方树[p]

#ituki
………………[p]

#志戸田 紗羅紗？
不过还没结束呢[r]
必须将这个人的自我完全抹除才行[r]
你就暂时在那里看着吧[p]

#志戸田 紗羅紗？
动弹不得的马门家后裔 真是双令人憎恶的眼睛[l][r]
用末裔之血来偿还我吧[p]
#
……当纱罗纱口中漏出这句话的瞬间，[r]
面色铁青的贤治郎开始发生剧烈变化。[p]
[playse storage=ti.ogg volume="10" loop="true"]
身体部分被白色柔软细胞取代的部位，[r]
不断膨胀收缩——[r]
正带着明确意图向某种形态演变。[p]
[stopse]
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="makado" face="ghost_g" wait="false" time="2000" top="-100"]
[wait time="3000"]
[chara_move name="makado" anim="false" width="-=200" top="-50" left="150"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#makado
……[p]
[stopse]
#makado
…………御白姬[p]

#志戸田 紗羅紗？
不准跟我说话[wait time="500"]　区区眷属也配[p]

#makado
……[p]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=3000 volume="30"]
#
马门贤治郎高高扬起神厩舍的注连绳。[r]
即便并非惯用手，动作却娴熟利落。[p]
[chara_hide name="makado" wait="false"]
[playse storage=run.ogg volume="10" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[font size="40"]
[resetdelay]
#ituki
——！　[quake time="30"][wait time="500"]
纱罗纱！！[p]
[quake time="30"]
[mask time="10"]
[playse  volume="70" buf="0" storage="punch.ogg" ]
[wait time="500"]
[mask_off time="10"]
[quake time="10"]
[resetfont]
;ＳＥ鞭
#
宗方树在贤治郎抛出的[r]
绳索轨迹中　闪电般护住了志户田纱罗纱的身躯。[p]

结果手臂被缠住，正好……[r]
被拽向贤治郎制造出的四足生物[r]
那如前肢”般的部位近前。[p]
[delay speed="60"]
#ituki
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
呜、[wait time="500"]咕唔……！[p]

#志戸田 紗羅紗？
……树月？[l][r]
[delay speed="50"]
你要做什么，我根本无需担心[p]

#志戸田 紗羅紗？
要完全附身的话　必须从这里抽离自我才行[r]
毕竟那姑娘还有呼吸　所以――[p]
#ituki
呜、呜…吵死了…吵死了…[p]
[chara_show name="ituki" face="angryB_s" time="200" wait="true" top="-160"]
[font size="40"]
#ituki
[filter invert="90"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
……从这里开始全员
[chara_move name="ituki" top="-200" width="+=200" wait="false" anim="true" left="20"]
给我滚！！！[wait time="400"][er][stop_kanim name=树]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_hide name="ituki" wait="false" time="100"]
[free_filter]
#makado
！　呃…[p][resetfont]
[resetdelay]
#
[playse  volume="40" buf="0" storage="shimeage.ogg"  loop="true"]
树月的所有发丝骤然缠紧贤治郎的躯体，[r]
化作蛇首的部分露出尖锐獠牙――[p]

#ituki
消失吧！滚出八种！你……………[p]
[stopse]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="40"]
你这……[r][wait time="500"]
当初就不该让你们踏进这座小镇！！！[p]
[resetfont]
[font size="20"]
#makado
――快住手[p][resetfont]
[playse storage=book.ogg volume="80" sprite_time="0000-0130"]
[wse]
[playse storage=book.ogg volume="80" sprite_time="0000-0300"]
#ituki
[quake time="30"]
[quake time="30"]
[font color="0xf08080"]
呜啊！！[wait time="300"][er]
;ＳＥドカッ
#
白色块状物将宗方树狠狠踹飞，[r]
她的身躯划出弧线――[wait time="500"]坠入灌木丛中。[p]
[playse storage=wara.ogg volume="100" sprite_time="0000-0300"]
[wse]
[playse  volume="140" buf="0" storage="book.ogg"]
[delay speed="100"]
#ituki
咳……马门、[wait time="500"]贤治郎…………[p]
[font size="20"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
(……我的忘却祝福……居然失效了)[p][resetfont]
[delay speed="50"]
#志戸田 紗羅紗？
……这个男人只是在理性层面上服从我的指令[r]
你可是我的手脚啊[p]
[chara_show name="sarasa" top="-160" wait="false" face="closeEye_gs"]
敢妨碍这点的你　实乃大不敬[r]
树月[p]

#ituki
…………纱、纱罗纱……[p]

#志戸田 紗羅紗？
所以……[p]
[filter grayscale="100"]
[chara_hide name="sarasa" time="10"]
[chara_show name="mokke" top="-160" wait="false" time="100" left="100"]
;-------------------------------------------------------------------------------
;表情
[chara_face name="mokke" face="normal" storage="chara/mokke/osira/normal.png"]
[chara_face name="mokke" face="hate" storage="chara/mokke/osira/hate.png"]
[chara_face name="mokke" face="closeEye" storage="chara/mokke/osira/closeEye.png"]
[chara_face name="mokke" face="shout" storage="chara/mokke/osira/shout.png"]
[chara_face name="mokke" face="smile" storage="chara/mokke/osira/smile.png"]
[chara_face name="mokke" face="smileMini" storage="chara/mokke/osira/smileMini.png"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '志戸田 紗羅紗？'
[endscript]

;-------------------------------------------------------------------------------
#mokke:closeEye
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
要称呼我为[free_filter]
御白姬才对，这个冥顽不灵的家伙！[p]
[chara_hide name="mokke" time="10"]
[chara_show name="ituki" wait="false" top="-160" face="sadB_s"]
还是说这具肉体的原主意识，[r]
莫非是觉得失去太可惜了吗！？[p]
[font size="20"]
[fadeoutbgm time="2000"]
#ituki
没……错啊[p]
[delay speed="100"]
#ituki:cry4_s
我……已经不想再失去了……[p][resetfont]
[delay speed="60"]
#mokke
是吗是吗　原来如此啊[r]
那么看来必须放弃些期望了呢　树月[p]

我赋予这个男人的能力是[r][wait time="500"][font color="0xf08080"]
【一种将生物之死当作从未发生过一样来欺骗的力量】[resetfont][p]
[delay speed="50"]
就连奄奄一息的志户田纱罗纱　也早已……[l][r][font color="0xf08080"]
或许已被祝福所维持的虚伪生命[resetfont]所取代了也说不定啊[p][resetfont]

#ituki
…………[l][r]
[delay speed="120"]
#ituki:tweetG_s
虚伪的、生命？？[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[delay speed="50"]
#mokke
是啊。正因如此你才必须接受现实　树月[r]
人命终有尽时　与已完成使命之人的对话，就放弃吧[p]

若你无法咽下……这条真理的话…………[p]
[mask time="100"]
[chara_hide name="ituki" time="10"]
[chara_show name="makado" face="ghost_g" wait="false" time="2000" top="-100"]
[chara_move name="makado" anim="false" width="-=200" top="-50" left="150"]
[wait time="600"]
[mask_off time="100"]
你也会像【这个男人】一样[r]
不得不供奉自己血亲的腐肉啊[p]
[chara_hide name="makado" time="10" pos_mode="false"]
[chara_show name="ituki" top="-160" wait="false" time="100" face="tweetG_s"]
#ituki
——！！[wait time="700"]
#ituki:angryB_s
…………[p]
[chara_hide name="ituki" wait="false"]
[font size="40"]
#ituki:shout_s
[filter invert="90"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
闭嘴、快睡！！！[p][stop_kanim name=树]

[resetfont]
[delay speed="100"]
#mokke
[quake time="30"]
[free_filter]
……！你、你这……[wait time="500"]竟将眷属获赐的[wait time="500"]祝福，[p]

对我……[wait time="500"]……………[p]
[mask time="2000"]
#
[playse  volume="80" buf="0" storage="book.ogg"]
[wse]
[wait time="5000"]
[chara_show name="makado" top="-10" face="worry_g" time="10"]
[mask_off time="2000"]
…………………………………………[l][r][delay speed="50"]
回头望去，贤治郎的形貌再度发生了异变。[p]

树月用冰冷的目光蔑视着那个身影。[p]
#ituki
……你也别来追我们。[r]
马门贤治郎……[p]
[delay speed="100"]

#ituki
——要是纱罗纱死了[wait time="500"]　我绝对回来宰了你[p]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
;ＳＥ走る
#makado
……[p]

#makado:closeEye_g
…………[p]
[mask folder="bgimage" graphic="still/part5.png" time="3000"]
[chara_hide name="makado" time="10"]
[fadeoutbgm time="3000"]
[wait time="3000"]
[showsave]
;セーブしますか？
@jump storage="chapter_5/day1_vol3.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
