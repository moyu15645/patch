[eval exp="f.save_title = '五章パート３'"]
;-------------------------------------------------------------------------------
[bg storage="brack.png" time="10"]
;-------------------------------------------------------------------------------

[chara_face name="sarasa" face="normal_w" storage="chara/sarasa/waka/normal_w.png"]
[chara_face name="sarasa" face="angry_w" storage="chara/sarasa/waka/angry_w.png"]
[chara_face name="sarasa" face="closeEye_w" storage="chara/sarasa/waka/closeEye_w.png"]
[chara_face name="sarasa" face="monaka_w" storage="chara/sarasa/waka/monaka_w.png"]
[chara_face name="sarasa" face="sad_w" storage="chara/sarasa/waka/sad_w.png"]
[chara_face name="sarasa" face="smile_w" storage="chara/sarasa/waka/smile_w.png"]
[chara_face name="sarasa" face="smileCE_w" storage="chara/sarasa/waka/smileCE_w.png"]

;-------------------------------------------------------------------------------

[chara_face name="makado" face="normal_w" storage="chara/makado/waka/normal_w.png"]
[chara_face name="makado" face="angry_w" storage="chara/makado/waka/angry_w.png"]
[chara_face name="makado" face="closeEye_w" storage="chara/makado/waka/closeEye_w.png"]
[chara_face name="makado" face="smile_w" storage="chara/makado/waka/smile_w.png"]
[chara_face name="makado" face="smileCE_w" storage="chara/makado/waka/smileCE_w.png"]
[chara_face name="makado" face="smileMini_w" storage="chara/makado/waka/smileMini_w.png"]
[chara_face name="makado" face="worry_w" storage="chara/makado/waka/worry_w.png"]
[chara_face name="makado" face="wow_w" storage="chara/makado/waka/wow_w.png"]
[chara_face name="makado" face="wowCM_w" storage="chara/makado/waka/wowCM_w.png"]

;-------------------------------------------------------------------------------
;makado
[chara_new  name="kyosiro" storage="chara/kyosiro/normal.png" jname="馬門享四郎"]
;表情
[iscript]
TYRANO.kag.stat.charas['kyosiro'].jname = "馬門 享四郎"
[endscript]
[chara_face name="kyosiro" face="normal" storage="chara/kyosiro/normal.png"]
[chara_face name="kyosiro" face="lookAway" storage="chara/kyosiro/lookAway.png"]
[chara_face name="kyosiro" face="smile" storage="chara/kyosiro/smile.png"]
[chara_face name="kyosiro" face="wow" storage="chara/kyosiro/wow.png"]
;-------------------------------------------------------------------------------
;あとでけす
[iscript]
TYRANO.kag.stat.charas['makado'].jname = "馬門 賢治郎"
[endscript]

;-------------------------------------------------------------------------------

@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[font size="20"]
[delay speed="100"]
#
[mask_off]
——啊[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
——纱罗纱……[wait time="500"][er]

——纱罗纱　把那个交出来……！[wait time="800"][er]
[mask time="100"]
[bg storage="indoor/makado_ima_m.jpg" time="100" cross="false"]
[wait time="1000"]
[chara_show name="kinuyo" top="-160" time="10" face="angry"]
;○馬門家
[mask_off time="100"]
[resetdelay][font size="40"]
#kinuyo
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
纱罗纱！[resetfont]　你真的已经……[r]
明明是个女孩子怎么这么贪吃啊！？[p]
[chara_move name="kinuyo" left="360" anim="true" wait="false"]
[chara_show name="sarasa" top="-160" wait="false" face="monaka_w" left="-120"]
#sarasa
……[p]

#kinuyo:sad
连别人份的零食都不准吃！[p]
[delay speed="50"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
#
……啊啊[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="sad_gs"]
年幼的自己，正在眼前把糯米饼塞得满嘴都是。[p]
[chara_mod name="sarasa" face="closeEye_gs"]
#
这是——[r][wait time="500"]
世人常说的走马灯[playse  volume="20" buf="0" storage="sariin.ogg" ]　
之类的东西吧。[p]
[chara_hide name="sarasa" time="300" wait="false" pos_mode="false"]
[resetdelay]
#
「这不是挺好的嘛。[r]
小孩子嘛，吃得多才能长得壮。[r]
不用客气啦」[p]
[chara_show name="sarasa" top="-160" wait="false" time="100" left="-120" face="monaka_w"]
[chara_show name="kinuyo" top="-160" wait="false" time="100" left="360"]
#kinuyo
知子小姐，话是这么说……但纱罗纱她挑食啊！[p]
#kinuyo:sad
肉和鸡蛋总是剩下，[r]
净把糯米饼和栗子羊羹往嘴里塞。[r]
这样下去只会横向发展啊！[p]

#sarasa
……[p]
[delay speed="50"]
#
「对了，贤治郎。把你的也给她吧？」[p]
[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[chara_hide_all time="10"]
[chara_show name="makado" top="-30" face="normal_w" wait="false"]
#makado
哎？[p]

#makado:smileMini_w
啊……说的也是。来，给你[p]
[resetdelay]
[font size="20"]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" face="monaka_w" wait="false" time="100" top="-160"]
#sarasa
咔嚓咔嚓咔嚓咔嚓咔嚓咔嚓[p]
#
[chara_hide_all time="10"]
[chara_show name="sarasa" face="sadB_gs" top="-160" wait="true" time="100"]
[resetfont]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
（……好丢脸！！）[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="kinuyo" top="-160" face="sad" time="100" wait="false"]
#kinuyo
纱罗纱！快道谢！！[p]
[chara_hide name="kinuyo" time="10"]
[chara_show name="sarasa" top="-160" face="smile_w" wait="false" time="100" left="-120"]
[chara_show name="makado" top="-30" face="smileMini_w" wait="false" time="100" left="320"]
#sarasa
谢谢啦[p]

[delay speed="50"]
#makado
纱罗纱，你喜欢最中饼吗？[p]
[chara_mod name="sarasa" face="normal_w"]
[anim name="sarasa" top="+=30" time="200"]
[anim name="sarasa" top="-=30" time="200"]

#
年幼的我对着贤治郎先生点了点头。[p]

#kinuyo
真是的，这孩子……[p]
对不起啊，贤治郎先生。[r]
连你的点心都被让出来了……[p]
[resetdelay]
#makado:smile_w
不会啊，看她吃得这么香反而很有趣呢。[r]
没关系的[p]
#
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
「贤治郎！不准对女孩子说有趣这种话！」[p]

#makado:worry_w
啊……对不起[p]
[delay speed="50"]
#kinuyo
话说回来……今早你是去学校参加模拟考的吧？[p]

明明前不久才刚结束中考，[r]
现在就得考虑大学出路了。[r]
当学生真辛苦呢[p]
[resetdelay]
#makado:smile_w
不过嘛，准备工作越早开始越好。[r]
我想从现在就开始努力[p]

#sarasa:smile_w
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
这个分给爸爸[p]
[chara_mod name="makado" face="worry_w"]
#kinuyo
咦？[p]

#sarasa
这个很好吃所以我要分给爸爸！[p]
[font size="40"]
#kinuyo
爸爸才不要纱罗纱吃剩的东西！[p]
[resetfont]
#sarasa:closeEye_w
才不会呢　只要啊——地喂他什么都会开心的[p]

#sarasa:normal_w
呐阿姨，纱罗纱的爸爸呢？[r]
纱罗纱得去见爸爸才行[p]
#
「纱罗纱的爸爸现在[r]
我家爸爸正在外面和人聊天，[r]
要不等到他回来？外面可热得很呢」[p]

#sarasa:angry_w
诶——。我现在就要去嘛。纱罗纱现在、就要去见爸爸[p]
[chara_hide_all time="10"]
[chara_show name="kinuyo" face="sad" top="-160" left="-70" wait="false" time="100"]
[chara_show name="sarasa" face="angry_gs" top="-160" left="360" wait="false" time="100"]
#kinuyo
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
纱罗纱！妈妈要生气了哦！[p]
[delay speed="50"]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
就是！乖乖听话啊你这孩子……！[p]
[chara_hide_all time="10"]
[chara_show name="makado" top="-30" face="normal_w" wait="false" time="100"]
#makado
要我带你过去吗？[p]
[chara_move name="makado" left="360" wait="false" anim="true"]
[chara_show name="kinuyo" top="-60" left="-120" wait="false" face="sad"]
#kinuyo
不用太惯着她啦贤治郎先生。[r]
这孩子啊　发现耍赖有用就会得寸进尺的[p]
#makado:smile_w
没事……不要紧的。[p]
#makado:smileMini_w
我爸他们出门也挺久了，[r]
我顺便送点茶水过去吧[p]
[delay speed="50"]
#kinuyo:angry
哎呀，真是……[r][wait time="500"]
实在不好意思啊……[p]

#makado:smile_w
不用　别在意[p]

#makado:smileMini_w
那走吧，纱罗纱[p]
#
……………………[p]

…………两个我跟在贤治郎先生身后。[p]

[mask]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="1000"]
[chara_hide_all time="10"]
#sarasa
[bg storage="jinja_m.jpg" time="10"]
[chara_show name="sarasa" top="-160" face="smile_w" wait="false" time="100" left="-120"]
[chara_show name="makado" top="-30" face="normal_w" wait="false" time="100" left="320"]
[mask_off time="2000"]
;○境内
贤治郎先生。谢谢你—[p]

#makado:angry_w
没事，我才是得救了。[r]
一直被老妈她们夹在中间　待着可难受了……[p]

#sarasa:normal_w
叛逆期？[p]
[delay speed="60"]
#makado:worry_w
啊—，不是……可能吧。[p]
#makado:closeEye_w
虽说有叛逆期的话父母可能反而会放心，[r]
但到底该怎么反抗　我到现在还是不明白……[p]
[delay speed="50"]
#sarasa:closeEye_w
教你个好办法，离家出走就行了。[l][r]
#sarasa:smile_w
就算他们求着说'快回来吧'，也要拒绝三次[p]

#makado:normal_w
…………………………[l][r]
#makado:smileMini_w
要是他们没说到第四句'快回来吧'的话，你怎么办？[p]

#sarasa:normal_w
那就真正地离家出走。[r][wait time="500"]
那应该就是成为大人的时机吧？[p]

#makado:wowCM_w
……[p]
[resetdelay]
#makado:smileMini_w
真厉害啊纱罗纱。能想到这种事比我还成熟呢[p]

#sarasa:closeEye_w
嗯。等我离家的时候要住在海边，[r]
还打算邀请朋友来玩。[p]
#sarasa:smile_w
虽然这个想法还没告诉本人，[r]
但肯定会说'很棒'的[p]
#makado
嘿……[p]
[delay speed="50"]
#makado:smile_w
离开父母的话……[r]
就算一直吃最中饼，也不会被任何人骂吧[p]
[resetdelay]
#sarasa:angry_w
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
才不是呢！平时才不会这样连别人的份都偷吃。[r]
今天的最中饼实在太美味了，所以才想多拿几个！[r][wait time="500"]
我最喜欢夹着栗子馅的最中饼了！[p]

#makado:smileCE_w
哈哈哈……我懂，确实很好吃呢[p]
[delay speed="60"]
#
——啊，是这样啊。[p]

贤治郎先生在我十岁的时候，就是这种感觉。[p]

和现在一样[wait time="500"]　对后辈很温柔[wait time="500"][r]
　和现在一样[wait time="500"]　总是很会照顾别人的感受[r]

比现在更加自然地笑着。[p]
[font size="20"]
……啊，还有头发呢。[p]
[fadeoutbgm time="3000"]
@layopt layer=message0 visible=false
[clearfix]
[resetfont]
[chara_hide_all wait="false"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="1000"]
[chara_show name="kyosiro" top="-10" face="normal" wait="false"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#kyosiro
贤治郎。你带纱罗纱过来有什么事吗？[p]
[delay speed="80"]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——！这个人……！[p]
[delay speed="50"]
#makado
[chara_move name="kyosiro" left="-70" anim="true" wait="false" top="-30"]
[chara_show name="makado" left="340" face="normal_w" wait="false" top="-30"]
爸爸。纱罗纱的爸爸呢？[p]
#
对了，这个人……[r][wait time="500"]
我，都记得很清楚。[p]

贤治郎先生的父亲，[wait time="500"]享四郎先生…………[p]
#kyosiro:lookAway
你这家伙——本尊不在可真是走运啊——。[r]
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]
那家伙被男人叫「老爸」的话，[r]
会毫无理由地心情变差啊[p]

#makado:worry_w
本人不在……？也就是说[p]

#kyosiro:normal
已经先回去了。说是突然有工作[p]

#makado:wow_w
啊……[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="sad_w" wait="false" left="100"]
#sarasa
……………………[p]
[chara_move name="sarasa" left="-120" anim="true" wait="false" top="-160"]
[chara_show name="kyosiro" left="300" face="normal" wait="false" top="-30" zindex="2"]
#kyosiro
……嗯？怎么，那家伙有什么事吗……[p]
[font size="40"]
#kyosiro:wow
[playse  volume="20" buf="0" storage="kakan.ogg" ]
——！[p][resetfont]

#kyosiro:smile
哎呀。[r][wait time="500"]
[anim name="kyosiro" top="+=30" time="200"]
[anim name="kyosiro" top="-=30" time="200"]
难道说，这是给我的礼物吗？大小姐[p]

#sarasa
……[p]
[font size="20"]
#sarasa:monaka_w
咔嚓咔嚓咔嚓咔嚓咔嚓咔嚓[p][resetfont]
#kyosiro:normal
嚯！吃得真香啊[p]

#sarasa:angry_w
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[anim name="sarasa" top="+=60" time="150"]
[anim name="sarasa" top="-=60" time="150"]
……哼，我才不认识什么爸爸！！[p]

#kyosiro:smile
[anim name="kyosiro" top="+=30" time="150"]
[anim name="kyosiro" top="-=30" time="150"]
[anim name="kyosiro" top="+=30" time="150"]
[anim name="kyosiro" top="-=30" time="150"]
哈哈！志户田家的小公主发火啦。
那家伙也是个混蛋魔王呢[p]
[chara_move name="kyosiro" left="400" wait="false" time="300"]
[chara_show name="makado" top="-30" face="worry_w" wait="false" left="250" zindex="1" time="300"]
#makado
老爸，这孩子正在气头上呢……[p]
[delay speed="50"]
#sarasa:sad_w
——今年暑假爸爸肯定又要毁约了[p]

#makado:normal_w
[playse  volume="20" buf="0" storage="sariin.ogg" ]
诶？[p]

#sarasa
反正暑假期间肯定不会回来了。[r][wait time="500"]
然后说着'对不起'，就想用玩具来讨好我[p]
[delay speed="70"]
#sarasa:angry_w
我的房间里……会多出第二个旋转木马啊[p]
#makado
旋转木马……[p]
[delay speed="50"]
#kyosiro:wow
哎呀呀。[l][r]
#kyosiro:normal
纱罗纱和爸爸约定了什么吗？[p]

#sarasa:normal_w
嗯。有三年的约定呢[l][r]
#sarasa:closeEye_w
说要带我去坐[wait time="500"]　旋转木马的[p]
#sarasa:normal_w
……………去年啊　因为毁约了[r]
就拿了个旋转木马玩具　糊弄过去了[l][r]
#sarasa:angry_w
真的不能原谅　不过因为很可爱就摆出来了[p]
#kyosiro:lookAway
嘿！旋转木马真不错呢，我也很喜欢。[l][r]
#kyosiro:smile
是要去东京的游乐园坐吗？啊、难道说是海外！？[p]

#sarasa:sad_w
不是的，其实只要是旋转木马哪里都可以的。[r]
打个比方的话，惠那峡旁边那个游乐园的就完全足够了[p]

#makado:worry_w
诶？那里……？[p]

#sarasa:normal_w
贤治郎先生去过吗？[p]
#makado:wowCM_w
啊、那个、[wait time="500"]
[delay speed="60"]
#makado:closeEye_w
嗯……算是吧，毕竟离得近[p]

#kyosiro:lookAway
那时候的贤治郎真是可爱呢。[r]
看到靠近的玩偶装就害怕，拼命往爸爸妈妈身后躲……[p]
[resetdelay]
#makado:angry_w
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=makado keyframe=up time=300 wait="false"]
这都多少年前的事了啊！！[p][stop_kanim name=makado]
[delay speed="60"]
#sarasa
………………[p]
#sarasa:sad_w
……纱罗纱像那么小的时候，[r]
爸爸和哥哥也都会陪我一起玩的[p]
#
[fadeoutbgm time="8000"]
[chara_hide_all time="3000"]
但是到了现在这个年纪，[r]
他们就再也不回来了。[p]
[chara_show name="sarasa" top="-160" wait="true" face="closeEye_gs" time="1000" zindex="2"]
…………………………原来你都还记得啊。[r]
那些童年时…寂寞的回忆。[p]
……我只是想像从前那样，[r][wait time="500"]
希望有人能看着[wait time="500"]开心玩耍的我——[p]
[chara_mod name="sarasa" face="sad_gs"]
看着[wait time="500"]我欢笑着，[r][wait time="500"]
露出欣慰笑容的样子啊。[p]
#makado
那明年要是再被放鸽子的话　我带你去吧[p]
#sarasa:wow_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
…………………………………………[l][r][stop_kanim name=sarasa]
[chara_mod name="sarasa" face="normal_w" cross="false" time="500"]
诶？[p]
[delay speed="50"]
[chara_move name="sarasa" left="-120" anim="true" wait="false"]
[chara_show name="makado" top="-30" face="worry_w" time="100" wait="false" left="320" zindex="2"]
#makado
啊、明年夏天有补习班的课。[wait time="500"][delay time="70"][r]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
#makado:angry_w
啊……不对。[wait time="500"]后年就是升学考试了……[p]
[delay speed="50"]
#makado:smileMini_w
那个、果然还是……[wait time="500"]三年后之类的可以吗？[r]
我、大学入学那年的、暑假。[p]
#makado:smile_w
如果到那时候、[r]
纱罗纱还没被爸爸[r]
带去游乐园的话――[p]
#makado:smileCE_w
我带你去坐旋转木马。[p]
#
………………[p]

#sarasa
………………[l]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
惠那峡？[p]
[resetdelay]
#makado:wow_w
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=makado keyframe=up time=300 wait="false"]
诶！？
[fadeinbgm storage=sicilienne.ogg loop=true time=3000 volume="30"]　うん、
惠那峡的旋转木马也不错啊！？[r]
我记得那边好像是特别设计的双层款式。[r]
喂，老爸！？[p][stop_kanim name=makado]
[chara_move name="makado" left="430" anim="true" wait="false"]
[chara_show name="kyosiro" zindex="1" top="-30" left="280" time="100" wait="true" face="wow"]
#kyosiro
诶！？
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=kyosiro keyframe=up time=300 wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
　啊、啊啊、说的也是。[r]
可不能小看本地的游乐园啊，纱罗纱！[p]
[stop_kanim name=kyosiro]
#kyosiro:smile
不过贤治郎倒是挺敢说啊。[r]
要是当年的纱罗纱交了男朋友的话，[r]
你打算怎么负这个责啊～？[p]

#makado:smileCE_w
哈哈。初中生的恋爱关系什么的，根本无伤大雅啦[p]
#
——聊过。这种话题。[p]
[delay speed="60"]
啊，这样啊。[r]
窥视自己的回忆，原来就是这种感觉吗——[p]
[delay speed="70"]
……如果我死了，我房间里的玩具和衣服们……[r]
会变成怎样呢。[p]
[delay speed="50"]
#sarasa
……那，[p]
#sarasa:closeEye_w
和贤治郎先生的新约定里，可以再加一个条件吗？[p]

#makado:normal_w
诶？条件？是什么呢。[r]
要是太刁难人的话我可能会很困扰啊[p]

#sarasa:normal_w
其实、也不是什么大不了的事。[l][r]
#sarasa:smile_w
只是想带我一个朋友同行而已[p]

#kyosiro:lookAway
哦！好啊、是什么样的朋友？[r]
是想分享快乐的那种、特别要好的朋友吗？[p]
#sarasa
不是。[p]
#sarasa:smileCE_w
和那孩子在一起、就算是无聊的事也想一起做。[r]
就是那么重要的朋友哦[p]

#sarasa:smile_w
我……其实挺喜欢贤治郎先生的、[r]
我也想让她能喜欢上你呢。[r]
所以，带她一起去吧！[p]
[delay speed="60"]
#makado:smileMini_w
……当然好啊[p]

#makado:smileCE_w
纱罗纱总是能教会我很多美好的话语呢！[r]
这样啊，连无聊的事也要一起经历吗……[p]
[delay speed="50"]
#makado:smile_w
不知怎么的现在，[r]
我也突然想起一个想单独带去游乐园的朋友了。[p]
肯定和纱罗纱也[r]
能和纱罗纱的朋友也搞好关系的家伙啊…………[p]
[delay speed="100"]
[playse  volume="20" buf="0" storage="sariin.ogg"]
[font color="0xf08080"]
#
——啊啊，这一定是……[p]
[delay speed="60"]
[resetfont]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="sad_gs" wait="false" time="1000"]
#sarasa
…………………………………………[p]

#sarasa:closeEye_gs
………………贤治郎先生[p]

#sarasa:lookAway_gs
到头来这个约定……谁都没能遵守呢[p]
[chara_show name="kyosiro" top="-30" face="smile" wait="false" time="100"]
[stopbgm]
#kyosiro
虽然能遵守是再好不过，[r]
但想要遵守”的努力过程才具有最强的效力啊[r]
约定这种诅咒呢[p]

#sarasa:wow_gs
……诶？[p]

#志戸田 紗羅紗
诅咒？约定这种事算是诅咒吗？[p]
[delay speed="50"]
#kyosiro
是啊。用语言将对方捆绑束缚，[r]
试图决定未来命运的、最便捷也最亲近的诅咒[p]
[chara_hide name="sarasa" wait="false"]
[resetdelay]
#kyosiro:lookAway
纱罗纱和别人约定时也要小心些。[r]
言语会化作诅咒，[r]
最终成为记忆　[wait time="500"]并与肉体同化[p]

#makado
——父亲。[l][r]
[delay speed="60"]
像纱罗纱这样的孩子，听我们讲家事未免……[p]
[delay speed="50"]
#kyosiro:normal
有这么个老故事。[l][r]
#kyosiro:smile
某天祖父的嘴突然歪斜了[wait time="500"]　——[r]
有个姑娘来神社求助[p]

#kyosiro
虽然很多人尝试医治他的嘴，但都无济于事。[l][r]
#kyosiro:wow
然而仔细调查后发现，[r]
[anim name="kyosiro" top="+=60" time="400"]
[anim name="kyosiro" top="-=60" time="400"]
……原来老人前一晚吃了”鹿肉”[p]
[delay speed="60"]
#makado
父亲……[p]
[resetdelay]
#sarasa
没关系啦贤治郎先生。[r]
纱罗纱总是在图书馆借很多[r]
占卜啊咒术之类的书呢[p]
[delay speed="50"]
……那个、[r]
嘴巴歪斜的老人，昨天晚餐吃了鹿肉对吧。[p]
这和嘴巴歪掉有什么关系吗？[r]
是过敏之类的吗？[p]

#kyosiro:smile
[playse  volume="20" buf="0" storage="sariin.ogg" ]
老人，和神明[font color="0xf08080"]
契约[resetfont]
的约定啊[p]
#kyosiro:normal
那对父女家中供奉的神明，[r]
向信徒立下了‘不可食用鹿肉”[r]
的戒律[p]
[delay speed="60"]
#kyosiro:lookAway
[font color="0xf08080"]那位通过约定将身体奉献给神的老人[resetfont]
而老人，[r]
因触犯戒律招致神罚……[r]
面容才会被肆意扭曲[p]
[delay speed="50"]
#sarasa
哼嗯。那个老爷爷，明明立下了那样的约定[r]
却还是忍不住要吃鹿肉呢……[p]

#makado
……[l][r]
是啊。对纱罗纱来说就像最中饼那样的存在吧[p]
[font size="40"]
#sarasa
[quake time="30"]
唔！[p][resetfont]

#kyosiro:normal
总之……无论多么灵异的事件，[r]
只要好好分析就能找出规律性――[r]
应该能发现其中的规则。[p]
#kyosiro:smile
世上没有无缘无故的诅咒。[r][wait time="500"]
请务必记住哦，纱罗纱[p]
#
…………享四郎先生，曾对我说过这样的话吗。[p]
[delay speed="60"]
……可是。[l]就在他说出那句话的瞬间——[r]
他看向的，似乎是我——[p]
[resetdelay]
#kyosiro
[anim name="kyosiro" top="+=60" time="200"]
[anim name="kyosiro" top="-=60" time="200"]
好了，[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
差不多该回去了！要是一直待在外头[r]
会着凉倒下的！[p]
[chara_move name="kyosiro" left="-70" anim="true" wait="false"]
[chara_show name="makado" left="320" wait="false" top="-30" face="worry_w"]
#makado
啊，对了。[p]
#makado:normal_w
老爸，我在走廊上备好茶了。[r]
纱罗纱的那份也有准备，所以是两人份的……[p]

#kyosiro:smile
哦—不愧是我引以为傲的儿子！真贴心啊。[l][r]
#kyosiro:normal
像你这样的家伙，去哪儿都能出人头地[p]
#makado:smileMini_w
去哪儿什么的……[r][wait time="500"]
#makado:smile_w
我除了这儿哪儿都不会去的，老爸[p]
[delay speed="50"]
#kyosiro:lookAway
啊—，这个嘛……[l][r]
#kyosiro:normal
你的直觉也很敏锐，[r]
就算当上神官 也一定能成为很优秀的人吧[p]

#makado:smileCE_w
……嗯[p]

#kyosiro:smile
贤治郎你一定能 成长为像父亲那样出色的男人[p]
#
……恍惚间听着这段对话，[r]
我看见年幼的自己正头也不回地朝走廊方向跑去。[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all time="1000" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="200"]
[chara_show name="sarasa" face="wow_gs" top="-160" wait="false"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
哇……我、我怎么一个人乱跑！？[p]
[font size="20"]
#kyosiro
啊，纱罗纱在拼命喝茶呢[p]

#makado
原来是口渴了啊[p]
[resetfont]
[delay speed="60"]
#sarasa:sad_gs
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
（啊～～真是的，好丢脸……[r]
我以前居然这么孩子气吗……）[p]

#sarasa:worry_gs
（……）[p]
[chara_mod name="sarasa" face="wow_gs"]
#
……等等。[p]
[delay speed="70"]
这段回忆，[r][wait time="500"]
该不会不是我的回忆吧？[p]
[mask time="2000"]
[bg storage="porch_m.jpeg" time="10"]
[chara_hide name="sarasa" time="10"]
[chara_show name="sarasa" top="-300" face="smile_w" left="-150"]
[chara_show name="makado" top="-10" face="normal_w" left="430"]
[chara_show name="kyosiro" top="-10" face="normal" left="250"]
;○縁側
[mask_off time="2000"]
#sarasa
[anim name="sarasa" top="+=30" time="150"]
[anim name="sarasa" top="-=30" time="150"]
好慢啊[p]
[resetdelay]
#kyosiro
抱歉抱歉。[l][r]
#kyosiro:smile
啊，这里空调风吹过来真凉快啊！[p]

#makado:smileMini_w
毕竟上了年纪，别太勉强自己啊。老爸[p]

#kyosiro:lookAway
[anim name="kyosiro" top="+=30" time="150"]
[anim name="kyosiro" top="-=30" time="150"]
[anim name="kyosiro" top="+=30" time="150"]
[anim name="kyosiro" top="-=30" time="150"]
说什么呢—。我可还正当年呢—[l][r]
[delay speed="60"]
#kyosiro:wow
……喂，哦[p]
[chara_hide_all wait="false"]
[image layer=0 folder="image" name="mugicha" storage="item/mugicha.png" width="460" x="250" y="107" time="800" ]
;アイテムスチル；麦茶
[delay speed="50"]
#kyosiro
贤治郎—，[r]
你特意准备了老爸最爱的饮料吗！[p]
[delay speed="70"]
#makado
没有，只是……。[r][delay speed="50"]
家里待客用的配对玻璃杯，不就只剩这一对了吗？[p]

#sarasa
那个啊，贤治郎先生。[l][r]
这种时候啊，就算不认同也该装作点头的样子哦[p]
[resetdelay]
#kyosiro
没错啊贤治郎。这就是所谓的「可爱之处」啊[p]
[font size="20"]
#makado
…………连老爸都……[p]
[resetfont]
#
对着沉默的贤治郎先生，年幼的我——露出仿佛获胜般的，[r]
令人牙痒痒的得意笑容。[p]

#sarasa
（……这什么表情啊……）[p]
#
而在一旁微笑注视着我的享四郎先生。[p]
[free layer=0 name="mugicha" time="800"]
[fadeoutbgm time="3000"]
掌心里的……[r][wait time="500"]
正当要把那朵向日葵送到嘴边时。[p]

#sarasa
——啊[p]
#
老人布满皱纹的手突然滑脱了杯子。[p]
[font size="40"]
[quake time="30"]
#sarasa
——危险！！！[wait time="200"][er]
[resetfont]
[mask time="100"]
@layopt layer=message0 visible=false
[clearfix]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
;ＳＥガシャン
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = 'オシラヒメ'
[endscript]
#
[wse]
[wait time="2000"]
[bg storage="still/siro.png" time="10"]
[mask_off time="3000"]
[playse  volume="05" buf="0" storage="walk_rouka.ogg" loop="true"]
;○白空間
[wait time="4000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
………………………………………………………………[p]
#？？
马门之血。终究不得不断绝吗[p]
[delay speed="100"]
#
…………？[p]
[font size="20"]
#sarasa
……这里是、[p]
[resetfont]
#？？
你将与我合为一体。从此无需再做什么了[p]
[font size="20"]
#
――身体、动不了。[p]

站在对面的，是体型与我十分相似的、某人。[p]

#sarasa
你……是谁？[p]
[resetfont]

#mokke
御白姬[p]
[delay speed="50"]
我既是你的母亲，同时、也将成为你[p]
[delay speed="100"]
[font size="20"]
#sarasa
……我的、妈妈是………………[r][wait time="500"]
…………志户田绢世[p]
[delay speed="50"]
[resetfont]
#mokke
绢世！既是我的眷属，亦是我的女儿。[r]
但她回到我身边时，早已与男人交合过了[p]
#mokke
所以我一直在等待。[r][wait time="500"]
等待着纯净无暇、与我血脉相连的你的肉体[p]
[delay speed="100"]
#sarasa
……血脉……？[p]
[delay speed="60"]
#mokke
即便在脱离母胎后被人为切断，[r]
与我相连的血脉之线　一直绵延不绝地延伸着[p]

#mokke
而这条线的终点就是志户田纱罗纱[wait time="500"]　正是你啊[p]

#sarasa
…………[p]
[font size="40"]
#sarasa
…………！！！！[wait time="100"][er]
[mask time="100"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[bg storage="siro1.png" time="10"]
[chara_show name="sarasa" face="wow_gs" top="-160" time="10" left="360"]
[chara_show name="mokke" face="closeEye" top="-160" time="10" left="-120"]
;ＳＥシャン
[mask_off time="100"]
#sarasa
[font size="40"]
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
[anim name="sarasa" left="-=10" time=50 ]
[anim name="sarasa" left="+=10" time=50 ]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
啊、啊啊啊啊啊！！！[p]
[resetfont]
#mokke
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=mokke keyframe=up time=300 wait="false"]
！！　……[p][stop_kanim name=mokke]
[resetdelay]
#sarasa
……啊、我、我的……我的后背被划伤了！[r]
被诅咒之后的贤治郎先生…………[p]

#sarasa:lookAway_gs
为什么我会在这种地方发呆呢，[r]
必须赶快回去解除诅咒才行，[r]
一树要对贤治郎先生……！[p]


#mokke
…………[p]

#sarasa:worry_gs
啊……您、您是御白姬大人吗！？[r]
既然是真正的神明——就请救救我吧！？[p]

#sarasa:angry_gs
我现在必须[r]
立刻去见贤治郎先生他们！[r]
我被你的敌人——おくろもっけ下了诅咒……！！！！[p]
#sarasa:worry_gs
所以，求求你！[p]
[delay speed="100"]
#sarasa:worryLA_gs
赐予我、祝福……[p]

#sarasa:wow_gs
………………………………………………………………[p]
*noroi
;选择正确的选项
#
到目前为止[r]
被おくろもっけ诅咒的条件，[p]
[font size="25"]
[link target="*noroi_yes"]【１】从御白姬那里获得了祝福的人[endlink][r]
[link target="*noroi_no"]【２】狮心教的眷属[endlink][r]

[call target="*Sub_hover"]

[s]
;-------------------------------------------------------------------------------

;▶オシラヒメから祝福を授かっている者
;▶シシン教の眷属
*noroi_no
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]


――应该不止那一个才对。[p]


@jump target="*noroi"
;-------------------------------------------------------------------------------
*noroi_yes
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[cm]

#sarasa
…………御白姬。[p]

祝福、呢[p]
…………………………………………………………[p]
#sarasa
祝福，是否包含在[wait time="500"]与神的约定之中？[p]

#mokke
……………[p]

[delay speed="70"]
#mokke:smileMini
……我们之间所立之物的名号，怎样都无所谓。[l][r]
但『那东西”是仅赐予我眷属的奇迹[p]

#mokke:normal
立誓成为[r]
我手足的行为——[p]

所以呢？[r][wait time="500"]
你这家伙不是也有祈祷吗？[p]

#sarasa:worry_gs
…………[p]

#sarasa:closeEye_gs
——当然，要说祈祷的话，可是多到数不完呢[p]

#sarasa
…………[l][r]
#sarasa:sad_gs
你”对我祈祷的，究竟是什么？[p]

[mask]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="yama.jpeg" time="10"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[chara_hide_all time="10"]
[wait time="2000"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
;○森
[mask_off time="3000"]
[font size="20"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#ituki
纱罗纱、纱罗纱……[p]
[resetfont]
#？？
……一树[p]

#ituki
[quake time="30"]
！！[p]
[delay speed="120"]
#ituki
……马门贤治郎[wait time="500"]　你还有脸来这儿？[p]
[chara_show name="makado" face="worry_g" wait="false" top="-10"]
#makado
……[p]
[delay speed="50"]
#
从树丛遮蔽的另一侧，[r]
传来少女咬牙切齿的低语。[p]

#ituki
刚才说的话　没听见吗？[l][r]
[delay speed="60"]
都说了　别　追　着　我　了[p]
[resetdelay]
#ituki
这世上任何形态的事物都比不过对你的厌恶[r]
连一片衣角都不要让我看见[p]
你该明白——凡是和你扯上关系的人[r][wait time="500"]
没有一个得到救赎[p]
滚得远远的[p]
[delay speed="120"]
#makado:closeEye_g
…………[p]
#makado:worry_g
就一会儿……听我说几句好不好……[p]
[resetdelay]
#ituki
与其被你杀害[wait time="500"]　那个女人和纱罗纱[r]
还不如由我来动手[p]
[font size="40"]
#makado:closeEye_g
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
……他们根本不该死的！[p]
[font size="20"]
#ituki
——啊？[p]
[resetfont]
[delay speed="120"]
#makado
刚才、我……被注视着[p]

#makado:worry_g
感觉纱罗纱[wait time="500"]正在回溯我的记忆……[r]
她和我、还有父亲之间的过去…………[p]

#makado:closeEye_g
所以……她一定还活着[r]
我就是想告诉你这个……[p]

#ituki
——贤治郎先生。[p]
[delay speed="50"]
关于你至今【作为被赐予祝福的眷属】这件事[r]
您有什么头绪吗？[p]

#makado:tweet_g
……咦？[p]
[fadeoutbgm time="3000"]
#ituki
您的祝福——[wait time="500"]　祈祷是，[l][r][font color="0xf08080"]
【一种将生物之死当作从未发生过一样来欺骗的力量】[resetfont]这样的能力哦。[p]

这样的愿望，我至今从未听闻。[l][r]
因为，[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
三柱女神[font color="0xf08080"]从不回应涉及生死的祈愿[resetfont][wait time="500"][r]
这就是规则呀[p]

#makado:worry_g
……这、这样的规则？[p]

#ituki
…………[p]
凡是祈求生命诞生或死亡的眷属，都必须……[r]
在我们使用的两种祈愿文中[r][font color="0xf08080"]
使用「伪物」[resetfont]的那类文章才行[p]
否则的话[r][wait time="500"]
据说会被授予『禁断的祝福』[p]

但我心里有数。[wait time="600"][r]
曾经三位女官之中——[p]
也有不惜违背戒律，[r]
也要实现你心愿的女子存在呢[p]

#ituki
贤治郎先生。[l][r]
你以前从雾绘那里得到过祈愿文书吧。[r][wait time="500"]
而且还是以非正式的形式[p]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
#makado:tweet_g
————[wait time="800"]祈愿文书，[p]
[delay speed="100"]
#makado:closeEye_g
……直到前几天为止，我都还不知情——[r][wait time="500"]
真的、完全不记得自己何时成为了眷属……[p]
[resetdelay]
#ituki
啊啊啊、啊哈哈哈。[r]
忘掉了忘掉了。[r]
想不起来的记忆里、净是对某人不利的事[p]

#ituki
我明白了。[l][r]
反正雾绘那家伙、没征得同意也没好好说明[r]
就擅自动用了三位女官的力量吧。[p]

为了成为你心中、[wait time="500"]独一无二的特别存在[p]
[delay speed="150"]
#makado:worry_g
……特别……[p]

#ituki
……[p]
[delay speed="50"]
#ituki
果然这个[r][wait time="500"]
向我们揭示了无人知晓的新事实[r]
刚才”的纱罗纱　确实就是　御白姬本人吧[p]

而她所陈述的　关于你的祝福内容――[r]
【隐瞒人员死亡】这个事实也同样千真万确[p]
[delay speed="60"]
#makado:tweet_g
……对于狮心教的你而言，方才显现的存在是[r]
你是否真能咽下这个事实，[p]
#makado:worry_g
我…………我、[l][r]
#makado:closeEye_g
……[p]
[chara_hide name="makado" time="10"]
[chara_show name="ituki" face="shout_s" top="-160" wait="false" time="100"]
[font size="40"]
#ituki
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
吵死了！！！！　给我闭嘴！！！！[p]
[resetfont][resetdelay]
#ituki:angryB_s
从很久以前开始，[r]
对我而言的御白姬就只有纱罗纱一个人！！[r]
只有这孩子才是我的信仰啊！！！[p]
[delay speed="60"]
#ituki:cry4_s
就因为你存在，连生死都变得暧昧不清――[r][resetdelay][wait time="500"]
我根本无能为力！！！[r]
告诉我啊，这孩子到底是活着！？还是死了！？[p]
[font color="0xf08080"]
[chara_hide name="ituki" wait="false" pos_mode="false"]
[font size="40"]
#ituki:cry5_s
现在让雾绘的尸体在镇上活动的[r]
不就是贤治郎先生你吗！！[p]
不准再[r]
把八种町当作你的茧来摆布了！！！[p]
[resetfont]
#makado
[quake time="30"]
――！[p]
[delay speed="100"]
#makado
……什么时候，小雾……[p]
[font size="20"]
#ituki
呜呜——……呜……呜……醒醒……[r]
快回来啊…………[p]
[resetfont]
[chara_show name="makado" face="tweet_g" top="-10" wait="false"]
#makado
…………………………………………[p]
[delay speed="80"]

#makado:closeEye_g
……对不起，[r]
趁现在……我要走得越远越好……[p]
@layopt layer=message0 visible=false
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[mask time="2000"]
[chara_hide name="makado" time="10"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="1000"]
#
[bg storage="brack.png" time="10"]
[mask_off time="500"]
;暗転
[delay speed="50"]
;ＳＥざっざっ
[font size="22"]
@layopt layer=message0 visible=true
……拨开草木，向深山前进。[l][r]
[r]
这具被剥夺了日常形态的身体，[r]
被疼痛与真相搅乱的脑子[wait time="500"]　正拼命想要逃往某处。[l][r]
[r]
只是机械地[wait time="500"]迈动着双腿。[p]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[resetfont]
#makado
（…………………………………………）[p]
（难道是我的祝福……[l]让本该死去的[r]
尸骨无存的雾绘的幻影　在这座城镇　重现了吗）[p]

#makado
（想要抹消死亡的心愿，[r][wait time="500"]
让雾绘实现这种愿望的缘由[r]
根本不存在啊）[p]

#makado
（从未如此期盼过）[p]
[stopbgm]
（从未如此祈求过）[p]
[delay speed="80"]
#makado
（根本不曾祈愿过）[p]
[font color="0xf08080"]
#makado
（是这样吧，[wait time="500"]父亲，）[p]

[mask time="300"]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="yotuyamabridge_m.jpg" time="10"]
;○橋
[mask_off time="300"]
[playbgm storage=bigriver.ogg loop=true volume="10"]
[wait time="5000"]
;ＳＥ滝
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

#makado
…………[p]

#makado
……………………………………………………………………[r]
……………………………………………………………………[p]
[delay speed="50"]
#
应有的姿态。[wait time="500"]该去的地方。[r]
应尽之事。[p]
应有的姿态。[wait time="500"]
该去的地方。[r][wait time="500"]

应尽之事。[p]

应有的姿态。该去的地方。[r]
应尽之事。[p]
[delay speed="100"]
这一切，雾绘本该都明白的。[p]
雾绘——正是背负着这一切，坠落了。[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="3000"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="1000"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="5000"]
[resetdelay]
[chara_show name="riki" top="-100" face="smileCE_s" time="100" wait="true"]
#riki
[stopbgm][resetfont]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
哦——！贤治郎——！找到你啦——！[p]

#makado
――――……[p]

#riki:hate_s
哈啊？这造型也太恶心了吧～。[p]
[delay speed="50"]
#riki:smile_s
手上还沾满血……我最近刚学会形容这种场面的词儿，[r][wait time="500"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
叫血腥飞溅对吧！？[p]
[delay speed="120"]
[font size="20"]
#makado
……………………………………………………[l][r]
………………………………………………………血浆四溅？[p]
[delay speed="50"]
[resetfont]
#riki:lookAway_s
啊。好像是。嗯。可能是那个吧[p]
#riki:normal_s
不过按这情形，这大概就是你获得的天赋祝福咯。[r][wait time="300"]
[resetdelay]
#riki:smileCE_s
[playse  volume="20" buf="0" storage="kansei.ogg"]
嘿嘿，这不挺好的嘛！完全搞不懂你要干啥的氛围！[p]
#riki:angry_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——不如说浑身祝福还带着伤意味着啊。[r][delay speed="70"]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
该不会……刚才还在被诅咒状态下打架吧！？[p]
[font size="20"]
#makado
…………[l]被诅咒了[p]
[resetfont]
[resetdelay]
#riki
果然啊。[l][r]
#riki:think_s
怎么办啊　白绢祭的游行要通宵走路的吧？[p]
#riki:smileCE_s
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
大清早就伤成这样，体力肯定撑不住啦！[r]
啊哈哈！[p]

#makado
……………………[p]
[delay speed="100"]
#makado
……登利君。你……[l][r]
以前你问过我，[wait time="500"]能不能直视那些再也醒不过来的家人的脸，[r][wait time="500"]
还记得吧？[p]
[resetdelay]
#riki:normal_s
嗯？[wait time="500"]　啊——。　问过啊[p]
[delay speed="120"]
#makado
你当时……[wait time="500"]是因为"看不下去"，才这么问我的吗？[p]
[delay speed="50"]
;-------------------------------------------------------------------------------
[chara_face name="riki" face="smile1_s" storage="chara/riki/smile1_s.png"]
[chara_face name="riki" face="smile2_s" storage="chara/riki/smile2_s.png"]
[chara_face name="riki" face="smile3_s" storage="chara/riki/smile3_s.png"]
;-------------------------------------------------------------------------------
#riki:normal_s
对啊—。这不是明摆着嘛。[r]
因为根本没法觉得他们还和以前一样活着啊[p]

#makado
……………………………………………………[p]

#riki:lookAway_s
说实话啊。真想干脆一口气把他们全杀了。[r]
不仅外形变得面目全非 靠着砸钱和机器硬吊着命……[l][r]
老妈趁势变脸的模样 还有亲戚们的嘴脸 都恶心透顶[p]
[delay speed="60"]
#riki:smile1_s
可是啊……[p]
#riki:smile2_s
内心深处总觉得知贵会再来见我们[r]
会产生这种期待的[wait time="500"] 不正是我和老妈吗！[p]
#riki:smile3_s
决定生命终结时机的，到底该是谁呢。[r][wait time="500"]
我为了不必思考那些　选择了信仰神明[p]
#
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[wait time="2000"]
#
………………………………[p]

…………必须离开这里才行。[p]

#riki:sad_s
啊？你要去哪，贤治郎[p]

#makado
……没[l]……[p]
[delay speed="100"]
总之现在只想逃得远远的。[r]
免得又被诅咒缠上　真的痛下杀手……[p]
#
[resetdelay]
;ＳＥ走る
[playse storage=run.ogg volume="40" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="10" sprite_time="0000-0130"]
[wse]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
#riki:wow_s
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
……喂、[r]
喂！贤治郎——！！？[p]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal_s" time="100"]
[chara_show name="hino" top="-100" left="400" wait="false" face="angry_s" time="100"]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
登利你这家伙登利，别一个人擅自往前猛冲啊！[p]

#riki:normal_s
啊，日野～阿奇。你们太慢啦[p]

#aki
居然能轻易找到这种隐蔽的地方　不愧是烟鬼呢[p]

#riki:smileCE_s
哦！而且连贤治郎都找到啦！[p]

#hino:smile_s
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
噢！找到了吗，太好了太好了！[l][r]
[delay speed="50"]
#hino:tweet_s
话说，他人呢？现在什么情况？[p]

#riki:normal_s
已经被诅咒了，往更深处逃走了[p]
[font size="40"]
#hino:shame_s
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
被诅咒了！？！ 逃跑了吗！？！？[p]
[resetfont]
#aki
不是说好要抓住他的吗[p]

#riki:think_s
嗯……怎么说呢，总觉得那家伙的样子各种不对劲啊。[p]
#riki:normal_s
比起那家伙，[r]
还是先确认志户田他们现在的情况比较好吧[p]
[resetdelay]
#hino:angry_s
哈啊～～？！ 你让我们就凭你那野兽般的直觉行动！？[r]
太不负责任了！[l][r]
要是贤治郎先生被诅咒后出事了怎么办！？[p]
#riki:angry_s
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
被诅咒的家伙有什么好担心的啊。[r]
会被御黑祟诅咒威胁到生命的，[wait time="500"]只有志户田一个人而已[p]
[delay speed="50"]
#hino:tweet_s
……？[wait time="500"]　啊咧？[l]　说的也是。[r][wait time="500"]
被诅咒的人只不过是被操控着去袭击志户田而已啊……[p]
[delay speed="60"]
#hino:sad_s
奇怪……[wait time="500"]为什么我会担心被诅咒者的死活啊[p]

#aki:tweet_s
……喂 你们两个……[p]

#aki:tweetLA_s
这个地方……[wait time="500"][r]
暑假刚开始的时候[wait time="500"]　是不是[wait time="500"]　发生过什么事件？[p]

#hino
……………………[p]

#riki:sad_s
………………………………[p]
#
………………………………………………………[p]
[chara_hide_all time="5000" wait="false"]
[bg storage="brack.png" time="5000" wait="true" cross="false"]

决定生命终结时机的，究竟该是谁。[p]
[resetdelay]
作为至高悲剧的人类死亡，[r]
岂是能与对话之辈相谈的命运。[p]
[delay speed="70"]
（……但是）[p]

（雾绘，你一定……[r][wait time="500"]
你才不是被那种女神杀害的）[p]
[delay speed="50"]
雾绘之死。[l]与所敬仰父亲的回忆。[l][r]
自身不堪的过往。[l]女神所编织触碰的命运。[p]

这一切，[wait time="500"]都不该被杀害。[p]
[mask folder="bgimage" graphic="still/part5.png" time="3000"]
[fadeoutbgm time="5000"]
[wait time="5000"]
;セーブしますか？
[showsave]

@jump storage="chapter_5/day1_vol4.ks"

;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
