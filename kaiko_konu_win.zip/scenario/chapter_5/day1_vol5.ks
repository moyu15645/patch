[eval exp="f.save_title = '五章パート４'"]
;-------------------------------------------------------------------------------;-------------------------------------------------------------------------------

@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[bg storage="still/sleep_1.png" time="10"]
[mask_off time="5000"]
[delay speed="50"]
#ituki
……纱罗纱[p]
#ituki
纱罗纱、纱罗纱……[p]
#ituki
呜……呜、不要、不要不要不要……[r]
怎么办、怎么办…………！[p]
#ituki
喂、你还活着对吧……[l][r]
真的，[wait time="500"]………………………………………………[p]
[delay speed="100"]
[font size="20"]
真的、还活着吗……？[r]
呜……呜[p]
[fadeoutbgm time="4000"]
[resetfont]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[mask folder="bgimage" graphic="still/part5.png" time="4000"]
[bg storage="siro1.png" time="10"]
[chara_show name="sarasa" face="worry_gs" top="-160" time="10" left="420"]
[chara_move name="sarasa" width="-=100"]
[chara_show name="mokke" face="normal" top="-160" time="10" left="-80"]
[chara_move name="mokke" width="-=100"]
#sarasa
;ＳＥシャン
[mask_off time="2000"]
;○白空間
[delay speed="50"]
御白姬[p]
#sarasa
……您说[font color="0xf08080"]一直在等待[wait time="500"][resetfont]　着我呢[l][r][resetfont]
还说　您[font color="0xf08080"]亦是我的母亲[resetfont][p]

身为这片土地女神的您　怎会有等待我这种人的理由……[r]
这种事情　真的存在吗[p]
#mokke
是为了让我成为你啊[p]
#sarasa:wow_gs
……您要、成为我？[p]
[resetdelay]
#mokke
从获释那刻起直至此时此刻[r]
我一直在操控着我可爱的眷属们[p]
#mokke
作为我忠实的手足而存在[p]
#sarasa
………………[p]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
御黑祟的诅咒真面目是？[r]
[glink color="btn_12_black" target="*but" text="御黑祟与八种町人们的约定" width="5" x="680" y="60" ]
[glink color="btn_12_black" target="*good" text="御白姬与眷属立下的约定" width="20" x="630" y="60" exp="f.flag1=true" clickse="tapSE.ogg"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[current layer="message0"]
[position vertical=false]
#mokke
那是什么东西？[p]

@jump target="loop"
;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]
[delay speed="60"]
#sarasa
…………至今为止　眷属们被下达的[r]
袭击志户田纱罗纱的命令是……[p]
#sarasa
御白姬[wait time="1000"][r]
是您干的吗？[p]
@layopt layer=message0 visible=false
[clearfix]
#mokke:smileMini
[wait time="4000"]
#mokke:smile
[wait time="6000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
在眼前，我点了点头。[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask time="100"]
@layopt layer=message0 visible=false
[clearfix]
[wait time="3000"]
[bg storage="yotuyamabridge_m.jpg" time="10"]
[chara_hide_all time="10"]
[mask_off time="100"]
[playbgm storage=bigriver.ogg loop=true volume="10"]
[wait time="3000"]
;○森の橋
[chara_show name="riki" top="-100" face="sad_s" time="100" wait="false"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="tweet_s"]
[chara_show name="hino" top="-100" left="400" wait="false" face="sad_s"]
#aki
[delay speed="50"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……果然　这里发生过什么吧。[r]
在这个暑假　刚开始的时候[p]
#riki
搞…搞什么啊—。阿奇。[l][r]
那种事我哪记得啊—，去问日野不就好了？[p]
#hino
不……我也、该说完全没有头绪……[p]
#aki
说得更具体一点的话[r]
有没有谁变成忌日的日子？[p]
#aki:tweetLA_s
在八月的　最开始[p]
#hino:tweet_s
嗯？[p]
#hino:smile_s
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
八月的话，有柳田国男的忌日啊。[r]
所以我每年都会前后两天离开八种去扫墓[p]
[delay speed="70"]
#hino:sad_s
啊咧……但是今年没去呢。[r]
为啥来着……[p]
#aki:hate_s
……[p]
#aki:tweet_s
…………我们、[p]
@layopt layer=message0 visible=false
[clearfix]
;ＳE電話
[playse storage="phone.ogg" loop="true" volume="30" buf="1"]
[chara_mod name="aki" face="wow_s"]
[chara_mod name="riki" face="wow_s"]
[chara_mod name="hino" face="shame_s"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="aki" top="+=30" time="150"]
[anim name="aki" top="-=30" time="150"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#hino
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000" buf="2"]
――！[p]
[stopse buf="1"]
[chara_hide name="hino" wait="false"]
#riki:worry_s
嗯？喂国雄——谁啊这种时候……[p]
[font size="40"]
[stopbgm]
[resetdelay]
#hino
[playse  volume="20" buf="0" storage="kakan.ogg" ]
为什么不联系我啊、[r]
马力根小姐！！！[p]
#
[chara_mod name="riki" face="wow_s"]
[quake time="30"]
！！[p]
[resetfont]
……日野将通话声音用扬声器外放。[p]
[font color="0xb0c4de"]
[delay speed="60"]
#marigan
————啊、喂喂？嗯——……[l][r]
这信号怎么这么差啊[p]
[resetdelay]
[resetfont]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[chara_hide_all time="10"]
[chara_show name="hino" face="shame_s" time="100" wait="true" top="-100"]
——啊啊、糟糕！[r]
只有在贤治郎先生家的Wi-Fi覆盖范围内才能接通信号吗[p]
[font color="0xb0c4de"]
#marigan
啊、[fadeinbgm storage=hitoriboti.ogg loop=true time=5000 volume=30]
听到了。喂——喂。[l][r]
我是纪伊玛莉甘。最近过得还不错吧～[p]
[resetfont]
#hino:sad_s
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
玛莉甘小姐！我、我……[p]
[font color="0xb0c4de"]
#marigan
抱歉啦～。我连经纪人都没通知，[r]
突然消失吓到你了吧～[p]
[resetfont]
[chara_show name="riki" top="-100" wait="true" time="100" face="shoutG_s"]
#riki
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
喂玛莉甘！！你这他妈算什么事啊！！[p]
[font color="0xb0c4de"]
#marigan
……嗯？[p]
[resetfont]
[delay speed="50"]
#riki:angry_s
我说你啊，把我们耍得团团转，[p]
#riki:shoutG_s
摆出一副什么都知道的嘴脸，[r]
结果屁都不透露就半夜逃跑？！[p]
[resetdelay]
[font size="40"]
#riki:wow_s
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
亏你还是个大人！[p]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
所谓的天才少年啊、[r]
就是要把小屁孩的本事发挥到极致啊！！！[p]
[resetfont]
[delay speed="60"]
[font size="20"]
#marigan
[font color="0xb0c4de"]
……听不见啊- 你们接的是多垃圾的信号啊[p]
[resetfont]
[font color="0xb0c4de"]
[delay speed="50"]
算了无所谓，日野。[r][wait time="500"]
我只是想最后好好跟你道个别罢了[p]
[resetfont]
#hino:sad_s
[playse  volume="20" buf="0" storage="sariin.ogg" ]
诶？道别是指……[p]
[font color="0xb0c4de"]
[font italic="true"]
[font size="20"]
#marigan
『——本航班即将起飞 请速至4号登机口登机』[p]
[resetfont]
#
——玛莉甘的声音背后，传来飞机引擎的轰鸣……[l][r]
随后，传来高跟鞋铿锵有力地踱步声。[p]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="400"]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="400"]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="400"]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="800"]
[font color="0xb0c4de"]
#marigan
老娘啊——肯定不会再回这个国家了。[l][r]
所以想跟没来得及道别的你最后说说话！[p]
[resetfont]
#hino:shame_s
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="100"]
诶……！？！[p]
#hino:sad_s
不、不再回来……！！这是什么意思！？[p]
[chara_hide_all wait="false" time="4000"]
[bg storage="kuko.jpeg" wait="false" cross="false" time="4000"]
;○空港
#marigan
在被套上项圈前开溜呗。[r]
毕竟老娘在这个国家能做的事都已经做完了啊—[p]
[font size="20"]
[font color="0xb0c4de"]
#hino
项圈……[wait time="500"]您说什么呢玛莉甘小姐，[r]
你、你果然是在被什么人追捕吗！？！[p]
[delay speed="100"]
……啊啊事到如今……！[r]
恕我直言不讳了！！[p]
[resetfont][resetdelay]
[font color="0xb0c4de"]
[quake time="30"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
这次出版的书！[wait time="500"]老实说，太令人失望了！！[r]
写的内容全都是过去文章的再收录——[p]
[delay speed="70"]
五年前的演讲会上，您是这么说的吧。[p]

"下次执笔写书时 要从更久远的历史脉络中[r][wait time="500"]
彻底剖析八种町根深蒂固的民间信仰[wait time="500"]以纸质形式留存于世"……[l][r]
[resetdelay]
我和爷爷，都满怀期待地等待着那一刻。[p]
那些传承御白姬传说的人们，[r][wait time="500"]
究竟是怎样在八种生活的。[p]
如今的自己[r][wait time="500"]
究竟是站在由怎样的时光与人群编织而成的历史之上[r]
如果没有办法了解这一切……[l]那么我们就算被赐予再多未来[p]
在真正的意义上也无法前进[p]
[delay speed="50"]
[quake time="30"][font size="40"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
所以！[resetfont]　[font color="0xb0c4de"]为了在未来的洪流中生存下去 我――[r][wait time="500"][resetfont]
即使爷爷去世了　留下的资料被亲手烧毁[r][wait time="500"]
即使孤身一人被遗留在狮心教[wait time="500"]　我也坚持研究至今！[p]
[font size="20"]
可是……[p]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[delay speed="100"]
[font size="40"]
连你也――[wait time="500"][r][delay time="50"]
连你也要抛弃我吗！？[r]
马利根小姐！！[p][resetfont]
#
长篇倾诉的日野气息紊乱。[l][r]
或许是信号问题，马利根稍迟片刻才作出回应。[p]
[resetdelay]
[fadeoutbgm time="5000"]
#marigan
我也是迫不得已啊。[r][wait time="500"]
要是不抛下你，大家全都会变成大逆不道的罪人[p]
[font color="0xb0c4de"][font size="20"]
#hino
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
诶……？[p]
[resetfont]
[chara_show name="marigan" top="-10" face="smileB" wait="false" time="500"]
#marigan
嘛，总之就是说，[r]
像我这种人只要待在让自己活得轻松的――[r][wait time="500"]
能包容自己罪孽的环境里苟且偷生就行啦[p]
#marigan:tweetLA
如果控制不住想偷别人东西的冲动[r]
那就去个能纵容盗窃癖的地方呗。[p]
要是有杀人冲动的话，[r]
去找个会祝福杀戮的地方不就好了。[p]
#marigan:worry
[delay speed="60"]
……这个比喻不太恰当呢。那种地方根本不存在。[r][wait time="500"]
[resetdelay]
#marigan:angry
不对说不定真有？[r]
在这个世界的某个角落或许就存在这种地方！[p]
#marigan:smileCE
这么一想是不是开始兴奋起来了？[wait time="500"]　[r]
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
[anim name="marigan" left="-=10" time=50 ]
[anim name="marigan" left="+=10" time=50 ]
啊啊果然世界真美妙啊，[r][wait time="500"]
人类文化真是既美妙又充满未知！[p]
[delay speed="60"]
若能实现的话真想亲眼见证一切！[r]
活着真是让人欲罢不能呢！[p]
[font color="0xb0c4de"][font size="20"]
#hino
[quake time="30"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——我也已经无法抑制这种冲动了啊！[l][r]
[delay speed="60"]
所以……！[p]
#
[resetfont]
[chara_hide name="marigan" time="200" wait="false"]
[bg storage="brack.png" time="200" wait="true" cross="false"]
#marigan
就算背负罪孽也想知晓真相对吧[p]
[bg storage="yotuyamabridge_m.jpg" time="100" wait="false" cross="false"]
[chara_show name="hino" top="-100" wait="false" face="sad_s" time="100"]
[resetdelay]
#hino
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="40"]
那个[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
说得对！[p]
[font color="0xb0c4de"][font size="20"]
[delay speed="60"]
#marigan
为什么会这样无可救药呢。[r][wait time="500"]
像我们这样的人类啊[p]
早就知道了。[wait time="500"][p]
你这种死心塌地追随到底的地方[r]
可爱得让我着迷呢[p]
#
[playse storage="phone.ogg" volume="30" sprite_time="0000-200"]
[wait time="3000"]
[resetfont]
#
听到了通话结束的提示音。[p]
#hino
………………………………[p]
[chara_hide name="hino" wait="false"]
#
…………………………………………………………[p]
#riki
…………到、到底怎么了。[l][r]
对话走向太莫名其妙了根本听不懂在说什么啊[r]
这算什么冷笑话？[p]
#
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[chara_show name="aki" face="ghost_s" wait="true" time="3000" top="-100"]
#aki
日野[p]
[font size="20"]
#hino
…………[l]怎么了，器乐堂[p]
[resetfont]
#aki
给[wait time="500"]　这个[p]
#hino
诶？[p]
#
阿奇从自己内心的空洞中[r]
取出某物……[wait time="500"]递了过来。[p]
[playse storage=page.ogg volume="50"]
[wse]
[stopbgm]
是封信。[p]
[delay speed="70"]
#aki
玛丽甘小姐让我保管好的[r][wait time="500"]
在你刚才说出那句话之前[p]
#
…………………………………………………………[p]
#hino
刚才的……………………[r]
那句话――？[p]
#aki
「想知道真相」这句话[p]
[mask time="5000"]
#aki:hate_s
[wait time="2000"]
[bg storage="indoor/aki_room.jpeg" time="10"]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
[wait time="5000"]
#
[mask_off time="300"]
――三天前。24日，晚上7点。[p]
[delay speed="50"]
[font size="20"]
#
「有客人――？」[p]
[delay speed="60"]
[font size="40"]
#aki:tweetLA_s
没事的，爸爸。[r]
放心吧 就在那儿待着别动[p]
[resetfont]
#aki:normal_s
……真没常识呢 这个时间突然闯进来。[r]
到底 在想些什么？[p]
[resetdelay]
[chara_move name="aki" left="-70" width="-=50" anim="true" wait="false" top="+=10"]
[chara_show name="marigan" top="-60" face="normal" wait="false" left="360"]
#marigan
不让我向令尊问个好吗？[p]
#aki
如果您有被陌生人说教的癖好 我倒是可以叫他来。[r]
家父 最讨厌的就是纪伊玛莉甘这种女人了[p]
#marigan:angry
哦。那好吧。[p]
#marigan:smileB
今天呢。[wait time="500"][r]
有件东西想请你保管，所以来拜托你[p]
[delay speed="60"]
#aki
诶　是什么东西啊[p]
[resetdelay]
#marigan:normal
这个世界的秘密[p]
#aki:wow_s
这么　重要的东西　我可保管不了[p]
#marigan:tweetLA
不。如果是你的话一定可以。[l][r][font color="0xf08080"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
拥有[resetfont]无尽藏身之处的你的话[p]
#aki:worry_s
……唔[p]
[delay speed="100"]
#aki:ghost_s
大家　都挺能说的嘛[wait time="500"][r]
像我这种人的　秘密的话[p]
[delay speed="60"]
#marigan:smileB
哼哼。生气了？还是无语了？[p]
[delay speed="50"]
#aki
我可是很理解的[wait time="500"]　关于日野你为何[r]
会觉得　和我不是同类人[p]
#marigan:worry
……我可没说过是从日野那里听来的哦[p]
#aki
不　我能明白[p]
[anim name="aki" top="-=60" time="150"]
[anim name="aki" top="+=70" time="150"]
[anim name="aki" top="-=10" time="150"]
#aki:tweetLA_s
是他　告诉你的吧　关于我们的祝福[r][wait time="500"]
『必须告诉你这份美妙的神秘！』　这样　的眼神[p]
#aki:worry_s
像日野和你这样的人　很罕见[r]
特别是在这　八种町[p]
#marigan:normal
……诶，你是这样看待我们的？[wait time="500"]　为什么呢[p]
[delay speed="60"]
#aki:normal_s
理由………[r][wait time="500"]
唔………[p]
…………………………[p]
#aki:tweet_s
――狮心教的定期集会　簇之日　称呼的由来[r][font color="0xf08080"]
蚕的结茧工具[wait time="500"]　簇[l][r][resetfont]
如果是你的话　一定见过吧[p]
#marigan:tweet
嗯。[wait time="500"]这一带最常用的是，[r]
硬纸板做的旋转簇吧……[p]
[mask]
#aki
[chara_hide_all time="10"]
[bg storage="still/mabusi.jpg" time="10"]
[mask_off time="3000"]
;○マブシ
养蚕的家蚕会在簇中　结茧[r]
等待自己羽化成蛾的那天……[p]
[delay speed="50"]
#aki
而我们眷属[r][wait time="500"]
在那个　被分隔开的　空间之中[r][wait time="500"]
保持不破坏　保护着自己的　那层躯壳[wait time="500"]　迎来下次集会[p]

不必经历羽化[wait time="500"]　不必走向消亡[r][wait time="500"]
永远被守护着[wait time="500"]　维持蛹的形态就好[p]
所以狮心教的定期集会[r]
在蔟之日来临后　就完成一个轮回[p]
#marigan
不是很美妙吗[l][r]
这就是你们用御白姬的手足立下的誓言呢[p]
[bg storage="still/mabusi_2.jpeg" wait="false" cross="false" time="4000"]
;○アパート
[resetdelay]
#aki
但　日野是不同的[r][wait time="500"]
他打破了那层保护壳　试图站在这座城市里[p]
#aki
不是被八种　被狮心教所笼罩[wait time="500"][r]
而是凭自己的意志　选择了这座城市和狮心教[p]
[mask]
[bg storage="indoor/aki_room.jpeg" time="10"]
[chara_show name="aki" top="-100" time="10" face="normal_s"]
[chara_move name="aki" left="-70" width="-=50" anim="true" wait="false" top="+=10" time="10"]
[chara_show name="marigan" top="-60" face="normal" wait="false" left="360" time="10"]
#marigan
[mask_off time="300"]
……在八种，这种人很罕见吧？[p]
[resetdelay]
#aki:tweetLA_s
所以作为眷属　他反倒算是个异类[r]
和我还有力他们不同　虔诚度完全不够呢[p]
#marigan:smile
呵呵……[wait time="500"]　那，这次配送你也不愿接手吗？[p]
[delay speed="60"]
#aki:normal_s
不[p]
#aki:smileB_s
我欠他人情　这次就由我来吧[p]
[mask time="3000"]
[fadeoutbgm time="2000"]
[wait time="2000"]
[chara_hide_all time="10"]
[bg storage="yotuyamabridge_m.jpg" time="10"]
[chara_show name="aki" top="-100" face="ghost_s" time="10"]
[mask_off time="100"]
[playbgm storage=bigriver.ogg loop=true volume="10"]
#aki
――所以才替你保管至今[r][wait time="500"]
为了偿还欠你的债[p]
[delay speed="100"]
#hino
…………………………………………[p]
#
[chara_hide name="aki" time="1000"]
[delay speed="60"]
[playse storage=page.ogg volume="50"]
[wse]
日野接过了信件。[p]
随后，[l]静静地展开阅读。[p]
[delay speed="50"]
[chara_show name="riki" wait="false" face="sad_s" top="-100"]
#riki
……怎、怎么样？　上面写了什么？[p]
#hino
……嗯[p]
[fadeoutbgm time="5000"]
#hino
嗯…………[p]
[chara_hide name="riki" time="10"]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=page.ogg volume="50"]
[wse]
[wait time="2000"]
[bg storage="still/hino_back.png" time="3000" wait="false" cross="false"]
[playse storage="takibi.ogg" volume="50" loop="true"]
[wait time="6000"]

@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#hino
――谢谢你　器乐堂[p]
#aki
诶……[p]
[delay speed="50"]
#hino
多亏了你　我的暑假作业好像完成了[p]
#aki
……完成了？[p]
#hino
嗯[p]
[stopse]
#hino
关于八种的事，已经全部理清了[p]
[mask time="100"]
[wait time="3000"]
[font color="0xb0c4de"]
#
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[bg storage="brack.png" time="10"]
[mask_off time="100"]
致日野君[p]
[playse storage=page.ogg volume="50"]
@layopt layer=message0 visible=false
[clearfix]
;土地は　生きている
[bg storage="still/tegami1.png" time="10"]
[wait time="3000"]
@layopt layer=message0 visible=true
[delay speed="50"]
――更准确地说，[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/tegami2.png" time="10"]
[wait time="5000"]
;土地は　生き物である／
@layopt layer=message0 visible=true
――――更准确地说[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="still/tegami3.png" time="10"]
[wait time="8000"]
;土地は　『意識を持った生き物』である／
@layopt layer=message0 visible=true
……自古以来[l][r]
[r][r][r]
这个国家就流传着「神明孕育大地」[r]
的历史记载，[r]
你可以将其视为符合这一说法的佐证[p]
[playse storage=page.ogg volume="50"]
[r][r]
土地确实拥有自主意识，[r]
有时如同证明这点般　如胎动般震颤着。[l][r]
我国境内这种现象尤为显著[l][r]
[r][r]
因此[wait time="500"]　虽说世界各地"他们"的意识明晰程度存在巨大差异……[r][wait time="500"]
但我国境内的存在　大多具有格外强烈的自我意识[l][r]
[r][r][r]
我们所立足之处　是具有明确自我意识、[r]
在人类范畴中[r]
永远无法企及的　拥有超常能力的生物之上――[p]
[bg storage="brack.png" time="3000" wait="false" cross="false"]
[playse storage=page.ogg volume="50"]
[wse]
[wait time="500"]
[r][r][r][r]
我将此称为　【超自然】　。[p]
――在人类的活动之中[r][wait time="500"]
运用超自然力的文化实践　遍及各个领域……[l][r]
[r]
就算是历史教科书记载的事件[wait time="500"]　很多也与此相关哦。[r]
革命、起义、宗教、瘟疫、灭亡、军事利用……[l][r]
[r][r]
正因为人们对于各地滋生的[r]
超常存在有着朦胧的认知，[r]
才将栖息之地的力量　与它们共处的方法作为传说代代相授[r]
传承至今[p]
[playse storage=page.ogg volume="50"]
当时的国家政权[r]
开始系统收集这些传说[r]
通过实地考察明确了这一事实[r]
向『最初的探究者”提出――[l][r]
[r]
关于具有意识的土地存在[r]
[r][r]
[wait time="500"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
【国家機密】恳请将其作为国家机密予以封存。[l][r]
[r][r]
――他接受了这个请求。[r][wait time="500"]
为了维持世界平衡，避免『再次爆发大战”。[p]
[resetdelay]
所以[r]
这份保密义务　也同样强加给我们这些后继者[r][wait time="500"]
日野[l]
[r][r]
这封信里记载的是[r]
我国研究者们无数次抵达真相[r][wait time="500"]
并持续隐瞒至今的事实[l]
[r][r]
你也已经[wait time="500"]　无法回到知晓前的状态了[r]
今后就以'抵达者'的身份　永远保持沉默活下去吧[l][r]　
就像你的祖父烂照完成了他的使命那样[p]
[r][r]
[delay speed="60"]
……能赠予被禁言之人的……[l][r]
[r]
只有我们花费数十年才查明的　这个事实[r]
以及顺便　八种这片土地的起源罢了。[l][r]
[r][r]
[playse storage=page.ogg volume="50"]
实现人类祈愿的超自然存在”[r]
[r][r]
八种町这个生命体[l][r]
[r][r][r][r]
[wait time="1000"]
「被命名为「御白姬」[wait time="500"]　曾与人类相交过呢[p]
[resetfont]
[resetdelay]
[playse storage=page.ogg volume="50"]
[wse]
[mask time="3000"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[bg storage="siro1.png" time="10"]
[chara_show name="sarasa" face="sad_gs" top="-160" time="10" left="420"]
[chara_move name="sarasa" width="-=100"]
[chara_show name="mokke" face="normal" top="-160" time="10" left="-80"]
[chara_move name="mokke" width="-=100"]
[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
;0000-58100
#mokke
[mask_off]
;○白空
所谓祈愿，就是有意识的生命……　灵魂最脆弱的部分吧[p]
#mokke:smileMini
情感越是积累　就越发无法抑制祈愿。[l][r]
所以人类终将成为我的眷属[r]
将名为回望的自我　在我面前展露无遗吧[p]
[delay speed="60"]
#sarasa:worry_gs
[playse  volume="20" buf="0" storage="sariin.ogg" ]
名为回望的……自我……？[p]
[delay speed="50"]
#mokke:closeEye
没错。回忆即是自我　自我即是记忆[p]
#sarasa:lookAway_gs
就这样　利用人心的弱点……[r][wait time="500"]
借此来操控命令吗[p]
[font size="40"]
[resetdelay]
#mokke:smileMini
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="mokke" top="+=60" time="200"]
[anim name="mokke" top="-=60" time="200"]
噢！[r]
越是生命力衰弱就越合我意！！[p]
[resetfont]
#mokke:smile
那些拼命想保全自己性命的家伙最是无趣。[r]
必须得是沉沦在晦暗摇曳中的、未成熟的灵魂才行！[p]
[delay speed="100"]
#sarasa:sad_gs
………………。[l][r]
#sarasa:closeEye_gs
;-------------------------------------------------------------------------------
[chara_face name="mokke" face="lookAway" storage="chara/mokke/osira/lookAway.png"]
;-------------------------------------------------------------------------------
您…还真是健谈呢[p]
[delay speed="60"]
#mokke:lookAway
理所当然。你可知道我这次解封时隔了多少年？[p]
#mokke:normal
吾乃御白姬。[r]
正是要尔等[wait time="500"]知晓[font color="0xf08080"]渴求的世界[resetfont]之人[p]
#mokke:hate
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
可恨……那个满身腥臭的秃驴，区区驽马血统的贱种[r]
竟敢持续对我做出勒紧缰绳的僭越之举[p]
[resetdelay]
#mokke:smile
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
不过　嘴角无须衔布的感觉是何等畅快啊！[r]
还能给眷属们下达敕令，实在令人欣喜！[l][r]
要不要听我唱首歌？我的歌艺可是相当精湛哦[p]
[delay speed="60"]
#sarasa
（………嘴角的，布条？）[p]
#sarasa:wow_gs
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[font size="20"]
（――原来如此，[font color="0xf08080"]那件道具[resetfont][font size="20"]
的正确使用方法是……！！）[p]
#
[stop_kanim name=sarasa]
[resetfont]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop2
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
[font size="25"]
[r]
【选择正确的选项】[r]
从持有的道具中选择能让御白姬沉默的道具[r]
[glink color="btn_12_black" target="*but2" text="班级备忘录" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good2" text="絹布" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*but2" text="旧报纸" width="20" x="580" y="60"]
[glink color="btn_12_black" target="*but2" text="关于诅咒的备忘录" width="20" x="530" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop2"
;-------------------------------------------------------------------------------
*good2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]

[image layer=0 folder="image" name="kenpu" storage="item/kenpu.png" width="460" x="270" y="107" time="2000" ]
我将手中的绢布，[chara_hide_all wait="true" time="500"]
塞进了自己嘴里。[p]
[resetdelay]
[font size="40"]
[free layer=0 name="kenpu" time="800"]
#mokke
[quake time="30"]
[playse  volume="20" buf="0" storage="shimeage.ogg" ]
呜啊！？！？ 呜呃呜呜！！ 呜哈哈哈！[p]
[resetfont]
#sarasa
（原来是这样用的……！）[p]
[font size="40"]
[chara_show name="mokke" face="shout" top="-160" time="300" left="-80" wait="false"]
#mokke
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
混账东西你他妈找死！！！！[chara_move name="mokke" width="-=100" anim="true" wait="false"]
[p]
[chara_show name="sarasa" face="normal_gs" top="-160" time="300" left="420" wait="false"]
[resetfont]
[delay speed="60"]
#sarasa:closeEye_gs
力量、似乎不相上下呢。[chara_move name="sarasa" width="-=100" anim="true" wait="false"]
我们……[p]
[resetdelay]
[font size="40"]
#mokke
看起来势均力敌呢，才怪！！[l][r]
[resetfont]
#mokke:hate
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
[anim name="mokke" left="-=10" time=50 ]
[anim name="mokke" left="+=10" time=50 ]
你这混蛋在想什么！？[r]
吾乃此地的守护神御白姬！！！[p]
[delay speed="50"]
#sarasa:sad_gs
因为……我想确认一件事。[r]
想确认我和你，究竟有多么相似[p]
[delay speed="60"]
#sarasa:lookAway_gs
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
守护神大人……[r][wait time="500"]
为什么和我的体型一模一样……？[p]

#mokke:lookAway
……[p]
[resetdelay]
#mokke:normal
你很喜欢让人重复说同样的话呢。[l][r][delay speed="60"]
因为接下来我将成为你，[wait time="500"]
别再让我说第二遍[p]

#sarasa:closeEye_gs
……听多少遍都不明白……[p]
[resetdelay]
#mokke:smileMini
作为同一具肉体中的两个自我[r]
此刻正显现给你看呢[p]
[delay speed="60"]
虽然能让四肢忠实地行动，[r]
我无法完全夺取眷属的肉体本身。[l][r]
毕竟，[font color="0xf08080"]是另一个物种[resetfont]啊……[p]
#mokke:closeEye
[resetdelay]
但你不同。[wait time="500"]继承了我血脉的真正子嗣[p]
[resetdelay]
[font color="0xf08080"]
#mokke:smile
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
拥有与我相同的'见证回忆'之瞳，知晓我所聆听的祈愿。[r]
能让我保持原貌进入的容器 就是你啊！！[p][resetfont]

#sarasa:worry_gs
………………………………………………[p]
[delay speed="60"]
#
那副欢欣雀跃 朝气蓬勃的模样，[r]
甚至对尚未完全理解现状的我来说[r]
散发着难以名状的不适感。[p]

……方才塞进她嘴里的那块[r]
我死死盯着手中绢布。[p]
#sarasa:lookAway_gs
………………………………………………[p]
#sarasa:sad_gs
……虽然震惊，[l]但母亲大人并非关键[r]
你不得不被封印的理由……[r]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
#sarasa:closeEye_gs
我似乎渐渐明白了[p]
[resetfont]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop3
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
“御黑祟”的诅咒究竟是什么？[r]

[glink color="btn_12_black" target="*good3" text="诅咒人心的脆弱之处" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but3" text="随心所欲地诅咒眷属" width="20" x="630" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop3"
;-------------------------------------------------------------------------------
*good3
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]

#sarasa
我们至今归咎于御黑祟的那些诅咒[r]
全部
[font color="0xf08080"]如果这是出自御白姬之手的话……[p]
#sarasa:normal_gs
正如您所言『祈祷是心灵的弱点』因此[r]
向御白姬[font color="0xf08080"]献上弱点[resetfont]
并[wait time="500"] 获得了赐予祝福的[font color="0xf08080"]约定[resetfont][r]
[font color="0xf08080"]这样一来，就能解释为何只有“眷属”接连遭受诅咒的状况。[p][resetfont]
[delay speed="50"]
#sarasa:closeEye_gs
也就是说……从一开始[r]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
这座城镇[font color="0xf08080"]
所谓的『御黑祟』根本[resetfont]就不存在呢[p]
[resetdelay]
#mokke:normal
哼，连听都没听说过呢[p]

#mokke:smile
你们这群把童话当真还横冲直撞的样子……[r][wait time="500"]
简直滑稽可笑？！[p]

#sarasa:worry_gs
………可笑？[p]
#sarasa:sad_gs
这有什么好笑的……[r]
在这次事件里，镇上有那么多人被蛊惑，[r]
甚至真的闹出了人命啊[p]
[font size="40"]
#mokke:smileMini
[quake time="30"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
死了人啊！[p]
[resetfont]
#mokke:lookAway
[stopbgm]
啊，是说那三个色情狂的宫女吧。[r][wait time="500"]
最讨厌这些色情狂了。光是看着都觉得污秽[p]
#mokke:normal
不过感觉如何，第一次目睹他人死亡。[r]
应该震撼得难以承受吧[p]
[delay speed="70"]
#sarasa:worry_gs
…………………………[l][r]
#sarasa:wow_gs
…………………………………………[r]
…………………………………………[p]
#mokke:smileMini
…………………………[l][r]
#mokke:closeEye
[resetdelay]
啊哈哈！明明不用假装生气也可以的……[p]
#mokke:lookAway
你根本不可能为连正常对话都没有过的对象之死感到悲伤。[r]
你就是这样的女人，纱罗纱。[p]
[delay speed="60"]
#sarasa
………………不[l][r]
[resetdelay]
不，我明明是在悲伤的啊[r]
如果是女神大人的话，您应该也看见了吧[p]
#mokke:smileMini
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[font size="38"]
看见了、都知道的！！全部所有！！[r]
正因如此我才这么说！！[p]
[resetfont]
毕竟雾绘死时的模样简直像道成寺传说那般华丽啊。[r]
镇上的人们这个月可完全不缺谈资，[p]
[delay speed="60"]
#mokke:smile
呵呵，不过……[r]
那个女人，现在不知正卡在哪处黄泉路上呢。[p]
#sarasa:worry_gs
…………………………………………[l][r]
#sarasa:sadB_gs
……………………………（太差劲了）[p]
[mask time="10"]
[filter grayscale="100"]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all wait="true"]
[wait time="1000"]
#
[bg storage="still/kami_1.png" time="10" wait="true"]
[mask_off time="10"]
[playse storage=page.ogg volume="50" buf="1"]
[bg storage="still/kami_2.png" time="10" wait="true"]
[playse storage=page.ogg volume="50" buf="2"]
[bg storage="still/kami_3.png" time="10" wait="true"]
[playse storage=page.ogg volume="50" buf="3"]
[bg storage="still/kami_4.png" time="10" wait="true"]
[playse storage=page.ogg volume="50" buf="4"]
[bg storage="still/kami_5.png" time="10" wait="true"]
[playse storage=page.ogg volume="50" buf="5"]
[bg storage="still/kami_end.png" time="10" wait="true"]
[playse storage=page.ogg volume="50" buf="0"]
[wse]
[wait time="2000"]
[mask time="10"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[bg storage="siro2.png" time="100" wait="false"]
[wait time="1000"]
[free_filter]
[chara_show name="mokke" top="-160" time="300" left="-80" wait="true"]
[chara_move name="mokke" width="-=100" anim="true" wait="true"]
[chara_show name="sarasa" top="-160" time="300" left="420" wait="true"]
[chara_move name="sarasa" width="-=100" anim="true" wait="true"]
[mask_off time="1000"]
[wait time="2000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
获得肉身的御白姬，终将与宗方树相见。[p]
作为至高女神崇拜着她的[wait time="500"]　狮心教三位神官少女。[p]
#sarasa
（……一树她）[p]

#sarasa
（一树她，肯定不会相信这种女神）[p]
#
[chara_hide_all wait="false" time="2000"]
[bg storage="brack.png" time="2000" wait="true" cross="false"]
若让心怀期待之人失望　那便不再是神像。[p]
#sarasa
……………………………………………………[font color="0xf08080"]（不行）[wait time="200"][p]
#
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[wait time="4000"]
必须封印才行。[p]
[resetfont]
[mask time="100"]
@layopt layer=message0 visible=false
[clearfix]
;ＳEカーン
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[wait time="2000"]
[bg storage="still/huin1.png" time="10"]
[mask_off time="100"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[wse]
[wait time="5000"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font size="22"]
[delay speed="60"]
某处昏暗的场所。[l][r]
而扭曲雕刻的木像，正独自细微地颤动。[l][r]
[resetfont]
咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒[l][r]
[r]
[font size="22"]
[delay speed="60"]
那木像上缠着块陈旧不堪的破布，[r]
如同绑匪用的蒙眼布般紧紧裹住。[p]
[resetfont]
[resetdelay]
咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒[r]
[r][r]
咔嗒咔嗒咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒咔嗒咔嗒[r]
[r]
咔嗒咔嗒咔嗒咔嗒咔嗒咔嗒[r]
咔嗒咔嗒咔嗒咔嗒咔嗒咔嗒[r][er]
@layopt layer=message0 visible=false
[wait time="3000"]
[quake time="30"]
[wait time="3000"]
[quake time="30"]
[wait time="3000"]
[bg storage="still/huin2.png" time="10"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
咔。[p]
[delay speed="120"]
#オシラヒメ
[font color="0xf08080"]
今早没人会来！[p]
仅剩听觉的我　获得了视觉。[p]
不过是两年前　冬天的事。[p]
[resetfont]
#
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask time="100"]
[wait time="5000"]
[bg storage="siro2.png" time="100" wait="false"]
;ＳEカーン
[mask_off time="3000"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[delay speed="100"]
#mokke
……………………………………………………。[l][r]
你这家伙　原来如此[wait time="500"]　是"同类"啊[p]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
#
[quake time="30"]
[font size="40"]
————！！！[resetfont]　刚才的……[er]
#mokke
既然你有这打算　就尽情注视吧[p]
#
果然　刚才我[wait time="500"]　看见的是……[er]
#mokke
随你便吧　没有自我的女孩[r]
反正从这里开始你也无处可去了[p]
[font size="40"]
[resetdelay]
[chara_show name="mokke" time="100" wait="true" face="smile" top="-160"]
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[bg storage="siro3.png" time="100" wait="false"]
[quake time="100"][font color="0xf08080"]
就当是黄泉路上的饯别礼[playbgm storage=lost-happy.ogg loop=true volume="50"][r]
带着这片土地的记忆上路吧！！！！[p]
[resetfont]
#
御白姬用充满轻蔑的语气如此唾弃道。[p]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop4
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]

[r]
【选择正确的选项】[r]
两年前的冬天发生在纱罗纱身上的、与眼睛有关的事件是？[r]

[glink color="btn_12_black" target="*but4" text="变得能够看到他人的过去了" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good4" text="无法再正确识别眷属以外的人" width="20" x="630" y="60" ]
[resetfont]
[s]
;-------------------------------------------------------------------------------
*but4
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop4"
;-------------------------------------------------------------------------------
*good4
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]


[chara_hide name="mokke" time="10"]
[chara_show name="sarasa" top="-160" wait="false" face="angry_gs" time="100"]
#sarasa
你通过绢布施加的封印　[font color="0xf08080"]封住了嘴[resetfont]与
[font color="0xf08080"]眼睛[r][resetfont]
所以只能用[font color="0xf08080"]耳朵[resetfont]聆听狮心教信徒们的祷告[r][resetfont]
赐予祝福[p]

#sarasa:worry_gs
然后立下契约　将灵魂……[wait time="500"][font color="0xf08080"]只保留奉献自我者的形貌[resetfont][r]
你的眼睛能够认知到吧[p]
#sarasa:sadB_gs
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
所以我也和你一样[r][font color="0xf08080"]
只能正确看见眷属之人的姿态[r][resetfont]
正因为和你一样　[font color="0xf08080"]拥有窥视人类记忆的双眼[resetfont]　的我……！[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="mokke" top="-160" time="100" wait="true" face="smile"]
#mokke
[playse  volume="20" buf="0" storage="kakan.ogg"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
[anim name="mokke" top="+=30" time="150"]
[anim name="mokke" top="-=30" time="150"]
没错！　非眷属的灵魂只能模糊感知[r]
而且我对连手脚都不完整的人类毫无兴趣！！[p]
哎呀，怎么……？[r]
纱罗纱，莫非你有什么不满吗？[p]
[playse  volume="100" buf="1" storage="punch.ogg" sprite_time="0500-30000"]
#mokke:lookAway
[delay speed="60"]
这可是超越人类认知、能够浏览记忆的眼睛啊。[r]
稍微无法正确认知世界，就忍受不了了吗？[r]
呵呵……[p]
#sarasa
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[chara_hide name="mokke" wait="false"]
（然后，在这个御白姬之眼觉醒的清晨，[r]
未曾出现在她面前的人物是――）[p]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop5
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
[font size="25"]
【选择正确的选项】[r]
御白姬获得双眼的冬日清晨，本该来到祠堂的是谁？[r]

[glink color="btn_12_black" target="*but5" text="馬門賢治郎" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*good5" text="馬門享四郎" width="20" x="630" y="60" ]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but5
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop5"
;-------------------------------------------------------------------------------
*good5
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]

#
两年前的冬天——突然倒下的享四郎先生。[l][r]
只有他知晓用绢布施行封印的方法……[p]
所以[font color="0xf08080"]他倒下之后[resetfont]，[r]
我的眼睛与御白姬相连 彻底改变了——[p]
他曾经施行的封印，[r]
[font color="0xf08080"]那是为了将我和御白姬分开的东西――――！！[p][resetfont]
[resetdelay]
#mokke
[playse  volume="20" buf="0" storage="sariin.ogg" ]
那老东西因继承断代而死 对我而言也是幸运[p]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
！！[p]
#mokke
多亏如此 我成为了[font color="0xf08080"]首[resetfont]位马门家的眷属与[r]
[font color="0xf08080"]随着绢布的烧毁[resetfont]我获得了行动的自由[p]
[quake time="100"]
数百年后[r]
时运 气数 形势 都将迎来轮转的宿命吧！[p]
[fadeoutbgm time="5000"]
[delay speed="50"]
#sarasa
……绢布烧毁了？[p]
#mokke
即便被封印着，[r]
只要看到自己能依附的肉体”就能明白[p]

像志户田纱罗纱这样的……[l][r][playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]与我血脉相连之人[resetfont]的肉体[p]
利用这点[wait time="500"]　我烧毁了自身的凭依之躯[r]
为了离开那间满是尘埃的马厩　来到城镇之中[p]
[delay speed="70"]
#sarasa
……那么[r][wait time="500"]
烧毁绢布解除封印的　终究是你自己…………[p]
#sarasa
…………………………[l][r]
（？[wait time="500"]　不对、更重要的是……）[p]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
…………………………她从刚才就一直、[r]
坚称我与她之间存在"[font color="0xf08080"]血缘关系[resetfont]"[r]
[p]

若真如她所言　我与她之间存在[font color="0xf08080"]血缘关系[resetfont][r][wait time="500"]
那么她能占据的躯体　就仅限于这类存在了[p]
这座城镇里……[wait time="500"]还存在另一具她能寄宿的[r]
躯体才对。[p]
[fadeinse  volume="05" buf="1" storage="walk_rouka.ogg" loop="true" time="3000"]
[font size="20"]
[chara_show name="sarasa" top="-160" face="sadB_gs" left="360" time="100"]
#sarasa
――难道说　你竟………[l][r]
[delay speed="120"]
用我母亲的躯体来解除封印……[p]
[chara_show name="mokke" top="-160" left="-120" face="smileMini" time="100"]
#mokke
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[resetdelay]
[quake time="30"]
[resetfont]
啊哈哈哈哈哈哈哈！！[p]
#mokke:normal
在意的话[wait time="500"]　像刚才那样窥视不就好了[r][wait time="500"]
随你便好了[wait time="500"]　我不会逃的[p]
#
[chara_mod name="mokke" face="smile"]
[chara_move name="mokke" top="+1000" time="5000" wait="true" anim="true"]
[chara_hide name="mokke" time="10" pos_mode="false"]
[delay speed="60"]
……………………………………[p]
她如同催促着「快点看啊」一般，[r]
哗啦一声展开衣摆　傲慢地仰躺在地。[p]
正对着我的方向[r]
那张扭曲笑脸里　透着令人不安的气息。[p]
#
一股恶寒[r]
顺着贤治郎先生划过的那道伤口　笔直窜了上来。[p]
#sarasa:worry_gs
……………………………………[p]
#sarasa:worryLA_gs
……………………………………[p]
#sarasa:closeEye_gs
[delay speed="100"]
……………………[p]
[delay speed="60"]
#sarasa:angry_gs
……………………………………[p]
#
[stopse buf="1"]
[mask time="100"]
[chara_hide name="sarasa" time="10"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[wse]
[playse storage="takibi.ogg" volume="50" loop="true"]
[wait time="3000"]
;ＳEカーン
[clearfix]
[bg storage="still/kaiko_2.png" time="10"]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[mask_off time="2000"]
[font color="0xf08080"]
燃烧着。[l][r]
[r][r]
只属于我的秘密。[l][r]
[r][r][r]
只属于我的祈愿。[p]
属于我的事物　早已无处可寻。[p][resetfont]
@layopt layer=message0 visible=false
[wait time="2000"]
[bg storage="siro3.png" time="10"]
[stopse]
[mask_off time="3000"]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[filter blur="6"]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
啊[p]
#sarasa
……………………[p]
[playse  volume="50" buf="0" storage="book.ogg" ]
#
忽然回过神来，发现自己已经瘫坐在地。[p]
纯白空间的地面，冰冷得超乎想象。[p]
#sarasa
…………[l]为、……………………[p]
[delay speed="50"]
为什么…………[l]雾绘小姐要把那段过去，[r][wait time="500"]
当作仅属于自己的东西来守护……[r]
明明[wait time="500"]　为此离开了小镇啊[p]
[delay speed="60"]
#sarasa
这件事[l]　要让雾绘亲手烧掉吗…………？[p]
#
[chara_show name="mokke" top="-160" wait="true" face="normal"]
[chara_move name="mokke" anim="true" width="+=300" wait="true" time="2000" left="-=140" top="-=100"]
#mokke
你会看电视节目吧。[p]
节目播完之后怎么办？[l][r]
你以为就再也看不到那些内容了吗？[p]
[font size="20"]
#sarasa
电……电视……？[p]
[resetfont]
#mokke
我一直都是观众啊。[r]
早就厌倦在舞台上扮演角色了。[p]

电视播出的内容能有什么秘密？[r]
这都是一回事。[p]
对我而言根本不存在什么秘密。[r]
「只属于我的秘密」「只属于我的祈祷」[r]
雾绘那些令人无语的说辞已经……[p]
[resetdelay]
那家伙自说自话的狗血剧码，[r]
倒也让我看得挺乐呵的。包括结局在内。[p]
[delay speed="50"]
#sarasa
我们所见之人的过往[r]
绝非为了娱乐而编织的故事[l][r]
这一切都是大家珍视的回忆。[p]
#sarasa
你也应该……[wait time="500"]用和我相同的目光，[r]
凝视过她和贤治郎先生的过往…………[p]

对她而言[r][wait time="500"]
能获得那个秘密是多么重要的回忆[r]
你应该明白吧……[p]
#mokke
…………………………[p]
[font size="20"]
[delay speed="120"]
#sarasa
可为什么，为什么…………[p]
[resetfont]
[quake time="30"]
[resetdelay]
为什么要对雾绘小姐――！！[p]
#mokke:shout
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
烦死了，因为她用起来正合适啊！！[p]
#mokke:hate
[font color="0xf08080"]
把没有自我意识的东西塞进体内 还出现在我面前，[r]
谁让她曾是我的女儿！！[p]
#mokke:lookAway
毕竟这是我开眼以来 第一个死去的血亲，[r]
就算污秽不堪我也忍了[p]
[delay speed="120"]
#
………………………………………………………………[r]
………………………………………………………………[r]
血亲。[p]
@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop6
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]
#
[r]
【选择正确的选项】[r]
御白姬所说的血亲”指的是谁？[r]

[glink color="btn_12_black" target="*but6" text="志戸田家" width="20" x="680" y="60" ]
[glink color="btn_12_black" target="*but6" text="宗方家" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good6" text="志戸田家与宗方家" width="20" x="580" y="60"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but6
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop6"
;-------------------------------------------------------------------------------
*good6
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]

[mask time="2000"]
[chara_hide name="mokke" time="10"]

;セーブしますか？
[showsave]
[free_filter]
@jump storage="chapter_5/day1_vol6.ks"

;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
