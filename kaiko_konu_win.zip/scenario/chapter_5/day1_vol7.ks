[eval exp="f.save_title = '五章パート６'"]
;-------------------------------------------------------------------------------
[chara_face name="ituki" face="ghost" storage="chara/ituki/ghost.png"]
;-------------------------------------------------------------------------------
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[mask]
#
[bg storage="still/den_28.png" time="10"]
[mask_off]
[resetdelay]
――正如生命无法永恒延续，[r]
万物终有迎来终结之日。[p]
[delay speed="50"]
即便是这座小镇的现人神[r][wait time="500"]
御白姬的存在亦不例外。[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[bg storage="still/den_25.png" time="500"]
某日 御白姬突然[r]
企图占据亲生女儿的躯壳[r][wait time="500"]
[delay speed="60"]
操纵信徒犯下暴行[p]
[resetdelay]
[bg storage="still/den_26.png" time="500"]
女儿不堪忍受 逃进了附近的神社[l][r]
[r]
「救命！我不想死！」[p]
「你这非人的怪物！！[r] 果然无法与人类共存！！」[p]
[playse  volume="70" buf="0" storage="punch.ogg" ]
[bg storage="still/den_27.png" time="10"]
剃发的神官立刻将御白姬封印[r][wait time="500"]
狮心教对女神的本质产生了怀疑[p]
[delay speed="50"][font color="0xf08080"]
「沦为「怪物家族」[resetfont][l]的三名女子开始遭受迫害[l][r]
目睹这一切的神官心生怜悯[p]
[delay speed="70"]
[bg storage="still/den_29.png" time="2000" wait="false"]
――于是[wait time="500"] 某个「故事」便诞生了[p]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[delay speed="50"]
为了掩盖不光彩的往事 让她能重新作为女神被供奉……[r][wait time="500"]
便是这样一个故事。[l][r]
[r][delay speed="80"]
「为了将这个传说告知世人[r]　本神社今后将持续举办祭典」[l][r]
[r][r][r][r]
「但是[wait time="500"]　志户田家的千金。」[p]
「若追溯您与狮心教的渊源[r]　[wait time="500"]
终有一日这个真相会在后世被揭露」[l][r]
[r]
「您必须[wait time="500"]　从狮心教的历史中[wait time="500"]　彻底消失」[l][r]
[r][r][r][r]
……明治初年[wait time="500"]　的事。[l][r]
[r][r]
神官的名字是[wait time="500"]　马门审四郎。[p]
[mask]
[bg storage="mountainRoad_m.jpeg" time="10"]
[filter saturate="0" layer="base"]
;○森の中
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
;ＳEカーン
[chara_show name="sarasa" face="normal_g" top="-100" time="10"]
[playse  volume="60" buf="0" storage="sariin.ogg" ]
[wse]
[mask_off]
！！[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide name="sarasa" wait="true" time="3000"]
[wait time="2000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
………………………………[p]
[resetdelay]
[chara_show name="makado" top="-10" face="tweetB_e" left="-90" wait="false"]
#ituki
[chara_show name="ituki" left="360" face="sadB_s" wait="false" top="-50" wait="false"]
啊……！？[r]
这是什么，这棵树是……！！[p]
[delay speed="60"]
#
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
——突然间，视野里的一切都褪成了白色。[p]
而且，还不止如此。[p]
直到刚才还能听见的鸟鸣蝉噪……[r]
除了我们之外的生命气息，[r]
短短数秒内便消失得无影无踪。[p]
#makado
……究竟，八种发生了什么…………[p]
[chara_hide_all time="100"]
[chara_show name="sarasa" top="-100" wait="false" face="closeEye_g"]
#sarasa
[delay speed="50"]
……这里，我认为是为自我构筑的空间[p]
#makado
哎……？[p]
#sarasa:normal_g
……就在刚才，我也被带进了那个地方。[r]
御白姬创造的、为自我存在的纯白空间里……[p]
#
……没错。[p]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
那个地方也是，[r]
那是御白姬为了达成[font color="0xf08080"]某个目的[resetfont]而准备的场所……[p]

@layopt layer=message1 visible=true
;-------------------------------------------------------------------------------
*loop
;-------------------------------------------------------------------------------
[current layer="message1"]
[position vertical=true]
[font color="0x000000" face="serif" shadow="0xffffff"]

[r]
[font size="25"]
【选择正确的选项】[r]
刚才纱罗纱被带去的「白色空间」里，御白姬的目的是？[r]

[glink color="btn_12_black" target="*but2" text="将女神之位让与纱罗纱" width="20" x="630" y="60" ]
[glink color="btn_12_black" target="*good" text="抹去纱罗纱的自我并占据其身体" width="20" x="580" y="60" ]
[glink color="btn_12_black" target="*but2" text="随心所欲地操纵眷属" width="20" x="530" y="60"]

[resetfont]
[s]
;-------------------------------------------------------------------------------
*but2
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@jump target="loop"
;-------------------------------------------------------------------------------
*good
;-------------------------------------------------------------------------------
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
@layopt layer=message1 visible=false
[current layer="message0"]
[position vertical=false]
[wse]
#sarasa:closeEye_g
这个空间是……[r]
我认为是为了决定与八种之地相称的自我而存在的场所[p]
#sarasa:tweet_g
	…………因为现在这片土地上，存在着两个自我……[l][r]
	在其中一个消失之前，都无法离开这里[p]
[delay speed="60"]
[chara_hide name="sarasa" time="100"]
[chara_show name="ituki" left="360" face="sad_s" time="300" wait="false" top="-50" wait="false"]
#makado
[chara_show name="makado" top="-10" face="worry_e" time="300" left="-90" wait="false"]
……[l]
#makado:closeEye
虽然不太明白，[r]
但这个世界是为你和另一个御白姬准备的，[r]
结果我们也误闯进来了啊[p]
#ituki:tweetLA_s
得赶快消灭那家伙，回到原来的八种町。[l][r]
我绝不会让纱罗纱消失的　绝对不行[p]
#sarasa
……嗯[p]
[chara_hide_all wait="false" time="300"]
必须抓紧了，要赶在御白姬到达之前――！[p]
@layopt layer=message0 visible=false
[clearfix]
[mask folder="bgimage" graphic="still/part5.png"]
[wait time="1000"]
[bg storage="hall_m.jpg" time="10"]
#
[mask_off time="5000"]
[wait time="3000"]
;○お堂
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
―这座祠堂，也和原来的八种町完全一模一样……[p]

然而[wait time="500"]　这一路上所见的所有风景，无一例外地，[r]
都化作了纯白。[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="kirie" top="-100" face="normal" wait="true" time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#kirie
…………[p]
[chara_hide name="kirie"]
[chara_show name="ituki" left="360" face="hate_s" time="10" wait="false" top="-50" wait="false"]
#makado
[chara_show name="makado" top="-10" face="lookAway_e" time="10" left="-90" wait="false"]
………………[p]
[resetdelay]
#ituki
少骗人了 姐姐明明已经死了啊[p]
#kirie
居然还叫我姐姐呢[p]
#ituki:hateG_s
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
――！！[p]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
#ituki:shout_s
[quake time="30"]
你这混蛋、把纱罗纱伤得那么深[r]
事到如今还装什么女神啊！！！[p]
[chara_hide_all wait="false"]
#
树月朝着那团呈现姐姐姿态的[r]
混沌发泄般冲了过去――[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[chara_show name="sarasa" top="-100" time="300" wait="false" face="angry_g"]
#sarasa
[font size="40"]
一树，
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
住手！！[p]
#
[stop_kanim name=sarasa]
[chara_hide name="sarasa" wait="false"]
;ＳE締めあげる
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
[wse]
[quake time="100"]
[chara_show name="kirie" top="-100" face="cut" left="90" wait="false" time="200"]
[chara_show name="ituki" top="-100" wait="true" time="100" left="180" face="angryB_s"]
[chara_move name="ituki" wait="false" time="100" width="-=40" anim="true"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
――！！[p]
[resetfont]
#kirie
呵呵……你真是可爱呢 一树[r][wait time="500"]
要不要把眼珠也挖出来？[p]
[delay speed="60"]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
――树月在雾绘的怀中，被利刃所指。[p]
#ituki:shout_s
你以为这种程度就能让树月乖乖听话吗？[r]
无论是表面还是内在[p]
[resetdelay]
#kirie
都会让你听进去的[p]
[font size="20"]
#ituki:angryB_s
……………………什么叫让我听进去啊[p]
[font size="40"]
#ituki
[filter invert="90" name="ituki"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
――闭嘴！！！[p]
[stop_kanim name=ituki]
;ＳEカーン
[free_filter name="ituki"]
#kirie
………………[p]
#ituki:sadB_s
……………………[p]
[font size="20"]
[delay speed="60"]
#ituki:tweetG_s
……呐[p]
[resetfont]
#
…………树月，似乎无法掩饰困惑的神情。[p]
[font size="20"]
#ituki
为什么……为什么没有倒下[p]
[font size="40"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
为什么，[wait time="500"]没有石化！？[p]
[delay speed="50"]
[resetfont]
#sarasa
……眷属无法对主人御白姬施加祝福[p]
祝福是……成为御白姬手足的[wait time="500"]　誓约的证明[r]
由她所赐予的力量[p]
[delay speed="60"]
#ituki:sadB_s
可是……刚刚纱罗纱体内有这个女人的时候，[r]
我、明明能让你忘记的……[p]
#kirie
因为那具躯体还是人类的容器啊[p]
[font color="0xf08080"]
[delay speed="80"]
可恶　明明差一点就能夺取成功了……[p]
[resetfont]
[delay speed="50"]
#
雾绘小姐用她原本的眼睛[wait time="500"]　充满怨恨地瞪视我之后，[r]
骨碌转动瞳孔……[l][r]
将视线定格在身旁的宗方树月身上，[wait time="500"]停下了动作。[p]
[font color="0xf08080"]
#kirie
这一切全都是你这混账的错[wait time="500"]　树月[r][resetfont]
要不是你非要来碍事的话――[p]
这次也是[wait time="500"]　[font color="0xf08080"]
就连那天的雨也是[r][wait time="500"]
本应该能用贤治郎杀掉纱罗纱的[p]
#
[chara_hide_all time="10"]
[chara_show name="makado" wait="true" time="600" face="worry_e" top="-10"]
#makado
[delay speed="60"]
………………………………[p]
#makado:hurryB_e
……啊　下雨那天？[p]
[mask time="100"]
[chara_hide name="makado" time="10"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
;ＳEカーン
[fadeinbgm storage=rain.ogg loop=true time=5000 volume=100 sprite_time="2000-61000"]
[bg storage="brack.png" time="10"]
[clearfix]
[wait time="3000"]
#
;ＢＧＭ雨
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[mask_off time="4000"]
Hoc volo sic jubeo sit pro ratione voluntas[r][wait time="800"]
[r]
Hoc volo sic jubeo sit pro ratione voluntas[r][wait time="800"]
[r][wait time="800"]
让志户田纱罗纱独自待着[wait time="500"]　让她一个人[wait time="500"][r]
接下来会有人处理的　不是你而是其他什么人[l][r]
[r]
我不会让你的手沾血　我还想和你重新在一起[l][r]
[r]……[l][r][r]
[fadeoutbgm time="4000"]
[wait time="4000"]
声音停止了。[p]
@layopt layer=message0 visible=false
[bg storage="fork_n.jpg" wait="true" cross="false" time="3000"]
[wait time="3000"]
;○町
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
#ituki
@layopt layer=message0 visible=true
……[p]
[quake time="30"]
[delay speed="50"]
#ituki
……！[wait time="500"]　咦、纱罗纱……[p]
[delay speed="60"]
（……为什么、我没送她回家呢。[r]
	太危险了啊……）[p]
#
……[wait time="500"]还是回去、送她到家吧[p]
[fadeinbgm storage=summer-incect.ogg loop=true time=5000 volume=20]
@layopt layer=message0 visible=false
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
@layopt layer=message0 visible=false
[bg storage="ton_n.jpg" wait="true" time="3000" cross="false"]
[wait time="3000"]
;○トンネル
@layopt layer=message0 visible=true
……………………………………………………[p]
#ituki
…………咦？[p]
@layopt layer=message0 visible=false
;スチル：襲われてるやつ
[mask]
[bg storage=still/first_contact.png time="10"]
[mask_off]
[wait time="2000"]
@layopt layer=message0 visible=true
#ituki
这…………[p]
[resetdelay]
[bg storage="ton_n.jpg" wait="false" time="100" cross="false"]
[font size="40"]
你在干什么啊！！！！快放开那孩子！！！！[p]
[resetfont]
[chara_hide name="ituki" wait="false"]
;ＳEカーン
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
[wse]
#？？
………[wait time="500"]呜[p]
#
;ＳEドサッ
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
[delay speed="50"]
巨大的白色幼虫轰然倒下。[p]

那些肉块如同退潮般收缩，[r]
逐渐化成一个男人的身形。[p]
#ituki
哈啊、哈啊、哈啊…………[p]
（……这家伙）[p]
（这家伙好像是雾绘的青梅竹马……）[p]
[delay speed="100"]
（——马门，[wait time="500"]贤治郎）[p]
#sarasa
为什么[p]
#ituki
……[wait time="500"]咦？[p]
[delay speed="60"]
#
抬起头来。[p]
[chara_show name="sarasa" face="sadB" top="-160" wait="true" time="1000"]
#sarasa
连一树也[p]
[delay speed="100"]
………………[l]会变成、怪物吗[p]
#ituki
…………[p]
@layopt layer=message0 visible=false
[chara_hide name="sarasa"]
[fadeoutbgm time="4000"]
[wait time="4000"]
@layopt layer=message0 visible=true
#
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
――我看到了你恐惧的表情。[l][r]
[r][r][r]
但这一瞬间[l][r]
[r][r][r]
明明我比你更[r]
害怕正在发生的事。[p]
[bg storage="brack.png" time="100"]
;ＳEカーン
[wait time="4000"]
我从两人之间[wait time="500"]抹去了刚刚发生的事[l][r]
[r][r]
而选择离开现场的我[l][r]
[r]
如往常一般[wait time="500"]　我窥向镜中[p]
[mask time="100"]
[playse  volume="70" buf="0" storage="sariin.ogg" ]
[wse]
[chara_face name="makado" face="true" storage="chara/makado/rady/true.png"]
#kirie
[bg storage="hall_m.jpg" time="10"]
@layopt layer=message0 visible=false
[wait time="2000"]
[mask_off time="3000"]
[wait time="2000"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

树月啊[p]
你这家伙总是挑错时机[r][wait time="500"]
要是那天就解决掉纱罗纱的话……[p]
[chara_show name="kirie" face="lookAway" top="-100" wait="false" time="2000"]
……她明明还对我露出可爱的笑容[r]
本可以和”志户田纱罗纱”一起在这小镇生活的吧？[p]
#ituki
…………我也、被诅咒了啊[p]
[delay speed="60"]
#kirie
因为你的自我总是反复无常呢[p]
每次对话都断断续续的[r]
很寂寞　很痛苦啊[p]
[chara_hide name="kirie" time="10"]
[chara_show name="ituki" wait="false" top="-50" face="sadB_s"]
[delay speed="100"]
#ituki
……因为[wait time="500"]　我不记得[wait time="500"]　这样的回忆[p]
[chara_hide name="ituki" wait="false" time="10" pos_mode="false"]
[chara_show name="makado" wait="false" top="-10" face="hurryB_e" left="100"]
#makado
……………………我也是　这种事[p]
#makado:tweetB_e
…………[l]完全想不起来[wait time="500"]　任何线索……[p]
[delay speed="50"]
#kirie
没有任何线索？[wait time="500"]　这很奇怪啊[p]
你这家伙[wait time="500"]　根本不存在……[l][r]
每次被感谢那些残缺的记忆时　都会感到违和感吧？[l][r][font color="0xf08080"]
马门贤治郎救下了被可疑分子袭击的志户田纱罗纱”[resetfont]这样[p]
[chara_hide_all time="10"]
[chara_show name="kirie" time="10" face="smile" top="-100" zindex="2"]
[resetdelay]
#kirie
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
……你们马门家的男人最擅长[r]
编造对自己有利的谎言了！！[p]
[chara_move name="kirie" left="-130" wait="false" anim="true" wait="false"]
[chara_show name="sarasa" top="-50" face="angry_g" left="10" time="10" zindex="1"]
[chara_move name="sarasa" width="-=100" anim="true" wait="false"]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
最初是我误以为被救了”而感激[r]
擅自用虚假记忆填补了缺失的过往[p]
[delay speed="60"]
#sarasa:tweet_g
为什么要这样逼他到绝境？[r]
[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
难道说……[wait time="500"]你至今还保留着下达命令的权限？[p]
#kirie:sad
…………[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_hide_all wait="true" time="2000"]
[chara_show name="makado" top="-10" face="worry_e" wait="false"]
#makado
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
……………………[p]
#makado:closeEyeB
纱罗纱　其实我……[p]
[chara_hide name="makado" time="10"]
[chara_show name="sarasa" top="-10" face="tweet_g" wait="false"]
#sarasa
贤治郎先生[r]
你对我根本不需要有任何愧疚[p]
[delay speed="50"]
#sarasa:closeEye_g
那天你来找我　让我彻底改变了[p]
#sarasa:smileMini_g
[playse  volume="20" buf="0" storage="sariin.ogg" ]
现在的我　能像这样亲口说出心声了[r]
就算不依靠一树和贤治郎先生的力量[p]
#
[chara_move name="sarasa" left="5" anim="true" wait="false"]
[chara_show name="ituki" face="smileLA_s" left="-90" wait="false" top="-50"]
#ituki
………………纱罗纱……[p]
#
[chara_hide_all time="100"]
[chara_show name="makado" top="-10" face="worry_e"]
[delay speed="100"]
#makado
…………[l][r]
#makado:sad
不对　现在的你一定是[p]
…………[r][wait time="500"]
#makado:lookAway_e
只是回归了本该有的模样[p]
[chara_face name="kirie" face="cut2" storage="chara/kirie/cut2.png"]
[chara_hide name="makado" time="10" wait="true"]
[chara_show name="kirie" top="-100" face="cut2" wait="false" time="200"]
;ＳEシャン
[font size="40"]
[resetdelay]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
#kirie
[font color="0xf08080"]
什么该有的模样　不知天高地厚的东西！！！[p]
[resetfont]
#kirie
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
[anim name="kirie" left="-=10" time=50 ]
[anim name="kirie" left="+=10" time=50 ]
快点把身体交出来[r]
否则就算在这个空间里也要把你们封印[p]
[font size="40"]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50" buf="2"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-50" face="shout_g" wait="false" time="100"]
;ＳEシャン
[font color="0xb0c4de"]
#sarasa
想封印我[r]
你以为只有你能安然无恙吗！[p]
[resetfont]
[delay speed="50"]
#sarasa:angry_g
……先前一树的祝福，[r]
对现在的你根本不起作用[p]
#sarasa:sad_g
现阶段我和你的[r]
究竟共享着多少[font color="0xb0c4de"]
御白姬[resetfont]的力量……[r]
根本无人知晓！[p]
[chara_hide name="sarasa" time="10" wait="true"]
[chara_show name="kirie" top="-100" face="cut2" wait="false" time="200"]
[font size="40"]
#kirie
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
即便如此也无所谓[r]
能拉你这可恨的家伙陪葬我死而无憾！！[p]
[chara_show name="ituki" top="-100" wait="true" time="100" left="180" face="tweetG_s"]
[chara_move name="ituki" wait="false" width="-=40" anim="true"]
#ituki:tweetG_s
不行啊纱罗纱[wait time="500"][r]
[resetfont]
我绝不会让你完成封印！！[p]
[delay speed="60"]
#kirie
啊啊……你的舌头一点都不可爱，[wait time="500"][r]
那种东西不需要！！[p]
#
[playse  volume="20" buf="0" storage="sariin.ogg" ]
御白姬高举起了利刃——！[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" face="sad_g" time="100" wait="false" top="-50"]
#sarasa
[quake time="30"]
[font size="40"]
——一树！！！[p]
[stopbgm]
[resetfont]
@layopt layer=message0 visible=false
[clearfix]
[quake time="30"]
[mask time="100"]
[playse  volume="100" buf="0" storage="punch.ogg" ]
[wse]
[chara_hide name="sarasa" time="10"]
[chara_show name="kirie" face="sad" top="-50" time="10"]
[wait time="4000"]
;ＳE鞭
[mask_off time="4000"]
[wait time="3000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#ituki
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……！[p]
[delay speed="120"]
怎、[wait time="500"]么…………[p]
#kirie
啊、[wait time="500"]啊…………[p]
#
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="+=800" time="800"]
[chara_hide name="kirie" time="200"]
[wait time="2000"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
;ＳE倒れる
[delay speed="70"]
――御白姬附身的肉体，当场瘫倒在地。[p]
#ituki
………………怎……[p]
你这是什么意思[wait time="700"]　马门贤治郎[p]

#makado
……[l]祝福，[r]
如果对赐予祝福的御白姬无效的话[p]
[chara_show name="makado" top="-10" face="true" wait="false" left="100"]
[delay speed="50"]
这份力量，
这是父亲赐予我们之物。[r][wait time="600"]
为了履行马门神社的职责，请你安眠吧[p]
#
贤治郎如此说着，[r]
缓缓走近倒地的躯体。[p]
[mask time="2000"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]
[chara_hide name="makado" wait="false" time="10"]
[mask_off time="2000"]
宗方树从雾绘的臂弯里挣扎出来，[r]
抬起了脸。[p]
;立ち絵出す
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
#ituki
………………………………[p]
――[wait time="500"](得、得救了)[p]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wse]
……………[l][playse  volume="20" buf="0" storage="sariin.ogg" ]
咦、纱罗纱？[p]
@layopt layer=message0 visible=false
[clearfix]
#
[camera wait="true" x="0" time="10"]
[camera x="60" y="0" wait="true" zoom="1.10"]
[camera x="-100" y="0" wait="true"]
[reset_camera]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
………………………………[l][r]
…………………………………………………[p]
――不见了。[p]
……无论怎么张望，都找不到纱罗纱的身影。[l][r]
明明刚才还那么耀眼地[r]
存在于触手可及之处。[p]
[font size="20"]
#kirie
呜……[p]
[resetdelay]
[resetfont]
[quake time="40"]
呜呜、呜哇！！！[p]
;ＳE走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="600"]

[chara_show name="makado" top="-10" face="shout_e" time="100" wait="false" left="100"]
[font size="40"]
#makado
[quake time="30"]
等等！！[l][r][resetfont]
#makado:tweetB_e
……可恶、必须追上去[p]
[chara_hide name="makado" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]
#ituki
[delay speed="60"]
啊……等、[wait time="500"] [resetdelay]别丢下我！[p]
#
[delay speed="60"]
两人追逐着雾绘的背影――[p]
[mask]
[bg storage="mountainRoad_m.jpeg" time="10"]
[wait time="2000"]
[mask_off time="6000"]
[resetdelay]
#ituki
……[l][r]
既然是贤治郎先生制造的躯体，只要贤治郎先生毁掉它就行了。[r][wait time="500"]
为什么不这样做而是放跑她？[p]
#
边跑边朝前方的男人低声说道。[p]
#makado
……让我、[wait time="500"]来破坏？[p]
#
前方的男人头也不回地反问道。[p]
[delay speed="50"]
#ituki
祝福……[wait time="500"]都是依附于我自身的东西。[l][r]
既然是你创造的存在，你应该可以随意处置吧[p]
#makado
……[l]我也，[r]
虽然知道那东西是因我而诞生的，[l][r]
我还不能很好地掌控自己的……[wait time="500"]祝福。[p]
#ituki
即便如此，那也应该由马门贤治郎来破坏。[l][r]
这八种之地的任何人，[wait time="500"]都不配摧毁那个雾绘的形态。[r]
就连御白姬的两人也不例外[p]
#makado
——我知道[l][r]
[delay speed="60"]
……纱罗纱她……究竟去了哪里呢[p]
[resetdelay]
#ituki
虽然不知道，但肯定没事的[r]
那孩子绝不会无缘无故消失[p]
[delay speed="60"]
#
明明心底坚信着这一点，[wait time="500"][r]
说出口的声音却颤抖着。[p]
#makado
……是啊。[wait time="500"]我知道的[p]
#
;ＳE鞭
[quake time="30"]
[mask time="10"]
[playse  volume="100" buf="0" storage="punch.ogg" ]
[wait time="500"]
[bg storage="yotuyamabridge_m.jpg" time="10"]
[wait time="500"]
[mask_off time="100"]
[quake time="10"]
[playbgm storage=bigriver.ogg loop=true volume="05"]
;○森橋
[font size="40"]
#kirie
嘎啊啊啊啊啊[p]
[resetfont]
[chara_show name="makado" top="-10" face="true" wait="false" left="100"]
#makado
绝不会让你再往前一步，[l][r]
……这是第二次了。不会再失手了[p]
[font size="20"]
#kirie
呜、呜呜、呜呜呜…………[p]
[resetfont]
[chara_mod name="makado" face="lookAway_e" time="300"]
#makado
…………[p]
[chara_hide name="makado" wait="false"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="500"]
#
贤治郎从倚靠在桥栏杆的那具躯体旁，[r]
轻轻取走了凶器。[p]
然后，[wait time="500"]犹豫不决地举起了它。[p]
#makado
……………………………………[p]
[resetdelay]
#kirie
马门君[p]
#ituki
别听信[l]　那声音和身影全都不、[wait time="500"]没有一样是真实的[p]
#kirie
倒也不能这么说啊[p]
[delay speed="60"]
喂你们啊。[l]　贤治郎在那个下雨天、[r]
为什么[wait time="500"]在树月折返的几十分钟里没能[r]
解决掉志户田纱罗纱[wait time="500"]　知道原因吗？[p]
#ituki
……因为这家伙，根本没那个胆量吧。[l][r]
无所谓了[p]
#kirie
开什么玩笑。[l]就凭那种弱不禁风的小姑娘身体[r]
男人稍微用力就能让她彻底报废[p]
[resetdelay]
#makado
恶心　别说了[p]
[delay speed="60"]
#kirie
那时候，我啊……[l][r]
连一根手指都动不了。　被你的肉体和灵魂抗拒着[p]
#makado
————什么？[p]
#kirie
根本就不听使唤呢。[l]御白姬的眼睛、[wait time="500"]手、[wait time="500"]嘴、[wait time="500"]……[r][wait time="500"]
为了将触及之物全部[font color="0xf08080"]驱逐[resetfont]，你被施加了[font color="0xf08080"]祝福[resetfont][p]
[font size="40"]
#ituki
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
――！！[l][r]
[quake time="30"]
[font size="20"]
[delay speed="100"]
那种、驱逐的祝福…………[wait time="300"]难道是[p]
[resetfont][resetdelay]
#kirie
没错。你一直以来都被雾绘的祝福所庇护，[r]
从而远离了我的掌控。[l][r]
所以我早就放弃了利用你这具派不上用场的躯体[p]
即便在那家伙跳楼自尽之后[wait time="500"]　也消停了很久[p]
[fadeoutbgm time="5000"]
[delay speed="60"]
#ituki
……………………诶？[l][r]
…………这算什么、太奇怪了吧[p]
祝福应该……[wait time="500"][r]
[resetdelay]
在受祝福者死去后，[wait time="500"]就会全部消失才对[p]
[delay speed="50"]
#kirie
雾绘的自我[r]
一直被禁锢在这具临时肉体里　微小又微小地[p]
所以才一直残留着啊[r][wait time="500"]
直到被那个叫川铃木的男人打破前、都一直附着在你背上[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeinbgm storage=tukutukulong.ogg loop=true time=10000 volume=05]
[wait time="5000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[delay speed="60"]
即便这样、你仍觉得现在的她是冒牌货吗？[wait time="500"][r]
能杀掉吗？[wait time="500"]　马门君[p]
[delay speed="120"]
#makado
……………………………[p]
你、你这家伙……[p]
[resetdelay]
;ＳE走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[font size="40"]
#makado
[quake time="30"]
！！[p]
@layopt layer=message0 visible=false
[clearfix]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
@layopt layer=message0 visible=true
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[resetfont]
#
[delay speed="60"]
[font size="22"]
……[wait time="500"]化作雾绘形貌的肉块，正试图从桥栏杆上站起身来。[l][r]
[r]
贤治郎将其拽倒在地。[l]
[r][r]
仰面倒在木板上的雾绘[wait time="500"]　一边流泪一边快意地笑了。[l]
[r][r][resetfont]
「啊哈哈哈哈哈哈！　啊哈哈哈哈哈哈哈！[r]　啊
——哈哈哈啊啊哈哈哈哈哈哈！！！！！！」[p]
[r][font size="22"][r]
对她而言，这种现状似乎有趣到难以自抑。[l][r]
[r]
贤治郎仍伏在桥栏杆上，[wait time="500"]沉默着一动不动。[l][r]
[r][r]
只是低垂着头。[l][r]
[r][r][resetfont][resetdelay]
「要是第一次也能这样赶上就好了啊！！！[r][wait time="500"]　那
样的话你就能，[r]　忘记雾绘继续活下去了！！」[p]
「你害怕第二次死亡吗，[r]　最恐惧直面不可逆结局的人就是你，[wait time="500"][r]　生
命终究无法挽留，[r]　[wait time="500"]逝者永不回头！！」[p]
[chara_show name="ituki" top="-100" face="shout_s" time="100" wait="false" left="140"]
[font size="40"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#ituki
[quake time="30"]
[font color="0xf08080"]
[playse  volume="20" buf="0" storage="kaminari.ogg"]
……你啊！！[p][resetfont]
[resetfont]
[chara_mod name="ituki" face="angryB_s"]
#kirie
！！[l]　你算什么东西啊[p]
#
[delay speed="50"]
我站在河岸边缘，朝着桥上的两人大声喊道。[p]
#kirie
你这家伙对这具肉身还能有什么留恋[p]
长久以来不都深恶痛绝吗[wait time="500"]　从三位官女手中逃出来惨死野外的[r][wait time="500"]
在八种之外根本活不下去的女人[p]
#ituki:hateG_s
我讨厌你啊[r][wait time="500"]
在这般世界里 能不忘却喜爱之事的人本就寥寥无几[p]
但是呢[p]
;-------------------------------------------------------------------------------
[chara_face name="kirie" face="back3" storage="chara/kirie/back3.png"]
[chara_face name="kirie" face="back4" storage="chara/kirie/back4.png"]
[chara_face name="kirie" face="back5" storage="chara/kirie/back5.png"]
;-------------------------------------------------------------------------------
#ituki:shout_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
姐姐她啊，[r]
始终不忍心将他人拖入自己的痛苦深渊！[r][wait time="500"]
虽然关于那个人大多记忆都已模糊，唯有这点我记得清清楚楚！[p]
[stop_kanim name=ituki]
[delay speed="70"]
#ituki:angryB_s
所以……所以才会死去！[p]
明明是个看似任性从不深思的人，[r]
却总为自己的所作所为惶恐不安，[wait time="500"]缺乏自信，[wait time="500"][r]
连央求他人陪葬都做不到……[p]
#ituki:sadB_s
……………………………………………………[r]
……………………………………………………[p]
#ituki:shout_s
[resetdelay]
[quake time="30"]
[font size="36"]
知道吗！？御白姬！！！！[p]
#ituki
雾绘会死，[r][wait time="500"]
是因为这世上根本没人能救得了她！！[p]
[fadeoutbgm time="20000"]
[fadeoutbgm time="4000"]
[chara_hide name="ituki" wait="false"]
[resetfont]
[delay speed="60"]
[bg storage="indoor/makado_roka.jpeg" cross="false" wait="true"]
你也好！！[wait time="500"]我也罢！！[wait time="500"]连优和全家人都！[l][r]
[fadeinbgm storage=umitoyadorino.ogg time=10000 volume=20 sprite_time="0000-58000" loop=true]
在场的贤治郎先生也是，[wait time="500"]力也好阿基也罢日野也是……[p]
[bg storage="school/kyukosya_heya.jpeg" cross="false" wait="true" ]
八种的人[wait time="500"]八种之外的每个人，[r]
我们都没能成为拯救姐姐的存在[wait time="500"]　所以姐姐才会死的！！！[p]
[bg storage="fork_a.jpg" cross="false" wait="true"]
……………………………………………………[r]
……………………………………………………[p]
但是呢，只有一个人[wait time="500"][r]
我知道有个孩子或许能救雾绘。[p]
这孩子从小和雾绘素不相识，[r]
连对话都只有一两次[wait time="500"]　之后就再也没见过了……[p]
雾绘死后　『知道过去的话真想救她』，[wait time="500"][r]
那孩子傲慢地关心着姐姐的一切[p]
@layopt layer=message0 visible=false
[clearfix]
[bg storage="indoor/miyage2.jpeg" cross="false" wait="true" time="500"]
[bg storage="indoor/sisin.jpeg" cross="false" wait="true" time="500"]
[bg storage="ton_a.jpg" cross="false" wait="true" time="500"]
[mask]
[bg storage="yotuyamabridge_m.jpg" time="10"]
[chara_show name="ituki" top="-100" face="cry5_s" time="100" wait="false" left="140"]
[wait time="3000"]
[resetdelay]
[mask_off]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
她将会在这个城市里[wait time="500"][l][r]成为真正的女神
成为能拯救像雾绘这样的孩子[wait time="500"]　那种存在的女孩[p]
[font size="40"]
[anim name="ituki" top="+=30" time="150"]
[anim name="ituki" top="-=30" time="150"]
她就是志户田纱罗纱啊，姐姐——[wait time="500"][r]
我现在依然和那孩子[wait time="500"]　是朋友啊！！！[p]
#
[resetfont]
[stopbgm]
[mask time="100"]
[playse storage=ti.ogg volume="50"]
[wse]
;ＳEザクッ
[chara_hide name="ituki" time="10"]
[chara_show name="kirie" top="-60" face="back3" time="10" left="10"]
[wait time="3000"]
[mask_off time="6000"]
[font size="20"]
[delay speed="120"]
#kirie
――――――――――――呜……[p]
[resetfont]
#
…………………………………………[l][r][wait time="500"]
#makado
雾绘[p]
[font size="20"]
#kirie
………………[l]贤、[wait time="500"]治、郎[p]
[resetfont]
[delay speed="50"]
#makado
睡吧。[l][r]
我也、[wait time="700"]不会再忘记了[p]
[delay speed="100"]
#
…………贤治郎将、[wait time="500"]利刃留在雾绘胸口，松开了手。[l][r]
雾绘、[wait time="500"]只是静静站在原地，一言不发。[p]
#kirie
……干得漂亮啊、[wait time="500"]贤治郎？[p]
#kirie
……是啊。明明以为这条命只属于我自己，[r]
结果[wait time="500"]　还是分了一点　给马门君……[p]
[font size="20"]
#
轻声地，[wait time="500"][r]
「总觉得现在　就像故事的最终场景一样」[wait time="500"]低语道。[p]
[resetfont]
#kirie
但我[wait time="500"]　最讨厌女主角死掉的电影了[l][r]
[iscript]
TYRANO.kag.stat.charas['kirie'].jname = '宗方 きりえ'
[endscript]
#kirie:back4
因为那种结局，[wait time="500"]除了悲伤什么也没有[p]
@layopt layer=message0 visible=false
[clearfix]
#kirie:back5
;白い塊
[wait time="5000"]
[anim name="kirie" top="+=30" time="150"]
[anim name="kirie" top="+=800" time="800"]
[chara_hide name="kirie" time="200"]
[wait time="2000"]
[playse  volume="50" buf="0" storage="book.ogg" ]
[wse]
[free_filter]
[playbgm storage=bigriver.ogg loop=true volume="10"]
[wait time="6000"]
;○橋（元の色）
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#
;ＢＧＭ滝
…………[p]
…………………………………………[p]
……………………………………………………[l][r]
……………………………………………………[p]
……………………………………………………[r]
………………………………沉默了相当长的时间。[p]
#
突然，看向身旁。[p]
[delay speed="60"]
#ituki
…………这种时候，哭出来也没关系吧[p]
[delay speed="70"]
雾绘一直、都希望贤治郎先生……[wait time="500"][r]
能为她的事[wait time="500"]　而哭泣吧[p]
……………………………………………………[r]
……………………………………………………[p]
[bg storage="brack.png" wait="false" cross="false" time="3000"]
……………………………………………………[r]
……………………………………………………[p]
……………………………………………………[r]
………………[wait time="500"]求求你、哭出来吧[p]
[mask folder="bgimage" graphic="still/part5.png"]
[fadeoutbgm time="5000"]
[wait time="6000"]
[showsave]
;セーブしますか？
@jump storage="epilogue/day1.ks"
;セーブしますか？
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
