*part5
[eval exp="f.save_title = '五章パート１'"]

;-------------------------------------------------------------------------------
#
[bg storage=./school/croom_m.jpg time="10"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
[mask_off time="3000"]
[playse storage=bell.ogg sprite_time="0000-6000" volume="5"]
[wse]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[chara_show name="kuma" top="-160" face="normal" wait="false" time="2000"]
――8月25日。[p]
[delay speed="50"]
#kuma:normal
各位。[r]
下周这个时间　想必我正在做《城镇与我》的课题发表吧[p]

请务必让初中二年级这不会再来的暑假　不留遗憾[r]
度过。[p]
另外…[p]
#kuma:smile
志户田　请起立[p]
[chara_hide name="kuma" wait="false"]
#sarasa
……………………是[p]
#
我拉开椅子站起身来。[p]

#kuma
终于到了后天周日　在四ツ山的马门神社[r]
将举办历史悠久的传统祭典「白绢祭」呢[p]
[resetdelay]
在座同学中应该有不少人正在研究[r]
关于御白姬和白绢祭的课题吧……[wait time="500"][r][delay speed="50"]
我们二班一组的志户田同学　将作为御白姬的扮演者参与祭典[p]

请大家一起为同窗的荣耀时刻加油助威吧。[r]
那么有请志户田同学　来说几句吧[p]
#
环视整个教室。[p]

与全班同学四目相对。[p]

我轻轻呼出一口气，开始说道。[p]
[chara_show name="sarasa" top="-160" face="closeEye" wait="false"]
#sarasa
……能获得冠以[r]
城镇女神御白姬之名的角色……[r]
我感到无比荣幸[p]
[resetdelay]
#sarasa:normal
为了能顺利完成祭典　希望大家也能[r]
继续支持我[p]

;se拍手
[playse  volume="30" buf="0" storage="kansei.ogg"]

#黒田
加油啊！[p]

#委員長
……哼[p]
#
[clearfix]
@layopt layer=message0 visible="false"
[chara_hide name="sarasa" wait="false"]
[bg storage="brack.png" time="100" cross="false" time="2000"]
[wait time="3000"]
@layopt layer=message0 visible="true"
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font size="22"]
你认为美丽的东西可能实则肮脏，[r]
[r]
觉得肮脏的东西也许才是真正的美丽？[l][r]
[r]
[r]
[delay speed="60"]
除非亲手触碰否则永远无法知晓。[r]
[r]
这个夏天的回忆如此告诫我。[p]
[resetfont]
[mask folder="bgimage" graphic="still/part5.png" time="3000"]
[wait time="2000"]
;第五章　蛹からうまれた者
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#三人官女
[chara_show name="kirie" face="normal" time="10" top="-100"]
[chara_show name="ituki" left="360" face="normal" time="10" top="-100"]
[chara_show name="suguru" left="-70" face="normal" time="10" top="-100"]
[stopbgm]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]
[mask_off time="100"]
这个城镇的女神会死于谁手？[p]
[chara_hide_all time="10"]
[bg storage="still/kirie_smile2.png" time="100"]
#kirie
「就是你啊，马门同学」[p]
#
[clearfix]
@layopt layer=message0 visible="false"
[bg storage="still/kirie_smile3.png" time="100"]
[wait time="2000"]
[mask time="10"]
[bg storage="indoor/makado_ima_m.jpg" time="10"]
[wait time="2000"]
[mask_off time="10"]
#makado
@layopt layer=message0 visible="true"
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
[quake time="30"]
[quake time="30"]
[font size="40"]
——！！[p][resetfont]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=20]
[delay speed="50"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '叔父'
[endscript]
#mokke
嗯？怎么了[p]
[delay speed="70"]
#makado
……啊、……[l][r]
对不起 我好像稍微睡着了……[p]
#
暴露自己松懈的样子很羞耻，[r]
用手掌遮住额头，躲开了叔叔的视线。[p]
#makado
（………………………………………）[l][r]
（…………………我真蠢）[p]
[delay speed="50"]
#mokke
这也难怪。祭典前总是特别忙[p]

#mokke
………………………………………………[l][r]
……贤治郎啊，[p]
[resetdelay]
照顾哥哥这种事 这种时期就算拜托别人[r]
也没什么关系吧。[r]
没人会遭报应的？[p]
[delay speed="60"]
#makado
……不。我希望父亲能留在家里。[r]
尽可能让家人在一起……[p]
………………[wait time="800"][r]
抱歉，这明显是我精神松懈的证据呢。[r]
我去洗把脸[p]
[resetdelay]
#mokke
贤治郎你就算再怎么逼迫自己 哥哥也不会醒来的[p]

#makado
…………[p]

#mokke
我们这一脉……[r]
你作为祭主无法保持「完美」的原因[r]
果然还是源于哥哥继承仪式的失败啊[p]

#mokke
即便没有继承仪式这回事[r]
你也并非当不成这个町的神主。[p]
现在就让正值青春的你 决定将一生奉献于此[r]
未免为时过早——[p]

#makado
说什么希望他醒来 我照顾他可不是出于这种期待[p]
[fadeoutbgm time="3000"]
[delay speed="50"]
#makado
我只是……[wait time="500"]为了让自己心安[r]
才这样做的罢了。叔叔[p]
#
;s Eガラガラ
[playse  volume="40" buf="0" storage="hikidopen2.ogg"]
[wse]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="700"]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="1000"]
[delay speed="100"]
#mokke
……[wait time="500"]唔～[p]
[mask]
[chara_hide name="mokke"]
[chara_show name="hino" face="tweet" top="-100" time="10"]
[bg storage=./school/croom_m.jpg time="10"]
#hino
[mask_off time="100"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[resetdelay]
其实我从一开始就觉得贤治郎先生很不正常[p]
[chara_hide name="hino" time="10"]
[chara_show name="riki" face="normal" top="-100" wait="false" time="100"]
#riki
[playse  volume="20" buf="0" storage="kakan.ogg" ]
因为是神社却留着和尚头？[p]
[chara_hide name="riki" time="10"]
[chara_show name="aki" face="normal" top="-100" wait="false" time="100"]
#aki
[playse  volume="20" buf="0" storage="kakan.ogg" ]
还是假借大义之名 欺凌[r]
柔弱后辈的缘故？[p]
[chara_hide name="aki" time="10"]
[chara_show name="ituki" face="hate" top="-160" wait="false" time="100"]
#ituki
[playse  volume="20" buf="0" storage="kakan.ogg" ]
不 是因为他突然蹦出句流行歌词才最诡异吧[p]
[chara_move  name="ituki"  left=490 top=-160 wait="false" anim="true"]
[chara_show  name="aki" left=250 top=-100 wait="false" face="normal"]
[chara_show  name="riki" face="normal" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="shame" left=-230 top=-100 wait="false"]
#hino
[font size="40"]
[quake time="30"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
全都不对全都错！！[fadeinbgm storage=gymnopedies2.ogg loop=true time=800 volume=50]
[p]
[resetfont][resetdelay]
#hino:tweet
毕竟他可是继承了注连绳[r][font color="0xf08080"]
马门神社的传人[resetfont]啊[r]
因为他没能解除御厨子大人的诅咒[p]
#hino:sad
你们之前也听说过吧？[r]
作为封印之物的【神厩注连绳】本应……[r][delay speed="70"]
[playse  volume="20" buf="0" storage="sariin.ogg" ][font color="0xf08080"]
「一击就能封印御厨子大人」[resetfont]的存在才对[p]
#
——日野拾起了[r]
玛莉甘前几日说过的话语。[p]
[mask time="500"]
[bg storage="brack.png" time="100"]
[chara_hide_all time="10"]
[chara_show name="mokke" top="100" face="marigan" time="10"]
[iscript]
TYRANO.kag.stat.charas['mokke'].jname = '紀伊 マリガン'
[endscript]
[mask_off time="500"]
[delay speed="70"]
那时已经不存在任何人会再被诅咒的风险了。[r][resetfont]
诅咒的源头 正是在与神主对峙的[r]
正是因为被封印着[p]
[mask time="500"]
[chara_hide name="mokke" time="10"]
[bg storage=./school/croom_m.jpg time="10"]
[chara_show  name="aki" left=250 top=-100 time="10" face="normal"]
[chara_show  name="riki" face="normal" left=-70 top=-100 time="10"]
[chara_show  name="ituki" face="normal" left=490 top=-160 time="10"]
#hino
[chara_show  name="hino" face="normal" left=-230 top=-100 time="10"]
[resetdelay]
[mask_off time="500"]
但一直以来负责祛除诅咒的是志户田先生，[r]
贤治郎先生用注连绳做到的[r]
不过就是拖延被诅咒者的行动罢了[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="normal" wait="false"]
#sarasa
可光是这点拖延，我就被救了好多次啊[p]
[chara_move name="sarasa" left="360" wait="false" anim="false" time="100"]
[chara_show name="ituki" face="tweet" left="-70" top="-160" wait="false" time="100"]
#ituki
少在那儿马后炮。[p]
#ituki:hate
那家伙要是真有传说级别的力量，[r]
纱罗纱遇险的次数本该能减少很多的[p]
#sarasa:worry
…………才不是那样呢[p]

#riki
嗯——[wait time="500"][r]
话说回来，那个奥库罗姆克到底是什么玩意儿啊[p]

到底该相信传说故事到什么程度，也完全搞不清楚……[r]
虽然现在才说　但它的真实存在　简直莫名其妙啊[p]
[chara_hide_all time="10"]
[chara_show name="aki" wait="false" face="tweet" top="-100"]
#aki
……果然　这个小镇上[r]
存在着　某种　无法解决的　大问题啊[p]

#aki:hate
我们狮心教的眷属[r]
马门神社的祭主御白姬扮演者的大小姐们　全都毫不知情[r]
关于真正的秘密[p]
[delay speed="50"]
#aki:tweet
你也在前天……[r][wait time="500"][playse  volume="20" buf="0" storage="sariin.ogg" ]
[font color="0xf08080"]
亲身经历了那件事　应该深有体会吧？力[p][resetfont]

#sarasa
(——前天？)[p]
[chara_move  name="aki" left=250 top=-100 wait="false" anim="true"]
[chara_show  name="hino" face="normal" left=-230 top=-100 wait="false"]
[chara_show  name="ituki" face="normal" left=490 top=-160 wait="false"]
#riki
[chara_show  name="riki" face="tweetLA" left=-70 top=-100 wait="false"]
……哦。刻骨铭心啊。[r]
简直乱七八糟[p]
[resetdelay]
#ituki:tweet
23号那天　根本没什么集会吧？[r]
你们俩当时在约会吗？[p]

#hino:tweet
不。包括我和聪君在内，我们四个人碰了头。[r]
与狮心教无关，是以地域研究部的名义[p]

#ituki:smile
哦？有意思。地研的名义是搞什么名堂？[p]

#aki:normal
也没做什么特别奇怪的事啦[l][r]
#aki:tweetLA
[playse  volume="20" buf="0" storage="sariin.ogg" ]
[delay speed="60"]
只是…… [wait time="500"][font color="0xf08080"]
去找纪伊玛莉甘学姐[resetfont]打听些事情[p]

#sarasa
诶……原来是这样……？[p]
#hino:normal
目前为止，只有那位能确实地……[r]
掌握着我们尚不知晓的情报[p]

#hino:sad
只要去见她，应该就能问出来——[p]
@layopt layer=message0 visible=false
[clearfix]
[fadeoutbgm time="3000"]
[chara_hide_all time="3000" wait="false"]
[bg storage=saka_ｍ.jpeg time="3000" cross="false" wait="true"]
[fadeinbgm storage=tukutukulong.ogg loop=true time=8000 volume=40]
[wait time="3000"]
#
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

——23日，下午3点。[p]
[resetdelay]
[chara_show  name="hino" left=250 top=-100 wait="false" face="normal_s" time="100"]
[chara_show  name="aki" face="normal_s" left=-230 top=-100 wait="false" time="100"]
[chara_show  name="suguru" face="normal_s" left=490 top=-100 wait="false" time="100"]
#riki
[chara_show  name="riki" face="smileCE_s" left=-70 top=-100 wait="false" time="100"]
我啊、[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
我去买果汁！[p]

#hino:angry_s
要快点回来啊[r]
得在玛莉甘学姐转移前赶过去[p]
[chara_hide name="riki" wait="false" pos_mode="false"]
;se 走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
#hino
……呜嗯、那家伙竟然无视我们走掉了！？[r][wait time="500"]
#hino:shame_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
聪君，快跟过去看看！！[p][stop_kanim name=hino]
#suguru:wow_s
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=suguru keyframe=up time=300 wait="false"]
好、好的[p][stop_kanim name=suguru]
[chara_hide name="suguru" wait="false"]
;se 走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="1000"]

;se 走る

#aki
………………[l][r]
……呐　日野[p]
#aki
那个人　现在真的　在那个什么演艺事务所里对吧？[p]

#hino:tweet_s
啊？[r][wait time="500"]
嗯。我问过经纪人所以不会错的[p]

#aki
这样啊[wait time="500"]……[p]
[delay speed="100"]
#hino:normal_s
……………………[p]

#aki
……………………[p]

#hino:sad_s
…………………………………[p]
#hino:smile_s
[font size="20"]
我、[font size="40"]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=hino keyframe=up time=300 wait="false"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
我可太高兴了！器乐堂！[p][stop_kanim name=火野][resetfont]

#aki:wow_s
诶？[p]
[font size="20"]
[delay speed="10"]
#hino
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
因为你之前可是连续99次拒绝了我们地域研究部的邀请啊，[r]
能这样陪我们一起探索八种的历史，简直像做梦一样！[r]
这感觉简直就是水户黄门附体啊！！[p]
[resetfont][resetdelay]
[delay speed="50"]
#aki:smile_s
哈哈 现在还说这种话干嘛[r]
上次的故事会 我们不也跟去了嘛[p]

#hino:sad_s
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
啊、啊啊！对对，说起来是有这么回事[p]

#hino:smile_s
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[delay speed="100"]
……我日野国雄真是个糊涂虫，活像个八兵卫！[p]
[delay speed="50"]
#aki:normal_s
呵呵 你这人 果然 很奇妙呢[l][r]
#aki:smileB_s
明明看起来厚脸皮 其实很在意同行者沉默不语的时候[r]
你其实在害怕吧[p]

#hino:tweet_s
[font size="40"]
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
！　[resetfont]……在器乐堂眼里，我就是这样的形象吗[p]

#hino:normal_s
确实……我会特别注意[r]
同行伙伴有没有在勉强自己。[p]
#hino:sad_s
我天生就不擅长察言观色，[r]
爷爷也经常告诫我[r]
要学会关心他人……[p]
[resetdelay]
#aki:tweet_s
不用担心　今天的我并不是出于罪恶感或义务感[r]
我可不是勉强自己在配合你的兴趣爱好啊[p]
[delay speed="50"]
#aki:tweetLA_s
……至少关于你住的地方[r]
我是真心想了解清楚的[r]
毕竟我这辈子应该都不会离开八种了[p]
[delay speed="60"]
#aki
力那家伙八成也是[r]
怀着同样的想法跟来的吧……[p]
#hino:smile_s
原、原来如此……！[wait time="500"]那就好。只要不是勉强自己就好！[p]
[resetdelay]
#hino:happy_s
不过……[wait time="500"]呵，[r]
你和登利还有聪君关系真是好啊[p]
#hino:smile_s
我永远都无法，融入你们青梅竹马的小圈子。[r][wait time="500"]
这让我既感到心酸，又觉得美好。[r]
正是所谓的恩怨清和呢[p]
[resetdelay]
[delay speed="50"]
#aki:wow_s
没想到日野你也会有嫉妒这种细腻的感情啊[p]

#hino:angry_s
当然有。我可嫉妒得不得了呢[p]

#aki:smile_s
哈哈 要是让优听见 他肯定会很高兴吧[p]

;se走る
[font size="40"]
[delay speed="100"]
#suguru
[quake time="100"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[chara_mod name="hino" face="shame_s"]
[chara_mod name="aki" face="wow_s"]
噫、前、前辈～～～！[r]
阿奇～～～～！！！[p][resetfont]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="1000"]
[resetdelay]
[chara_show name="suguru" top="-100" face="sadB_s" wait="false"]
#aki
哇啊　怎么了　
这么慌张[p]

#hino
出什么事了吗？[p]
[chara_hide name="hino" time="10" pos_mode="false"]
[chara_hide name="aki" time="10" wait="false"]
[delay speed="100"]
#suguru
哈啊哈啊、力、力量……[p]
[font size="40"]
[delay speed="100"]
[quake time="100"]
[playse  volume="30" buf="0" storage="kaminari.ogg"]
力量被吸走啦！！！[p]
[chara_hide name="suguru" time="10"]
#
[chara_show name="aki" top="-100" face="wow_s" wait="false" time="100" left="-70"]
[chara_show name="hino" top="-100" face="shame_s" wait="false" time="100" left="330"]
[quake time="100"]
[playse  volume="20" buf="1" storage="kaminari.ogg"]
诶！？[p][resetfont]
[mask time="100"]
[stopbgm]
[bg storage=./school/croom_m.jpg time="10"]
[chara_hide_all time="10"]
[wait time="1000"]
[chara_show  name="aki" left=250 top=-100 time="10" face="normal"]
[chara_show  name="hino" face="angry" left=-230 top=-100 time="10"]
[chara_show  name="riki" face="normal" left=-70 top=-100 time="10"]
[resetdelay]
#ituki
[chara_show  name="ituki" face="hate" left=490 top=-160 time="10"]
[mask_off time="100"]
哈？　[wait time="500"]你在干嘛？[p]
#riki:shame
因为啊————！这也没办法吧！？[r]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
正好绝佳机会就在眼前嘛[p]
[delay speed="100"]
[chara_hide_all time="3000" wait="false"]
[bg storage="brack.png" time="3000" wait="false"]
#suguru
追上去发现他在自动贩卖机前和陌生人说话……[r][wait time="500"]
[fadeinbgm storage=severe-reprimande.ogg loop=true time=3000 volume="30"]
我稍微躲远点观察情况……[p]
[delay speed="50"]
[bg storage=saka_ｍ.jpeg time="300" cross="false" wait="false"]
[chara_show name="suguru" time="100" wait="false" face="sadB_s" top="-100"]
#suguru
结果像扛米袋一样，[font size="40"]唰！[resetfont]地一下……就被带走了……！[p]
[chara_hide name="suguru" time="10"]
[chara_show name="aki" top="-100" face="normal_s" wait="false" time="100"]
#aki
嗯——嘛 肯定 没事的啦。[r]
过会儿 自己 就会回来[wait time="100"][er]
[font size="40"]
[resetdelay]
#hino
[playse  volume="20" buf="0" storage="kaminari.ogg"]
[quake time="30"]
不行不行得去追！！[r][resetfont]
登利往哪边去了！？！[p]
[font size="20"]
#suguru
啊啊啊、在那边！！[p]
#hino
好——赶紧追！！！！[p]
[resetfont]
;se走る
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="200"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="2000"]
#aki
……………[l][r]
[delay speed="60"]
#aki:sad_s
真是的　拿你没办法啊……[p]
[resetdelay]
;se走る
[mask]
[chara_hide name="aki" time="10"]
[bg storage=rojiura_m.jpg time="10" cross="false" wait="true"]
[playse storage=run.ogg volume="50" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="2000"]
;路地裏
#
[mask_off]
…………[p]
#おじさん
……我并不想对你动粗[p]

我们也在赶时间，[r]
因为这个国家的未来与过去正危在旦夕[p]
[chara_show name="riki" face="smileB_s" top="-100" wait="false"]
[resetdelay]
#riki
我们？大叔有家人的！什么样的家人？都还好吗？[p]
#おじさん
家人……。[l][r]
是啊。对我来说，整个国家就是家人，[r]
我一直是这么认为的……[p]

#riki:smileCE_s
？这样啊！那赶紧去我家吧！[p]
#おじさん
[delay speed="50"]
去？不，在这里就好。[l][r]
刚才也说过，我只是有些事想问你……[p]

#？
喂喂　大叔。[p]

#おじさん
――！[er]
[resetdelay]
[font size="40"]
[chara_show name="hino" face="ghost_s" wait="false" time="100" top="-100"]
#hino
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
别往
[chara_move name="hino" top="-90" width="+=150" anim="true"]
这边看啊―――！！！[wait time="300"][er][resetfont]

;seドゴッ
[playse  volume="60" buf="0" storage="punch.ogg"]
#おじさん
[quake time="30"]
[quake time="30"]
咕哇！[p]
[chara_hide_all time="10"]
[chara_show name="suguru" top="-100" face="sad_s" wait="false" time="100"]
[delay speed="50"]
#suguru
[playse  volume="20" buf="0" storage="kakan.ogg" ]
（来了，小谷坂的弗兰肯”全力右直拳……！）[p]
[chara_hide time="10" name="suguru"]
[chara_show name="aki" top="-100" face="ghost_s" wait="true" time="100"]
#aki
[stopbgm]
[anim name="aki" top="-=60" time="150"]
[anim name="aki" top="+=70" time="150"]
[anim name="aki" top="-=10" time="150"]
啪嗒[p]
[chara_move  name="aki" left=250  anim="true" wait="false"]
[chara_show  name="hino" face="angry_s" left=-230 top=-100 time="10" wait="false"]
[chara_show  name="suguru" face="sad_s" left=490 top=-100 time="10" wait="false"]
#riki
[chara_show  name="riki" face="worry_s" left=-70 top=-100 time="10" wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[quake time="30"]
[playbgm storage=gymnopedies2.ogg loop=true volume=50]
啊—！？日野！阿奇、你干嘛啊――！！[r]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
马上把大叔从里面放出来啊！[p]
[font size="40"]
#hino:shame_s
[playse  volume="30" buf="0" storage="garasu.ogg" ]
[quake time="30"]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
你他妈到底在想什么——！！！[p][resetfont]

#suguru:wow_s
[anim name="suguru" top="+=30" time="150"]
[anim name="suguru" top="-=30" time="150"]
前辈！　请不要动手，[r]
眷属之间打架会被骂的！！[p]
[delay speed="60"]
#hino:smile_s
呵呵，[wait time="500"]呼——。说得对。不行，这样不行。[r]
我这是怎么了[p]
[delay speed="50"]
#aki:normal_s
[anim name="aki" top="-=60" time="150"]
[anim name="aki" top="+=70" time="150"]
[anim name="aki" top="-=10" time="150"]
你被绑架了吗　力。[p]
#aki:tweet_s
明明约好要去玛丽甘小姐那里的……[r]
你小子啊　连这种约定[r]
走三步就会忘掉吗？[p]

#riki:sad_s
啊、那是因为啊！！[l][r]
#riki:think_s
刚才那位大叔、[playse  volume="20" buf="0" storage="sariin.ogg" ]
想打听玛丽甘知道的情报。[r][wait time="500"]
所以我就试着绑架他之类的[p]

#hino:sad_s
……什么？[r][wait time="500"]
#hino:tweet_s
刚才的可疑分子、提到了玛丽甘小姐的名字吗？[p]

#riki:smile_s
哦[p]
#
[chara_hide_all time="2000" wait="false"]
[bg storage="brack.png" time="2000" wait="false"]
[delay speed="70"]
『你就是前几天和纪伊玛莉甘聊了很多的小家伙吧？』[p]

『如果方便的话 把从她那里听到的事[r]
也告诉我好不好……』[r]
这样。[p]

[mask]
[bg storage=./school/croom_m.jpg time="10"]
[chara_show  name="aki" left=250 top=-100 time="10" face="normal"]
[chara_show  name="hino" face="normal" left=-230 top=-100 time="10"]
[chara_show  name="riki" face="normal" left=-70 top=-100 time="10"]
[resetdelay]
[wait time="2000"]
#ituki
[chara_show  name="ituki" face="tweet" left=490 top=-160 time="10"]
[mask_off]
……也就是说你故意让那个大叔绑架你……[p]
[delay speed="50"]
#ituki:smile
觉得说不定能套出些玛莉甘的新情报[r]
打着这种算盘，结果真被绑了啊[p]
#riki:smileCE
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
[anim name="riki" top="+=30" time="150"]
[anim name="riki" top="-=30" time="150"]
啊！对对对！就是那样！[r]
我就是想那么干的啦[p]
[resetdelay]
#aki
不过　因为那些破事耽搁了时间[r]
等赶到事务所的时候[r]
玛莉甘小姐已经不在了呢[p]

#ituki:hate
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
把正主放跑可不太行吧[p]

#riki:shoutG
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
呜哇——！！！　别责难我啊！！[r]
不是我的错、不是的、反正不怪我！！[p]
#
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" face="normal" wait="true"]
[delay speed="50"]
#sarasa
……………………………[p]
[chara_hide name="sarasa" time="10"]
[chara_show name="aki" top="-100" face="smile" wait="false" time="300"]
#aki
怎么样？纱罗纱。[l][r]
#aki:ghost
想和这个绑架犯大叔聊聊吗？[p]
[chara_hide name="aki" time="10"]
[chara_show name="sarasa" top="-160" face="wow" wait="false" time="100"]

#sarasa
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=sarasa keyframe=up time=300 wait="false"]
诶……[p][stop_kanim name=sarasa]

#
阿奇刻意展示着自己的祝福能力。[l][r]
他[font color="0xf08080"]体内[resetfont]，恐怕还沉睡着另一个意识本体吧。[p]

#sarasa:worry
……………………………………[p]
……那个人，为什么会知道玛莉甘小姐的事……[l][r]
[delay speed="60"]
#sarasa:closeEye
更让我在意的是，为什么[font color="0xf08080"]
【纪伊玛莉甘所说的话】[resetfont]会被想知道[r]
那些事情的内容……[p]

#sarasa:normal
而且……说不定[r]
那个人我可能曾经见过……[wait time="500"][r]
有点想亲眼确认一下……吧[p]
[delay speed="50"]
[chara_move name="sarasa" anim="true" left="360" wait="false"]
[chara_show name="ituki" left="-70" face="smileCE" wait="false" top="-160"]
#ituki
见过？[wait time="500"]哈哈，说什么傻话。[r]
那家伙可是突然出现在八种的绑架未遂犯啊？[r]
那种优雅大小姐的朋友怎么可能会有正当理由啊喂[p]

#sarasa
嗯，所以说……[p]

我在暑假刚开始的时候……遭遇过类似[r]
绑架未遂的事件……[p]
#四人の眷属
[playbgm storage=severe-reprimande.ogg loop=true volume="30"]
[chara_hide_all time="10"]
[resetdelay]
[chara_show  name="aki" left=250 top=-100 time="300" face="wow" wait="false"]
[chara_show  name="hino" face="shame" left=-230 top=-100 time="300" wait="false"]
[chara_show  name="riki" face="sad" left=-70 top=-100 time="300" wait="false"]
[chara_show  name="ituki" face="hate" left=490 top=-160 time="300" wait="false"]
[playse  volume="20" buf="0" storage="garasu.ogg" ]
[quake time="30"]
[quake time="30"]
[font size="40"]
哈！？！？[p]

#ituki:hate
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
我可没听说过啊喂！！[r]
这到底是什么时候的事！？[p]
[resetfont]
[delay speed="60"]
#sarasa
应该是最开始……开学日放学路上吧。[r][wait time="500"]
在四ツ山的隧道附近……被人埋伏了……[p]
[resetdelay]
#ituki
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
你……你为什么要瞒着我们到现在！？对我们！！！[p]
[stop_kanim name=ituki]
[delay speed="60"]
#sarasa
因、因为……[wait time="500"]可能和这件事无关所以……[p]
在调查诅咒的过程中，我开始觉得那或许只是[r][playse  volume="20" buf="0" storage="sariin.ogg" ]
普通的可疑人士……[r]
所以才……！[p]

#sarasa
如果和诅咒无关的话……[r]
现在的我们根本束手无策……[p]

#aki:worry
[font color="0xf08080"]
难道说……被授予祝福的眷属外貌[resetfont]其实是假的吗[p]
#
我向阿奇点了点头。[p]

#riki:hate
那个大叔是连环犯吗——[r]
那不就是用调包形式诱拐小孩嘛。[r]
超危险啊[p]

#aki:sad
八种这地方治安好差 要不要搬家啊[p]

#hino:shame
[anim name="hino" left="-=10" time=50 ]
[anim name="hino" left="+=10" time=50 ]
这里才不是那么可怕的地方！！[r]
这、这一定是搞错了！[p]
#ituki:sad
呜……啊……[p]
[delay speed="60"]
#ituki
当、当时没有人跟你在一起吗……？[r]
怎么会沦落到被诱拐的处境啊……[p]
[chara_hide_all time="10"]
[chara_show name="sarasa" top="-160" wait="false" face="normal"]
#sarasa
……嗯，……………………[p]

#sarasa:sad
（……那时候，一树明明……[r]
说要一起走回家的……是我忘记了呢……）[p]
#
[mask]
[filter grayscale="100"]
[chara_hide name="sarasa" time="10"]
[bg storage=still/first_contact.png time="10"]
[mask_off]
那天，我的手机被某人远程操控，[r]
导致无法联系父母来接。[p]

正因如此，[r]
才会陷入孤身一人、易被袭击的境地。[p]

这种状况……如果是有人[font color="0xf08080"][playse  volume="20" buf="0" storage="sariin.ogg" ][r]
怀着恶意[resetfont]刻意设计的。[wait time="500"][r]
那恐怕——[p]
[mask]
[bg storage=./school/croom_m.jpg time="10"]
[chara_show name="sarasa" face="closeEye" top="-160" time="10" left="360"]
[chara_show name="ituki" face="sad" top="-160" left="-70" time="10"]
[free_filter]
#sarasa
[mask_off time="1000"]
（……虽然痛苦，但那天的一树[r]
可能正企图让某人「诱拐我」的假设，[r]
也无法否定）[p]
[resetdelay]
#ituki
[anim name="ituki" left="-=10" time=50 ]
[anim name="ituki" left="+=10" time=50 ]
喂……喂纱罗纱！你倒是说点什么啊！[p]

#sarasa:normal
…………[p]
[delay speed="60"]
#
——看到树月为我担忧的模样，[r]
就更难以开口说出真相了。[p]
继上次在蔟之日之后，[r][wait time="500"]
[delay speed="100"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
明明是想忘却的记忆，却要亲手再次挖开……[p]
[fadeoutbgm time="3000"]
[delay speed="50"]
#sarasa:closeEye
……没、没事的[p]
#sarasa:smile
因为那时候……[wait time="500"]贤治郎先生救了我。[r]
所以、我才没事的……[p]

#ituki:tweet
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=ituki keyframe=up time=300 wait="false"]
[playse  volume="20" buf="0" storage="sariin.ogg" ]
……啊、那个和尚……？[p][stop_kanim name=树]


#ituki:tweetB
……………………………………[p]
[chara_hide name="sarasa" wait="false" pos_mode="false"]
[chara_show  name="aki" left=250 top=-100 face="normal" wait="false"]
[chara_move  name="ituki" left=490  anim="false" wait="false"]
[chara_show  name="riki" face="sad" left=-70 top=-100 wait="false"]
#hino
[chara_show  name="hino" face="sad" left=-230 top=-100 wait="false"]
绕来绕去、话题又[fadeinbgm storage=gymnopedies2.ogg loop=true time=3000 volume=50]
回到了贤治郎先生身上啊[p]
[chara_mod name="ituki" face="angry"]
[resetdelay]
#riki:hate
那家伙啊、自从蔟祭那天之后就阴沉过头了[r]
连志户田都没法和他正常交流了吧？[wait time="500"][r]
明明正祭只剩两天了、真的没问题吗[p]

#sarasa
说不上话、不如说……[r]
根本就不是能正常对话的状态……[p]

#aki
最后连当天的游行队伍都没来参加[p]

#hino:angry
不、不至于吧……他可是祭主啊[p]

#hino:tweet
……但是，[wait time="500"]
#hino:sad
……唔……[p]
[delay speed="60"]
[font color="0xf08080"]
#
看着日野欲言又止的样子，[r]
我已然明白他想说什么。[p][resetfont]
#hino
——既、既然贤治郎先生被证实是眷属……[r][wait time="500"]
需要考虑的事情是，……[p]

#hino
如果他已经被授予了祝福[r][wait time="500"]
他　[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
会被诅咒的啊……[p]

#sarasa
………………[p]
[resetdelay]
#aki:tweet
嘛　他就是因为害怕这个　才躲着的吧[r]
纱罗纱那孩子[p]
[delay speed="50"]
#sarasa
……[r]
虽然心里明白、可是……[p]

#sarasa
总觉得……[wait time="500"]比起可能会被诅咒的贤治郎先生袭击这件事，[r]
贤治郎先生状态异常才更让我放心不下……[p]

#aki:wow
诶？[l][r]
[resetdelay]
#aki:smile
现在的纱罗纱简直就像在谈恋爱一样。[r]
难道你喜欢上贤治郎先生了？[p]

#ituki:tweetB
[playse  volume="40" buf="0" storage="shimeage.ogg" ]
哈？[p]
[delay speed="50"]
#hino:shame
[anim name="hino" top="+=30" time="150"]
[anim name="hino" top="-=30" time="150"]
呜哇……[wait time="500"]树月、快按住他、快按住啊。[p]
#hino:smile
那个那个、志户田。[delay speed="100"][wait time="500"]
[playse  volume="20" buf="0" storage="kakan.ogg" ]
……你是在单相思吗？[p]
#hino:tweet
#sarasa
诶……？[p]
[delay speed="60"]
喜欢……怎么说呢……。[r][wait time="500"]
确实、[r]
在人类当中应该算是帅气的类型吧……[p]
[resetdelay]
#riki:normal
你的审美标准范围到底有多宽啊？[p]
[delay speed="60"]
#sarasa
……想要更多地了解这个人，[r]
如果这种心情就叫做喜欢的话……[p]
我……[wait time="500"]也深爱着这里的每一个人……[p]
[playse  volume="30" buf="0" storage="kansei.ogg"]
#ituki:smileCE
纱罗纱……[p]

#riki
这不是阿拉伯后宫国王的经典台词嘛[p]

#aki:sad
切～真没劲。[r]
那贤治郎先生就算被诅咒了你也不在乎咯？[p]
[font size="40"]
#hino:smile
器乐堂他[r]
你这有点过度曲解我的话了吧！[p]
[resetfont]
[delay speed="100"]
#riki:normal
………………………………………………[l][r]
#riki:tweetLA
………………[l][r]
#riki:shame
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[resetdelay]
……唔————！！[p]
#aki:tweet
啊咧 怎么了登利君。[r]
你这不是一副很想说什么的样子嘛[p]
#riki:angry
[playse  volume="20" buf="0" storage="kakan.ogg" ]
[keyframe name=up]
[frame p=25% y=50 ]
[endkeyframe]
[kanim name=riki keyframe=up time=300 wait="false"]
管他是眷属还是被诅咒，[r]
只要把暗御津羽神封印掉就完事了[r]
全部解决不就行了吗！？？[p][stop_kanim name=riki]

#aki:wow
哇 一进来就火气这么大[p]
[font size="40"]
#riki:angry
因为啊————！[p][resetfont]
#riki:worry
贤治郎怎么着 眷属怎么着 根本不用想这么多乱七八糟的，[r]
只要把下诅咒的暗御津羽神干掉[r]
不就万事大吉了吗？？！？[p]
#riki:shoutG
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
[anim name="riki" left="-=10" time=50 ]
[anim name="riki" left="+=10" time=50 ]
所以说啊、现在只要考虑封印的事就行啦！！[r]
只要考虑怎么才能完成封印就行啦！！[p][resetfont]

#aki:worry
你生什么气啊？[p]

[font size="40"]
#riki:shame
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
连在学校里都要[r]
老子不想被这些破事烦心啊！！！[p][resetfont]　
[delay speed="50"]

#
……或许登利说得对。[p]
[chara_hide_all]
说到底，究竟是谁……烧毁了【封印绢布】。[l][r]
那个人为何[r]
会知道马门家世代秘藏的祠堂位置？[p]
[delay speed="60"]
贤治郎先生又为什么……[r]
难道他忘记了自己曾是眷属的身份？[p]
[chara_show name="sarasa" top="-160" wait="false" face="closeEye"]
#sarasa
（需要考虑的事情实在太多、太多了……[r][wait time="500"]
	总之，只要能成功封印御黑目鬼……）[p]
#sarasa:normal
（我和贤治郎先生也就不用像现在这样……[r][wait time="500"]
被小镇和自身的真相所困扰）[p]
[delay speed="50"]
#
果然还是该[font color="0xf08080"][playse  volume="20" buf="0" storage="sariin.ogg" ]
以获取封印方法[resetfont]为最优先事项行动。[p]
[bg storage="brack.png" time="2000" wait="false"]
纪伊玛莉甘曾在我们寻求封印知识时，[r]
之前一直建议我们阅读狮心教的『茧之典』……[p]

那本『茧之典』中记载的是，[r]
[font color="0xf08080"]宗方家与志户田家的秘密协定[resetfont]。[p]
也就是说，[r]
封印的秘密就隐藏在这两家的关系之中吗？[p]
[chara_mod name="sarasa" face="closeEye"]
[delay speed="80"]
——啊，不，或者说……[p]
[delay speed="50"]
[playse storage=page.ogg volume="50"]
[clearfix]
[position layer="message0" left=15 top=30 width=930 height=650 visible=true]
[font color="0xb0c4de"]
[r]
[r]
[r]
由宗方家选出的三位巫女若与[r]
志户田家产生疏离[r]
则严禁利用这一事实进行接触[r][wait time="500"]
[r]
[r]
[delay speed="120"]
马门神社神主　马门审四郎[p][resetfont]
[bg storage=./school/croom_m.jpg wait="false" cross="false"]
[playse storage=page.ogg volume="50"]
[position layer="message0" left=15 top=510 width=930 height=190 visible=true]
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#sarasa
（……志户田家、宗方家……还有马门家，这三家之间……[wait time="500"][r]
莫非藏着什么秘密？）[p]
[chara_hide name="sarasa" wait="false" time="300"]
@layopt layer=message0 visible=false
[clearfix]
;ＳＥガラガラ
[playse  volume="70" buf="0" storage="hikidopen2.ogg"]
[wse]
[chara_show name="nyudo" top="-100" face="normal" wait="true"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]
#nyudo
…………………………[p]
[resetdelay]
[chara_hide name="nyudo" time="10"]
[chara_show name="aki" top="-100" left="-150" wait="false" face="normal"]
[chara_show name="hino" top="-100" left="100" wait="false" face="normal"]
#riki
[chara_show name="riki" top="-100" left="400" wait="false" face="normal"]
啊，是永海酱啊[p]

#nyudo
…………………………[p]

#riki:smile
正在东张西望呢[p]

#nyudo
……………………[playse  volume="20" buf="0" storage="sariin.ogg" ]！[p]
[playse storage=run.ogg volume="10" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="20" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="30" sprite_time="0000-0300"]
[wait time="300"]
[playse storage=run.ogg volume="40" sprite_time="0000-0300"]
#riki:hate
哇、往这边来了[p]

#ituki
别 说什么哇啊的[p]
[chara_hide_all time="10"]
[chara_show name="nyudo" face="normal" top="-100" wait="false"]
#nyudo
你们……看起来精神不错呢……[p]

#aki
既然看起来这样 那都是因为平时[r]
习惯了粉饰外表的功劳啊[p]
[font size="40"]
#hino
[playse  volume="30" buf="0" storage="kaminari.ogg"]
[quake time="30"]
怎么回事啊 特意跑到2年1班的教室来！[r][resetfont]
地质研究会有什么问题吗？ 入道老师！！[p]
[delay speed="60"]
#nyudo:angryB
噫……不是的、不是这样的……[l][r]
#nyudo:normal
我、给大家带来了……[wait time="500"][playse  volume="20" buf="0" storage="sariin.ogg" ]
一份留言[p]

#ituki
留言……？谁托你带的啊[p]

#nyudo:normal
…………………………[p]

#nyudo:smile
呵……呵呵……[p]

#nyudo
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
[anim name="nyudo" left="-=10" time=50 ]
[anim name="nyudo" left="+=10" time=50 ]
呵呵、呵呵呵……[wait time="1000"][playse  volume="20" buf="0" storage="kakan.ogg" ]
是纪伊玛莉甘小姐[p]

[chara_hide name="nyudo" time="10"]
#
[font size="40"]
[chara_show  name="ituki"  left=490 top=-160 wait="false" face="tweet"]
[chara_show  name="aki" left=250 top=-100 wait="false" face="wow"]
[chara_show  name="riki" face="wow" left=-70 top=-100 wait="false"]
[chara_show  name="hino" face="shame" left=-230 top=-100 wait="false"]
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
[stopbgm]
！！[p][resetfont]
[resetdelay]
#aki:tweet
——她说什么？[p]
[delay speed="70"]
#
……随着阿奇率先开口，[r]
所有人的视线都集中在入道身上。[p]
[chara_hide_all time="10"]
[chara_show name="nyudo" top="-100" face="normal" wait="false"]
#nyudo:normal
那个…………………………[p]
[font color="0xf08080"]
#nyudo:closeEye
如果抓到了追踪我的人[r]
就让宗方树夺取他的记忆然后放走”[p]

让那个男人和你们之间[l][r]
[delay speed="100"]
当作什么都没发生过”[p][resetfont]
#nyudo:normal
说……………………[p]

#aki
……[p]

#riki
……性、性命？[p]
[resetdelay]
#ituki
——完全听不懂。[l][r]
连我的祝福能力，那个女人[wait time="500"]都知道吗？[p]
#hino
……我这边，从前几天开始——[r][wait time="500"]
就一直联系不上马利根小姐。[p]

入道老师是从马利根小姐那里[r]
什么时候的事？[p]
[delay speed="60"]
#nyudo:normal
哎呀……我和她几小时前才见过面……[p]

#nyudo:closeEye
毕竟……[r][wait time="800"]
她说今早就要离开这个小镇了[p]
[chara_hide time="10" name="nyudo"]
[chara_show name="sarasa" top="-160" wait="false" face="wow" time="100"]
[font size="40"]
#sarasa
[playse  volume="100" buf="0" storage="punch.ogg" sprite_time="0500-30000"]
……诶！？[p][resetfont]
[delay speed="60"]
那……那么说[wait time="500"]关于奥露姆克的封印和小镇的秘密[r]
[wait time="500"]
本该最接近真相的她已经………………[p]
不在这个[wait time="500"]小镇了，[p]
#
[resetdelay]
[mask time="100"]
[chara_hide name="sarasa" time="10"]
[bg storage="brack.png" time="10" wait="false"]
[playbgm storage=sicilienne.ogg loop=true volume=30]
[font color="0xf08080"]
[mask_off time="100"]
无论如何挣扎，时间都不会停止。[r]
说到底，从女人胯下诞生的我们，终究无能为力。[p]
[delay speed="100"]
来吧，马上就要正式开始了。[r]
即便什么都没解决，正式演出也要开始了。[p]
[resetfont]
[delay speed="50"]
……从阿奇手中解脱，夺走树月数日完整记忆的，[r]
那个男人的外表。[p]
@layopt layer=message0 visible=false
[clearfix]
[chara_show name="mokke" face="ojisan" top="100" wait="true" time="4000"]
[wait time="2000"]
@layopt layer=message0 visible=true
[button x=850 y=340 fix="true" role="backlog" folder="image" graphic="button/log.png"]
[button x=850 y=420 fix="true" role="sleepgame" folder="image" target="*tiplist" graphic="button/item_menu.png"]

——与那天[wait time="500"]袭击我的可疑人物相貌[wait time="500"]
并不相同。[p]
@layopt layer=message0 visible=false
[clearfix]
[wait time="2000"]
[chara_hide name="mokke" wait="false" time="1000"]
[playse  volume="40" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="30" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="20" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wse]
[playse  volume="10" sprite_time="0000-0700" buf="0" storage="walk_rouka.ogg" ]
[wait time="3000"]
[playse  volume="50" buf="0" storage="sariin.ogg" ]
[bg storage="still/gimon.png" time="2000" wait="true"]
[p]
[playse storage=tapSE.ogg sprite_time="0000-2000" volume="50"]

[fadeoutbgm time="2000"]
[showsave]
@jump storage="chapter_5/day1_vol2.ks"

;サブルーチン
;---------------------------------------------------------
*Sub_hover
;---------------------------------------------------------
[iscript]
$("span[style^=cursor]").hover(
function() {
$(this).css("color", "#96C3DB");
},
function() {
  $(this).css("color", "#ffffff");
　}
);
[endscript]
[return]
;--------------------------------------------------------

[s]
;tipプラグイン
*tiplist
[tip_list]
[s]
