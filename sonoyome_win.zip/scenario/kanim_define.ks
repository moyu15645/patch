;このゲームで使用するキーフレームアニメを宣言

;頷く
[keyframe name="unazuki0"]
[frame p=50%  y="15" ]
[frame p=100%  y="0" ]
[endkeyframe]

[keyframe name="unazukiA"]
[frame p=50%  y="20" ]
[frame p=100%  y="0" ]
[endkeyframe]

[keyframe name="unazukiU"]
[frame p=50%  y="30" ]
[frame p=100%  y="0" ]
[endkeyframe]

;首振り
[keyframe name="kubihuri0"]
[frame p=50%  x="10" ]
[frame p=100%  x="0" ]
[endkeyframe]

[keyframe name="kubihuriA"]
[frame p=50%  x="15" ]
[frame p=100%  x="0" ]
[endkeyframe]

[keyframe name="kubihuriU"]
[frame p=50%  x="20" ]
[frame p=100%  x="0" ]
[endkeyframe]

;びっくり
[keyframe name="bikkuri0"]
[frame p=50%  y="-15" ]
[frame p=100%  y="0" ]
[endkeyframe]

[keyframe name="bikkuriA"]
[frame p=50%  y="-20" ]
[frame p=100%  y="0" ]
[endkeyframe]

[keyframe name="bikkuriU"]
[frame p=50%  y="-30" ]
[frame p=100%  y="0" ]
[endkeyframe]

;右に走る
[keyframe name="run_right0"]
[frame p=100%  x="200" opacity="0"]
[endkeyframe]

[keyframe name="run_rightA"]
[frame p=100%  x="300" opacity="0"]
[endkeyframe]

[keyframe name="run_rightU"]
[frame p=100%  x="400" opacity="0"]
[endkeyframe]

;左に走る
[keyframe name="run_left0"]
[frame p=100%  x="-200" opacity="0"]
[endkeyframe]

[keyframe name="run_leftA"]
[frame p=100%  x="-300" opacity="0"]
[endkeyframe]

[keyframe name="run_leftU"]
[frame p=100%  x="-400" opacity="0"]
[endkeyframe]

;ロゴ回転
[keyframe name="logo_rot"]
[frame p=0% scale=0 rotate=-240]
[frame p=100% scale=1 rotate=0]
[endkeyframe]

[return]