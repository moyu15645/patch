*start
*sana22
;第２２節
;[eval exp="f.loveS=100"]
;[eval exp="f.hiroine=1"]
;BGM再生
[playbgm  loop="true"  storage="07serious.mp3" sprite_time="32250-112250"  restart="false"]

;背景：カフェ
[bg time="1000" wait="true" method="fadeIn" storage=BG_CAFE_01A.jpg]

;メッセージウインドウ表示
[layopt layer=message0 visible=true ]
[layopt layer="fix" visible="false" ]
[anim layer="message0" opacity=0 time=0]
[anim layer="message0" opacity=255 time=500]
[layopt layer="fix" visible="true" ]
[wait time=350]

;ボイス設定
[voconfig sebuf=1 name="sana" vostorage="_voice/sana/S0{number}.mp3" number=623 ]
[voconfig sebuf=1 name="freesia" vostorage="_voice/freesia/T0{number}.mp3" number=187 ]
[voconfig sebuf=1 name="ayaka" vostorage="_voice/ayaka/H0{number}.mp3" number=313 ]
[voconfig sebuf=1 name="akira" vostorage="_voice/akira/X0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ami" vostorage="_voice/ami/A0{number}.mp3" number=101 ]
[voconfig sebuf=2 name="hibiki" vostorage="_voice/hibiki/B0{number}.mp3" number=216 ]
;[voconfig sebuf=1 name="ane" vostorage="_voice/ane/L0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="shima" vostorage="_voice/shima/O0{number}.mp3" number=251 ]
[vostart]
[voice_repeat_on]
;立ち絵：彩永
[chara_part  name="sana"  face="ATJ"  body="A04" ]
[chara_show  name="sana"  wait="true" time="600" zindex="1" left="200" top="80" width="1200"]
[akira]
「请同意我和彩永的婚约」[p]
[none]
[playse buf=1 storage=_voice/hukugou/Z0112.mp3 loop=false ]
[xanim keyframe="unazuki0" name="sana" count="1" time="800" easing="linear" ]
#akirasena
「求您了」[p]
[none]
#haha
「不行」[p]
[none]
#titi
「你不再重新考虑一下吗？」[p]
[akira]
「考虑多少次都不会改变」[p]
[none]
#haha
「组建家庭和养育孩子[r]
可不是一般的辛苦哦？」[p]
[none]
#titi
「妈妈说得对」[p]
[xanim keyframe="unazuki0" name="sana" count="1" time="400" easing="linear" ]
[sana]
「不管有什么困难，只要想办法总能克服。[r]
我绝不会放弃」[p]
[none]
#haha
「我一个人撑起这个家，所以完全明白其中的艰辛。[r]
你做不到的」[p]
[none]
#titi
「我好歹也——」[p]
[none]
#haha
「爸爸你别插嘴」[p]
[akira]
「我有决心一辈子支持彩永」[p]
[none]
#haha
「嘴上说说当然容易，这让我怎么相信」[p]
[akira]
「我们之前不也都好好克服过来了吗」[p]
[none]
#haha
「可你们毕竟还是孩子。没有妈妈们照顾的话[r]
根本活不下去的吧？」[p]
[akira]
「所以我要搬出去住」[p]
[none]
#haha
「哎！？难道你要寄人篱下！？」[p]
[akira]
「不是。我要去大月小姐工作的福利院[r]
住宿舍上班」[p]
[none]
#haha
「那不就是初中辍学吗！？」[p]
[none]
#titi
「光凭一时冲动决定未来可不好啊？」[p]
[akira]
「毕业资格随时都能取得。现在我只想为将来[r]
培养能支持彩永的力量」[p]
[none]
#haha
「你就不怕被周围人用异样眼光看待吗？」[p]
[akira]
「放眼四周的话，也会有人愿意伸出援手哦？」[p]
[none]
#haha
「即便如此我也不会批准伴侣制度」[p]
[akira]
「那我就单方面解除伴侣制度」[p]
[none]
#haha
「诶！？」[p]
[akira]
「不是因为被谁规定才这么做。[r]
我是凭自己的意志选择彩永的」[p]
[xanim keyframe="unazuki0" name="sana" count="1" time="400" easing="linear" ]
[sana]
「我也是凭自己的意志选择诚的」[p]
[none]
#haha
「就是这丫头把诚害成这样的！！」[p]
[none]
;BGM再生
[playbgm  loop="true"  storage="05fiting.mp3" sprite_time="27042-108169"  restart="false"]
;フェイス：綾華
[chara_part  name="ayaka"  face="ATJ"  body="A01" ]
[chara_show  name="ayaka"  wait="true" time="600" left="-385" top="560" layer="message0" zindex="1000" width="1100"]
[chara_part  name="sana"  face="AOD"  ]
;[xanim keyframe="kubihuri0" name="ayaka" count="2" time="400" easing="linear" direction=alternate]
[ayaka]
「这话不对吧？」[p]
[none]
;キャラ削除
[chara_hide_all  wait="true"  time="600"  layer="message0"]
;フェイス：響
[chara_part  name="hibiki"  face="AEG"  body="A01" ]
[chara_show  name="hibiki"  wait="true" time="600" left="-385" top="525" layer="message0" zindex="1000" width="1100"]
;[xanim keyframe="unazuki0" name="hibiki" count="1" time="400" easing="linear" ]
[hibiki]
「这家伙本来就这样啦？」[p]
[none]
;キャラ削除
[chara_hide_all  wait="true"  time="600"  layer="message0"]
;フェイス：堤
[chara_part  name="freesia"  face="ADY"  body="A01" acce="none"]
[chara_show  name="freesia"  wait="true" time="600" left="-385" top="560" layer="message0" zindex="1000" width="1100"]
;[xanim keyframe="bikkuri0" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「是！！」[p]
[none]
;キャラ削除
[chara_hide_all  wait="false"  time="600"  ]
[chara_hide_all  wait="true"  time="600"  layer="message0"]
;立ち絵：堤
[chara_part  name="freesia"  face="ATJ"  body="A01" ]
[chara_show  name="freesia"  wait="false" time="600" zindex="2" left="-250" top="80" width="1200"]
;立ち絵：綾華
[chara_part  name="ayaka"  face="ATJ"  body="A01" ]
[chara_show  name="ayaka"  wait="false" time="600" zindex="1" left="200" top="80" width="1200"]
;立ち絵：響
[chara_part  name="hibiki"  face="ATJ"  body="A01" ]
[chara_show  name="hibiki"  wait="true" time="600"  zindex="2" left="650" top="-10" width="1250"]
[akira]
「为什么大家都在这里？」[p]
[chara_part  name="hibiki"  face="AEG" ]
[xanim keyframe="bikkuri0" name="hibiki" count="1" time="400" easing="linear" ]
[hibiki]
「搭档，这可不兴说啊」[p]
[chara_part  name="ayaka"  face="AAK"  ]
[xanim keyframe="unazuki0" name="ayaka" count="1" time="800" easing="linear" ]
[ayaka]
「是樱庭君叫我们来的吧？」[p]
[chara_part  name="freesia"  face="AIK"  ]
[xanim keyframe="bikkuri0" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「APP有通知！」[p]
[akira]
（肯定是阿米小姐！）[p]
[none]
#haha
「你们懂什么？」[p]
[chara_part  name="hibiki"  face="ATJ" ]
[xanim keyframe="unazuki0" name="hibiki" count="1" time="800" easing="linear" ]
[hibiki]
「我倒要问问你们为啥不明白？诚一旦决定就不会回头[r]
你不是他母亲吗？」[p]
[chara_part  name="ayaka"  face="ADY"  ]
[xanim keyframe="kubihuri0" name="ayaka" count="2" time="600" easing="linear" direction=alternate]
[ayaka]
「与其这样推开他，不如承认[r]
「这破制度倒是挺精明的嘛？」[p]
[chara_part  name="freesia"  face="ADY"  ]
[xanim keyframe="bikkuri0" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「这么登对的未婚妻上哪儿找啊！」[p]
[none]
#haha
「外人别在这说风凉话！」[p]
[none]
;キャラ削除
[chara_hide  name="ayaka"  wait="true"  time="600"  ]
;立ち絵：大月
[chara_part  name="shima"  face="AIK"  body="A01" ]
[chara_show  name="shima"  wait="true" time="600" zindex="3" left="200" top="80" width="1200"]
[xanim keyframe="bikkuri0" name="shima" count="1" time="400" easing="linear" ]
[shima]
「不是外人。我们是樱庭君的'伙伴'哟」[p]
[none]
#haha
「这种伙伴对诚来说——」[p]
[none]
;BGM：停止
[stopbgm]
#titi
「诚交到了很好的伙伴呢」[p]
[none]
;BGM再生
[playbgm  loop="true"  storage="08romantic.mp3" sprite_time="22941-95294"  restart="false"]
#haha
「爸！？」[p]
[none]
;キャラ削除
[chara_hide  name="shima"  wait="true"  time="600"  ]
;立ち絵：彩永
[chara_part  name="sana"  face="ATJ"  body="A04" ]
[chara_show  name="sana"  wait="true" time="600" zindex="3" left="200" top="80" width="1200"]
#titi
「孩子他妈，差不多该认可他们了吧？」[p]
[none]
#haha
「爸爸你懂什么！？」[p]
[none]
#titi
「什么都没搞明白的是我们这些当父母的」[p]
[none]
#haha
「！？」[p]
[none]
#titi
「诚长成好男人了啊」[p]
[akira]
「都是爸爸妈妈的功劳」[p]
[none]
#haha
「……要把大学读完」[p]
[akira]
「诶？」[p]
[none]
#haha
「好好用功考上好大学。[r]
在那之前妈妈会替你保密的」[p]
[akira]
「妈妈……！」[p]
[none]
#haha
「彩永酱她——」[p]
[none]
#haha
「要当个称职的母亲。[r]
谁都想早点抱上孙子呀」[p]
[preload storage="./data/bgm/09ed.mp3"]
[chara_part  name="sana"  face="AEG"  ]
[xanim keyframe="unazuki0" name="sana" count="1" time="400" easing="linear" ]
[sana]
「好！」[p]
[none]
母亲露出了略带不甘、却又如释重负般的[r]
柔和表情。[p]
[none]
[xanim keyframe="unazuki0" name="sana" count="1" time="400" easing="linear" ]
[playse buf=1 storage=_voice/hukugou/Z0113.mp3 loop=false ]
#akirasena
「谢谢您」[p]
[none]
[fadeoutbgm time=1000]
母亲靠着父亲的肩头离开了店铺。[p]

[eval exp="f.loveS+=1"]
[if exp="f.loveS>=90"]
[eval exp="f.sp=[0,28,14,0,0,1,1,1,6,2]"]
[else]
[eval exp="f.sp=[0,28,14,0,0,1,1,1,5,2]"]
[endif]
[if exp="f.loveS==100"]
[eval exp="sf.compS=1"]
[endif]

;BGM再生
[playbgm  loop="true"  storage="09ed.mp3" restart="false"]
;キャラ削除
[chara_hide  name="freesia"  wait="true"  time="600"  ]
;立ち絵：綾華
[chara_part  name="ayaka"  face="AAK"  body="A01" ]
[chara_show  name="ayaka"  wait="true" time="600" zindex="2" left="-250" top="80" width="1200"]
[xanim keyframe="unazuki0" name="ayaka" count="1" time="800" easing="linear" ]
[ayaka]
「樱庭君的父母真是不得了的人呢」[p]
[akira]
「是吗？多亏他们才有现在的我」[p]
[chara_part  name="hibiki"  face="AEG2" ]
[xanim keyframe="bikkuri0" name="hibiki" count="1" time="400" easing="linear" ]
[hibiki]
「以后还能上同一所高中呢，搭档！」[p]
[none]
;キャラ削除
[chara_hide  name="ayaka"  wait="true"  time="600"  ]
;立ち絵：堤
[chara_part  name="freesia"  face="AEG2"  body="A01" ]
[chara_show  name="freesia"  wait="true" time="600" zindex="2" left="-250" top="80" width="1200"]
[xanim keyframe="bikkuri0" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「又能一起活动了！」[p]
[none]
;キャラ削除
[chara_hide  name="hibiki"  wait="true"  time="600"  ]
;立ち絵：大月
[chara_part  name="shima"  face="AEG"  body="A01" ]
[chara_show  name="shima"  wait="true" time="600" left="650" top="80" width="1200"]
[xanim keyframe="unazuki0" name="shima" count="1" time="400" easing="linear" ]
[shima]
「如果将来想就业的话随时欢迎过来」[p]
[akira]
「大家！谢谢你们！」[p]
[chara_part  name="sana"  face="AEG2"  ]
[xanim keyframe="unazuki0" name="sana" count="1" time="400" easing="linear" ]
[sana]
「诚也谢谢你」[p]
[akira]
「嗯，彩永也谢谢你」[p]
[none]
;キャラ削除
[chara_hide  name="shima"  wait="true"  time="600"  ]
;立ち絵：響
[chara_part  name="hibiki"  face="AEG"  body="A01" ]
[chara_show  name="hibiki"  wait="true" time="600"  zindex="2" left="650" top="-10" width="1250"]
[xanim keyframe="bikkuri0" name="hibiki" count="1" time="400" easing="linear" ]
[hibiki]
「那咱们开庆功宴吧！就当是订婚宴」[p]
[none]
;キャラ削除
[chara_hide  name="freesia"  wait="true"  time="600"  ]
;立ち絵：堤
[chara_part  name="ayaka"  face="AEG"  body="A01" ]
[chara_show  name="ayaka"  wait="true" time="600" zindex="2" left="-250" top="80" width="1200"]
[xanim keyframe="unazuki0" name="ayaka" count="1" time="800" easing="linear" ]
[ayaka]
「本来是打算庆祝出院的呢」[p]
[none]
;キャラ削除
[chara_hide  name="sana"  wait="true"  time="600"  ]
;立ち絵：堤
[chara_part  name="freesia"  face="AAK"  body="A01" acce="none"]
[chara_show  name="freesia"  wait="true" time="600" zindex="3" left="200" top="80" width="1200"]
[xanim keyframe="bikkuri0" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「突然被卷进修罗场可饶了我吧」[p]
[akira]
「大家对不起。但你们能赶来我真的超开心」[p]
[chara_part  name="hibiki"  face="AEG2" ]
[xanim keyframe="bikkuri0" name="hibiki" count="1" time="400" easing="linear" ]
[hibiki]
「这不是应该的吗搭档！服务员麻烦点单！」[p]
[none]
我们举行了订婚庆祝。人数份的整层蛋糕和[r]
派对餐盘在餐桌上摆好了。[p]

[if exp="f.loveS>=90"]
;キャラ削除
[chara_hide_all  wait="true"  time="1000"  ]
;立ち絵：彩永
[chara_part  name="sana"  face="AEG"  body="A04" ]
[chara_show  name="sana"  wait="true" time="600" zindex="1" left="0" top="0" width="1600"]
[xanim keyframe="bikkuriA" name="sana" count="1" time="400" easing="linear" ]
[sana]
「诚，现在提交申请吧？」[p]
[akira]
「嗯，这就是最终决定了」[p]
[none]
[chara_move  name="sana" time="1200" anim="true" left="-250" top="0" width="1600" height="2250" effect="easeInOutQuad" wait="true"]
[clearfix name="machera"]
;マチェラ起動;イラスト：スマホの枠
[playse buf="0" storage="se/slidein.mp3" ]
[image name="smartphone" time="0"  storage="sumartphone/sy_item01_00.png"  visible="true"  x="700"  y="300"  clickable_img=""  layer="2" zindex=1005]
[image name="smartphone" time="0"  storage="sumartphone/sy_item01_08.png"  visible="true"  x="700"  y="300"  clickable_img=""  layer="2" zindex=1006]
[image name="smartphone2" time="0"  storage="sumartphone/button_keizoku.png"  visible="true"  x="700"  y="300"  clickable_img=""  layer="2" zindex=1007]
[image name="smartphone" time="0"  storage="sumartphone/name_sana.png"  visible="true"  x="700"  y="300"  clickable_img=""  layer="2" zindex=1010]
[image name="smartphone2" time="0"  storage="sumartphone/commentC14.png"  visible="true"  x="700"  y="300"  clickable_img=""  layer="2" zindex=1007]
[anim name="smartphone" time=0 opacity=0 ]
[anim name="smartphone" time=800 top=0  opacity=255 ]
[anim name="smartphone2" time=0 opacity=0 ]
[anim name="smartphone2" time=800 top=0  opacity=255 ]
[wait time=800]
[akira]
（咦，阿米小姐不见了）[p]
[chara_part  name="sana"  face="ATJ"  ]
[sana]
「怎么了？」[p]
[akira]
「唔、没什么」[p]
[chara_part  name="sana"  face="AEG"  ]
[xanim keyframe="bikkuriA" name="sana" count="1" time="400" easing="linear" ]
[sana]
「那开始咯！」[p]
[none]
[button  target="link2" graphic="../fgimage/sumartphone/button_keizoku_off.png" enterimg="../fgimage/sumartphone/button_keizoku_active.png" x=851 y=265 width=398 height=90]
[playse buf=1 storage=_voice/hukugou/Z0114.mp3 loop=false ]
[chara_part  name="sana"  face="AEG2"  ]
[xanim keyframe="unazukiA" name="sana" count="1" time="800" easing="linear" ]
#akirasena
「预备——」
[s]
*link2
[none]
[playse buf="0" storage="se/decision5.mp3" ]
[cm]
[er]
[free layer=2 name="smartphone2" time=0]
[image name="smartphone" time="0"  storage="sumartphone/button_keizoku_ok.png"  visible="true"  x="700"  y="0"  clickable_img=""  layer="2" zindex=1010]
[image name="smartphone" time="0"  storage="sumartphone/commentS02.png"  visible="true"  x="700"  y="0"  clickable_img=""  layer="2" zindex=1010]
[image name="smartphone" time="200"  storage="sumartphone/sy_item01_09.png"  visible="true"  x="700"  y="0"  clickable_img=""  layer="2" zindex=1009]
[wait time=1500]
[freeimage layer=2 time=1000 wait=false]
[eval exp="f.sp=[0,28,21,0,0,1,1,1,7,2]"]

[endif]

[none]
[vostop]

;キャラ削除
[chara_hide_all  wait="false"  time="1000"  ]

;////メッセージウィンドウ削除////
[anim layer="message0" opacity=255 time=0]
[anim layer="message0" opacity=0 time=500]
[wait time=50]
[layopt layer="fix" visible="false" ]
[wait time=450]
[voice_repeat_clear]
[cm]
;
;BGM停止
;[fadeoutbgm  time="1000"  ]
;
;背景：削除
[bg  time="1500" wait="true" method="fadeIn"  storage="VISUAL_BLACK.png"  ]
[wait time="500"]

;ED
[call storage="ed.ks"]

[if exp="f.loveS>=90"]
[jump storage="S23.ks" target="start"]
[else]
[bg  time="2000" wait="true" method="fadeIn"  storage="VISUAL_BLACK.png"  ]
[eval exp='location.href = "./index.html"']
[endif]
[s]
