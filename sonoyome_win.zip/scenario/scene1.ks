;いよいよ、その許嫁は初恋を知らないが開始されます。

*start

[cm  ]
[clearfix]
[start_keyconfig]

;メッセージウィンドウの設定
[position layer="message0" left=0 top=580 width=1600 height=320 page=fore visible=false ]

;文字が表示される領域を調整
[position layer=message0 page=fore frame="MessageWindow.png" margint="110" marginl="300" marginr="160" marginb="60"]

;キャラクターの名前が表示される文字領域
[ptext name="chara_name_area" layer="message0" color="0x423852" size=34 bold="false" x=357 y=659  face=""]

;上記で定義した領域がキャラクターの名前表示であることを宣言（これがないと#の部分でエラーになります）[p]
[chara_config ptext="chara_name_area"]

;ボイスリピート設定
[voice_repeat_config x=301 y=654]

;イニシャルメニューボタン非表示
[hidemenubutton]

;モノローグ用メッセージウィンドウメニュー設定
[button role="fullscreen" graphic="BlankChip.png" x="495" y="845" width="170" height="50" visible="false" ]
[button role="backlog" graphic="BlankChip.png" x="666" y="845" width="140" height="50" visible="false" ]
[button role="save" graphic="BlankChip.png" x="807" y="845" width="105" height="50" visible="false" ]
[button role="load" graphic="BlankChip.png" x="913" y="845" width="105" height="50" visible="false" ]
[button role="auto" graphic="BlankChip.png" x="1019" y="845" width="105" height="50" visible="false" ]
[button role="skip" graphic="BlankChip.png" x="1125" y="845" width="100" height="50" visible="false" ]
[button role="sleepgame" graphic="BlankChip.png" x="1226" y="845" width="130" height="50" visible="false" storage="config.ks"]
[button role="title" graphic="BlankChip.png" x="1357" y="845" width="100" height="50" visible="false" ]
[button role="window" graphic="BlankChip.png" x="1530" y="705" width="70" height="70" visible="false" ]
[button role="sleepgame" name="machera" auto_next="false" graphic="MacheraIcon.png" x="1450" y="750" width="150" height="150" visible="false" storage="smartphone.ks"]

[deffont size="34" color="0x423852" bold="false" edge="3px 0xFFFFFF" edge_method="shadow" ]
[resetfont ]

[free layer="1" name="title00" time=1000 wait=false]
[fadeoutbgm time=2000]
[bg time="2000" wait="true" method="fadeIn" storage=VISUAL_WHITE.png]
[wait time=1000]
;[jump  storage="shortcutmenu.ks"  target=""  ]
[jump  storage="common.ks"  target=""  ]
[s]