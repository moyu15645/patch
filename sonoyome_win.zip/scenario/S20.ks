*start
*sana20
;第２０節

;BGM再生
[playbgm  loop="true"  storage="07serious.mp3" sprite_time="32250-112250"  restart="false"]

;背景：病室
[bg time="1000" wait="true" method="fadeIn" storage=BG_BYOSHITSU_01A.jpg]

;メッセージウインドウ表示
[layopt layer=message0 visible=true ]
[layopt layer="fix" visible="false" ]
[anim layer="message0" opacity=0 time=0]
[anim layer="message0" opacity=255 time=500]
[layopt layer="fix" visible="true" ]
[wait time=350]

;ボイス設定
[voconfig sebuf=1 name="sana" vostorage="_voice/sana/S0{number}.mp3" number=618 ]
;[voconfig sebuf=1 name="freesia" vostorage="_voice/freesia/T0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ayaka" vostorage="_voice/ayaka/H0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="akira" vostorage="_voice/akira/X0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ami" vostorage="_voice/ami/A0{number}.mp3" number=101 ]
;[voconfig sebuf=2 name="hibiki" vostorage="_voice/hibiki/B0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ane" vostorage="_voice/ane/L0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="shima" vostorage="_voice/shima/O0{number}.mp3" number=246 ]
[vostart]
[voice_repeat_on]
;立ち絵：大月
[chara_part  name="shima"  face="AKN"  body="A02" ]
[chara_show  name="shima"  wait="false" time="600" left="250" top="0" width="1600"]
;立ち絵：彩永
[chara_part  name="sana"  face="AKN"  body="A03" ]
[chara_show  name="sana"  wait="true" time="600" left="-250" top="0" width="1600"]
[none]
#ishi
「轻度缺氧呢」[p]
[none]
我在转送到的医院里恢复了意识。[r]
看来我们总算得救了。[p]
[none]
#ishi
「要是吸入了有毒气体就没命了吧」[p]
[none]
桌上瘫倒着一个软趴趴的毛绒玩偶。[p]
[none]
#ishi
「能这么轻症收场也是多亏了她实施的[r]
急救措施」[p]
[akira]
「是彩永救了我们」[p]
[chara_part  name="sana"  face="ATJ"  ]
[xanim keyframe="kubihuriA" name="sana" count="2" time="400" easing="linear" direction=alternate]
[sana]
「不，是诚救了我哦？」[p]
[none]
彩永将手边的白色手杖朝这边示意。[r]
那是我制作的折叠式白色手杖。[p]
[chara_part  name="shima"  face="ANK"  ]
[xanim keyframe="unazukiA" name="shima" count="1" time="800" easing="linear" ]
[shima]
「谢谢你救了彩永」[p]
[none]
;SE：カーテン
[playse buf="0" storage="se/Curtain012.mp3" ]
#haha
「诚！！」[p]
[akira]
「妈妈」[p]
[none]
#haha
「接到电话就急忙赶来了！」[p]
[akira]
「让你担心了真对不起」[p]
[none]
#haha
「能活着就足够了。看到新闻画面的时候[r]
我还以为已经没救了」[p]
[none]
;BGM停止
[stopbgm]
#ishi
「在那样的状况下能带着全盲的人逃生简直是奇迹」[p]
[none]
#haha
「诶、刚才说什么？」[p]
[chara_part  name="sana"  face="AKN"  ]
[sana]
「……是诚背着失明的我逃出来的」[p]
[none]
;BGM再生
[playbgm  loop="true"  storage="07serious.mp3" sprite_time="32250-112250"  restart="false"]
#haha
「都因为这样诚才会变成这样……都是彩永酱的错……」[p]
[chara_part  name="sana"  face="ANK"  ]
[xanim keyframe="unazukiA" name="sana" count="1" time="800" easing="linear" ]
[sana]
「对不起……」[p]
[none]
#haha
「这可不是道歉就能解决的问题！！[r]
竟然骗了妈妈……！！」[p]
[akira]
「不是的妈妈！多亏彩永提醒我异常[r]
我们才能及时逃出来」[p]
[akira]
「恐怕同层的大多数人……[r]
我只是轻微缺氧而已」[p]
[none]
#haha
「就算这样也不能原谅。你给我出去！」[p]
[chara_part  name="shima"  face="AOD"  ]
[xanim keyframe="bikkuriA" name="shima" count="1" time="400" easing="linear" ]
[shima]
「别这样！你也为彩永想想——」[p]
[none]
#haha
「快给我出去！！」[p]
[akira]
「彩永、大月小姐对不起」[p]
[none]
;SE：カーテン
[playse buf="0" storage="se/Curtain012.mp3" ]
[xanim keyframe="run_leftA" name="sana" count="1" time="800" easing="linear" ]
[xanim keyframe="run_leftA" name="shima" count="1" time="800" easing="linear" wait=false]
#haha
「和彩永酱分手吧。那孩子会让诚你不幸的」[p]
[akira]
「不是的妈妈」[p]
[akira]
「我的幸福由我自己决定」[p]
[none]
听到这句话的瞬间，母亲当场瘫坐痛哭。[p]
[none]
#haha
「明明不久前还是那么乖的孩子，为什么……」[p]
[none]
前来接应的父亲搀着母亲的肩膀，就这样离开了病房。[p]
;キャラ削除
[chara_hide_all  wait="true"  time="5"  ]
;BGM：停止
[stopbgm]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[akira]
（这样一来，我是不是就从当好孩子的束缚中解放了呢）[p]
[none]
;背景：病室
[bg time="1000" wait="false" method="fadeIn" storage=BG_BYOSHITSU_01A.jpg]
[wait time="500"]
[none]
;SE：ノック
[playse buf="0" storage="se/nock.mp3" ]
#？？？
「你好，身体感觉怎么样？」[p]
;名前表示は？？？#senahaha
[none]
临近探视时间结束时，一位访客来到了病房。[p]
[none]
;SE：カーテン
[playse buf="0" storage="se/Curtain012.mp3" ]
;BGM再生
[playbgm  loop="true"  storage="03date.mp3" sprite_time="14656-87938"  restart="false"]
#senahaha
「我是彩永的妈妈。那孩子一直承蒙你照顾」[p]
[akira]
「彩永的妈妈！？初次见面我是樱庭诚。[r]
没能去拜访您实在抱歉」[p]
[none]
#senahaha
「不用担心，诚君的事情我都从彩永那里[r]
详细听说了」[p]
[akira]
「原来是这样。彩永她还好吗？」[p]
[none]
;背景：明転
[bg time="1000" wait="false" method="fadeIn" storage=VISUAL_WHITE.png]
[wait time=500]
;立ち絵：彩永
[chara_part  name="sana"  face="ATJ"  body="A03" ]
[chara_show  name="sana"  wait="false" time="600" left="0" top="0" width="1600"]
#senahaha
「检查结果显示非常健康，根本不需要住院」[p]
[chara_part  name="sana"  face="AKN"  ]
[akira]
「太好了……但她没有消沉吧？[r]
毕竟和母亲发生了争执」[p]
[none]
;BGM再生
[playbgm  loop="true"  storage="07serious.mp3" sprite_time="32250-112250"  restart="false"]
[chara_part  name="sana"  face="ANK"  ]
#senahaha
「她哭了。对彩永来说，被周围人讨厌是件[r]
非常痛苦的事」[p]
[akira]
「彩永……要是我能早点说服母亲就好了」[p]
[none]
;キャラ削除
[chara_hide_all  wait="true"  time="600"  ]
;背景：病室
[bg time="1000" wait="false" method="fadeIn" storage=BG_BYOSHITSU_01A.jpg]
#senahaha
「其实我刚才也和您母亲谈过了」[p]
[akira]
「真的吗！？……谈得怎么样？」[p]
[none]
#senahaha
「搞砸了呢！」[p]
[none]
故意做出夸张的懊恼表情。[r]
看到这个动作不由得泄了气。[p]
[akira]
（彩永的调皮劲儿肯定是遗传自她妈妈吧）[p]
[none]
#senahaha
「弥补差距真是件不容易的事呢」[p]
[akira]
「我相信只要肯动脑筋就能填补差距」[p]
[none]
#senahaha
「呵呵，诚君和彩永描述的一模一样呢」[p]
[akira]
「彩永都说了我什么？」[p]
[none]
;BGM再生
[playbgm  loop="true"  storage="08romantic.mp3" sprite_time="22941-95294"  restart="false"]
;背景：明転
[bg time="1000" wait="false" method="fadeIn" storage=VISUAL_WHITE.png]
;立ち絵：彩永
[chara_part  name="sana"  face="AEG2"  body="A01" ]
[chara_show  name="sana"  wait="false" time="600" left="0" top="0" width="1600"]
#senahaha
「关于诚君的事她可是什么都告诉我哦？」[p]
[none]
[chara_part  name="sana"  face="AEG"  ]
[xanim keyframe="bikkuriA" name="sana" count="1" time="400" easing="linear" ]
#senahaha
「比如雕刻很棒啊，按哪里会喊疼啊，[r]
会温柔地叫我名字啊」[p]
[none]
[chara_part  name="sana"  face="ASK"  ]
#senahaha
「还有接吻时像晚霞一样让人沉醉什么的」[p]
[akira]
「连这种事都被抖出来真是羞死了」[p]
[none]
[chara_part  name="sana"  face="ASK"  body="A04" wait="false" time=600]
#senahaha
「彩永现在真的很有女孩子样。明明以前对打扮[r]
完全没兴趣的」[p]
[akira]
「是这样吗？」[p]
[none]
[chara_part  name="sana"  face="ADY"  ]
#senahaha
「以前都是我帮她整理仪表，自从遇见诚君后[r]
开始自己主动打理了」[p]
[none]
[chara_part  name="sana"  face="ASK"  ]
[xanim keyframe="kubihuriA" name="sana" count="2" time="400" easing="linear" direction=alternate]
#senahaha
「还会问『诚觉得这样奇怪吗？可爱吗？』[r]
完全是女孩子做派了吧？」[p]
[akira]
（原来她一直都在为我注意着仪表打扮啊）[p]
[none]
;キャラ削除
[chara_hide_all  wait="true"  time="600"  ]
;背景：病室
[bg time="1000" wait="false" method="fadeIn" storage=BG_BYOSHITSU_01A.jpg]
#senahaha
「连我都觉得像在谈恋爱似的。[r]
不知不觉就把诚君和我父亲重叠起来了」[p]
[akira]
「听说是在医疗设备公司工作对吧？」[p]
[none]
#senahaha
「是啊。在知道彩永眼睛看不见的那天[r]
我就辞掉了之前的工作」[p]
[none]
#senahaha
「『要去医疗设备公司，想帮上彩永的忙』[r]
挨家挨户去面试」[p]
[akira]
「真是位了不起的父亲呢。我不确定自己能做到那种程度」[p]
[none]
[image name="item"  wait=true  time="600"  storage="itemcg/sy_item11.png"  visible="true"  width="500"  height="500"  x="550"  y="110"  layer="2" zindex=1005]
#senahaha
「诚君做的白手杖，爸爸可是赞不绝口哦？」[p]
[akira]
「给他看了吗！？ 外行人做的太惭愧了」[p]
[none]
#senahaha
「『把我一直想做的事轻松实现了』[r]
「应该没那么简单吧」[p]
[none]
;イラスト削除
[free name="item" wait=true time=600 layer=2 ]
[akira]
「那我真的很开心。能用自己的方式帮上彩永的忙[r]
」[p]
[none]
#senahaha
「彩永身边都是很好的人呢」[p]
[none]
#senahaha
「玉木老师、大月小姐，还有诚君，能遇到你们[r]
那孩子真是有福气」[p]
[akira]
「我也是。托彩永的福[r]
遇到了很多美好的邂逅」[p]
[none]
#senahaha
「那孩子就拜托你们多多关照了」[p]
[akira]
「好的。我会和彩永一起幸福的」[p]
[none]
[eval exp="f.loveS+=1"]
[if exp="f.loveS>=90"]
[eval exp="f.sp=[1,26,3,0,0,1,1,1,6,1]"]
[else]
[eval exp="f.sp=[1,26,3,0,0,1,1,1,5,1]"]
[endif]
[vostop]

;////メッセージウィンドウ削除////
[anim layer="message0" opacity=255 time=0]
[anim layer="message0" opacity=0 time=500]
[wait time=50]
[layopt layer="fix" visible="false" ]
[wait time=450]
[voice_repeat_clear]
[cm]
;
;BGM停止
[fadeoutbgm  time="1000"  ]
;
;背景：削除
[bg  time="1000" wait="true" method="fadeIn"  storage="VISUAL_BLACK.png"  ]
[wait time="500"]

;アイキャッチ
[eyecatch echar="S" estory="S21" evoice="1"]

[jump storage="S21.ks" target="start"]
[s]
