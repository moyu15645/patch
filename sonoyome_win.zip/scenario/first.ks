;一番最初に呼び出されるファイル

[title name="その許嫁は初恋を知らない"]

[stop_keyconfig]

;ティラノスクリプトが標準で用意している便利なライブラリ群
;コンフィグ、CG、回想モードを使う場合は必須
@call storage="tyrano.ks"

;ゲームで必ず必要な初期化処理はこのファイルに記述するのがオススメ

;メッセージボックスは非表示
@layopt layer="message" visible=false

;最初は右下のメニューボタンを非表示にする
[hidemenubutton]

;定義
[call storage="chara_define.ks"]
[call storage="macro.ks"]
[call storage="flag.ks"]
[call storage="kanim_define.ks"]
[call storage="novecole.ks"]

;プラグイン
[plugin name=custom_ruby]
[plugin name=voice_repeat]

;BGMとSEの初期化と再設定マクロ
[macro name=bgmse_initialize]
	[iscript]
		//効果音の初期値(ここの値を変えることで初回起動時の音量の変更が可能)

		if (typeof sf.current_se0_vol == "undefined") {
			sf.current_se0_vol = 50;
		}

		if (typeof sf.current_se1_vol == "undefined") {
			sf.current_se1_vol = 50;
		}

		if (typeof sf.current_se2_vol == "undefined") {
			sf.current_se2_vol = 50;
		}
	[endscript]

	[seopt buf="0" volume="&String(sf.current_se0_vol)" effect=true]
	[seopt buf="1" volume="&String(sf.current_se1_vol)" effect=true]
	[seopt buf="2" volume="&String(sf.current_se2_vol)" effect=true]
	[seopt buf="3" volume="&String(sf.current_se0_vol)" effect=true]
[endmacro]
[bgmse_initialize]

[deffont size="34" color="0x423852" bold="false" edge="3px 0xFFFFFF" edge_method="shadow" ]
[resetfont ]

[message_config speech_bracket_float="true" speech_margin_left="true" line_spacing="25"]

;タイトル画面へ移動
@jump storage="title.ks"

[s]
