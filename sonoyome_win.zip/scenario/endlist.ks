[cm]
[clearfix]
[image layer="1" name="endlist" visible="true" storage="endlist.png" x="0" y="0" time="200" wait="false" zindex=1010]

[layopt layer="2" visible="true"]
[if exp="sf.endS1==1"]
[ptext layer="2" name="endtext" x=480 y=197 color=0x423852 time="0" size=32 text="END1　　「白谷さんが無事で良かったな」"]
[else]
[ptext layer="2" name="endtext" x=480 y=197 color=0x423852 time="0" size=32 text="END1　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endS2==1"]
[ptext layer="2" name="endtext" x=480 y=257 color=0x423852 time="0" size=32 text="END2　　「じゃあな、相棒」"]
[else]
[ptext layer="2" name="endtext" x=480 y=257 color=0x423852 time="0" size=32 text="END2　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endS3==1"]
[ptext layer="2" name="endtext" x=480 y=317 color=0x423852 time="0" size=32 text="END3　　「ラッキーエレベーターだね」"]
[else]
[ptext layer="2" name="endtext" x=480 y=317 color=0x423852 time="0" size=32 text="END3　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endS4==1"]
[ptext layer="2" name="endtext" x=480 y=377 color=0x423852 time="0" size=32 text="END4　　「ぴったりの許婚だね」"]
[else]
[ptext layer="2" name="endtext" x=480 y=377 color=0x423852 time="0" size=32 text="END4　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endT1==1"]
[ptext layer="2" name="endtext" x=480 y=492 color=0x423852 time="0" size=32 text="END1　　「堤さん、転校したってよ」"]
[else]
[ptext layer="2" name="endtext" x=480 y=492 color=0x423852 time="0" size=32 text="END1　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endT2==1"]
[ptext layer="2" name="endtext" x=480 y=552 color=0x423852 time="0" size=32 text="END2　　「誠も私のようになれ」"]
[else]
[ptext layer="2" name="endtext" x=480 y=552 color=0x423852 time="0" size=32 text="END2　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endT3==1"]
[ptext layer="2" name="endtext" x=480 y=612 color=0x423852 time="0" size=32 text="END3　　「許婚もらっちゃうね」"]
[else]
[ptext layer="2" name="endtext" x=480 y=612 color=0x423852 time="0" size=32 text="END3　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.endT4==1"]
[ptext layer="2" name="endtext" x=480 y=672 color=0x423852 time="0" size=32 text="END4　　「”最高の夫婦”っすからね」"]
[else]
[ptext layer="2" name="endtext" x=480 y=672 color=0x423852 time="0" size=32 text="END4　　「　？　？　？　？　？　」"]
[endif]

[if exp="sf.compS==1 && sf.compT==1"]
[ptext layer="2" name="endtext" x=550 y=776 color=0x423852 time="0" size=35 text="相性１００％フルコンプリート"]
[else]
[ptext layer="2" name="endtext" x=550 y=776 color=0x423852 time="0" size=35 text="　？　？　？　？　？　？　？　"]
[endif]

[anim layer="2" name=endtext opacity=0 time=0]
[anim layer="2" name=endtext opacity=255 time=200]

[if exp="sf.endS4==1"]
	[if exp="sf.badge1==1"]
	[image layer="1" name="badgebuttonS" visible="true" storage="badgebutton2.png" x="1192" y="362" time="200" wait="false" zindex=1010]
	[else]
	[image layer="1" name="badgebuttonS" visible="true" storage="badgebutton1.png" x="1192" y="362" time="200" wait="false" zindex=1010]
	[endif]
[endif]

[if exp="sf.endT4==1"]
	[if exp="sf.badge2==1"]
	[image layer="1" name="badgebuttonT" visible="true" storage="badgebutton2.png" x="1192" y="657" time="200" wait="false" zindex=1010]
	[else]
	[image layer="1" name="badgebuttonT" visible="true" storage="badgebutton1.png" x="1192" y="657" time="200" wait="false" zindex=1010]
	[endif]
[endif]

[if exp="sf.compS==1 && sf.compT==1"]
	[if exp="sf.badge3==1"]
	[image layer="1" name="badgebuttonC" visible="true" storage="badgebutton2.png" x="1192" y="761" time="200" wait="false" zindex=1010]
	[else]
	[image layer="1" name="badgebuttonC" visible="true" storage="badgebutton1.png" x="1192" y="761" time="200" wait="false" zindex=1010]
	[endif]
[endif]

*return_badge

[cm]
[button graphic="config/c_btn_back.png" enterimg="config/c_btn_back2.png"  target="*backtitle" x=1380 y=40 ]


[if exp="sf.endS4==1"]
[button graphic="config/c_btn_back.png" enterimg="config/c_btn_back2.png"  target="*badge1" x=1192 y=362 width=238 height=66 ]
[endif]

[if exp="sf.endT4==1"]
[button graphic="config/c_btn_back.png" enterimg="config/c_btn_back2.png"  target="*badge2" x=1192 y=657 width=238 height=66 ]
[endif]

[if exp="sf.compS==1 && sf.compT==1"]
[button graphic="config/c_btn_back.png" enterimg="config/c_btn_back2.png"  target="*badge3" x=1192 y=761 width=238 height=66 ]
[endif]


[s]

*backtitle
[free layer="1" name="badgebuttonS" time=150 wait=false]
[free layer="1" name="badgebuttonT" time=150 wait=false]
[free layer="1" name="badgebuttonC" time=150 wait=false]
[free layer="2" name="endtext" time=200 wait=false]
[free layer="1" name="endlist" time=200 wait=true]
[jump  storage="title.ks"  target="*op"  ]
[s]

*badge1
[eval exp="sf.badge1=1"]
[give_emblem id="8091" pid="0ccd6d07b438c130a42dae915a9f40e3" ]
[free layer="1" name="badgebuttonS" time=0 wait=false]
[image layer="1" name="badgebuttonS" visible="true" storage="badgebutton2.png" x="1192" y="362" time="200" wait="false" zindex=1010]
[jump  storage="endlist.ks"  target="*return_badge"  ]
[s]

*badge2
[eval exp="sf.badge2=1"]
[give_emblem id="8092" pid="84951d5835c4f175bbd651cf6544cd4d" ]
[free layer="1" name="badgebuttonT" time=0 wait=false]
[image layer="1" name="badgebuttonT" visible="true" storage="badgebutton2.png" x="1192" y="657" time="200" wait="false" zindex=1010]
[jump  storage="endlist.ks"  target="*return_badge"  ]
[s]

*badge3
[eval exp="sf.badge3=1"]
[give_emblem id="8093" pid="cb1300290d6edc3524927b85e663cbfb" ]
[free layer="1" name="badgebuttonC" time=0 wait=false]
[image layer="1" name="badgebuttonC" visible="true" storage="badgebutton2.png" x="1192" y="761" time="200" wait="false" zindex=1010]
[jump  storage="endlist.ks"  target="*return_badge"  ]
[s]
