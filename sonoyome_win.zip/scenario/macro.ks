;このゲームで使用するマクロを宣言

;========キャラ名表示マクロ========
[macro name=sana]
[font color="0xF99800"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0xF99800" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#sana
[ruby text="（しらたにさな）" x=256 y=-28 scale=0.7]
[endmacro]

[macro name=sana_qes]
[font color="0xF99800"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0xF99800" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#sana
#？？？
;[ruby text="（しらたにさな）" x=256 y=-28 scale=0.7]
[endmacro]

[macro name=freesia]
[font color="0x761CE7"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x761CE7" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#freesia
[ruby text="（つつみふりーじあ）" x=280 y=-28 scale=0.7]
[endmacro]

[macro name=freesia_non]
[font color="0x761CE7"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x761CE7" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#freesia
;[ruby text="（つつみふりーじあ）" x=280 y=-28 scale=0.7]
[endmacro]

[macro name=freesia_qes]
[font color="0x761CE7"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x761CE7" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#freesia
#？？？
;[ruby text="（つつみふりーじあ）" x=280 y=-28 scale=0.7]
[endmacro]

[macro name=ayaka]
[font color="0xFF0020"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0xFF0020" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#ayaka
[ruby text="（ほんじょうあやか）" x=280 y=-28 scale=0.7]
[endmacro]

[macro name=ayaka_qes]
[font color="0xFF0020"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0xFF0020" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#ayaka
#？？？
;[ruby text="（ほんじょうあやか）" x=280 y=-28 scale=0.7]
[endmacro]

[macro name=akira]
[font color="0x003ABB"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x003ABB" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#akira
[ruby text="（さくらばあきら）" x=236 y=-28 scale=0.7]
[endmacro]

[macro name=hibiki]
[font color="0x00556E"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x00556E" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="1"]
#hibiki
[ruby text="（ぼうそうひびき）" x=236 y=-28 scale=0.7]
[endmacro]

[macro name=shima]
[font color="0xFF1B80"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0xFF1B80" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#shima
[ruby text="（おおつきしま）" x=257 y=-28 scale=0.7]
[endmacro]

[macro name=shima_qes]
[font color="0xFF1B80"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0xFF1B80" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#shima
#？？？
;[ruby text="（おおつきしま）" x=257 y=-28 scale=0.7]
[endmacro]

[macro name=ami]
[font color="0x00AB8A"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x00AB8A" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#ami
[endmacro]

[macro name=ami_qes]
[font color="0x00AB8A"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x00AB8A" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#ami
#？？？
[endmacro]

[macro name=ane]
[font color="0x986200"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x986200" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#ane
[ruby text="（さくらばりん）" x=225 y=-28 scale=0.7]
[endmacro]

[macro name=ane_qes]
[font color="0x986200"]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x986200" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
[stopse buf="2"]
#ane
#？？？
;[ruby text="（さくらばりん）" x=225 y=-28 scale=0.7]
[endmacro]

;========モノローグマクロ========
[macro name=none]
[stopse buf="1"]
[stopse buf="2"]
[resetfont ]
[free  name="chara_name_area" layer="message0"]
[ptext name="chara_name_area" layer="message0" color="0x423852" size=34 bold="false" x=357 y=659  face=""]
[chara_config ptext="chara_name_area"]
#
[endmacro]

;========アイキャッチマクロ========
[macro name=eyecatch]
[clickable width="1600" height="900" x=0 y=0 target="click"]
[eval exp="mp.ecbase = 'ecbase' + mp.echar + '.png'"]
[bg time="1000" wait="false" method="fadeIn" storage="&mp.ecbase"]
[wait time=400]

[playse buf="0" storage="se/eyecatch.mp3" ]

[eval exp="mp.ecname = 'eyecatch/ecname' + mp.echar + '.png'"]
[image name="ecname" time="0"  storage="&mp.ecname"  visible="true"  x="0"  y="0"  clickable_img=""  layer="2" zindex=1006]
[anim layer="2" name=ecname left=-300 opacity=0 time=0]
[anim layer="2" name=ecname left=0 opacity=255 time=1000]

[eval exp="mp.ecstand = 'eyecatch/ecstand' + mp.echar + '.png'"]
[image name="ecstand" time="0"  storage="&mp.ecstand"  visible="true"  x="0"  y="0"  clickable_img=""  layer="2" zindex=1005]
[anim layer="2" name=ecstand left=300 opacity=0 time=0]
[anim layer="2" name=ecstand left=0 opacity=255 time=1000]

[image name="eclogo" time="0"  storage="eyecatch/eclogo.png"  visible="true"  x="10"  y="579"  clickable_img=""  layer="2" zindex=1005]
[xanim name=eclogo keyframe=logo_rot time=1000 easing="cubic-bezier(.2,.72,.62,1)"]

[wait time=1300]

[eval exp="mp.ectitle = 'eyecatch/ectitle' + mp.estory + '.png'"]
[image name="ectitle" time="0"  storage="&mp.ectitle"  visible="true"  x="0"  y="0"  clickable_img=""  layer="2" zindex=1005]
[anim layer="2" name=ectitle opacity=0 time=0]
[anim layer="2" name=ectitle opacity=255 time=600]

[wait time=400]
[eval exp="mp.ecvoice = 'system/' + mp.echar + mp.evoice + '.mp3'"]
[playse buf="1" storage="&mp.ecvoice" ]

[wait time=3000]
[jump target="click"]
[s]
*click
[wait_cancel]
[cm]

[freeimage layer='2' time=480 wait=false]
[bg time="1000" wait="true" method="fadeIn" storage="VISUAL_BLACK.png"]

[endmacro]

/*
;========BGMマクロ========
;『OP』
[macro name=bgm00]
[playbgm  loop="true"  storage="00op.mp3" restart="false"]
[endmacro]
;『日常』
[macro name=bgm01]
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]
[endmacro]
;『落ち着いた日常』
[macro name=bgm02]
[playbgm  loop="true"  storage="02nitizyou_calm.mp3" sprite_time="22000-128666"  restart="false"]
[endmacro]
;『デートやウキウキ』
[macro name=bgm03]
[playbgm  loop="true"  storage="03date.mp3" sprite_time="14656-87938"  restart="false"]
[endmacro]
;『アプリを開いたBGM』
[macro name=bgm04]
[playbgm  loop="true"  storage="04app.mp3" sprite_time="22500-90000"  restart="false"]
[endmacro]
;『カッコいい・壮大・戦闘BGM』
[macro name=bgm05]
[playbgm  loop="true"  storage="05fiting.mp3" sprite_time="27042-108169"  restart="false"]
[endmacro]
;『ギャグ』
[macro name=bgm06]
[playbgm  loop="true"  storage="06gyagu.mp3" sprite_time="12799-76799"  restart="false"]
[endmacro]
;『シリアス』
[macro name=bgm07]
[playbgm  loop="true"  storage="07serious.mp3" sprite_time="32250-112250"  restart="false"]
[endmacro]
;『感動的・ロマンティック』
[macro name=bgm08]
[playbgm  loop="true"  storage="08romantic.mp3" sprite_time="22941-95294"  restart="false"]
[endmacro]
*/

;========選択肢マクロ========
/*
;////選択肢////
[macro name=select]
[image name="select0" time="100"  storage="dialog/sentaku_bg.png"  width="1600"  height="900"  x="0"  y="0"  clickable_img=""  layer="1" zindex=900 visible=true]
[image name="select1" layer="1" x="1600" y="250" width="900" height="130" storage="dialog/selectframe.png" clickable_img="" zindex=905 visible=true]
[image name="select2" layer="1" x="1600" y="450" width="900" height="130" storage="dialog/selectframe.png" clickable_img="" zindex=905 visible=true]
[ptext name="select1" layer="1" x="1600" y="296" width="900" align="center" text="%text1" color="" edge="3px 0xFFFFFF" size="34" bold="" face="" visible=true]
[ptext name="select2" layer="1" x="1600" y="496" width="900" align="center" text="%text2" color="" edge="3px 0xFFFFFF" size="34" bold="" face="" visible=true]
[anim  name="select1" time=0 opacity=0 ]
[anim  name="select2" time=0 opacity=0 ]
[anim name="select1" left="-=1250" time=250  opacity=255 ]
[wait time="250"]
[anim name="select2" left="-=1250" time=250  opacity=255 ]
[clickable  storage=""  x="350"  y="250"  width="900"  height="130"  target="%target1"  _clickable_img=""  ]
[clickable  storage=""  x="350"  y="450"  width="900"  height="130"  target="%target2"  _clickable_img=""  ]
[endmacro]
;////選択後////
[macro name=select1]
[playse  time="1000"  buf="1"  storage="se/decision5.mp3"   ]
[anim name="select0" time=500 opacity=0 ]
[anim name="select1" time=1500 opacity=0 ]
[anim name="select2" time=500 opacity=0 ]
[wa]
[free layer="1" name="select0" time=0]
[free layer="1" name="select1" time=0]
[free layer="1" name="select2" time=0]
[endmacro]

[macro name=select2]
[playse  time="1000"  buf="1"  storage="se/decision5.mp3"   ]
[anim name="select0" time=500 opacity=0 ]
[anim name="select1" time=500 opacity=0 ]
[anim name="select2" time=1500 opacity=0 ]
[wa]
[free layer="1" name="select0" time=0]
[free layer="1" name="select1" time=0]
[free layer="1" name="select2" time=0]
[endmacro]
*/

[return]