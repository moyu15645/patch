[preload storage="./data/bgm/00op.mp3"]

;////ロゴ表示////
[image name="title00" time="0"  storage="title00.png" visible="true" width="1600"  height="900"  x="0"  y="0"  clickable_img=""  layer="1" zindex=1005]
[image name="title00" time="0"  storage="title01.png" visible="true" width="1600"  height="900"  x="0"  y="0"  clickable_img=""  layer="1" zindex=1005]
[anim name="title00" time=0 opacity=0 ]
[anim name="title00" time=500  opacity=255 ]
;
[bg  time="500"  method="fadeIn"  storage="cg/cg01.jpg"  ]
[p]

;BGM再生
[playbgm  loop="true"  storage="00op.mp3" restart="false"]
;
;/////ロゴ削除////
[anim name="title00" time=600 opacity=0 ]
[bg  time="1000"  method="fadeIn"  storage="okotowari.jpg" wait=false  ]
[clickable target=wc width=1600 height=900 x=0 y=0]
[wait  time="4000"  ]
;
*wc
[cm]
[wait_cancel]

;///ロゴ完全消去///
[free layer="1" name="title00" time=0]
;
;////タイトル前処理終了///

[cm]
@clearstack
[image name="title00" time="1000" wait=false  storage="title01.png" visible="true" width="1600"  height="900"  x="0"  y="0"  clickable_img=""  layer="1" zindex=1005]
[image name="title00" time="1000" wait=false  storage="title03.png" visible="true" width="1600"  height="900"  x="0"  y="0"  clickable_img=""  layer="1" zindex=1005]
[bg  storage="cg/cg01.jpg"  cross="false"  time="1000"  ]
[cg storage="cg/cg01.jpg"]
@wait time = 200

*start 
[preload storage="data/bgm/08romantic.mp3" single_use="false"]
[preload storage="data/bgm/04app.mp3" single_use="false"]
[preload storage="data/sound/se/slidein.mp3" single_use="false"]
[preload storage="data/fgimage/sumartphone/sy_item01_01.png"]
[preload storage="data/fgimage/sumartphone/sy_item01_03.png"]
[preload storage="data/fgimage/sumartphone/sy_item01_04.png"]
[preload storage="data/video/opmv.mp4"]

*op
*cg
[button x=1359 y=375 graphic="title/button_start.png" enterimg="title/button_start2.png"  target="gamestart" keyfocus="1"]
[button x=1359 y=459 graphic="title/button_load.png" enterimg="title/button_load2.png" role="load" keyfocus="2"]
[button x=1359 y=543 graphic="title/button_config.png" enterimg="title/button_config2.png" role="sleepgame" storage="config.ks" keyfocus="3"]
[button x=1359 y=627 graphic="title/button_cg.png" enterimg="title/button_cg2.png" storage="cg.ks" keyfocus="4"]
[button x=1359 y=711 graphic="title/button_op.png" enterimg="title/button_op2.png" storage="op.ks" keyfocus="5"]
[button x=1359 y=795 graphic="title/button_end.png" enterimg="title/button_end2.png" storage="endlist.ks" keyfocus="6"]

[s]

*gamestart
;一番最初のシナリオファイルへジャンプする
;SE：決定
[playse buf="0" storage="se/decision5.mp3" ]
@jump storage="scene1.ks"

[s]
