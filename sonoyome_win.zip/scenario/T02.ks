*start
*freesia02
;第２節

;BGM再生
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]

;背景：屋上
[bg time="1000" wait="true" method="fadeIn" storage=BG_OKUJO_01B.jpg]

;メッセージウインドウ表示
[layopt layer=message0 visible=true ]
[layopt layer="fix" visible="false" ]
[anim layer="message0" opacity=0 time=0]
[anim layer="message0" opacity=255 time=500]
[layopt layer="fix" visible="true" ]
[wait time=350]

;ボイス設定
;[voconfig sebuf=1 name="sana" vostorage="_voice/sana/S0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="freesia" vostorage="_voice/freesia/T0{number}.mp3" number=201 ]
[voconfig sebuf=1 name="ayaka" vostorage="_voice/ayaka/H0{number}.mp3" number=318 ]
[voconfig sebuf=1 name="akira" vostorage="_voice/akira/X0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ami" vostorage="_voice/ami/A0{number}.mp3" number=101 ]
;[voconfig sebuf=2 name="hibiki" vostorage="_voice/hibiki/B0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="ane" vostorage="_voice/ane/L0{number}.mp3" number=137 ]
;[voconfig sebuf=1 name="shima" vostorage="_voice/shima/O0{number}.mp3" number=101 ]
[vostart]
[voice_repeat_on]

;イラスト：校長像
[image name="item"  wait=true  time="600"  storage="itemcg/sy_item06.png"  visible="true"  width="500"  height="500"  x="550"  y="110"  layer="2" zindex=1005]
[akira]
「校长，我被甩了」[p]
[none]
追着堤小姐最后还是被甩开了。[r]
一边喷着清漆一边对雕像说话。[p]
;イラスト削除
[free name="item" wait=true time=600 layer=2 ]
;CG02
[bg time="1000" wait="true" method="fadeIn" storage=cg/cg02_2.jpg]
;立ち絵：綾華
;[chara_part  name="ayaka"  face="ATJ"  body="A01" ]
;[chara_show  name="ayaka"  wait="true" time="600" left="300" top="80" width="1000"]
[ayaka]
「哟 雕刻部那个老好人樱庭君」[p]
;立ち絵：綾華
[akira]
「哇 本城同学！？」[p]
;立ち絵：移動
;[chara_move  name="ayaka" time="1000" anim="true" left="0" top="0" width="1600" height="2250" effect="easeInOutQuad"]
[ayaka]
「太惊喜了。又在这里见到你了」[p]
[akira]
「是啊，我也留在这所学校了」[p]
[ayaka]
「明明是值得高兴的重逢却一脸闷闷不乐。[r]
「该不会是被甩了吧？」[p]
[akira]
「怎么可能，没那回事啦？」[p]
[ayaka]
「哼～。看你慌慌张张逃出教室的样子，[r]
还以为肯定是被甩了呢」[p]
[akira]
「你都看见了？」[p]
[ayaka]
「从这儿全看见了。樱庭君，被人放鸽子了吧—」[p]
[akira]
「真的耶，教室里面看得一清二楚」[p]
[ayaka]
「还有从走廊一直偷看的金发小妹也。[r]
在那儿盯了快一小时呢」[p]
[akira]
「居然待了那么久。那孩子就是你的未婚妻堤小姐？」[p]
[ayaka]
「你说堤小姐？凭什么那丫头就天造地设，[r]
我却像垃圾一样不般配！？」[p]
[akira]
「虽然从外表看确实是个小太妹啦」[p]
[ayaka]
「那孩子真是小太妹？」[p]
[akira]
「诶，不是吗？」[p]
[none]
[bg time="200" wait="true" method="fadeIn" storage=cg/cg02_1.jpg]
[ayaka]
「哼～想当我的未婚夫就告诉你？」[p]
[akira]
「之前说过是恶作剧对吧？」[p]
[none]
;背景：屋上
[bg time="1000" wait="true" method="fadeIn" storage=BG_OKUJO_01B.jpg]
;フェイス：綾華
[chara_part  name="ayaka"  face="AAK"  body="A01" ]
[chara_show  name="ayaka"  wait="true" time="600" left="200" top="60" zindex="1000" width="1200"]
[xanim keyframe="kubihuri0" name="ayaka" count="2" time="400" easing="linear" direction=alternate]
[ayaka]
「要是被甩了随时可以来找我哦」[p]
[none]
[xanim keyframe="run_left0" name="ayaka" count="1" time="800" easing="linear" ]
;SE：扉を閉める音
[playse buf="0" storage="se/ss08_door.mp3" ]
[akira]
「什么意思？……走掉了」[p]
[akira]
（被甩的事完全暴露了。为什么堤小姐会[r]
躲了整整一小时呢）[p]
[none]
我怀着烦闷的心情，把雕像搬到通风处[r]
结束了今天的工作。[p]
[none]
;SE：歩く音(屋上・屋外)
[playse buf="0" storage="se/walk.mp3" ]
;キャラ削除
[chara_hide  name="ayaka"  wait="true"  time="5" ]
;BGM：停止
[fadeoutbgm time="1000"]
[wait time=1000]
;フェイス：堤
[chara_part  name="freesia"  face="AOD"  body="A01" acce="none"]
[chara_show  name="freesia"  wait="true" time="600" left="-385" top="560" layer="message0" zindex="1000" width="1100"]
[freesia]
「臭味是从这附近……哇靠这造型也太生猛了吧！？」[p]
[chara_part  name="freesia"  face="AKK"  ]
[freesia]
「边缘处理干净利落，表面处理也毫无瑕疵！」[p]
[chara_part  name="freesia"  face="ADY"  ]
[freesia]
「……这学校肯定藏着造型社团吧」[p]
[none]
[chara_hide_all  wait="true"  time="600"  layer="message0"]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[wait time="500"]
;BGM再生
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]
;背景：リビング
[bg time="1000" wait="false" method="fadeIn" storage=BG_LIVING_02A.jpg]
[wait time="500"]
[akira]
「我回来了」[p]
[none]
#haha
「欢迎回家。那个未婚妻孩子怎么样！？」[p]
[akira]
（要是说那种野丫头类型的话老妈会暴走吧[r]
何况还被甩了）[p]
[akira]
「堤小姐。是个很可爱的人」[p]
[none]
#haha
「进展顺利吗！？」[p]
[akira]
「唔～很难说呢？」[p]
[none]
#haha
「难道是个品行不好的孩子！？」[p]
[akira]
（不愧是妈妈，真敏锐啊）[p]
[akira]
「可能有点难相处的感觉吧？」[p]
[none]
#haha
「呵呵，优等生诚也会为恋爱发愁呢」[p]
[akira]
「女孩子的事情我完全搞不懂啊」[p]
[akira]
（堤小姐也好本城小姐也好，说实话她们在想什么[r]
完全搞不明白呢……）[p]
[none]
#haha
「有什么烦恼都可以和妈妈说哦」[p]
[akira]
「嗯，谢谢！」[p]
[none]
#haha
「但像姐姐那样整天宅在家里的生活方式，[r]
我可完全无法理解呢」[p]
[none]
[fadeoutbgm time="1000"]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[wait time="500"]
;BGM再生
[playbgm  loop="true"  storage="02nitizyou_calm.mp3" sprite_time="22000-128666"  restart="false"]
;背景：玄関
[bg time="1000" wait="false" method="fadeIn" storage=BG_JITAKUGENKAN_01A.jpg]
[wait time="500"]
;立ち絵：姉
[chara_part  name="ane"  face="ATJ"  body="A01" ]
[chara_show  name="ane"  wait="true" time="600" left="175" top="30" width="1250"]
[ane]
「……」[p]
[akira]
「哇，老姐」[p]
[none]
突然出现的是姐姐樱庭凛。从高中辍学直到现在26岁，[r]
一直过着家里蹲的生活。[p]
[akira]
「刚才的对话……你都听到了？」[p]
[xanim keyframe="unazuki0" name="ane" count="1" time="400" easing="linear" ]
[ane]
「嗯」[p]
[none]
[xanim keyframe="run_left0" name="ane" count="1" time="800" easing="linear" ]
;SE：扉が閉まる音
[playse buf="0" storage="se/ss17_door.mp3" ]
[akira]
（好尴尬……上次听到她的声音是几年前的事了）[p]
[none]
[eval exp="f.loveT-=1"]
[vostop]
[fadeoutse buf="0"  time="1000"  ]
;キャラ削除
[chara_hide_all  wait="true"  time="5"  ]

;////メッセージウィンドウ削除////
[anim layer="message0" opacity=255 time=0]
[anim layer="message0" opacity=0 time=500]
[wait time=50]
[layopt layer="fix" visible="false" ]
[wait time=450]
[voice_repeat_clear]
[cm]
;
;BGM停止
[fadeoutbgm  time="1000"  ]
;
;背景：削除
[bg  time="1000" wait="true" method="fadeIn"  storage="VISUAL_BLACK.png"  ]
[wait time="500"]

;アイキャッチ
[eyecatch echar="F" estory="F03" evoice="1"]

[jump storage="T03.ks" target="start"]
[s]
