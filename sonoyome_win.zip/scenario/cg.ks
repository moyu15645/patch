;=========================================
; CG モード　画面作成
;=========================================

@layopt layer=message0 visible=false

@clearfix
[hidemenubutton]
[cm]

[image layer=2 name="cgmode" visible=true left=0 top=0 storage="config/cgmode.png" folder="image" zindex=1006]

[iscript]
    
    tf.page = 0;
    tf.selected_cg_image = ""; //選択されたCGを一時的に保管
    
[endscript]

*cgpage
[layopt layer=1 visible=true]
[layopt layer=2 visible=true]
[bg  storage="cg/cg01.jpg"  cross="false"  time="5" wait=false ]


[cm]
[button graphic="config/c_btn_back.png" enterimg="config/c_btn_back2.png"  target="*backtitle" x=1380 y=40 ]

[iscript]
    tf.tmp_index = 0;
    tf.cg_index = 12 * tf.page;
    tf.top = 100;
    tf.left = 60;
    
[endscript]

[iscript]
	tf.target_page = "page_"+tf.page;
[endscript]

*cgview
@jump target=&tf.target_page

*page_0
[cg_image_button graphic="cg/cg01.jpg"  x=64 y=209 width=468 height=264 no_graphic="../image/BlankChip.png" folder="bgimage"]
[cg_image_button graphic="cg/cg02_2.jpg,cg/cg02_1.jpg,cg/cg02_4.jpg,cg/cg02_3.jpg"   no_graphic="../image/BlankChip.png"  x=566 y=209 width=468 height=264 folder="bgimage"]
[cg_image_button graphic="cg/cg03_1TJ.jpg,cg/cg03_2TJ.jpg,cg/cg03_2EG.jpg,cg/cg03_2SK.jpg" no_graphic="../image/BlankChip.png"  x=1068 y=209 width=468 height=264 folder="bgimage"]
[cg_image_button graphic="cg/cg04_1TJ.jpg,cg/cg04_2TJ.jpg,cg/cg04_2OD.jpg,cg/cg04_2EG.jpg" no_graphic="../image/BlankChip.png"  x=320 y=521 width=468 height=264 folder="bgimage"]
[cg_image_button graphic="cg/cg05_TJ.jpg,cg/cg05_EG.jpg,cg/cg05_IK.jpg,cg/cg05_DY.jpg"  no_graphic="../image/BlankChip.png"  x=824 y=521 width=468 height=264 folder="bgimage"]

@jump target="*common"

*common


*endpage



[s]

*backtitle
[cm]
[free layer=2 name="cgmode" time=200]
@clearstack
[jump storage="title.ks" target="*cg"]

*nextpage
[emb exp="tf.page++;"]
@jump target="*cgpage"


*backpage
[emb exp="tf.page--;"]
@jump target="*cgpage"

*clickcg
[cm]

[layopt layer=1 visible=false]
[layopt layer=2 visible=false]
[eval exp="tf.cg_index=0"]

*cg_next_image

[image storage=&tf.selected_cg_image[tf.cg_index] folder="bgimage"  ]
[l]

[eval exp="tf.cg_index++"]

@jump target="cg_next_image" cond="tf.selected_cg_image.length > tf.cg_index"


@jump  target=*cgpage
[s]

*no_image

@jump  target=*cgpage



