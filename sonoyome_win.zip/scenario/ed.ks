[skipstop  ]
[stop_keyconfig]
;
;プリロードロケーション1
[preload storage="./data/bgimage/BG_SCHOOLROUKA_01A.jpg"]
;
[image name="stuff_lay" time="0"  storage="../bgimage/VISUAL_BLACK.png"  width=""  height=""  x="975"  y="0"  clickable_img=""  layer="2" zindex=1020 visible="true"]
[image name="stuff_list" time="0"  storage="stuff_list.png"  width=""  height=""  x="1053"  y="900"  clickable_img=""  layer="2" zindex=1030]
[wait time="500"]
;
;スタッフロール
[anim name="stuff_list" top="-=6778" time=70000 opacity=255 effect="linear" wait="false"]
[image name="staff_back" time="0"  storage="../bgimage/VISUAL_BLACK.png"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1020  wait="false"]
[anim name="staff_back"  time=2500  opacity=0]
;
;
;プリロードロケーション2
[preload storage="./data/bgimage/BG_KYOSHITSU_01A.jpg"]
;
;ロケーション1
[image name="ed_back1" time="0"  storage="../bgimage/BG_SCHOOLROUKA_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1018 wait="false"]
[anim name="ed_back1" left="-=500" time=10000  opacity=255 effect="linear"]
[wait time=10000]
[anim name="ed_back1" left="-=50" time=1000  opacity=0 effect="linear"]
;
;
;プリロードロケーション3
[preload storage="./data/bgimage/BG_SCHOOLGENKAN_01A.jpg"]
;
;ロケーション2
[image name="ed_back2" time="0"  storage="../bgimage/BG_KYOSHITSU_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1017 wait="false"]
[anim name="ed_back2" left="-=563" time=10000  opacity=255 effect="linear"]
[wait time=10000]
[anim name="ed_back2" left="-=50" time=1000  opacity=0 effect="linear" wait="false"]
[free layer="2" name="stuff_black" time="0"]
;
;
;プリロードロケーション4
[preload storage="./data/bgimage/BG_TAIIKUKAN_01A.jpg"]
;
;ロケーション3
[image name="ed_back3" time="0"  storage="../bgimage/BG_SCHOOLGENKAN_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1016 wait="false"]
[anim name="ed_back3" left="-=563" time=10000  opacity=255 effect="linear"]
[wait time=10000]
[anim name="ed_back3" left="-=50" time=1000  opacity=0 effect="linear" wait="false"]
[free layer="2" name="ed_back1" time="0"]
;
;
;プリロードロケーション5
[preload storage="./data/bgimage/BG_CAFE_01A.jpg"]
;
;ロケーション4
[image name="ed_back4" time="0"  storage="../bgimage/BG_TAIIKUKAN_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1015 wait="false"]
[anim name="ed_back4" left="-=563" time=10000  opacity=255 effect="linear"]
[wait time=10000]
[anim name="ed_back4" left="-=50" time=1000  opacity=0 effect="linear" wait="false"]
[free layer="2" name="ed_back2" time="0"]
;
;
;プリロードロケーション6
[preload storage="./data/bgimage/BG_BUSHITSU_01A.jpg"]
;
;ロケーション5
[image name="ed_back5" time="0"  storage="../bgimage/BG_CAFE_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1014 wait="false"]
[anim name="ed_back5" left="-=563" time=10000  opacity=255 effect="linear"]
[wait time=10000]
[anim name="ed_back5" left="-=50" time=1000  opacity=0 effect="linear" wait="false"]
[free layer="2" name="ed_back3" time="0"]
;
;
;プリロードロケーション7
[preload storage="./data/bgimage/BG_OKUJO_01A.jpg"]
;
;ロケーション6
[image name="ed_back6" time="0"  storage="../bgimage/BG_BUSHITSU_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1013 wait="false"]
[anim name="ed_back6" left="-=563" time=10000  opacity=255 effect="linear"]
[wait time=10000]
[anim name="ed_back6" left="-=50" time=1000  opacity=0 effect="linear" wait="false"]
[free layer="2" name="ed_back4" time="0"]
;
;
;ロケーション7
[image name="ed_back7" time="0"  storage="../bgimage/BG_OKUJO_01A.jpg"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=1012 wait="false"]
[anim name="ed_back7" left="-=500" time=10000  opacity=255 effect="linear"]
[wait time=12000]
[free layer="2" name="ed_back5" time="0"]
;
;
[image name="ed_black" time="1000"  storage="../bgimage/VISUAL_BLACK.png"  width=""  height=""  x="0"  y="0"  clickable_img=""  layer="2" zindex=10121 wait="true"]
[wait time=10]
[bg time="0" wait="true" method="fadeIn" storage="VISUAL_BLACK.png"]
[wait time=10]
[freeimage layer="2"  time="0"  wait="false"]
;
[start_keyconfig  ]
[return]
