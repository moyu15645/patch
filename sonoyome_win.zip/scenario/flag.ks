;このゲームで使用するフラグを初期化

;選択肢フラグ
[eval exp="f.S2=0"]
[eval exp="f.S4=0"]

;好感度フラグ
[eval exp="f.loveS=70"]
[eval exp="f.loveT=70"]

;スマートフォンステータス
[eval exp="f.sp=[1,1,0,0,0,0,0,0,0,0]"]

;ルート分岐フラグ
[eval exp="f.ansS=0"]
[eval exp="f.ansT=0"]

[return]