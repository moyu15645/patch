*start
*freesia08
;第８節

;BGM再生
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]

;背景：玄関(自宅)
[bg time="1000" wait="true" method="fadeIn" storage=BG_JITAKUGENKAN_01A.jpg]

;メッセージウインドウ表示
[layopt layer=message0 visible=true ]
[layopt layer="fix" visible="false" ]
[anim layer="message0" opacity=0 time=0]
[anim layer="message0" opacity=255 time=500]
[layopt layer="fix" visible="true" ]
[wait time=350]

;ボイス設定
;[voconfig sebuf=1 name="sana" vostorage="_voice/sana/S0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="freesia" vostorage="_voice/freesia/T0{number}.mp3" number=405 ]
;[voconfig sebuf=1 name="ayaka" vostorage="_voice/ayaka/H0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="akira" vostorage="_voice/akira/X0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ami" vostorage="_voice/ami/A0{number}.mp3" number=101 ]
;[voconfig sebuf=2 name="hibiki" vostorage="_voice/hibiki/B0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ane" vostorage="_voice/ane/L0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="shima" vostorage="_voice/shima/O0{number}.mp3" number=101 ]
[vostart]
[voice_repeat_on]

;立ち絵：堤
[chara_part  name="freesia"  face="ATJ"  body="A02"   acce="A00"]
[chara_show  name="freesia"  wait="true" time="600" left="200" top="50" width="1200"]
堤小姐过来打招呼。两小时前去接她，但和母亲的约定还是[r]
迟到了三十分钟。[p]
;BGM再生
[playbgm  loop="true"  storage="06gyagu.mp3" sprite_time="12799-76799"  restart="false"]
#haha
「「请进……你这头发是什么颜色啊！！」[p]
[chara_part  name="freesia"  face="ADY"  ]
[xanim keyframe="unazuki0" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「「呃」[p]
[none]
#haha
「「你该不会是小混混吧？」[p]
[akira]
「「虽然容易让人误会但不是啦！」[p]
[chara_part  name="freesia"  face="ATJ"  ]
[xanim keyframe="unazuki0" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「「不好意思」[p]
[none]
#haha
「「既然是学生就希望你把发色染回来」[p]
[akira]
「总站在玄关说话怪怪的，去客厅吧！」[p]
[none]
#haha
「是吗？妈妈可不想让不良少年进家门呢」[p]
[chara_part  name="freesia"  face="AAK"  ]
[xanim keyframe="kubihuri0" name="freesia" count="2" time="400" easing="linear" direction=alternate]
[freesia]
「不是的，我只是个家里蹲……」[p]
[akira]
「总之先去客厅再说！！」[p]
[akira]
（简直一团糟。我的伴侣制度恐怕今天就要[r]
完蛋了……）[p]
[none]
;キャラ削除
[chara_hide_all  wait="true"  time="600"  ]
[fadeoutbgm time=1000]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[wait time="500"]
;BGM再生
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]
;背景：リビング
[bg time="1000" wait="false" method="fadeIn" storage=BG_LIVING_01A.jpg]
[wait time="500"]
;イラスト：高級そうなケーキと紅茶
[image name="item"  wait=false  time="600"  storage="itemcg/sy_item10.png"  visible="true"  width="500"  height="500"  x="75"  y="110"  layer="2" zindex=1005]
[playse buf="0" storage="se/z015saraoku.mp3" ]
;立ち絵：堤
[chara_part  name="freesia"  face="ATJ"  body="A02" ]
[chara_show  name="freesia"  wait="true" time="600" left="0" top="0" width="1600"]
#haha
「这是在超人气店铺买的。不预约都买不到哦」[p]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「太感谢了」[p]
[none]
桌上摆满了看似高级的蛋糕和红茶。但堤小姐却[r]
对食物毫无兴趣，完全没有动刀叉。[p]
[none]
;イラスト削除
[free name="item" wait=true time=600 layer=2 ]
#haha
「妈妈，果然还是应该让堤小姐辞职比较好吧……」[p]
[akira]
「别放弃嘛，再听听她怎么说？堤小姐来自我介绍一下」[p]
[chara_part  name="freesia"  face="AAK"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「呃、部长……叫什么来着……堤」[p]
[akira]
（为什么记不住我的名字啊！？）[p]
[none]
#haha
「堤小姐的名字是什么呢？高节……」[p]
[chara_part  name="freesia"  face="ATJ"  ]
[xanim keyframe="bikkuriA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「小苍兰」[p]
[none]
#haha
「这名字就叫小苍兰！？这种不是所谓的闪亮名字[r]
吗？」[p]
[akira]
（妈妈的反应和我如出一辙）[p]
[chara_part  name="freesia"  face="ADY"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「失礼了」[p]
[none]
#haha
「果然还是让人不安啊……转学前是哪所学校的？」[p]
[akira]
（这个我也没问过。不过我觉得是哪所学校[r]
并不重要）[p]
[chara_part  name="freesia"  face="ATJ"  ]
[freesia]
「私立玛丽亚学院」[p]
[akira]
（私立玛丽亚学院！？那不是县内学费最贵的地方[r]
吗！？）[p]
[none]
#haha
「不是县内学费最贵的地方吗！？」[p]
[akira]
（果然会这么想呢）[p]
[chara_part  name="freesia"  face="ADY"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「实在不好意思」[p]
[none]
#haha
「能让您花这么多钱，您父母是从事什么工作的？」[p]
[chara_part  name="freesia"  face="ATJ"  ]
[freesia]
「那个，那边放着的那个」[p]
[none]
堤小姐的注意力从母亲的话题转移，指向了电视机旁的架子。[p]
[none]
#haha
「什么东西……？」[p]
[none]
指尖所指的正是大河剧『清正记』的蓝光收藏版。[p]
[freesia]
「喜欢清正公吗？」[p]
[none]
#haha
「诶？是呀？现在正在播我每周都看呢」[p]
[chara_part  name="freesia"  face="AEG2"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「我也超喜欢的」[p]
[none]
#haha
「小堤你也看这个！？」[p]
[chara_part  name="freesia"  face="ATJ"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「嗯。原本就选修过相关课程。贱岳七本枪之类的人名[r]
都能背出来」[p]
[akira]
（懂得真多啊。这内容教科书上几乎都没记载）[p]
[none]
#haha
「真的吗！？关原之战特别帅对吧～妈妈[r]
超喜欢的」[p]
[chara_part  name="freesia"  face="ADY"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「关原之战可是连敌我都公认的杰出战役呢。虽然文禄之役也[r]
让人难以割舍就是了」[p]
[akira]
（太厉害了，居然能跟上喜欢大河剧的妈妈的话题！）[p]
[none]
#haha
「那个文禄之役啊，为什么清正公的功绩[r]
没被认可呢？」[p]
[chara_part  name="freesia"  face="AEG2"  ]
[xanim keyframe="bikkuriA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「这其中可是有各种复杂背景的呀～」[p]
[akira]
（非但没穿帮还在给她科普！？）[p]
[none]
[chara_part  name="freesia"  face="AKK"  ]
之后堤小姐和母亲继续热烈讨论着武将话题。[r]
我完全插不上话被晾在一边。[p]
[none]
#haha
「香雪兰懂得真多呢，聊起来特别开心」[p]
[chara_part  name="freesia"  face="ADY"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「您过奖了」[p]
[akira]
（虽然一度以为要露馅，没想到靠意外特长蒙混过去了）[p]
[none]
;BGM：停止
[stopbgm]
#haha
「既然学识如此渊博，想必令尊令堂[r]
「您说呢？」[p]
[akira]
（这是道送命题啊。我妈妈满意的[r]
答案根本……）[p]
[none]
;BGM再生
[playbgm  loop="true"  storage="06gyagu.mp3" sprite_time="12799-76799"  restart="false"]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[chara_part  name="freesia"  face="ATJ"  ]
[freesia]
「爸爸是议员，妈妈是议员秘书」[p]
[akira]
「诶？」[p]
[none]
#haha
「议员……难道是堤义彦先生？」[p]
[chara_part  name="freesia"  face="AIK"  ]
[xanim keyframe="bikkuriA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「对呀，你居然知道我爸名字呢」[p]
[none]
#haha
「什么叫知道！他可是县议会议员啊！？」[p]
[akira]
（这种事倒是早点说啊！！）[p]
[none]
母亲最吃头衔这一套。要是早报出这个名字，开场就该是简单模式[r]
才对。[p]
[chara_part  name="freesia"  face="AAK"  ]
[xanim keyframe="kubihuriA" name="freesia" count="2" time="400" easing="linear" direction=alternate]
[freesia]
「不过，这和父母没关系」[p]
[none]
#haha
「真是谦虚的好孩子呢～！」[p]
[akira]
（妈妈已经站到辩护方了。不过议员家的千金，哪个家长会[r]
怠慢呢）[p]
[chara_part  name="freesia"  face="ATJ"  ]
[xanim keyframe="unazukiA" name="freesia" count="1" time="800" easing="linear" ]
[freesia]
「不敢当」[p]
[none]
[bg time="1000" wait="false" method="fadeIn" storage=BG_LIVING_02A.jpg]
随后持续着诡异般的和谐氛围，[r]
寒暄总算平安结束了。[p]

[eval exp="f.sp=[1,26,15,0,0,1,1,1,2,1]"]

;キャラ削除
[chara_hide_all  wait="true"  time="600"  ]
[fadeoutbgm time=1000]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[wait time="500"]
;BGM再生
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]
;背景：玄関(自宅)
[bg time="1000" wait="false" method="fadeIn" storage=BG_JITAKUGENKAN_01A.jpg]
[wait time="500"]
;立ち絵：堤
[chara_part  name="freesia"  face="ATJ"  body="A02" ]
[chara_show  name="freesia"  wait="true" time="600" left="200" top="50" width="1200"]
#haha
「随时欢迎再来哦，我们要好好聊个痛快」[p]
[chara_part  name="freesia"  face="AEG2"  ]
[xanim keyframe="bikkuriA" name="freesia" count="1" time="400" easing="linear" ]
[freesia]
「好！」[p]
[none]
[eval exp="f.loveT+=1"]
[vostop]
;SE：扉を閉める音
[playse buf="0" storage="se/ss08_door.mp3" ]
;キャラ削除
[chara_hide_all  wait="true"  time="600"  ]

;////メッセージウィンドウ削除////
[anim layer="message0" opacity=255 time=0]
[anim layer="message0" opacity=0 time=500]
[wait time=50]
[layopt layer="fix" visible="false" ]
[wait time=450]
[voice_repeat_clear]
[cm]
;
;BGM停止
[fadeoutbgm  time="1000"  ]
;
;背景：削除
[bg  time="1000" wait="true" method="fadeIn"  storage="VISUAL_BLACK.png"  ]
[wait time="500"]

;アイキャッチ
[eyecatch echar="F" estory="F09" evoice="2"]

[jump storage="T09.ks" target="start"]
[s]
