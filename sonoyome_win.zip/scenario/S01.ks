*start
*sana01
;第１節

;BGM再生
[playbgm  loop="true"  storage="01nitizyou.mp3" sprite_time="7384-88615"  restart="false"]

;背景：リビング
[bg time="1000" wait="true" method="fadeIn" storage=BG_LIVING_01A.jpg]

;メッセージウインドウ表示
[layopt layer=message0 visible=true ]
[layopt layer="fix" visible="false" ]
[anim layer="message0" opacity=0 time=0]
[anim layer="message0" opacity=255 time=500]
[layopt layer="fix" visible="true" ]
[wait time=350]

;ボイス設定
[voconfig sebuf=1 name="sana" vostorage="_voice/sana/S0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="freesia" vostorage="_voice/freesia/T0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ayaka" vostorage="_voice/ayaka/H0{number}.mp3" number=101 ]
[voconfig sebuf=1 name="akira" vostorage="_voice/akira/X0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="ami" vostorage="_voice/ami/A0{number}.mp3" number=101 ]
[voconfig sebuf=2 name="hibiki" vostorage="_voice/hibiki/B0{number}.mp3" number=126 ]
;[voconfig sebuf=1 name="ane" vostorage="_voice/ane/L0{number}.mp3" number=101 ]
;[voconfig sebuf=1 name="shima" vostorage="_voice/shima/O0{number}.mp3" number=101 ]
[vostart]
[voice_repeat_on]

[none]
#haha
「首先给我好好打招呼」[p]
[akira]
「嗯没问题！」[p]
[none]
今天终于是正式见面的日子。虽然开学典礼在明天[r]
二年级生需要提前一天到校。[p]
[none]
#haha
「仪表整理好了吗？室内鞋之类的没落下东西吧？」[p]
[akira]
「都准备妥当啦」[p]
[none]
#haha
「接下来……」[p]
[none]
#titi
「诚已经不是小孩子了。妈妈你也该[r]
行吧」[p]
[none]
#haha
「就这种时候瞎操心。那孩子的事你什么都没[r]
管过」[p]
[none]
#titi
「知道啦」[p]
[none]
#haha
「诚是好孩子，和未婚妻家孩子也能处好吧？」[p]
[akira]
「嗯，我会尽力而为的」[p]
[none]
#haha
「这才像我的孩子。早点定下来[r]
好专心准备高考嘛」[p]
[none]
#titi
「妈妈！」[p]
[none]
#haha
「现在只能靠诚了。路上小心」[p]
[none]
;SE：扉を閉める音
[playse buf="0" storage="se/ss17_door.mp3" ]
;背景：自宅前
[bg time="1000" wait="false" method="fadeIn" storage=BG_JITAKUMAE_01A.jpg]
[akira]
「我出门了」[p]
[none]
;SE：歩く音(屋上・屋外)
[playse buf="0" storage="se/walk.mp3" ]
我带着沉重的负担感走出家门。[p]
;背景：通学路
[bg time="1000" wait="true" method="fadeIn" storage=BG_KOUTEI_01A.jpg]
但随着学校越来越近，脚步却逐渐轻快起来。[p]
[akira]
「最适合我的未婚妻会是什么样的人呢」[p]
[none]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[wait time="500"]
;背景：廊下(学校)
[bg time="1000" wait="false" method="fadeIn" storage=BG_SCHOOLROUKA_01A.jpg]
[wait time="500"]
;立ち絵：響
[chara_part  name="hibiki"  face="AEG"  body="A02" ]
[chara_show  name="hibiki"  wait="true" time="600" left="175" top="-10" layer="0" zindex="1" width="1250"]
[hibiki]
「新学期也请多关照啊搭档！」[p]
[akira]
「虽然分班了但还是请多关照啦」[p]
[chara_part  name="hibiki"  face="ATJ" ]
[hibiki]
「那我也去相亲了。未婚妻还在等着呢」[p]
[akira]
「嗯，我们一起加油吧！」[p]
[xanim keyframe="bikkuriA" name="hibiki" count="1" time="400" easing="linear" ]
[chara_part  name="hibiki"  face="AEG2" ]
[hibiki]
「噢！一起成为恋爱高手吧！」[p]
[none]
;SE：ハイタッチ
[playse buf="0" storage="se/HandFoleyClap011(Dry).mp3" ]
[xanim keyframe="run_left0" name="hibiki" count="1" time="800" easing="linear" ]
击掌之后，响重新背起吉他盒，[r]
意气风发地离开了。[p]
;キャラ削除
[chara_hide_all  wait="true"  time="5"  ]
[akira]
（好，我也要加油！）[p]
[none]
;背景：暗転
[bg time="1000" wait="true" method="fadeIn" storage=VISUAL_BLACK.png]
[wait time="500"]
;背景：教室
[bg time="1000" wait="false" method="fadeIn" storage=BG_KYOSHITSU_01A.jpg]
[wait time="500"]
教室里已经聚集了约半数的学生。[r]
整个空间弥漫着躁动不安的气氛。[p]
我也坐不住了，决定在教室后面等着。[p]
[akira]
（究竟是什么样的女孩呢）[p]
[none]
;BGM停止
[stopbgm]
;SE：扉が開く音
[playse buf="0" storage="se/z007dooropen.mp3" ]
[sana_qes]
「早上好！」[p]
;名前表示は？？？
[none]
;BGM再生
[playbgm  loop="true"  storage="03date.mp3" sprite_time="14656-87938"  restart="false"]
一声明快的问候响起，瞬间改变了教室的氛围。[p]
;立ち絵：彩永
[chara_part  name="sana"  face="ATJ"  body="A01" ]
[chara_show  name="sana"  wait="true" time="1000" left="200" top="80" width="1200"]
[sana_qes]
「樱庭诚同学在吗」[p]
;名前表示は？？？
[none]
其他男生听到叫的不是自己名字，纷纷垂头丧气。[p]
[akira]
「到，是我！」[p]
[akira]
（这么可爱的女孩居然是我的未婚妻！？）[p]
[akira]
「初次见面，我是樱庭诚」[p]
[stopse buf="0"]
[xanim keyframe="unazuki0" name="sana" count="1" time="800" easing="linear" ]
[chara_part  name="sana"  face="AEG"  ]
[sana_qes]
「呵呵，初次见面」[p]
;名前表示は？？？
[none]
但我立刻感到了违和感。右手握着的白色手杖毫无生气，[r]
空洞无神的双眸。这孩子该不会是——[p]
;BGM：停止
[stopbgm]
[chara_part  name="sana"  face="ATJ"  ]
[sana]
「我是白谷彩永，从盲校来的。我全盲，看不见东西」[p]
[none]
她就是与我天造地设的未婚妻。[p]
[xanim keyframe="unazuki0" name="sana" count="1" time="800" easing="linear" ]
[chara_part  name="sana"  face="AEG2"  ]
[sana]
「虽然笨手笨脚的，还请您多多指教。樱庭先生」[p]
[none]
[eval exp="f.loveS+=1"]
[eval exp="f.sp=[1,26,1,0,0,1,1,1,1,1]"]
[vostop]

;キャラ削除
[chara_hide_all  wait="false"  time="900"  ]

;////メッセージウィンドウ削除////
[anim layer="message0" opacity=255 time=0]
[anim layer="message0" opacity=0 time=900]
;[wait time=50]
[layopt layer="fix" visible="false" ]
;[wait time=450]
[voice_repeat_clear]
[cm]
;
;BGM停止
[fadeoutbgm  time="1000"  ]
;
;背景：削除
[bg  time="1500" wait="true" method="fadeIn"  storage="VISUAL_BLACK.png"  ]

;OP
[movie  volume="6"  storage="opmv.mp4"  skip="true"  ]

[jump storage="S02.ks" target="start"]
[s]
